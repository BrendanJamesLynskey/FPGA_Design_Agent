
## models by role (profile single)

clarify: claude_code claude-sonnet-5-5 (medium); model: claude_code claude-sonnet-5-5 (medium); tests: claude_code claude-sonnet-5-5 (medium); rtl: claude_code claude-sonnet-5-5 (medium). Interview oracle: openai/gpt-6-luna (fixed). The stage machine is plain code.

<!-- who-did-what:start -->
## Who did what

| # | who | stage | what | detail |
|---|---|---|---|---|
| 1 | agent | clarify | stage 0 work, visit 1 | 5 files in the design |
| 2 | agent | clarify | stage 0 work, visit 2 | 5 files in the design |
| 3 | auto | clarify | interview | answered: What is the register map (offset, width, reset value and access of every register) of the test shell? -> BUSY: offset 0x07, RO, reset 0: [0] a packet is part-way CTR_GOOD..CTR_PROTO: of |
| 4 | auto | clarify | interview | answered: What is TIMEOUT_CYCLES and what happens on timeout? -> TIMEOUT_CYCLES is 100000 cycles, not 100000000 as proposed. The specification do |
| 5 | auto | clarify | interview | answered: Is the class code for 'not new' one class, or are repeat and out of order separate? -> Not one class. Repeat (RESULT 5, counter 0x14) and stale (RESULT 6, counter 0x15 |
| 6 | auto | clarify | interview | answered: Are the class codes as proposed (0 none, 1 too long, 2 too short, 3 bad check, 4 unknown, 5 not new, 6 good)? -> No. The specification lists the class codes as 0 none, 1 good, 2 bad check, 3 sh |
| 7 | auto | clarify | interview | answered: Is a packet with a zero-byte body or only the end flag byte counted as too short? -> Yes. A packet that ends before 4 bytes is classed SHORT (3), so a packet holding |
| 8 | auto | clarify | interview | defaulted: Do the type, sequence and payload registers keep the last good packet or the last packet of any class? -> Last good packet only. |
| 9 | auto | clarify | interview | defaulted: What is the BUILD_STAMP value? -> 0, to be set by the build. |
| 10 | auto | clarify | approved (review off) |  |
| 11 | agent | board-and-device-planning | stage 1 work, visit 1 | 7 files in the design |
| 12 | agent | board-and-device-planning | stage 1 work, visit 2 | 8 files in the design |
| 13 | auto | board-and-device-planning | approved (review off) |  |
| 14 | auto | board-and-device-planning | architecture approved | source: agent |
| 15 | agent | rtl-design-creation | stage 2 work, visit 1 | 17 files in the design |
| 16 | agent | rtl-design-creation | stage 2 work, visit 2 | 17 files in the design |
| 17 | agent | rtl-design-creation | stage 2 work, visit 3 | 17 files in the design |
| 18 | agent | rtl-design-creation | stage 2 work, visit 4 | 17 files in the design |
| 19 | agent | rtl-design-creation | stage 2 work, visit 5 | 17 files in the design |
| 20 | agent | rtl-design-creation | stage 2 work, visit 6 | 17 files in the design |

owner: 0, agent: 10, auto: 10
<!-- who-did-what:end -->

## review 00 clarify

approve by auto (gates fail)

## review 00 clarify

approve by auto (gates pass)

## review 01 board-and-device-planning

approve by auto (gates fail)

## review 01 board-and-device-planning

approve by auto (gates pass)

## architecture approval

approved (auto); written by the agent; sha256 cd84ed783597

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)
