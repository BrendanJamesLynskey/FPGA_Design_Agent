import zlib


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000, BUILD_STAMP=0,
                 DESIGN_ID=1129337649, MAX_PAYLOAD=8):
        self.CLKS_PER_BIT = CLKS_PER_BIT
        self.TIMEOUT_CYCLES = TIMEOUT_CYCLES
        self.BUILD_STAMP = BUILD_STAMP
        self.DESIGN_ID = DESIGN_ID
        self.MAX_PAYLOAD = MAX_PAYLOAD
        self.reset()

    def reset(self):
        self.buf = []
        self.busy = 0
        self.idle = 0
        self.byte_reg = 0
        self.result = 0
        self.typ = 0
        self.seq = 0
        self.pay0 = 0
        self.pay1 = 0
        self.last = 0
        self.have_last = 0
        self.ctr = [0] * 7

    def _classify(self):
        b = self.buf
        n = len(b)
        if n < 4:
            return 3
        L = b[1]
        if L > self.MAX_PAYLOAD or n > L + 8:
            return 4
        if n < L + 8:
            return 3
        crc = zlib.crc32(bytes(b[:n - 4])) & 0xFFFFFFFF
        got = b[n - 4] | (b[n - 3] << 8) | (b[n - 2] << 16) | (b[n - 1] << 24)
        if crc != got:
            return 2
        t = b[0]
        need = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}
        if t not in need:
            return 7
        if need[t] != L:
            return 8
        seq = (b[2] << 8) | b[3]
        if self.have_last:
            d = (seq - self.last) & 0xFFFF
            if not (1 <= d <= 32767):
                return 5 if d == 0 else 6
        return 1

    def _byte(self, v):
        self.byte_reg = v & 0x1FF
        self.idle = 0
        self.buf.append(v & 0xFF)
        if v & 0x100:
            cls = self._classify()
            b = self.buf
            self.result = cls
            idx = {1: 0, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5, 7: 6, 8: 6}[cls]
            self.ctr[idx] = (self.ctr[idx] + 1) & 0xFFFF
            if cls == 1:
                L = b[1]
                p = b[4:4 + L]
                p = p + [0] * (6 - len(p)) if len(p) < 6 else p
                self.typ = b[0]
                self.seq = (b[2] << 8) | b[3]
                self.pay0 = (p[0] << 8) | p[1]
                self.pay1 = (p[2] << 24) | (p[3] << 16) | (p[4] << 8) | p[5]
                self.last = self.seq
                self.have_last = 1
            self.buf = []
            self.busy = 0
        else:
            self.busy = 1

    def step(self, inputs=None):
        if self.busy:
            self.idle += 1
            if self.idle >= self.TIMEOUT_CYCLES:
                self.buf = []
                self.busy = 0
                self.idle = 0
        return {"UART_RXD_OUT": 1,
                "LED": ((self.last & 0xFF) << 8) | (self.ctr[0] & 0xFF)}

    def read_reg(self, offset):
        if offset == 0:
            return self.byte_reg
        if offset == 1:
            return self.result
        if offset == 2:
            return self.typ
        if offset == 3:
            return self.seq
        if offset == 4:
            return self.pay0
        if offset == 5:
            return self.pay1
        if offset == 6:
            return self.last | (self.have_last << 16)
        if offset == 7:
            return self.busy
        if 0x10 <= offset <= 0x16:
            return self.ctr[offset - 0x10]
        return 0

    def write_reg(self, offset, value):
        if offset == 0:
            self._byte(value)
