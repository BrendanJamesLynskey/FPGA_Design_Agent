"""pytest entry: runs the cocotb bench (cmd_parser_bench) against the RTL on three seeds."""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DESIGN = HERE.parent
sys.path.insert(0, str(DESIGN))
sys.path.insert(0, str(HERE))

try:
    from flow import cocotb_run
except ImportError:  # find the repo root that holds flow/
    for _p in DESIGN.parents:
        if (_p / "flow" / "cocotb_run.py").exists():
            sys.path.insert(0, str(_p))
            break
    from flow import cocotb_run

# keep in step with CPB / TIMEOUT in cmd_parser_bench.py
PARAMS = {"CLKS_PER_BIT": 6, "TIMEOUT_CYCLES": 20000}


def test_v2_e_cmd_parser_rtl():
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN / "rtl").glob("*.sv"))
    for seed in (1, 2, 3):
        cocotb_run.run(
            "v2_e_cmd_parser",
            "v2_e_cmd_parser_top",
            sources,
            "cmd_parser_bench",
            HERE,
            parameters=PARAMS,
            seed=seed,
        )
