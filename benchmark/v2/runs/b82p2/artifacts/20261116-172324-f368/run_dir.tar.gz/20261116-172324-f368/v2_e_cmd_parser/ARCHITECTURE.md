# Architecture: command packet screener (v2_e_cmd_parser)

Board nexys_a7_100t, part xc7a100tcsg324-1, top `v2_e_cmd_parser_top`, one clock domain (CLK100MHZ, 100 MHz).

## Block diagram

```text
 CPU_RESETN --> [rst_sync] --rst(active high)--> all blocks
 UART_TXD_IN --> [fpga_shell] --win_addr/wr/rd/wdata--> [win_regs]
 UART_RXD_OUT <-- [fpga_shell] <--win_rdata (1 clk after rd)-- [win_regs]
 [win_regs] --byte,end--> [byte_parser] --> [crc32]
 [byte_parser] --packet summary--> [classifier] --> counters x7, RESULT, TYPE, SEQ, PAY0, PAY1, LASTSEQ
 counters/LASTSEQ --> [win_regs] and --> LED[15:0]
 timeout counter (100000 clks) abandons a part-way packet; BUSY flag from parser
```

## Design notes

- BYTE write: 9 bits (data, end flag) registered, parser consumes within 4 clocks (one byte per 4 clocks).
- CRC-32 computed bytewise; the last 4 bytes are held back in a shift register as check bytes.
- At the end flag the classifier applies rules 1 to 6 in order; class, counters and fields valid within 4 clocks.
- Counters are 16 bits and wrap. Fields update only on a good packet.
- Timeout abandons the packet silently (no counter change; spec leaves it open).
- Resources predicted: about 600 LUT, 500 FF, 0 BRAM, 0 DSP.

## Clock plan

Single clock CLK100MHZ (100 MHz, 10 ns). No MMCM, no derived clocks, no CDC apart from the asynchronous reset button, synchronised by a 2-flop reset synchroniser (async assert, sync release); everything else uses synchronous active-high reset. UART_TXD_IN is synchronised inside fpga_shell.

## Pin list

| Port | Dir | Width | Board resource |
|---|---|---|---|
| CLK100MHZ | in | 1 | 100 MHz system clock |
| CPU_RESETN | in | 1 | CPU RESET button, active low |
| UART_TXD_IN | in | 1 | USB-UART host to FPGA |
| UART_RXD_OUT | out | 1 | USB-UART FPGA to host |
| LED | out | 16 | LED[15:0] |
