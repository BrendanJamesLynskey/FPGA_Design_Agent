bind v2_e_cmd_parser_top cmd_parser_checker u_cmd_parser_checker (
    .clk(CLK100MHZ),
    .rstn(CPU_RESETN),
    .uart_rx_in(UART_TXD_IN),
    .uart_tx_out(UART_RXD_OUT),
    .led(LED)
);
