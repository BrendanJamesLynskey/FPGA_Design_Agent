// Port-level cover points for v2_e_cmd_parser_top (bound by cmd_parser_checker_bind.sv).
`include "v_macros.svh"

module cmd_parser_checker (
    input wire        clk,
    input wire        rstn,
    input wire        uart_rx_in,
    input wire        uart_tx_out,
    input wire [15:0] led
);
    wire rst = ~rstn;
    reg seen_rst = 1'b0;
    reg past_ok = 1'b0;

    always @(posedge clk) begin
        past_ok <= 1'b1;
        if (rst) seen_rst <= 1'b1;
    end

    `V_COVER(C_led_good_nonzero, led[7:0] != 8'd0) // req: REQ-17
    `V_COVER(C_led_seq_nonzero, led[15:8] != 8'd0) // req: REQ-18
    `V_COVER(C_uart_rx_active, !uart_rx_in) // req: REQ-23
    `V_COVER(C_uart_tx_active, !uart_tx_out) // req: REQ-22
endmodule
