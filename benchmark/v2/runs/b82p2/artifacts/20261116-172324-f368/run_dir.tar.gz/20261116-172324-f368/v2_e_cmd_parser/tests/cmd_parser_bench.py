"""cocotb bench for v2_e_cmd_parser_top: the design is driven only through the test shell (UART, PROTOCOL.md 1.1),
window offset N = shell address 0x80 + N. Every register read is compared with model.py."""
import random
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402,F401
from model import Model  # noqa: E402

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ClockCycles, RisingEdge  # noqa: E402

CPB = 6           # CLKS_PER_BIT used in simulation (same value passed to the RTL by the pytest entry)
TIMEOUT = 20000   # TIMEOUT_CYCLES used in simulation
MODEL_PARAMS = dict(CLKS_PER_BIT=CPB, TIMEOUT_CYCLES=TIMEOUT)

NEED = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}
CLASS_CTR = {1: 0, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5, 7: 6, 8: 6}
ALL_REGS = list(range(0, 8)) + list(range(0x10, 0x17))


# ---------------------------------------------------------------- packet builders
def crc_bytes(body):
    c = zlib.crc32(bytes(body)) & 0xFFFFFFFF
    return [c & 0xFF, (c >> 8) & 0xFF, (c >> 16) & 0xFF, (c >> 24) & 0xFF]


def pkt(typ, length=None, seq=1, payload=None, flip=None):
    if length is None:
        length = NEED.get(typ, 0)
    if payload is None:
        payload = [(0x11 * (i + 1) + typ) & 0xFF for i in range(length if length <= 16 else 0)]
    body = [typ, length, (seq >> 8) & 0xFF, seq & 0xFF] + list(payload)
    c = crc_bytes(body)
    if flip is not None:
        c[flip] ^= 0xA5
    return body + c


# ---------------------------------------------------------------- bench
class Bench:
    def __init__(self, dut):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        self.m = Model(**MODEL_PARAMS)
        self.rxq = []
        self.framing_errors = 0

    async def start(self):
        d = self.dut
        d.UART_TXD_IN.value = 1
        d.CPU_RESETN.value = 0
        try:
            clk = Clock(self.clk, 10, unit="ns")
        except TypeError:
            clk = Clock(self.clk, 10, units="ns")
        cocotb.start_soon(clk.start())
        await ClockCycles(self.clk, 4)
        cocotb.start_soon(self.rx_loop())
        await self.reset()

    async def reset(self, cycles=8):
        self.dut.UART_TXD_IN.value = 1
        self.dut.CPU_RESETN.value = 0
        await ClockCycles(self.clk, cycles)
        self.dut.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 20)
        self.m.reset()
        self.rxq.clear()

    # ---- UART
    def _rxv(self):
        try:
            return int(self.dut.UART_RXD_OUT.value)
        except ValueError:
            return 1

    async def rx_loop(self):
        while True:
            await RisingEdge(self.clk)
            if self._rxv() == 0:
                await ClockCycles(self.clk, CPB // 2)
                if self._rxv() != 0:
                    continue
                val = 0
                for i in range(8):
                    await ClockCycles(self.clk, CPB)
                    val |= self._rxv() << i
                await ClockCycles(self.clk, CPB)
                if self._rxv() == 1:
                    self.rxq.append(val)
                else:
                    self.framing_errors += 1

    async def send_byte(self, b):
        bits = [0] + [(b >> i) & 1 for i in range(8)] + [1]
        for bit in bits:
            self.dut.UART_TXD_IN.value = bit
            await ClockCycles(self.clk, CPB)

    async def transact(self, cmd, addr, data=0):
        body = [cmd, addr] + list(data.to_bytes(4, "little"))
        chk = 0
        for x in body:
            chk ^= x
        frame = [0xA5] + body + [chk]
        self.rxq.clear()
        for x in frame:
            await self.send_byte(x)
        waited = 0
        while len(self.rxq) < 7:
            await ClockCycles(self.clk, CPB)
            waited += CPB
            assert waited < 4000, f"no shell response to cmd {cmd} addr {addr:#x}"
        r = list(self.rxq[:7])
        assert r[0] == 0x5A, f"bad response sync {r}"
        c = 0
        for x in r[1:6]:
            c ^= x
        assert c == r[6], f"bad response checksum {r}"
        await ClockCycles(self.clk, 2 * CPB)
        return r[1], int.from_bytes(bytes(r[2:6]), "little")

    async def read(self, off):
        st, d = await self.transact(1, 0x80 + off)
        assert st == 0, f"read window {off:#x} status {st}"
        return d

    async def write(self, off, val):
        st, d = await self.transact(2, 0x80 + off, val)
        assert st == 0, f"write window {off:#x} status {st}"

    # ---- byte intake (RTL and model together)
    async def put(self, byte, end=False):
        v = (byte & 0xFF) | (0x100 if end else 0)
        await self.write(0, v)
        self.m.write_reg(0, v)

    async def send(self, data):
        for i, x in enumerate(data):
            await self.put(x, i == len(data) - 1)

    # ---- checks
    async def expect_reg(self, off, label=""):
        got = await self.read(off)
        exp = self.m.read_reg(off)
        assert got == exp, f"reg {off:#x} {label}: rtl {got:#x} model {exp:#x}"
        return got

    def led_check(self):
        led = int(self.dut.LED.value)
        exp = self.m.step()["LED"]
        assert led == exp, f"LED rtl {led:#06x} model {exp:#06x}"

    async def check_all(self):
        for off in ALL_REGS:
            await self.expect_reg(off, "full sweep")
        self.led_check()

    async def check_pkt(self, exp_cls=None, fields=False, busy=False, full=False):
        got = await self.expect_reg(1, "RESULT")
        if exp_cls is not None:
            assert got == exp_cls, f"RESULT {got} expected class {exp_cls}"
            assert self.m.read_reg(1) == exp_cls, f"model class {self.m.read_reg(1)} expected {exp_cls}"
        if full:
            await self.check_all()
            return got
        await self.expect_reg(0x10 + CLASS_CTR[got], "class counter")
        if got == 1 and fields:
            for off in (2, 3, 4, 5, 6):
                await self.expect_reg(off, "good fields")
        if busy:
            b = await self.expect_reg(7, "BUSY")
            assert b == 0
        self.led_check()
        return got

    async def case(self, data, cls, **kw):
        await self.send(data)
        return await self.check_pkt(cls, **kw)

    def nseq(self):
        l = self.m.read_reg(6)
        return (((l & 0xFFFF) + 1) & 0xFFFF) if (l >> 16) & 1 else 1

    def last(self):
        return self.m.read_reg(6) & 0xFFFF


# ---------------------------------------------------------------- tests
# req: REQ-21, REQ-22, REQ-19
@cocotb.test()
async def test_smoke_registers_and_id(dut):
    b = Bench(dut)
    await b.start()
    st, d = await b.transact(1, 0x00)
    assert st == 0 and d == 0x43505331, f"DESIGN_ID {d:#x}"
    assert d == b.m.DESIGN_ID
    st, d = await b.transact(1, 0x01)
    assert d == 0x00010001
    await b.check_all()
    assert int(dut.LED.value) == 0
    # unmapped offsets read 0 and ignore writes
    for off in (8, 0x0F, 0x17, 0x20, 0x7F):
        assert await b.read(off) == 0
        await b.write(off, 0xFFFFFFFF)
        assert await b.read(off) == 0
    # read-only registers ignore writes
    for off in (1, 2, 3, 4, 5, 6, 7, 0x10, 0x12, 0x16):
        await b.write(off, 0x1FFFF)
    await b.check_all()
    # BYTE register reads back the last 9 bits written, and a non-end byte makes the packet busy
    await b.put(0x55, False)
    await b.expect_reg(0, "BYTE")
    assert await b.expect_reg(7, "BUSY") == 1
    await b.put(0xAA, True)
    await b.expect_reg(0, "BYTE")
    await b.check_pkt(3, full=True)


# req: REQ-23
@cocotb.test()
async def test_baud_rate(dut):
    b = Bench(dut)
    await b.start()
    runs = []

    async def mon():
        cnt = 0
        while True:
            await RisingEdge(b.clk)
            if b._rxv() == 0:
                cnt += 1
            elif cnt:
                runs.append(cnt)
                cnt = 0

    cocotb.start_soon(mon())
    await b.transact(1, 0x00)
    assert runs, "no response seen"
    # first byte 0x5A: start bit + bit0 are both 0 -> low for exactly two bit times
    assert runs[0] == 2 * CPB, f"first low run {runs[0]} clocks, expected {2 * CPB}"
    for r in runs:
        assert r % CPB == 0, f"low run of {r} clocks is not a multiple of CLKS_PER_BIT {CPB}"
    assert b.framing_errors == 0


# req: REQ-01, REQ-02
@cocotb.test()
async def test_too_long(dut):
    b = Bench(dut)
    await b.start()
    await b.case(pkt(2, 9, 1, [1, 2, 3, 4, 5, 6, 7, 8, 9]), 4)          # length byte 9
    await b.case([1, 9, 0, 1], 4)                                        # 4 bytes, length 9
    await b.case([1, 255, 0, 1, 0xAA], 4)                                # length 255
    await b.case(pkt(3, 0, 1) + [0xEE], 4)                               # one excess byte
    await b.case(pkt(3, 0, 1) + [1, 2, 3, 4, 5], 4)                      # many excess bytes
    await b.case(pkt(1, 8, 1, [1, 2, 3, 4, 5, 6, 7, 8]), 8)             # length 8 is not too long
    await b.case(pkt(3, 0, b.nseq()), 1, fields=True)                    # recovery


# req: REQ-03, REQ-04
@cocotb.test()
async def test_too_short(dut):
    b = Bench(dut)
    await b.start()
    await b.case([0x05], 3)
    await b.case([1, 2], 3)
    await b.case([1, 9, 0], 3)                    # 3 bytes with length 9
    await b.case([3, 0, 0], 3)
    await b.case([0xFF, 0xFF, 0xFF], 3)
    await b.case([3, 0, 0, 1], 3)                 # exactly 4 bytes
    await b.case(pkt(3, 0, 1)[:-1], 3)            # one byte missing
    await b.case(pkt(1, 2, 1)[:-1], 3)
    await b.case(pkt(2, 6, 1)[:5], 3)
    await b.case(pkt(3, 0, b.nseq()), 1)


# req: REQ-05
@cocotb.test()
async def test_bad_check(dut):
    b = Bench(dut)
    await b.start()
    for i in range(4):
        await b.case(pkt(3, 0, 1, flip=i), 2)
    p = pkt(1, 2, 1)
    p[4] ^= 1                                     # payload corrupted
    await b.case(p, 2)
    p = pkt(1, 2, 1)
    p[-4:] = p[-4:][::-1]                         # check bytes high byte first
    await b.case(p, 2)
    p = pkt(3, 0, 1)
    p[-4:] = [0, 0, 0, 0]
    await b.case(p, 2)
    await b.case(pkt(1, 2, 1), 1, fields=True)    # a correct check is accepted
    await b.check_all()


# req: REQ-06, REQ-07, REQ-25, REQ-26, REQ-27
@cocotb.test()
async def test_type_and_length(dut):
    b = Bench(dut)
    await b.start()
    for t in (0, 6, 7, 0x80, 0xFF):
        await b.case(pkt(t, 0, 1), 7)
    # wrong length for each type (valid check, payload consistent with the length byte)
    await b.case(pkt(1, 0, 1), 8)
    await b.case(pkt(1, 1, 1), 8)
    await b.case(pkt(2, 2, 1), 8)
    await b.case(pkt(2, 3, 1), 8)
    await b.case(pkt(3, 1, 1), 8)
    await b.case(pkt(3, 2, 1), 8)
    await b.case(pkt(4, 0, 1), 8)
    await b.case(pkt(4, 1, 1), 8)
    await b.case(pkt(5, 1, 1), 8)
    await b.case(pkt(5, 2, 1), 8)
    for t in (1, 2, 3, 4, 5):                     # right length is good
        await b.case(pkt(t, NEED[t], b.nseq()), 1)


# req: REQ-08, REQ-09, REQ-12, REQ-18
@cocotb.test()
async def test_sequence_rules(dut):
    b = Bench(dut)
    await b.start()
    steps = [(0xFFFF, 1), (0x0000, 1), (0x0000, 5), (0x8000, 6), (0x7FFF, 1), (0x7FFF, 5),
             (0xFFFE, 1), (0xFFFD, 6), (0xFFFE, 5), (0xFFFF, 1)]
    for seq, cls in steps:
        await b.send(pkt(3, 0, seq))
        await b.check_pkt(cls)
        await b.expect_reg(6, "LASTSEQ")
    # the first packet after reset may carry any number
    for first, second, cls2 in ((0x0000, 0x0000, 5), (0x8000, 0x0000, 6), (0x1234, 0x1235, 1)):
        await b.reset()
        await b.send(pkt(3, 0, first))
        await b.check_pkt(1)
        assert await b.expect_reg(6, "LASTSEQ") == (0x10000 | first)
        await b.send(pkt(3, 0, second))
        await b.check_pkt(cls2)


# req: REQ-10, REQ-04
@cocotb.test()
async def test_rule_priority(dut):
    b = Bench(dut)
    await b.start()
    await b.case(pkt(3, 0, 5), 1)
    await b.case([1, 200, 0], 3)                                       # short beats long
    await b.case([1, 20, 0, 6, 1, 2, 3, 4], 4)                          # long (and would be short)
    await b.case(pkt(3, 0, 6, flip=0) + [0x11], 4)                      # long beats bad check
    await b.case([9, 0, 0, 6], 3)                                       # short beats bad type
    await b.case([9, 0, 0, 1, 0xFF], 3)
    await b.case(pkt(9, 0, 6, flip=1), 2)                               # bad check beats bad type
    await b.case(pkt(3, 1, 6, [7], flip=0), 2)                          # bad check beats bad length
    await b.case(pkt(9, 0, 5), 7)                                       # bad type beats repeat
    await b.case(pkt(3, 1, 5, [7]), 8)                                  # bad length beats repeat
    await b.case(pkt(3, 1, 4, [7]), 8)                                  # bad length beats stale
    await b.case(pkt(0, 0, 4), 7)                                       # bad type beats stale
    await b.case(pkt(3, 0, 5), 5)
    await b.case(pkt(3, 0, 4), 6)
    await b.check_all()


# req: REQ-11, REQ-28, REQ-12, REQ-14, REQ-17, REQ-18
@cocotb.test()
async def test_good_fields(dut):
    b = Bench(dut)
    await b.start()
    cases = [
        (2, 0x1234, [0xAB, 0xCD, 0x01, 0x02, 0x03, 0x04]),
        (1, 0x1235, [0xDE, 0xAD]),                      # value field must clear to 0
        (3, 0x2336, []),                                # all payload fields clear
        (4, 0x2337, [0xFF, 0x01]),
        (5, 0x23A0, []),
        (2, 0x23A1, [0x80, 0x00, 0xFF, 0xFF, 0xFF, 0xFF]),
    ]
    for n, (t, seq, pay) in enumerate(cases, 1):
        await b.send(pkt(t, NEED[t], seq, pay))
        await b.check_pkt(1, fields=True)
        assert b.m.read_reg(0x10) == n
        assert int(dut.LED.value) == (((seq & 0xFF) << 8) | n)
    await b.check_all()


# req: REQ-13
@cocotb.test()
async def test_nongood_preserves_state(dut):
    b = Bench(dut)
    await b.start()
    await b.send(pkt(2, 6, 10, [9, 8, 7, 6, 5, 4]))
    await b.check_pkt(1, full=True)
    for data, cls in ((pkt(3, 0, 11, flip=3), 2), ([3, 0, 0], 3), ([1, 9, 0, 1], 4), (pkt(3, 0, 10), 5),
                      (pkt(3, 0, 9), 6), (pkt(9, 0, 11), 7), (pkt(3, 1, 11, [1]), 8)):
        await b.send(data)
        await b.check_pkt(cls, full=True)


# req: REQ-15, REQ-29, REQ-20, REQ-21
@cocotb.test()
async def test_end_flag_and_busy(dut):
    b = Bench(dut)
    await b.start()
    assert await b.expect_reg(7, "BUSY") == 0
    await b.case(pkt(3, 0, 1), 1)
    cases = [
        ("short", [0x03], 3),
        ("mid-payload end", [2, 6, 0, 5, 1, 2], 3),
        ("excess", pkt(3, 0, 50) + [0x55, 0x66], 4),
        ("bad check", pkt(3, 0, 50, flip=2), 2),
        ("bad type", pkt(9, 0, 50), 7),
        ("bad length", pkt(3, 1, 50, [1]), 8),
        ("repeat", None, 5),
        ("stale", None, 6),
        ("good", None, 1),
    ]
    for name, data, cls in cases:
        if name == "repeat":
            data = pkt(3, 0, b.last())
        elif name == "stale":
            data = pkt(3, 0, (b.last() - 1) & 0xFFFF)
        elif name == "good":
            data = pkt(3, 0, b.nseq())
        for i, x in enumerate(data[:-1]):
            await b.put(x, False)
            if i == 1:
                assert await b.expect_reg(7, f"BUSY {name}") == 1
        await b.put(data[-1], True)
        await b.check_pkt(cls, busy=True)
        # the byte after an end flag starts a fresh packet
        await b.case(pkt(3, 0, b.nseq()), 1)


# req: REQ-16, REQ-30
@cocotb.test()
async def test_counter_width(dut):
    b = Bench(dut)
    await b.start()
    for i in range(257):
        await b.put(0x41, True)
        if i in (254, 255, 256):
            got = await b.expect_reg(0x12, "CTR_SHORT")
            assert got == i + 1
    await b.check_all()
    # Wrap 65535 -> 0 cannot be reached over the UART in bounded time: it is covered by the model
    # comparison on the counters' 16-bit width and by hardware bring-up.


# req: REQ-19
@cocotb.test()
async def test_reset_clears_all(dut):
    b = Bench(dut)
    await b.start()
    await b.case(pkt(2, 6, 7, [1, 2, 3, 4, 5, 6]), 1, fields=True)
    await b.case(pkt(3, 0, 8, flip=0), 2)
    for x in (3, 0, 0):
        await b.put(x, False)
    assert await b.expect_reg(7, "BUSY") == 1
    await b.reset()
    await b.check_all()
    assert int(dut.LED.value) == 0
    # the partial bytes are gone and the last accepted sequence is cleared: same number is good again
    await b.case(pkt(3, 0, 7), 1, fields=True)
    await b.check_all()


# req: REQ-20
@cocotb.test()
async def test_timeout_abandons(dut):
    b = Bench(dut)
    await b.start()
    await b.case(pkt(3, 0, 1), 1)
    for x in (3, 0, 0):
        await b.put(x, False)
    assert await b.expect_reg(7, "BUSY") == 1
    await ClockCycles(b.clk, TIMEOUT + 3000)
    for _ in range(TIMEOUT + 10):
        b.m.step()
    assert await b.expect_reg(7, "BUSY after timeout") == 0
    await b.check_all()
    await b.case(pkt(3, 0, b.nseq()), 1, fields=True)


# req: REQ-01, REQ-02, REQ-03, REQ-05, REQ-06, REQ-08, REQ-10, REQ-11, REQ-13, REQ-15, REQ-29
@cocotb.test()
async def test_random_traffic(dut):
    seed = getattr(cocotb, "RANDOM_SEED", 1) or 1
    rnd = random.Random(seed)
    b = Bench(dut)
    await b.start()
    kinds = ["good"] * 4 + ["repeat", "stale", "badcrc", "short", "extra", "badtype", "badlen", "longlen", "early"]
    for i in range(12):
        kind = "good" if i == 0 else rnd.choice(kinds)
        l = b.last()
        have = (b.m.read_reg(6) >> 16) & 1
        t = rnd.randint(1, 5)
        ln = NEED[t]
        pay = [rnd.randrange(256) for _ in range(ln)]
        gseq = ((l + rnd.choice([1, 2, 100, 32767])) & 0xFFFF) if have else rnd.randrange(65536)
        if kind == "good":
            data = pkt(t, ln, gseq, pay)
        elif kind == "repeat":
            data = pkt(t, ln, l if have else gseq, pay)
        elif kind == "stale":
            data = pkt(t, ln, (l + rnd.choice([0x8000, 0x8001, 0xFFFF, 0xFFF0])) & 0xFFFF, pay)
        elif kind == "badcrc":
            data = pkt(t, ln, gseq, pay, flip=rnd.randrange(4))
        elif kind == "short":
            p = pkt(t, ln, gseq, pay)
            data = p[:rnd.randint(1, len(p) - 1)]
        elif kind == "extra":
            data = pkt(t, ln, gseq, pay) + [rnd.randrange(256) for _ in range(rnd.randint(1, 3))]
        elif kind == "badtype":
            data = pkt(rnd.choice([0, 6, 7, 9, 0x80, 255]), 0, gseq)
        elif kind == "badlen":
            l2 = rnd.choice([x for x in (0, 1, 2, 3, 4, 6, 7) if x != ln])
            data = pkt(t, l2, gseq, [rnd.randrange(256) for _ in range(l2)])
        elif kind == "longlen":
            l2 = rnd.randint(9, 255)
            data = [t, l2, gseq >> 8, gseq & 0xFF] + [rnd.randrange(256) for _ in range(rnd.randint(0, 6))]
        else:
            data = [rnd.randrange(256) for _ in range(rnd.randint(1, 3))]
        dut._log.info(f"random packet {i}: {kind} {bytes(data).hex()}")
        await b.send(data)
        await b.check_pkt(None, fields=True)
    await b.check_all()
