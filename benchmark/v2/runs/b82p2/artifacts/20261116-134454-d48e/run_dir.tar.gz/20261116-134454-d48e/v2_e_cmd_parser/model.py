import zlib


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000000, BUILD_STAMP=0,
                 DESIGN_ID=1129337649, MAX_PAYLOAD=8, SEQ_WINDOW=32767):
        self.TIMEOUT_CYCLES = TIMEOUT_CYCLES
        self.MAX_PAYLOAD = MAX_PAYLOAD
        self.SEQ_WINDOW = SEQ_WINDOW
        self.DESIGN_ID = DESIGN_ID
        self.reset()

    def reset(self):
        self.inputs = {}
        self.byte_reg = 0
        self.buf = []
        self.n = 0
        self.busy = 0
        self.idle_cnt = 0
        self.ctr = [0] * 7
        self.result = 0
        self.ltype = 0
        self.seq = 0
        self.pay0 = 0
        self.pay1 = 0
        self.last_seq = 0
        self.have_seq = 0

    def _finish(self, cls_buf, n):
        L = cls_buf[1] if n > 1 else 0
        b = cls_buf
        res = None
        if n < 4:
            res = 3
        elif L > self.MAX_PAYLOAD:
            res = 4
        elif n > 8 + L:
            res = 4
        elif n < 8 + L:
            res = 3
        else:
            body = bytes(b[:n - 4])
            rx = b[n - 4] | (b[n - 3] << 8) | (b[n - 2] << 16) | (b[n - 1] << 24)
            if zlib.crc32(body) != rx:
                res = 2
            else:
                t = b[0]
                need = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}
                seq = (b[2] << 8) | b[3]
                if t not in need:
                    res = 7
                elif need[t] != L:
                    res = 8
                else:
                    d = (seq - self.last_seq) & 0xFFFF
                    if self.have_seq and not (1 <= d <= self.SEQ_WINDOW):
                        res = 5 if d == 0 else 6
                    else:
                        res = 1
                        pl = b[4:4 + L] + [0] * 6
                        self.ltype = t
                        self.seq = seq
                        self.pay0 = (pl[0] << 8) | pl[1]
                        self.pay1 = (pl[2] << 24) | (pl[3] << 16) | (pl[4] << 8) | pl[5]
                        self.last_seq = seq
                        self.have_seq = 1
        self.result = res
        idx = {1: 0, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5, 7: 6, 8: 6}[res]
        self.ctr[idx] = (self.ctr[idx] + 1) & 0xFFFF

    def _write_byte(self, v):
        self.byte_reg = v & 0x1FF
        data = v & 0xFF
        end = (v >> 8) & 1
        if len(self.buf) < 16:
            self.buf.append(data)
        self.n += 1
        self.idle_cnt = 0
        if end:
            self._finish(self.buf, self.n)
            self.buf = []
            self.n = 0
            self.busy = 0
        else:
            self.busy = 1

    def step(self, inputs=None):
        if inputs:
            self.inputs.update(inputs)
            if self.inputs.get("CPU_RESETN", 1) == 0:
                self.reset()
                self.inputs["CPU_RESETN"] = 0
        if self.busy:
            self.idle_cnt += 1
            if self.idle_cnt >= self.TIMEOUT_CYCLES:
                self.result = 3
                self.ctr[2] = (self.ctr[2] + 1) & 0xFFFF
                self.buf = []
                self.n = 0
                self.busy = 0
                self.idle_cnt = 0
        led = (self.ctr[0] & 0xFF) | ((self.last_seq & 0xFF) << 8)
        return {"UART_RXD_OUT": 1, "LED": led}

    def read_reg(self, offset):
        if offset == 0:
            return self.byte_reg
        if offset == 1:
            return self.result
        if offset == 2:
            return self.ltype
        if offset == 3:
            return self.seq
        if offset == 4:
            return self.pay0
        if offset == 5:
            return self.pay1
        if offset == 6:
            return self.last_seq | (self.have_seq << 16)
        if offset == 7:
            return self.busy
        if 0x10 <= offset <= 0x16:
            return self.ctr[offset - 0x10]
        return 0

    def write_reg(self, offset, value):
        if offset == 0:
            self._write_byte(value)
