
## models by role (profile single)

clarify: claude_code claude-sonnet-5-5 (medium); model: claude_code claude-sonnet-5-5 (medium); tests: claude_code claude-sonnet-5-5 (medium); rtl: claude_code claude-sonnet-5-5 (medium). Interview oracle: openai/gpt-6-luna (fixed). The stage machine is plain code.

<!-- who-did-what:start -->
## Who did what

| # | who | stage | what | detail |
|---|---|---|---|---|
| 1 | agent | clarify | stage 0 work, visit 1 | 5 files in the design |
| 2 | agent | clarify | stage 0 work, visit 2 | 5 files in the design |
| 3 | auto | clarify | interview | answered: What is the register map (offset, width, reset value and access of every register) of the test shell? -> BUSY: offset 0x07, RO, reset 0: [0] a packet is part-way CTR_GOOD..CTR_PROTO: of |
| 4 | auto | clarify | interview | defaulted: What does TIMEOUT_CYCLES do? -> If no byte arrives for TIMEOUT_CYCLES clocks while a packet is part-way, the pac |
| 5 | auto | clarify | interview | answered: Which byte-register format marks the end flag? -> Confirmed, with one correction: the register is named BYTE (offset 0x00, RW), no |
| 6 | auto | clarify | interview | answered: Does a packet longer than expected with a length byte of 8 or less count as class 1 even when the CRC is bad? -> No. The proposed default is not supported. GOOD (class 1) requires a valid CRC,  |
| 7 | auto | clarify | interview | answered: Are the type, sequence, address and value registers cleared by a non-good packet? -> BUSY: offset 0x07, RO, reset 0: [0] a packet is part-way CTR_GOOD..CTR_PROTO: of |
| 8 | auto | clarify | interview | defaulted: Does the status register bit mean mid-packet only? -> STATUS bit 0 is 1 from the first byte of a packet until its END byte is processe |
| 9 | auto | clarify | approved (review off) |  |
| 10 | agent | board-and-device-planning | stage 1 work, visit 1 | 7 files in the design |
| 11 | agent | board-and-device-planning | stage 1 work, visit 2 | 8 files in the design |
| 12 | auto | board-and-device-planning | approved (review off) |  |
| 13 | auto | board-and-device-planning | architecture approved | source: agent |
| 14 | agent | rtl-design-creation | stage 2 work, visit 1 | 17 files in the design |
| 15 | agent | rtl-design-creation | stage 2 work, visit 2 | 17 files in the design |
| 16 | agent | rtl-design-creation | stage 2 work, visit 3 | 17 files in the design |
| 17 | agent | rtl-design-creation | stage 2 work, visit 4 | 17 files in the design |
| 18 | agent | rtl-design-creation | stage 2 work, visit 5 | 17 files in the design |
| 19 | agent | rtl-design-creation | stage 2 work, visit 6 | 17 files in the design |

owner: 0, agent: 10, auto: 9
<!-- who-did-what:end -->

## review 00 clarify

approve by auto (gates fail)

## review 00 clarify

approve by auto (gates pass)

## review 01 board-and-device-planning

approve by auto (gates fail)

## review 01 board-and-device-planning

approve by auto (gates pass)

## architecture approval

approved (auto); written by the agent; sha256 028b4144cb05

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)
