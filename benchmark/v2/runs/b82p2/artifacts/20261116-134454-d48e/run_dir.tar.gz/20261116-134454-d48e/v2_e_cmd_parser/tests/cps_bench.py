"""cocotb bench for the command packet screener (CPS1).

All stimulus goes through the test shell over the UART (window address 0x80 + register offset) and every
register value is compared with model.py.  CLKS_PER_BIT and TIMEOUT_CYCLES are shrunk (same values in the
model) to keep the bench fast.
"""
import random
import re
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model as model_mod  # noqa: E402

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ClockCycles, RisingEdge  # noqa: E402

N = 8
TMO = 6000
PARAMS = dict(CLKS_PER_BIT=N, TIMEOUT_CYCLES=TMO)

NEED = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}
STATE = [2, 3, 4, 5, 6]
ALL = [0, 1, 2, 3, 4, 5, 6, 7] + list(range(0x10, 0x17))
CTR_OF = {1: 0x10, 2: 0x11, 3: 0x12, 4: 0x13, 5: 0x14, 6: 0x15, 7: 0x16, 8: 0x16}


def mkpkt(t, seq, payload, L=None, crc_xor=0):
    L = len(payload) if L is None else L
    body = [t, L, (seq >> 8) & 0xFF, seq & 0xFF] + list(payload)
    c = (zlib.crc32(bytes(body)) ^ crc_xor) & 0xFFFFFFFF
    return body + list(c.to_bytes(4, "little"))


def status_pkt(seq, **kw):
    return mkpkt(3, seq, [], **kw)


class Env:
    def __init__(self, dut):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        self.m = model_mod.Model(**PARAMS)

    async def start(self):
        self.dut.UART_TXD_IN.value = 1
        self.dut.CPU_RESETN.value = 0
        try:
            c = Clock(self.clk, 10, unit="ns")
        except TypeError:
            c = Clock(self.clk, 10, units="ns")
        cocotb.start_soon(c.start())
        await ClockCycles(self.clk, 10)
        self.dut.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 20)
        self.m.reset()

    async def reset(self, cycles=10):
        self.dut.CPU_RESETN.value = 0
        await ClockCycles(self.clk, cycles)
        self.dut.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 20)
        self.m.reset()

    # ---- UART ----
    def _rxd(self):
        try:
            return int(self.dut.UART_RXD_OUT.value)
        except ValueError:
            return 1

    async def _recv(self, n):
        out = []
        for _ in range(n):
            waited = 0
            while True:
                await RisingEdge(self.clk)
                if self._rxd() == 0:
                    break
                waited += 1
                assert waited < 6000, "no response from the shell"
            await ClockCycles(self.clk, N // 2)
            b = 0
            for i in range(8):
                await ClockCycles(self.clk, N)
                b |= self._rxd() << i
            await ClockCycles(self.clk, N)
            assert self._rxd() == 1, "response stop bit low"
            out.append(b)
        return out

    async def _send(self, data):
        for b in data:
            for bit in [0] + [(b >> i) & 1 for i in range(8)] + [1]:
                self.dut.UART_TXD_IN.value = bit
                await ClockCycles(self.clk, N)

    async def xact(self, cmd, addr, data=0):
        body = bytes([cmd, addr]) + data.to_bytes(4, "little")
        chk = 0
        for x in body:
            chk ^= x
        req = bytes([0xA5]) + body + bytes([chk])
        t = cocotb.start_soon(self._recv(7))
        await self._send(req)
        fr = await t
        await ClockCycles(self.clk, 3 * N)
        assert fr[0] == 0x5A, f"bad response sync {fr}"
        x = 0
        for v in fr[1:6]:
            x ^= v
        assert x == fr[6], f"bad response checksum {fr}"
        return fr[1], int.from_bytes(bytes(fr[2:6]), "little")

    async def rd(self, off):
        st, d = await self.xact(1, 0x80 + off)
        assert st == 0, f"read 0x{off:02X} status {st}"
        return d

    async def wr(self, off, v):
        st, _ = await self.xact(2, 0x80 + off, v)
        assert st == 0, f"write 0x{off:02X} status {st}"

    # ---- packets ----
    async def put(self, data, end):
        v = data | (0x100 if end else 0)
        await self.wr(0, v)
        self.m.write_reg(0, v)

    async def send(self, pkt):
        for i, b in enumerate(pkt):
            await self.put(b, i == len(pkt) - 1)

    async def chk(self, offs, tag=""):
        for o in offs:
            got = await self.rd(o)
            exp = self.m.read_reg(o)
            assert got == exp, f"{tag}: reg 0x{o:02X} rtl=0x{got:X} model=0x{exp:X}"

    def check_led(self, tag=""):
        exp = (self.m.read_reg(0x10) & 0xFF) | ((self.m.read_reg(6) & 0xFF) << 8)
        got = int(self.dut.LED.value)
        assert got == exp, f"{tag}: LED rtl=0x{got:04X} model=0x{exp:04X}"
        return got

    async def after(self, res, tag=""):
        """The class register must be `res` (explicit) and equal to the model; its counter and good counter too."""
        r = await self.rd(1)
        assert r == res, f"{tag}: RESULT rtl={r} expected={res}"
        assert self.m.read_reg(1) == res, f"{tag}: model RESULT {self.m.read_reg(1)} != {res}"
        await self.chk([CTR_OF[res], 0x10], tag)
        self.check_led(tag)


# req: REQ-16, REQ-17, REQ-19
@cocotb.test()
async def test_smoke_registers(dut):
    e = Env(dut)
    await e.start()
    st, d = await e.xact(1, 0x00)
    assert st == 0 and d == 0x43505331, f"DESIGN_ID 0x{d:08X}"
    await e.chk(ALL, "reset values")
    for o in ALL:
        assert e.m.read_reg(o) == 0
    assert int(dut.LED.value) == 0
    # unmapped offsets read 0, writes ignored; read-only registers ignore writes
    for o in (0x08, 0x0F, 0x17, 0x20, 0x30, 0x7F):
        assert await e.rd(o) == 0, f"unmapped 0x{o:02X}"
    for o in (1, 2, 3, 4, 5, 6, 7, 0x10, 0x13, 0x16, 0x20, 0x50):
        await e.wr(o, 0xFFFFFFFF)
    await e.chk(ALL, "after RO writes")
    assert int(dut.LED.value) == 0
    # BYTE reads back the last 9 bits written
    await e.put(0x55, False)
    await e.chk([0, 7], "byte 0x55")
    await e.put(0xAA, True)
    await e.chk(ALL, "byte end")
    assert await e.rd(0) == 0x1AA


# req: REQ-09, REQ-10, REQ-11, REQ-15
@cocotb.test()
async def test_good_packets(dut):
    e = Env(dut)
    await e.start()
    # first packet after reset is accepted with any sequence number
    await e.send(mkpkt(2, 0xBEEF, [0x12, 0x34, 0xDE, 0xAD, 0xBE, 0xEF]))
    assert await e.rd(1) == 1
    assert await e.rd(2) == 2
    assert await e.rd(3) == 0xBEEF
    assert await e.rd(4) == 0x1234
    assert await e.rd(5) == 0xDEADBEEF
    assert await e.rd(6) == 0x1BEEF
    assert await e.rd(0x10) == 1
    assert int(dut.LED.value) == 0xEF01
    await e.chk(STATE + [1, 7, 0x10], "write pkt")
    pk = [
        (1, 0xBEF0, [0xAA, 0x55]),
        (3, 0xBEF2, []),
        (4, 0xBEF3, [0x01, 0x02]),
        (5, 0xBEF4, []),
    ]
    for t, s, pl in pk:
        await e.send(mkpkt(t, s, pl))
        await e.chk(STATE + [1, 7, 0x10], f"type {t}")
        e.check_led(f"type {t}")
        if not pl:
            assert await e.rd(4) == 0 and await e.rd(5) == 0, "zero fill"
        elif t == 1 or t == 4:
            assert await e.rd(5) == 0, "value is zero without value bytes"
    assert await e.rd(0x10) == 5
    assert int(dut.LED.value) == 0xF405


# req: REQ-01, REQ-02, REQ-12, REQ-13
@cocotb.test()
async def test_too_long(dut):
    e = Env(dut)
    await e.start()
    await e.send(status_pkt(0x0100))
    await e.after(1, "base")
    snap = [await e.rd(o) for o in STATE]
    pkts = [
        mkpkt(3, 0x0101, [0] * 9, L=9),               # length byte 9
        [3, 200, 1, 2, 0xAA, 0xBB],                    # length byte 200, 6 bytes
        [1, 9, 0, 0],                                  # exactly 4 bytes with L=9
        mkpkt(3, 0x0102, []) + [0],                    # one byte too many
        mkpkt(1, 0x0103, [1, 2]) + [9, 9, 9],          # three bytes too many
        [0] * 14,                                      # L=0, 14 bytes
        [3, 0xFF, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],       # L=255
    ]
    for i, p in enumerate(pkts):
        await e.send(p)
        await e.after(4, f"long {i}")
    assert await e.rd(0x13) == len(pkts)
    assert [await e.rd(o) for o in STATE] == snap, "long packets changed good state"
    assert await e.rd(0x10) == 1
    await e.chk(ALL, "end")


# req: REQ-01, REQ-03, REQ-04, REQ-12
@cocotb.test()
async def test_too_short(dut):
    e = Env(dut)
    await e.start()
    await e.send(status_pkt(0x0010))
    await e.after(1, "base")
    snap = [await e.rd(o) for o in STATE]
    full = status_pkt(0x0011)
    wpk = mkpkt(2, 0x0012, [1, 2, 3, 4, 5, 6])
    pkts = [
        [0x00],
        [0xFF],
        [1, 9],                  # length byte 9 but only 2 bytes: class 2
        [3, 0, 0],
        [1, 200, 5],
        [3, 0, 0, 1],            # 4 bytes, L=0 needs 8
        full[:-1],               # one byte short
        wpk[:-1],
        [1, 8, 0, 0, 0],         # L=8, 5 bytes
    ]
    for i, p in enumerate(pkts):
        await e.send(p)
        await e.after(3, f"short {i}")
    assert await e.rd(0x12) == len(pkts)
    assert [await e.rd(o) for o in STATE] == snap, "short packets changed good state"
    await e.chk(ALL, "end")


# req: REQ-05, REQ-12
@cocotb.test()
async def test_bad_crc(dut):
    e = Env(dut)
    await e.start()
    await e.send(status_pkt(0x0200))
    await e.after(1, "base")
    snap = [await e.rd(o) for o in STATE]
    corrupt = mkpkt(1, 0x0201, [0x10, 0x20])
    corrupt[4] ^= 0x01     # payload byte changed, CRC stale
    pkts = [
        status_pkt(0x0201, crc_xor=1),
        status_pkt(0x0201, crc_xor=0x80000000),
        corrupt,
        mkpkt(9, 0x0201, [], crc_xor=5),             # bad type and bad CRC: CRC rule first
        status_pkt(0x0200, crc_xor=0x00FF0000),      # repeat seq and bad CRC
        mkpkt(3, 0x0201, [0], crc_xor=1),            # wrong length and bad CRC
    ]
    for i, p in enumerate(pkts):
        await e.send(p)
        await e.after(2, f"crc {i}")
    assert await e.rd(0x11) == len(pkts)
    assert [await e.rd(o) for o in STATE] == snap
    # sequence number was not taken over by the bad packets
    await e.send(status_pkt(0x0201))
    await e.after(1, "good after bad crc")
    await e.chk(ALL, "end")


# req: REQ-06, REQ-07, REQ-12
@cocotb.test()
async def test_type_length(dut):
    e = Env(dut)
    await e.start()
    await e.send(status_pkt(0x0300))
    await e.after(1, "base")
    snap = [await e.rd(o) for o in STATE]
    pkts = [
        (7, mkpkt(0, 0x0301, [])),
        (7, mkpkt(6, 0x0300, [1, 2])),                # unknown type, repeated seq: type first
        (7, mkpkt(255, 0x0302, [])),
        (8, mkpkt(1, 0x0303, [])),                    # read needs 2
        (8, mkpkt(1, 0x0303, [1, 2, 3])),
        (8, mkpkt(2, 0x0303, [1, 2])),                # write needs 6
        (8, mkpkt(3, 0x0303, [7])),                   # status needs 0
        (8, mkpkt(5, 0x0300, [1, 2])),                # stop needs 0, seq repeat: length first
    ]
    for i, (res, p) in enumerate(pkts):
        await e.send(p)
        await e.after(res, f"proto {i}")
    assert await e.rd(0x16) == len(pkts)
    assert [await e.rd(o) for o in STATE] == snap
    await e.chk(ALL, "end")


# req: REQ-08, REQ-09, REQ-12, REQ-15
@cocotb.test()
async def test_sequence(dut):
    e = Env(dut)
    await e.start()
    seq = [(0xFFFE, 1), (0xFFFE, 5), (0xFFFD, 6), (0xFFFF, 1), (0x0000, 1),
           (0x7FFF, 1), (0xFFFF, 6), (0x7FFF, 5), (0x7FFE, 6), (0xFFFE, 1)]
    for i, (s, res) in enumerate(seq):
        await e.send(status_pkt(s))
        r = await e.rd(1)
        assert r == res, f"pkt {i} seq 0x{s:04X}: RESULT {r} expected {res}"
        assert e.m.read_reg(1) == res
        await e.chk([6], f"pkt {i}")
        e.check_led(f"pkt {i}")
    await e.chk(ALL, "end")
    assert await e.rd(0x10) == 5 and await e.rd(0x14) == 2 and await e.rd(0x15) == 3


# req: REQ-13, REQ-22, REQ-18
@cocotb.test()
async def test_end_closes_packet(dut):
    e = Env(dut)
    await e.start()
    s = 0x0400

    async def good_next():
        nonlocal s
        s += 1
        await e.send(status_pkt(s))
        await e.after(1, f"good after closed packet seq {s}")
        assert await e.rd(7) == 0

    await e.send([0x00])
    await e.after(3, "single END")
    await good_next()
    await e.send([1, 9, 0, 0])
    await e.after(4, "L=9 END")
    await good_next()
    await e.send([0x11] * 12)
    await e.after(4, "long END")
    await good_next()
    await e.send([0xFF])
    await e.after(3, "single FF END")
    await good_next()
    await e.chk(ALL, "end")


# req: REQ-20
@cocotb.test()
async def test_busy_flag(dut):
    e = Env(dut)
    await e.start()
    assert await e.rd(7) == 0
    p = status_pkt(0x0500)
    for i, b in enumerate(p[:-1]):
        await e.put(b, False)
        if i in (0, 1, 4):
            assert await e.rd(7) == 1, f"BUSY after byte {i}"
            assert e.m.read_reg(7) == 1
    assert await e.rd(0) == p[-2]
    await e.put(p[-1], True)
    assert await e.rd(7) == 0, "BUSY after END"
    assert await e.rd(0) == 0x100 | p[-1]
    await e.send([0x07])
    assert await e.rd(7) == 0, "BUSY after single-byte packet"
    await e.chk(ALL, "end")


# req: REQ-15
@cocotb.test()
async def test_leds(dut):
    e = Env(dut)
    await e.start()
    assert int(dut.LED.value) == 0
    await e.send(status_pkt(0x12AB))
    await e.chk([0x10, 6])
    assert int(dut.LED.value) == 0xAB01
    e.check_led()
    await e.send(mkpkt(4, 0x12AC, [1, 2]))
    await e.chk([0x10, 6])
    assert int(dut.LED.value) == 0xAC02
    await e.send(status_pkt(0x12AD, crc_xor=1))
    await e.chk([0x10, 6, 1])
    assert int(dut.LED.value) == 0xAC02, "LED changed on a bad packet"
    await e.send(status_pkt(0x13FF))
    await e.chk([0x10, 6])
    assert int(dut.LED.value) == 0xFF03
    e.check_led()


# req: REQ-16, REQ-09
@cocotb.test()
async def test_reset(dut):
    e = Env(dut)
    await e.start()
    await e.send(status_pkt(0x0400))
    await e.send([0x01])
    await e.send(status_pkt(0x0400))
    await e.send(status_pkt(0x0401, crc_xor=3))
    for p in (mkpkt(2, 0x0402, [1, 2, 3, 4, 5, 6]),):
        await e.send(p)
    assert await e.rd(0x10) == 2
    p = status_pkt(0x0403)
    for b in p[:3]:
        await e.put(b, False)
    assert await e.rd(7) == 1
    await e.reset()
    for o in ALL:
        got = await e.rd(o)
        assert got == 0, f"reg 0x{o:02X} = 0x{got:X} after reset"
    assert int(dut.LED.value) == 0
    # first-packet state: the old sequence number is accepted, and the part packet is gone
    await e.send(status_pkt(0x0402))
    await e.after(1, "first after reset")
    await e.chk(ALL, "after first")
    await e.send(status_pkt(0x0402))
    await e.after(5, "repeat")
    # reset again, first packet with sequence 0
    await e.reset()
    await e.send(status_pkt(0x0000))
    await e.after(1, "seq 0 first")
    assert await e.rd(6) == 0x10000
    await e.chk(ALL, "end")


# req: REQ-03, REQ-20
@cocotb.test()
async def test_timeout(dut):
    e = Env(dut)
    await e.start()
    p = status_pkt(0x0600)
    for b in p[:3]:
        await e.put(b, False)
    assert await e.rd(7) == 1
    await ClockCycles(dut.CLK100MHZ, 2 * TMO + 200)
    for _ in range(2 * TMO + 200):
        e.m.step()
    assert e.m.read_reg(1) == 3 and e.m.read_reg(7) == 0
    await e.chk(ALL, "after timeout")
    assert await e.rd(1) == 3 and await e.rd(0x12) == 1 and await e.rd(7) == 0
    await e.send(status_pkt(0x0601))
    await e.after(1, "after timeout")
    await e.chk(ALL, "end")


# req: REQ-14, REQ-23
@cocotb.test()
async def test_counter_wrap(dut):
    e = Env(dut)
    await e.start()
    classes = [
        (0x12, r"short", [0x00]),
        (0x13, r"long", [1, 9, 0, 0]),
        (0x11, r"crc|bad|chk|check", status_pkt(0x0700, crc_xor=1)),
        (0x16, r"proto|type|len", mkpkt(0, 0x0700, [])),
    ]

    def walk(h, depth, out):
        try:
            kids = list(h)
        except Exception:
            return
        for k in kids:
            out.append(k)
            if depth < 4:
                walk(k, depth + 1, out)

    allh = []
    walk(dut, 0, allh)
    cands = []
    for h in allh:
        name = str(getattr(h, "_name", "")).lower()
        try:
            w = len(h)
        except Exception:
            continue
        if w == 16 and not re.search(r"next|nxt|_d$|led|rdata", name):
            cands.append((name, h))
    found = 0
    for off, pat, pkt in classes:
        sel = [h for n, h in cands if re.search(pat, n)][:6]
        for h in sel:
            try:
                h.value = 0xFFFE
            except Exception:
                continue
            await ClockCycles(dut.CLK100MHZ, 3)
            if await e.rd(off) == 0xFFFE:
                found += 1
                for exp in (0xFFFF, 0x0000, 0x0001):
                    await e.send(pkt)
                    got = await e.rd(off)
                    assert got == exp, f"counter 0x{off:02X}: 0x{got:X}, expected 0x{exp:X}"
                break
            try:
                h.value = 0
            except Exception:
                pass
        await e.reset()
    if found == 0:
        # no internal counter could be preloaded: count past 255 through the shell instead
        dut._log.warning("counter wrap not reachable by deposit; counting to 257 only")
        for _ in range(257):
            await e.send([0x00])
        assert await e.rd(0x12) == 257
        assert e.m.read_reg(0x12) == 257
        assert int(dut.LED.value) == 0
    dut._log.info(f"wrap probe: {found} counters preloaded")


# req: REQ-01, REQ-02, REQ-03, REQ-04, REQ-05, REQ-06, REQ-07, REQ-08, REQ-09, REQ-10, REQ-12, REQ-13, REQ-15, REQ-22
@cocotb.test()
async def test_random_packets(dut):
    e = Env(dut)
    await e.start()
    seed = int(getattr(cocotb, "RANDOM_SEED", 1))
    rng = random.Random(seed)
    cats = ["good"] * 4 + ["repeat", "stale", "badcrc", "badtype", "badlen", "long_l", "long_extra", "short"]

    def newseq():
        r = e.m.read_reg(6)
        last, have = r & 0xFFFF, r >> 16
        if not have:
            return rng.randrange(65536)
        return (last + rng.choice([1, 2, 32767, rng.randrange(1, 32768)])) & 0xFFFF

    for k in range(10):
        cat = rng.choice(cats)
        r = e.m.read_reg(6)
        last = r & 0xFFFF
        t = rng.randrange(1, 6)
        pl = [rng.randrange(256) for _ in range(NEED[t])]
        if cat == "good":
            p = mkpkt(t, newseq(), pl)
        elif cat == "repeat":
            p = mkpkt(t, last, pl)
        elif cat == "stale":
            p = mkpkt(t, (last + rng.randrange(32768, 65536)) & 0xFFFF, pl)
        elif cat == "badcrc":
            p = mkpkt(t, newseq(), pl, crc_xor=rng.randrange(1, 1 << 32))
        elif cat == "badtype":
            L = rng.randrange(0, 5)
            p = mkpkt(rng.choice([0, 6, 7, 200, 255]), newseq(), [rng.randrange(256) for _ in range(L)])
        elif cat == "badlen":
            L = rng.choice([x for x in range(0, 9) if x != NEED[t]])
            p = mkpkt(t, newseq(), [rng.randrange(256) for _ in range(L)])
        elif cat == "long_l":
            p = [t, rng.randrange(9, 256)] + [rng.randrange(256) for _ in range(rng.randrange(2, 9))]
        elif cat == "long_extra":
            p = mkpkt(t, newseq(), pl) + [rng.randrange(256) for _ in range(rng.randrange(1, 4))]
        else:
            full = mkpkt(t, newseq(), pl)
            p = full[:rng.randrange(1, len(full))]
        await e.send(p)
        res = e.m.read_reg(1)
        got = await e.rd(1)
        assert got == res, f"[{k}:{cat}] RESULT rtl={got} model={res} pkt={p}"
        await e.chk([0x10, CTR_OF[res]], f"[{k}:{cat}]")
        e.check_led(f"[{k}:{cat}]")
        if k % 3 == 2:
            await e.chk(STATE + [7], f"[{k}:{cat}] state")
    await e.chk(ALL, "random end")
