`include "v_macros.svh"

// Port-only checker for the command packet screener: cover points on the LED outputs.
module cps_checker (
    input logic        clk,
    input logic        rst,
    input logic [15:0] led
);
  logic seen_rst = 1'b0;
  logic past_ok = 1'b1;
  always @(posedge clk) if (rst) seen_rst <= 1'b1;

  `V_COVER(C_led_lo_nonzero, led[7:0] != 8'h00) // req: REQ-15
  `V_COVER(C_led_hi_nonzero, led[15:8] != 8'h00) // req: REQ-15
endmodule

bind v2_e_cmd_parser_top cps_checker u_cps_checker (
    .clk(CLK100MHZ),
    .rst(~CPU_RESETN),
    .led(LED)
);
