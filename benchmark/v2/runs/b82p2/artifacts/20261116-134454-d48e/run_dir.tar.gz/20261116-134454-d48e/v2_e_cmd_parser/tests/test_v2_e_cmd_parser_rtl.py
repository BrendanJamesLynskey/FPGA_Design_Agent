import sys
from pathlib import Path

import pytest

for _p in Path(__file__).resolve().parents:
    if (_p / "flow" / "cocotb_run.py").exists():
        sys.path.insert(0, str(_p))
        break

from flow import cocotb_run  # noqa: E402

DESIGN = Path(__file__).resolve().parents[1]
PARAMS = {"CLKS_PER_BIT": 8, "TIMEOUT_CYCLES": 6000}


@pytest.mark.parametrize("seed", [1, 2, 3])
def test_cps_bench(seed):
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN / "rtl").glob("*.sv"))
    cocotb_run.run(
        "v2_e_cmd_parser",
        "v2_e_cmd_parser_top",
        sources,
        "cps_bench",
        DESIGN / "tests",
        parameters=PARAMS,
        seed=seed,
    )
