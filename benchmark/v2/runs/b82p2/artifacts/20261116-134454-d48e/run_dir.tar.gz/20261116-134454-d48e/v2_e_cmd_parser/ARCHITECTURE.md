# Architecture: command packet screener (CPS1)

## Block diagram

```text
 CPU_RESETN --> [reset_sync xpm_cdc_async_rst] --rst(active high)--+
                                                                   |
 UART_TXD_IN --> [ fpga_shell ] <-- win_addr/wr/rd/wdata/rdata --> [ cps_regs ] --> LED[15:0]
 UART_RXD_OUT <-- [          ]                                      |   ^
                                                  byte,end,valid    v   | class, fields
                                                                 [ cps_core ]
                                            (FSM, CRC-32 bytewise, 8-byte payload buffer,
                                             seq compare, timeout)
 CLK100MHZ -> all registers (single domain)
```

## Clock plan

One clock domain: CLK100MHZ, 100 MHz (10 ns), straight from the board oscillator through the input buffer. No MMCM, no derived clocks. The only crossing is the asynchronous CPU_RESETN button, taken in with xpm_cdc_async_rst (asynchronous assert, synchronous release); inside the design the reset is active high and synchronous. The shell handles UART_TXD_IN sampling itself.

## Design notes

- A BYTE write (bit 8 END) starts one byte of processing, finished within 4 clocks. The CRC is a byte-wise CRC-32 (reflected, 0xEDB88320). The CRC runs over every byte except the last 4 before END, so the last four bytes are held in a small shift register.
- Class priority: long, short, bad check, type or length, not new, good. The result codes are those in the RESULT register map.
- Timeout: if no byte arrives for TIMEOUT_CYCLES while a packet is part-way, the packet is dropped as short.
- Six 16-bit wrapping counters; the good-packet fields and last sequence number change only on a good packet.
- LED[7:0] is the good counter low byte and LED[15:8] the last accepted sequence low byte, both registered.

## Pin list

| Port | Dir | Width | Board resource |
|---|---|---|---|
| CLK100MHZ | in | 1 | 100 MHz oscillator |
| CPU_RESETN | in | 1 | CPU RESET button (active low) |
| UART_TXD_IN | in | 1 | USB-UART, host to FPGA |
| UART_RXD_OUT | out | 1 | USB-UART, FPGA to host |
| LED | out | 16 | LD0 to LD15 |

## Predicted resources

LUT 400 to 1200, FF 400 to 1100, BRAM 0, DSP 0.
