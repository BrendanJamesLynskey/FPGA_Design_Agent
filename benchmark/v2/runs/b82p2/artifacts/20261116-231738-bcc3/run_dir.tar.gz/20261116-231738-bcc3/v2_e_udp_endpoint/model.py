import zlib

# Type codes are not given in the spec; assumed: read 1, write 2, status 3,
# telemetry start 4, telemetry stop 5.
T_READ, T_WRITE, T_STATUS, T_TSTART, T_TSTOP = 1, 2, 3, 4, 5


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000000, BUILD_STAMP=0,
                 ID_WORD=1430540337, DEFAULT_PERIOD_TICKS=100, MIN_PERIOD_TICKS=4,
                 MAX_PAYLOAD_BYTES=8, REPLY_BUILD_CYCLES=100, MAX_TICK_WRITE=255):
        self.p = dict(CLKS_PER_BIT=CLKS_PER_BIT, TIMEOUT_CYCLES=TIMEOUT_CYCLES,
                      ID_WORD=ID_WORD, DEF=DEFAULT_PERIOD_TICKS,
                      MINP=MIN_PERIOD_TICKS, MAXP=MAX_PAYLOAD_BYTES,
                      MAXT=MAX_TICK_WRITE)
        self.inputs = {}
        self.reset()

    def reset(self):
        self.buf = []
        self.idle = 0
        self.scratch = [0, 0, 0]
        self.cnt = [0] * 7  # ok, badcrc, short, long, repeat, ooo, err
        self.refused = 0
        self.period = self.p['DEF'] & 0xFFFFFFFF
        self.ticks = 0
        self.pending = 0
        self.tele_on = 0
        self.tele_cnt = 0
        self.last_seq = None
        self.reply = b''
        self.frame = b''
        self.fseq = 0
        self.fcount = 0
        self.ridx = 0
        self.tidx = 0

    # ---- helpers
    def _refuse(self, i):
        self.cnt[i] = (self.cnt[i] + 1) & 0xFFFF
        self.refused = (self.refused + 1) & 0xFFFF

    @staticmethod
    def _pack(typ, status, seq, payload):
        b = bytes([typ | 0x80, status, (seq >> 8) & 255, seq & 255, len(payload)]) + bytes(payload)
        return b + zlib.crc32(b).to_bytes(4, 'little')

    def _word(self, data, i):
        w = data[4 * i:4 * i + 4]
        w = bytes(w) + bytes(4 - len(w))
        return int.from_bytes(w, 'big')

    def _regval(self, r):
        if r == 0:
            return self.p['ID_WORD'] & 0xFFFFFFFF
        if r in (1, 2, 3):
            return self.scratch[r - 1]
        if r == 4:
            return self.cnt[0]
        if r == 5:
            return self.refused
        if r == 6:
            return self.period
        return self.ticks & 0xFFFFFFFF

    def _packet(self, b):
        n = len(b)
        self.reply = b''
        if n < 4:
            return self._refuse(2)
        ln = b[1]
        if ln > self.p['MAXP'] or n > 8 + ln:
            return self._refuse(3)
        if n < 8 + ln:
            return self._refuse(2)
        if zlib.crc32(bytes(b[:-4])) != int.from_bytes(bytes(b[-4:]), 'little'):
            return self._refuse(1)
        typ = b[0]
        seq = (b[2] << 8) | b[3]
        pl = b[4:4 + ln]
        need = {T_READ: 2, T_WRITE: 6, T_TSTART: 2, T_STATUS: 0, T_TSTOP: 0}
        if typ not in need:
            self._refuse(6)
            self.reply = self._pack(typ, 1, seq, b'')
            return
        if ln != need[typ]:
            self._refuse(6)
            self.reply = self._pack(typ, 2, seq, b'')
            return
        if self.last_seq is not None:
            d = (seq - self.last_seq) & 0xFFFF
            if not (1 <= d <= 32767):
                self._refuse(4 if d == 0 else 5)
                self.reply = self._pack(typ, 4, seq, b'')
                return
        self.last_seq = seq
        status = 0
        payload = b''
        if typ == T_READ:
            r = (pl[0] << 8) | pl[1]
            if r >= 8:
                status = 3
            else:
                payload = self._regval(r).to_bytes(4, 'big')
        elif typ == T_WRITE:
            r = (pl[0] << 8) | pl[1]
            v = int.from_bytes(bytes(pl[2:6]), 'big')
            if r >= 8:
                status = 3
            elif r in (0, 4, 5, 6, 7):
                status = 5
            else:
                self.scratch[r - 1] = v
        elif typ == T_STATUS:
            vals = self.cnt + [self.fcount]
            payload = b''.join(v.to_bytes(2, 'big') for v in vals) + bytes([self.tele_on])
        elif typ == T_TSTART:
            per = (pl[0] << 8) | pl[1]
            if per != 0:
                self.period = max(per, self.p['MINP'])
            self.tele_on = 1
            self.tele_cnt = 0
        elif typ == T_TSTOP:
            self.tele_on = 0
            self.frame = b''
        if status:
            self._refuse(6)
            payload = b''
        else:
            self.cnt[0] = (self.cnt[0] + 1) & 0xFFFF
        self.reply = self._pack(typ, status, seq, payload)

    def _tick(self):
        self.ticks = (self.ticks + 1) & 0xFFFFFFFF
        if not self.tele_on:
            return
        self.tele_cnt += 1
        if self.tele_cnt >= self.period:
            self.tele_cnt = 0
            if not self.frame:
                pay = (self.ticks.to_bytes(4, 'big') + self.cnt[0].to_bytes(2, 'big')
                       + self.refused.to_bytes(2, 'big'))
                b = bytes([0xC0, 0, self.fseq >> 8, self.fseq & 255, 8]) + pay
                self.frame = b + zlib.crc32(b).to_bytes(4, 'little')
                self.fseq = (self.fseq + 1) & 0xFFFF
                self.fcount = (self.fcount + 1) & 0xFFFF

    # ---- API
    def step(self, inputs=None):
        if inputs:
            self.inputs.update(inputs)
        if self.pending > 0:
            self.pending -= 1
            self._tick()
        if self.buf:
            self.idle += 1
            if self.idle >= self.p['TIMEOUT_CYCLES']:
                self.buf = []
                self.idle = 0
                self.reply = b''
                self._refuse(2)
        return {'UART_RXD_OUT': 1, 'LED': self.cnt[0]}

    def write_reg(self, offset, value):
        value = int(value)
        if offset == 0:
            self.buf.append(value & 0xFF)
            self.idle = 0
            if value & 0x100:
                b = self.buf
                self.buf = []
                self._packet(b)
        elif offset == 1:
            self.pending = min(self.pending + (value & 0xFF), 255)
        elif offset == 3:
            self.ridx = value & 0x7F
        elif offset == 6:
            self.tidx = value & 0x7F
        elif offset == 8:
            self.frame = b''

    def read_reg(self, offset):
        if offset == 2:
            return len(self.reply)
        if offset == 3:
            return self.ridx
        if offset == 4:
            return self._word(self.reply, self.ridx)
        if offset == 5:
            return len(self.frame)
        if offset == 6:
            return self.tidx
        if offset == 7:
            return self._word(self.frame, self.tidx)
        if offset == 9:
            return self.tele_on | ((1 if (self.buf or self.pending) else 0) << 1)
        return 0
