"""cocotb bench for v2_e_udp_endpoint: drives the design through the test shell (UART) and
compares every register read with the reference model (model.py)."""
import random
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ClockCycles, FallingEdge, RisingEdge  # noqa: E402
from cocotb.utils import get_sim_time  # noqa: E402

# Small values, identical to the parameters passed by tests/test_v2_e_udp_endpoint_rtl.py
CPB = 8
TMO = 20000

T_READ, T_WRITE, T_STATUS, T_TSTART, T_TSTOP = (model.T_READ, model.T_WRITE, model.T_STATUS,
                                                model.T_TSTART, model.T_TSTOP)
ID_WORD = 0x55445031


def rd_p(r):
    return r.to_bytes(2, "big")


def wr_p(r, v):
    return r.to_bytes(2, "big") + (v & 0xFFFFFFFF).to_bytes(4, "big")


def pkt(typ, seq, payload=b"", ln=None, bad=False):
    ln = len(payload) if ln is None else ln
    b = bytes([typ & 255, ln & 255, (seq >> 8) & 255, seq & 255]) + bytes(payload)
    c = zlib.crc32(b)
    if bad:
        c ^= 0x00010000
    return b + c.to_bytes(4, "little")


def parse(rep):
    if rep is None:
        return None
    plen = rep[4]
    assert len(rep) == 9 + plen, f"reply length {len(rep)} vs payload {plen}"
    return rep[0], rep[1], (rep[2] << 8) | rep[3], bytes(rep[5:5 + plen])


def exp_frame(seq, ticks, cmds, refused):
    b = (bytes([0xC0, 0, seq >> 8, seq & 255, 8]) + ticks.to_bytes(4, "big")
         + cmds.to_bytes(2, "big") + refused.to_bytes(2, "big"))
    return b + zlib.crc32(b).to_bytes(4, "little")


class Env:
    def __init__(self, dut):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        self.cpb = CPB
        self.cyc = 0
        self.mcyc = 0
        self.rx = []
        self.starts = []
        self.widths = []
        self.m = None
        self.last = {"LED": 0}

    @classmethod
    async def create(cls, dut):
        env = cls(dut)
        await env.reset(first=True)
        return env

    async def _count(self):
        while True:
            await RisingEdge(self.clk)
            self.cyc += 1

    async def _rx_mon(self):
        sig = self.dut.UART_RXD_OUT
        while True:
            await FallingEdge(sig)
            t0 = self.cyc
            await ClockCycles(self.clk, self.cpb // 2)
            if int(sig.value) != 0:
                continue
            v = 0
            for i in range(8):
                await ClockCycles(self.clk, self.cpb)
                v |= int(sig.value) << i
            await ClockCycles(self.clk, self.cpb)
            assert int(sig.value) == 1, "UART framing error on the design's transmitter"
            self.rx.append(v)
            self.starts.append(t0)

    async def _width_mon(self):
        sig = self.dut.UART_RXD_OUT
        while True:
            await FallingEdge(sig)
            t0 = get_sim_time("ns")
            await RisingEdge(sig)
            self.widths.append(get_sim_time("ns") - t0)

    async def reset(self, first=False):
        d = self.dut
        if first:
            d.CPU_RESETN.value = 0
            d.UART_TXD_IN.value = 1
            try:
                cl = Clock(self.clk, 10, "ns")
            except TypeError:
                cl = Clock(self.clk, 10, units="ns")
            cocotb.start_soon(cl.start())
            cocotb.start_soon(self._count())
            await ClockCycles(self.clk, 6)
        else:
            await FallingEdge(self.clk)
            d.CPU_RESETN.value = 0
            d.UART_TXD_IN.value = 1
            await ClockCycles(self.clk, 4)
        await FallingEdge(self.clk)
        d.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 40)
        self.m = model.Model(CLKS_PER_BIT=CPB, TIMEOUT_CYCLES=TMO)
        self.mcyc = self.cyc
        self.last = {"LED": 0}
        self.rx.clear()
        if first:
            cocotb.start_soon(self._rx_mon())
            cocotb.start_soon(self._width_mon())
        assert int(d.LED.value) == 0

    def sync(self):
        n = self.cyc - self.mcyc
        self.mcyc = self.cyc
        for _ in range(n):
            self.last = self.m.step()

    def check_led(self):
        got = int(self.dut.LED.value)
        assert got == self.last["LED"], f"LED {got} != model {self.last['LED']}"

    async def idle(self, n):
        await ClockCycles(self.clk, n)
        self.sync()

    async def tx_byte(self, b):
        bits = [0] + [(b >> i) & 1 for i in range(8)] + [1]
        for bit in bits:
            self.dut.UART_TXD_IN.value = bit
            await ClockCycles(self.clk, self.cpb)

    async def xact(self, cmd, addr, data):
        self.rx.clear()
        body = bytes([cmd, addr]) + (data & 0xFFFFFFFF).to_bytes(4, "little")
        chk = 0
        for x in body:
            chk ^= x
        for b in bytes([0xA5]) + body + bytes([chk]):
            await self.tx_byte(b)
        n = 0
        while len(self.rx) < 7:
            await RisingEdge(self.clk)
            n += 1
            assert n < 100 * self.cpb * 10, "no shell response"
        resp = list(self.rx[:7])
        assert resp[0] == 0x5A
        c = 0
        for x in resp[1:6]:
            c ^= x
        assert c == resp[6], "shell response checksum"
        return resp[1], int.from_bytes(bytes(resp[2:6]), "little")

    async def wr(self, off, val):
        self.sync()
        st, _ = await self.xact(2, 0x80 + off, val)
        assert st == 0, f"shell write status {st}"
        self.m.write_reg(off, val)
        self.sync()
        self.check_led()

    async def rd(self, off):
        self.sync()
        st, d = await self.xact(1, 0x80 + off, 0)
        assert st == 0, f"shell read status {st}"
        exp = self.m.read_reg(off)
        assert d == exp, f"window reg {off}: design 0x{d:08X} model 0x{exp:08X}"
        self.sync()
        self.check_led()
        return d

    async def _readback(self, lenreg, idxreg, wordreg, beyond):
        ln = await self.rd(lenreg)
        nw = (ln + 3) // 4 + (1 if beyond else 0)
        data = b""
        for i in range(nw):
            await self.wr(idxreg, i)
            data += (await self.rd(wordreg)).to_bytes(4, "big")
        if ln == 0:
            assert not any(data)
            return None
        body = data[:ln]
        assert zlib.crc32(body[:-4]) == int.from_bytes(body[-4:], "little"), "CRC-32 of the readback"
        assert not any(data[ln:]), "bytes past the end must read 0"
        return body

    async def check_reply(self, beyond=False):
        return await self._readback(2, 3, 4, beyond)

    async def check_tele(self, beyond=False):
        f = await self._readback(5, 6, 7, beyond)
        if f is not None:
            assert len(f) == 17 and f[0] == 0xC0 and f[1] == 0 and f[4] == 8
        return f

    async def send(self, raw, beyond=False):
        for i, b in enumerate(raw):
            await self.wr(0, b | (0x100 if i == len(raw) - 1 else 0))
        return await self.check_reply(beyond)

    async def cmd(self, typ, seq, payload=b"", ln=None, bad=False, cut=None, extra=b"",
                  expect=-1, beyond=False):
        raw = pkt(typ, seq, payload, ln, bad)
        if cut is not None:
            raw = raw[:cut]
        raw += bytes(extra)
        p = parse(await self.send(raw, beyond))
        if expect == "drop":
            assert p is None, "dropped packet must earn no reply"
        elif expect != -1:
            assert p is not None, "a reply was expected"
            assert p[1] == expect, f"status {p[1]} expected {expect}"
        if p is not None:
            assert p[0] == ((typ | 0x80) & 255) and p[2] == seq
        return p

    async def regread(self, seq, r):
        p = await self.cmd(T_READ, seq, rd_p(r), expect=0)
        assert len(p[3]) == 4
        return int.from_bytes(p[3], "big")

    async def status(self, seq):
        p = await self.cmd(T_STATUS, seq, expect=0)
        assert len(p[3]) == 17
        v = [int.from_bytes(p[3][2 * i:2 * i + 2], "big") for i in range(8)]
        return v + [p[3][16]]


# ---------------------------------------------------------------- directed tests

# req: REQ-45, REQ-21, REQ-18, REQ-22, REQ-42
@cocotb.test()
async def test_reset_values(dut):
    env = await Env.create(dut)
    assert int(dut.UART_RXD_OUT.value) == 1
    for off in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 0x7F):
        assert await env.rd(off) == 0
    for off in (2, 4, 5, 7, 9, 10, 0x55):
        await env.wr(off, 0xFFFFFFFF)
    for off in (2, 3, 4, 5, 6, 7, 9, 10):
        assert await env.rd(off) == 0
    await env.wr(3, 0xFFFFFFFF)
    assert await env.rd(3) == 0x7F
    await env.wr(6, 0x1FF)
    assert await env.rd(6) == 0x7F
    await env.wr(3, 0)
    await env.wr(6, 0)
    assert await env.regread(1, 6) == 100
    assert await env.regread(2, 7) == 0
    for r in (1, 2, 3):
        assert await env.regread(2 + r, r) == 0


# req: REQ-17, REQ-18, REQ-21, REQ-22, REQ-08, REQ-20
@cocotb.test()
async def test_register_reads(dut):
    env = await Env.create(dut)
    p = await env.cmd(T_READ, 0x0010, rd_p(0), expect=0, beyond=True)
    assert p[3] == bytes([0x55, 0x44, 0x50, 0x31])
    assert await env.regread(0x11, 4) == 1  # count before this read is counted
    assert await env.regread(0x12, 4) == 2
    assert await env.regread(0x13, 5) == 0
    await env.cmd(T_READ, 0x14, rd_p(9), expect=3)
    assert await env.regread(0x15, 5) == 1  # refused count before this read
    assert await env.regread(0x16, 6) == 100
    assert await env.regread(0x17, 7) == 0
    await env.wr(1, 9)
    assert await env.regread(0x18, 7) == 9
    for i, r in enumerate((8, 9, 255, 256, 0xFFFF)):
        await env.cmd(T_READ, 0x20 + i, rd_p(r), expect=3)


# req: REQ-19, REQ-09, REQ-10
@cocotb.test()
async def test_scratch_and_readonly(dut):
    env = await Env.create(dut)
    vals = {1: 0xDEADBEEF, 2: 0x00000001, 3: 0xFFFFFFFF}
    s = 1
    for r, v in vals.items():
        await env.cmd(T_WRITE, s, wr_p(r, v), expect=0)
        s += 1
    for r, v in vals.items():
        assert await env.regread(s, r) == v
        s += 1
    await env.cmd(T_WRITE, s, wr_p(2, 0), expect=0)
    s += 1
    assert await env.regread(s, 2) == 0
    s += 1
    assert await env.regread(s, 1) == vals[1]
    s += 1
    before = {}
    for r in (0, 1, 2, 3, 6, 7):
        before[r] = await env.regread(s, r)
        s += 1
    for r in (0, 4, 5, 6, 7):
        await env.cmd(T_WRITE, s, wr_p(r, 0x12345678), expect=5)
        s += 1
    for r in (0, 1, 2, 3, 6, 7):
        assert await env.regread(s, r) == before[r]
        s += 1
    assert before[0] == ID_WORD


# req: REQ-02, REQ-03, REQ-04, REQ-42, REQ-25, REQ-26, REQ-24
@cocotb.test()
async def test_drop_rules(dut):
    env = await Env.create(dut)
    s = 1
    full = pkt(T_READ, s, rd_p(0))
    for n in (1, 2, 3):
        await env.cmd(T_READ, s, rd_p(0), cut=n, expect="drop")
    await env.cmd(T_READ, s, rd_p(0), cut=len(full) - 1, expect="drop")
    await env.cmd(T_READ, s, rd_p(0), cut=4, expect="drop")
    await env.cmd(T_READ, s, rd_p(0), bad=True, expect="drop")
    await env.cmd(T_STATUS, s, bad=True, expect="drop")
    await env.cmd(T_READ, s, bytes(9), ln=9, expect="drop")
    await env.cmd(T_READ, s, rd_p(0), extra=b"\x00", expect="drop")
    await env.cmd(T_READ, s, rd_p(0), extra=b"\x01\x02", expect="drop")
    await env.cmd(T_READ, s, b"", ln=255, cut=5, expect="drop")
    v = await env.status(1)  # the first accepted packet may carry any number
    assert v == [0, 2, 5, 4, 0, 0, 0, 0, 0], v
    assert await env.regread(2, 5) == 11
    assert await env.regread(3, 4) == 2


# req: REQ-05, REQ-06, REQ-07, REQ-08, REQ-09
@cocotb.test()
async def test_judging_order(dut):
    env = await Env.create(dut)
    s = 0x100
    await env.cmd(T_READ, s, b"", ln=200, cut=3, expect="drop")           # short beats long
    await env.cmd(T_READ, s, b"\0\0\0", ln=9, cut=5, expect="drop")       # long
    await env.cmd(T_READ, s, bytes(9), ln=9, bad=True, expect="drop")     # long beats bad check
    await env.cmd(T_READ, s, rd_p(0), bad=True, extra=b"\0", expect="drop")
    await env.cmd(0x77, s, b"\1\2", bad=True, cut=9, expect="drop")       # short beats bad check
    await env.cmd(0x77, s, b"", bad=True, expect="drop")                  # bad check beats unknown type
    await env.cmd(0x77, s, b"\1\2\3", expect=1)                           # unknown type beats length
    await env.cmd(0x00, s, b"", expect=1)
    await env.cmd(T_READ, s, b"\1\2\3", expect=2)                         # wrong length
    await env.cmd(T_STATUS, s, b"\1", expect=2)
    await env.cmd(T_WRITE, s, rd_p(1), expect=2)
    await env.cmd(T_TSTART, s, b"", expect=2)
    await env.cmd(T_TSTOP, s, b"\0", expect=2)
    await env.cmd(T_READ, s, rd_p(0), expect=0)                           # sequence accepted
    await env.cmd(T_READ, s, b"\1\2\3", expect=2)                         # length beats sequence
    await env.cmd(T_READ, s, rd_p(9), expect=4)                           # sequence beats register
    await env.cmd(T_WRITE, s, wr_p(0, 5), expect=4)                       # sequence beats access
    await env.cmd(T_READ, s + 1, rd_p(8), expect=3)
    await env.cmd(T_WRITE, s + 2, wr_p(8, 5), expect=3)                   # register beats access
    await env.cmd(T_WRITE, s + 3, wr_p(0, 5), expect=5)
    await env.cmd(T_WRITE, s + 4, wr_p(300, 5), expect=3)
    await env.cmd(T_WRITE, s + 5, wr_p(7, 5), expect=5)
    await env.cmd(T_TSTART, s + 6, b"\0\0", expect=0)
    await env.cmd(T_TSTOP, s + 7, expect=0)
    await env.cmd(T_STATUS, s + 8, expect=0)


# req: REQ-11, REQ-12, REQ-13, REQ-14, REQ-15, REQ-16
@cocotb.test()
async def test_sequence_rules(dut):
    env = await Env.create(dut)
    await env.cmd(T_READ, 0x8000, rd_p(1), expect=0)           # first packet: any number
    await env.cmd(T_READ, 0x8001, rd_p(1), expect=0)
    await env.cmd(T_READ, 0x0000, rd_p(1), expect=0)           # +32767 with wrap
    await env.cmd(T_READ, 0x8000, rd_p(1), expect=4)           # +32768 refused
    await env.cmd(T_READ, 0x0000, rd_p(1), expect=4)           # repeat
    await env.cmd(T_READ, 0xFFFF, rd_p(1), expect=4)           # old
    await env.cmd(T_READ, 0x0001, rd_p(1), expect=0)
    await env.cmd(T_WRITE, 0x0001, wr_p(1, 0x1234), expect=4)  # REQ-13
    assert await env.regread(2, 1) == 0
    await env.cmd(T_READ, 0x8002, rd_p(0), expect=4)           # REQ-14: refused number not kept
    await env.cmd(T_READ, 3, rd_p(0), expect=0)
    await env.cmd(T_TSTART, 4, b"\x00\x04", expect=0)
    await env.cmd(T_TSTOP, 4, expect=4)                        # REQ-15
    assert (await env.rd(9)) & 1 == 1
    await env.cmd(T_TSTART, 4, b"\x00\x32", expect=4)
    assert await env.regread(5, 6) == 4
    await env.cmd(T_READ, 6, rd_p(9), expect=3)                # REQ-16: number kept
    await env.cmd(T_READ, 6, rd_p(0), expect=4)
    await env.cmd(T_READ, 7, rd_p(0), expect=0)
    await env.cmd(T_WRITE, 8, wr_p(0, 1), expect=5)
    await env.cmd(T_READ, 8, rd_p(0), expect=4)
    await env.cmd(0x77, 9, b"", expect=1)                      # unknown type does not use the number
    await env.cmd(T_READ, 9, rd_p(0), expect=0)
    v = await env.status(10)
    assert v[4] == 6 and v[5] == 3 and v[6] == 3, v


# req: REQ-23, REQ-20, REQ-25, REQ-26, REQ-44, REQ-01
@cocotb.test()
async def test_status_counters(dut):
    env = await Env.create(dut)
    s = 0x1234
    v = await env.status(s)
    assert v == [0] * 9
    await env.wr(0, 0x100 | 0x55)                              # 1 byte: short
    await env.cmd(T_READ, 0, cut=3, expect="drop")             # short
    await env.cmd(T_READ, 0x1235, rd_p(0), bad=True, expect="drop")
    await env.cmd(T_READ, 0x1235, bytes(9), ln=9, expect="drop")
    await env.cmd(T_READ, 0x1235, rd_p(0), extra=b"\0", expect="drop")
    await env.cmd(T_READ, 0x1235, rd_p(0), cut=9, expect="drop")
    await env.cmd(0x77, 0x1235, b"", expect=1)
    await env.cmd(T_READ, 0x1235, b"\1\2\3", expect=2)
    await env.cmd(T_READ, 0x1235, rd_p(0), expect=0)
    await env.cmd(T_READ, 0x1235, rd_p(0), expect=4)
    await env.cmd(T_READ, 0x1000, rd_p(0), expect=4)
    await env.cmd(T_READ, 0x9235, rd_p(0), expect=4)
    await env.cmd(T_READ, 0x1236, rd_p(9), expect=3)
    await env.cmd(T_WRITE, 0x1237, wr_p(4, 1), expect=5)
    v = await env.status(0x1238)
    assert v == [2, 1, 3, 2, 1, 2, 4, 0, 0], v
    assert int(dut.LED.value) == 3
    assert await env.regread(0x1239, 5) == 13
    assert int(dut.LED.value) == 4
    assert await env.regread(0x123A, 4) == 4
    assert int(dut.LED.value) == 5
    p = await env.cmd(T_STATUS, 0x123B, expect=0, beyond=True)
    assert len(p[3]) == 17


# req: REQ-44
@cocotb.test()
async def test_led_count(dut):
    env = await Env.create(dut)
    for i in range(6):
        await env.cmd(T_READ, i + 1, rd_p(0), expect=0)
        assert int(dut.LED.value) == i + 1
    await env.cmd(T_READ, 7, rd_p(9), expect=3)
    assert int(dut.LED.value) == 6
    await env.cmd(T_READ, 7, rd_p(0), expect=4)
    assert int(dut.LED.value) == 6


# req: REQ-24, REQ-25, REQ-26, REQ-42
@cocotb.test()
async def test_counter_burst(dut):
    env = await Env.create(dut)
    rng = random.Random(7)
    for _ in range(150):
        await env.wr(0, 0x100 | rng.randrange(256))
    assert await env.rd(2) == 0
    v = await env.status(1)
    assert v[2] == 150 and v[0] == 0
    assert await env.regread(2, 5) == 150
    assert await env.regread(3, 4) == 2


# req: REQ-27, REQ-30, REQ-31, REQ-32, REQ-33, REQ-34, REQ-35, REQ-36, REQ-37, REQ-38, REQ-39
@cocotb.test()
async def test_telemetry_basic(dut):
    env = await Env.create(dut)
    s = 0x0100
    await env.cmd(T_TSTART, s, b"\x00\x0a", expect=0)
    cm, rf, tk = 1, 0, 0
    assert (await env.rd(9)) & 1 == 1
    await env.wr(1, 7)
    tk += 7
    assert await env.rd(5) == 0
    await env.wr(1, 3)
    tk += 3
    f = await env.check_tele(beyond=True)
    assert f == exp_frame(0, tk, cm, rf), f
    await env.cmd(T_READ, s + 1, rd_p(0), expect=0)
    cm += 1
    assert await env.check_tele() == exp_frame(0, 10, 1, 0)   # values as at the due tick
    await env.wr(1, 10)
    tk += 10
    assert await env.check_tele() == exp_frame(0, 10, 1, 0)   # dropped, not queued
    v = await env.status(s + 2)
    cm += 1
    assert v[7] == 1 and v[8] == 1
    await env.wr(8, 0)                                         # take
    assert await env.rd(5) == 0
    await env.wr(1, 10)
    tk += 10
    assert await env.check_tele() == exp_frame(1, tk, cm, rf)
    await env.wr(8, 1)
    await env.cmd(T_TSTOP, s + 3, expect=0)
    cm += 1
    assert (await env.rd(9)) & 1 == 0
    await env.wr(1, 20)
    tk += 20
    assert await env.rd(5) == 0
    await env.cmd(T_TSTART, s + 4, b"\x00\x00", expect=0)      # keeps period 10
    cm += 1
    await env.wr(1, 10)
    tk += 10
    assert await env.check_tele() == exp_frame(2, tk, cm, rf)  # sequence not cleared by stop/start
    await env.cmd(T_TSTOP, s + 5, expect=0)                    # stop forgets the held frame
    cm += 1
    assert await env.rd(5) == 0
    assert await env.check_tele(beyond=True) is None
    await env.wr(8, 0)                                         # take with no frame
    assert await env.rd(5) == 0
    await env.cmd(T_TSTART, s + 6, b"\x00\x00", expect=0)
    cm += 1
    await env.wr(1, 7)
    tk += 7
    await env.cmd(T_TSTART, s + 7, b"\x00\x00", expect=0)      # restarts the tick count
    cm += 1
    await env.wr(1, 5)
    tk += 5
    assert await env.rd(5) == 0
    await env.wr(1, 5)
    tk += 5
    assert await env.check_tele() == exp_frame(3, tk, cm, rf)
    await env.wr(8, 0)
    await env.wr(0, 0x100 | 0x42)                              # refused: short
    rf += 1
    await env.wr(1, 10)
    tk += 10
    assert await env.check_tele() == exp_frame(4, tk, cm, rf)
    v = await env.status(s + 8)
    assert v[7] == 5 and v[8] == 1


# req: REQ-27, REQ-28, REQ-29, REQ-30
@cocotb.test()
async def test_telemetry_period(dut):
    env = await Env.create(dut)
    s = 1
    for P, eff in ((2, 4), (3, 4), (1, 4), (4, 4), (5, 5), (0, 5), (300, 300), (0, 300), (7, 7)):
        await env.cmd(T_TSTART, s, P.to_bytes(2, "big"), expect=0)
        s += 1
        assert await env.regread(s, 6) == eff
        s += 1
        await env.wr(8, 0)
        if eff <= 7:
            await env.wr(1, eff - 1)
            assert await env.rd(5) == 0
            await env.wr(1, 1)
            assert await env.rd(5) == 17
            await env.wr(8, 0)
        else:
            await env.wr(1, 255)
            assert await env.rd(5) == 0
            await env.wr(1, 45)
            assert await env.rd(5) == 17
            await env.wr(8, 0)


# req: REQ-22, REQ-40, REQ-30
@cocotb.test()
async def test_tick_register(dut):
    env = await Env.create(dut)
    tot = 0
    s = 1
    for n in (0, 1, 255, 17, 0, 100):
        await env.wr(1, n)
        tot += n
        assert await env.regread(s, 7) == tot
        s += 1
    await env.cmd(T_TSTART, s, b"\x00\x04", expect=0)
    s += 1
    await env.wr(1, 255)
    tot += 255
    f = await env.check_tele()
    assert f[5:9] == (tot - 255 + 4).to_bytes(4, "big")      # frame holds the tick count of the due tick
    assert await env.regread(s, 7) == tot


# req: REQ-41, REQ-42, REQ-39
@cocotb.test()
async def test_readback_words(dut):
    env = await Env.create(dut)
    await env.cmd(T_STATUS, 1, expect=0)
    assert await env.rd(2) == 26
    body = await env.check_reply(beyond=True)
    assert len(body) == 26
    await env.wr(3, 5)
    assert await env.rd(3) == 5
    assert await env.rd(4) == int.from_bytes(body[20:24], "big")
    await env.wr(3, 6)
    assert await env.rd(4) == int.from_bytes(body[24:26] + b"\0\0", "big")
    for i in (7, 8, 64, 127):
        await env.wr(3, i)
        assert await env.rd(4) == 0
    await env.wr(3, 0)
    assert await env.rd(4) == int.from_bytes(body[0:4], "big")
    await env.wr(6, 3)
    assert await env.rd(6) == 3
    assert await env.rd(7) == 0
    await env.cmd(T_TSTART, 2, b"\x00\x04", expect=0)
    await env.wr(1, 4)
    assert await env.rd(5) == 17
    for i in (0, 1, 2, 3, 4, 5, 127):
        await env.wr(6, i)
        w = await env.rd(7)
        if i >= 5:
            assert w == 0
    await env.cmd(T_READ, 3, rd_p(0), expect=0)
    assert await env.rd(2) == 13
    await env.wr(3, 0)
    assert await env.rd(4) == 0x81000003
    await env.cmd(T_READ, 3, rd_p(0), cut=2, expect="drop")
    assert await env.rd(2) == 0


# req: REQ-38, REQ-39
@cocotb.test()
async def test_busy_and_stat(dut):
    env = await Env.create(dut)
    assert await env.rd(9) == 0
    raw = pkt(T_READ, 1, rd_p(0))
    await env.wr(0, raw[0])
    assert (await env.rd(9)) & 2 == 2
    for b in raw[1:-1]:
        await env.wr(0, b)
    assert (await env.rd(9)) & 2 == 2
    await env.wr(0, raw[-1] | 0x100)
    assert (await env.rd(9)) & 2 == 0
    await env.check_reply()
    await env.cmd(T_TSTART, 2, b"\x00\x08", expect=0)
    assert await env.rd(9) == 1
    await env.wr(0, 0x01)
    assert await env.rd(9) == 3
    await env.wr(0, 0x101)
    assert await env.rd(9) == 1
    await env.cmd(T_TSTOP, 3, expect=0)
    assert await env.rd(9) == 0


# req: REQ-02, REQ-42
@cocotb.test()
async def test_timeout_partial(dut):
    env = await Env.create(dut)
    await env.cmd(T_READ, 1, rd_p(0), expect=0)
    assert await env.rd(2) == 13
    raw = pkt(T_READ, 2, rd_p(0))
    for b in raw[:5]:
        await env.wr(0, b)
    assert (await env.rd(9)) & 2 == 2
    await env.idle(2 * TMO + 500)
    assert (await env.rd(9)) & 2 == 0
    assert await env.rd(2) == 0
    v = await env.status(3)
    assert v[2] == 1 and v[0] == 1
    assert await env.regread(4, 5) == 1


# req: REQ-45, REQ-12, REQ-34, REQ-36, REQ-21, REQ-18
@cocotb.test()
async def test_reset_midway(dut):
    env = await Env.create(dut)
    await env.cmd(T_WRITE, 5, wr_p(1, 0xAAAA5555), expect=0)
    await env.cmd(T_TSTART, 6, b"\x00\x05", expect=0)
    await env.cmd(T_TSTART, 7, b"\x00\x09", expect=0)
    await env.wr(1, 20)
    await env.wr(3, 4)
    await env.wr(6, 2)
    await env.cmd(T_READ, 8, rd_p(9), expect=3)
    for b in pkt(T_READ, 9, rd_p(0))[:4]:
        await env.wr(0, b)
    await env.reset()
    assert int(dut.LED.value) == 0
    for off in (2, 3, 4, 5, 6, 7, 9):
        assert await env.rd(off) == 0
    assert await env.regread(5, 1) == 0                       # first packet any number (older than before)
    assert await env.regread(6, 6) == 100
    assert await env.regread(7, 7) == 0
    assert await env.regread(8, 4) == 3
    assert await env.regread(9, 5) == 0
    v = await env.status(10)
    assert v[:7] == [5, 0, 0, 0, 0, 0, 0] and v[7] == 0 and v[8] == 0
    await env.cmd(T_TSTART, 11, b"\x00\x00", expect=0)
    await env.wr(1, 100)
    f = await env.check_tele()
    assert f[2:4] == b"\x00\x00"                              # frame sequence restarted at 0
    await env.reset()
    assert await env.rd(9) == 0 and await env.rd(5) == 0


# req: REQ-47
@cocotb.test()
async def test_uart_timing(dut):
    env = await Env.create(dut)
    await env.rd(2)
    assert len(env.starts) >= 7
    # first byte of a response is 0x5A: start bit and bit 0 are both low = 2 bit times
    assert abs(env.widths[0] - 2 * CPB * 10) <= 10, f"low pulse {env.widths[0]} ns for CLKS_PER_BIT {CPB}"
    seq = env.starts[-7:]
    gaps = [b - a for a, b in zip(seq, seq[1:])]
    assert all(g >= 10 * CPB - 1 for g in gaps), gaps
    # back-to-back bytes: a few idle clocks between frames are allowed, below one bit time
    assert min(gaps) <= 10 * CPB + CPB, gaps


# req: REQ-43, REQ-42
@cocotb.test()
async def test_reply_ready(dut):
    env = await Env.create(dut)
    raw = pkt(T_READ, 1, rd_p(0))
    for i, b in enumerate(raw):
        await env.wr(0, b | (0x100 if i == len(raw) - 1 else 0))
    # first access after the end flag: reply is already complete and the block ready again
    assert await env.rd(2) == 13
    await env.cmd(T_READ, 2, rd_p(0), expect=0)
    await env.cmd(T_READ, 3, rd_p(0), expect=0)


# ---------------------------------------------------------------- constrained random

def rand_packet(rng, st):
    typ = rng.choices([1, 2, 3, 4, 5, 0, 9, 0x41, 0x81, 0xC0],
                      weights=[18, 18, 12, 12, 8, 4, 3, 2, 2, 2])[0]
    reg = rng.choice([0, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 8, 9, 255, 256, 0xFFFF])
    val = rng.choice([0, 1, 0xFFFFFFFF, rng.getrandbits(32)])
    if typ == 1:
        pl = rd_p(reg)
    elif typ == 2:
        pl = wr_p(reg, val)
    elif typ == 4:
        pl = rng.choice([0, 1, 3, 4, 5, 6, 9, 16]).to_bytes(2, "big")
    else:
        pl = b""
    if rng.random() < 0.15:
        pl = (pl + bytes(rng.getrandbits(8) for _ in range(8)))[:rng.randint(0, 8)]
    r = rng.random()
    if r < 0.65:
        st["seq"] = (st["seq"] + rng.choice([1, 1, 1, 2, 100, 32767])) & 0xFFFF
        seq = st["seq"]
    elif r < 0.75:
        seq = st["seq"]
    elif r < 0.85:
        seq = (st["seq"] - rng.randint(1, 50)) & 0xFFFF
    elif r < 0.9:
        seq = (st["seq"] + 32768) & 0xFFFF
    else:
        seq = rng.getrandbits(16)
    ln = None
    bad = False
    cut = None
    extra = b""
    c = rng.random()
    if c < 0.08:
        bad = True
    elif c < 0.14:
        cut = rng.randint(1, 4 + len(pl) + 3)
    elif c < 0.18:
        extra = bytes(rng.getrandbits(8) for _ in range(rng.randint(1, 3)))
    elif c < 0.21:
        ln = rng.randint(9, 255)
    elif c < 0.23:
        cut = 1
    return typ, seq, pl, ln, bad, cut, extra


# req: REQ-01, REQ-05, REQ-11, REQ-20, REQ-23, REQ-25, REQ-26, REQ-30, REQ-31, REQ-32, REQ-33, REQ-35, REQ-39, REQ-40, REQ-41, REQ-44
@cocotb.test()
async def test_random_traffic(dut):
    seed = getattr(cocotb, "RANDOM_SEED", 1)
    rng = random.Random(seed)
    env = await Env.create(dut)
    st = {"seq": rng.getrandbits(16)}
    await env.cmd(T_TSTART, st["seq"], rng.choice([4, 5, 6, 8]).to_bytes(2, "big"))
    for it in range(30):
        a = rng.random()
        if a < 0.2:
            await env.wr(1, rng.choice([0, 1, 3, 7, 16, 100, 255]))
        elif a < 0.28:
            await env.wr(8, rng.getrandbits(8))
        elif a < 0.33:
            await env.wr(3, rng.randint(0, 255))
            await env.rd(3)
            await env.rd(4)
            await env.wr(6, rng.randint(0, 255))
            await env.rd(6)
            await env.rd(7)
        else:
            typ, seq, pl, ln, bad, cut, extra = rand_packet(rng, st)
            await env.cmd(typ, seq, pl, ln=ln, bad=bad, cut=cut, extra=extra)
        await env.check_tele()
        await env.rd(9)
    # final status command: accepted or refused depending on the random history, the model decides
    await env.cmd(T_STATUS, (st["seq"] + 1) & 0xFFFF)
