# UDP endpoint architecture

Single 100 MHz clock (CLK100MHZ), no derived clocks. The test shell (fpga_shell) bridges the USB-UART to a register window; the endpoint lives behind that window.

## Block diagram

```text
 UART_TXD_IN --> [fpga_shell] --win_*--> [shell_regs] --byte,end--> [pkt_rx + CRC32]
 UART_RXD_OUT <--[          ]<--rdata---     |  ^                         |
                                             |  |                         v
 CPU_RESETN --> [reset_sync] --rst--> all    |  +-- reply/frame words -[cmd_exec]--> LED[15:0]
                                             |                        |   |   ^
                                             v                        v   |   |
                                        [tick_gen] --tick--> [telemetry]  |   |
                                                                 held frame   |
                                        [reply_builder] <-----------------+
```

## Clock plan

One domain `sys`, CLK100MHZ at 100 MHz. CPU_RESETN is asynchronous at the pin; reset_sync (xpm_cdc_async_rst style: asynchronous assert, synchronous release) produces one active-high synchronous reset. All other logic uses synchronous reset only. No other crossings.

## Behaviour summary

- pkt_rx stores up to 16 bytes, counts all bytes seen (for too long), runs the Ethernet CRC-32 bytewise, and drops a partial packet after TIMEOUT_CYCLES idle clocks as too short.
- cmd_exec applies the judging order: too long, too short, bad check, unknown type, wrong length, sequence, register/access. Counters are 16 bit, wrapping. Register 5 counts all refused packets.
- reply_builder emits type|0x80, status, sequence, length, payload and CRC-32 within 100 clocks, one byte per clock, into a 26-byte buffer.
- telemetry holds at most one 17-byte frame, built when it falls due, dropped if one is held.
- tick_gen: TICK write adds n to a pending counter (saturating at 255), one tick per clock.
- Busy: from the first packet byte until reply built, and while ticks pending.

## Resources (prediction)

LUT 700 to 2200, FF 600 to 1800, BRAM 0 to 1, DSP 0.

## Pin list

| Port | Dir | Board resource |
|---|---|---|
| CLK100MHZ | in | 100 MHz oscillator |
| CPU_RESETN | in | CPU RESET button, active low |
| UART_TXD_IN | in | USB-UART host to FPGA |
| UART_RXD_OUT | out | USB-UART FPGA to host |
| LED[15:0] | out | LD15..LD0, commands-carried-out count |
