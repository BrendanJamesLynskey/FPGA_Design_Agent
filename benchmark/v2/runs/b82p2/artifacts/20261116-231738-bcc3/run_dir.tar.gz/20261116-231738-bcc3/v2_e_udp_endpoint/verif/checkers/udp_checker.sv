`include "v_macros.svh"

// Port-only checker for the top level (LED = commands-carried-out count, idle UART line).
module udp_checker (
    input logic        clk,
    input logic        rst,
    input logic [15:0] led,
    input logic        txd
);
  logic seen_rst = 1'b0;
  logic past_ok  = 1'b0;
  always @(posedge clk or posedge rst) if (rst) seen_rst <= 1'b1;
  always @(posedge clk) past_ok <= 1'b1;

  `V_SAME(A_led_step, 1'b1, (led == $past(led)) || (led == ($past(led) + 16'd1))) // req: REQ-44
  `V_RST(A_rst_led, led == 16'd0) // req: REQ-45
  `V_RST(A_rst_txd, txd == 1'b1) // req: REQ-45
  `V_COVER(C_led_nonzero, led != 16'd0) // req: REQ-44
  `V_COVER(C_led_step, led == ($past(led) + 16'd1)) // req: REQ-44
  `V_COVER(C_txd_low, txd == 1'b0) // req: REQ-47
endmodule
