"""Pytest entry: runs the cocotb bench tests/udp_bench.py against the RTL for three seeds."""
from pathlib import Path

import flow.cocotb_run as cocotb_run

DESIGN_DIR = Path(__file__).resolve().parents[1]
# Must equal CPB / TMO in tests/udp_bench.py
PARAMS = {"CLKS_PER_BIT": 8, "TIMEOUT_CYCLES": 20000}


def _run(seed):
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN_DIR / "rtl").glob("*.sv"))
    return cocotb_run.run(
        "v2_e_udp_endpoint",
        "v2_e_udp_endpoint_top",
        sources,
        "udp_bench",
        DESIGN_DIR / "tests",
        parameters=PARAMS,
        seed=seed,
    )


def test_bench_seed1():
    _run(1)


def test_bench_seed2():
    _run(2)


def test_bench_seed3():
    _run(3)
