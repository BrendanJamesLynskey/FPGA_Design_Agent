bind v2_e_udp_endpoint_top udp_checker u_udp_checker (
    .clk(CLK100MHZ),
    .rst(~CPU_RESETN),
    .led(LED),
    .txd(UART_RXD_OUT)
);
