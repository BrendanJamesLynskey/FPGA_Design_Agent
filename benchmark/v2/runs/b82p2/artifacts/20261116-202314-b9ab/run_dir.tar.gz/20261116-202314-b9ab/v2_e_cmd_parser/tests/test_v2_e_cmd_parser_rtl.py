"""pytest entry: runs the cocotb bench against the RTL for several seeds."""
import sys
from pathlib import Path

DESIGN = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(DESIGN))
sys.path.insert(0, str(DESIGN / "tests"))

from flow import cocotb_run  # noqa: E402

PARAMS = {"CLKS_PER_BIT": 8, "TIMEOUT_CYCLES": 4000}


def _run(seed):
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN / "rtl").glob("*.sv"))
    cocotb_run.run("v2_e_cmd_parser", "v2_e_cmd_parser_top", sources,
                   "v2_e_cmd_parser_bench", DESIGN / "tests",
                   parameters=PARAMS, seed=seed)


def test_seed_1():
    _run(1)


def test_seed_2():
    _run(2)


def test_seed_3():
    _run(3)
