# Architecture: command packet screener (CPS1)

Board: nexys_a7_100t, part xc7a100tcsg324-1, top `v2_e_cmd_parser_top`.

## Block diagram

```text
 CLK100MHZ ----------------------------------+--------------------+
 CPU_RESETN --> [rst_sync 2FF] --rst--+      |                    |
                                      v      v                    v
 UART_TXD_IN --> [ fpga_shell ] --win_*--> [ reg_map ] <--> [ cps_core ]
 UART_RXD_OUT <-- [ (115200)  ] <-win_rdata-             byte buf(8), CRC-32,
                                                         classifier, 7x16b counters
                                                              |
                                                  LED[7:0]  = good count low byte
                                                  LED[15:8] = last accepted seq low byte
```

Data flow: a write to BYTE (offset 0) hands a byte plus end flag to cps_core. The core updates the incremental CRC (last 4 bytes held back as the received check), stores up to 8 payload bytes in a staging buffer and counts all bytes. At the end flag it classifies in order too long, too short, bad check, unknown type/length, not new, good (done within 8 clocks). Only a good packet commits TYPE, SEQ, PAY0, PAY1 and LASTSEQ; every packet increments one counter and sets RESULT. BUSY is high from the first byte until classification.

## Clock plan

Single domain `clk` on CLK100MHZ, 100 MHz, no MMCM. No clock-domain crossings except the asynchronous CPU_RESETN button, taken through a 2-flop synchroniser (async input, synchronous release) and inverted once to an active-high synchronous reset used everywhere inside. No other asynchronous resets.

## Pin list

| Port | Dir | Board resource |
|---|---|---|
| CLK100MHZ | in | 100 MHz oscillator |
| CPU_RESETN | in | CPU RESET button, active low |
| UART_TXD_IN | in | USB-UART host to FPGA |
| UART_RXD_OUT | out | USB-UART FPGA to host |
| LED[15:0] | out | LEDs 15..0 |

## Resource prediction

LUT 400-1200, FF 350-1000, BRAM 0, DSP 0 (spec limit under 1500 each).
