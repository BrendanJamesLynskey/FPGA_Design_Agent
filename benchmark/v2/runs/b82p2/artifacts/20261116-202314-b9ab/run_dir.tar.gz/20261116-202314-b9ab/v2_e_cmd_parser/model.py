import zlib


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000, BUILD_STAMP=0,
                 DESIGN_ID=1129337649, MAX_LEN=8):
        self.CLKS_PER_BIT = CLKS_PER_BIT
        self.TIMEOUT_CYCLES = TIMEOUT_CYCLES
        self.BUILD_STAMP = BUILD_STAMP
        self.DESIGN_ID = DESIGN_ID
        self.MAX_LEN = MAX_LEN
        self._in = {"CPU_RESETN": 1, "UART_TXD_IN": 1}
        self.reset()

    def reset(self):
        self.buf = []
        self.byte_reg = 0
        self.result = 0
        self.typ = 0
        self.seq = 0
        self.pay0 = 0
        self.pay1 = 0
        self.last = 0
        self.have = 0
        self.ctr = [0] * 7
        self.busy = 0

    def _leds(self):
        return {"UART_RXD_OUT": 1,
                "LED": ((self.last & 0xFF) << 8) | (self.ctr[0] & 0xFF)}

    def step(self, inputs=None):
        if inputs:
            self._in.update(inputs)
        if not self._in.get("CPU_RESETN", 1):
            self.reset()
        return self._leds()

    def _classify(self):
        b = self.buf
        n = len(b)
        ln = b[1] if n >= 2 else 0
        if (n >= 4 and ln > 8) or (n >= 4 and n > ln + 8):
            return 4
        if n < 4 or n < ln + 8:
            return 3
        body = bytes(b[:-4])
        rx = b[-4] | (b[-3] << 8) | (b[-2] << 16) | (b[-1] << 24)
        if zlib.crc32(body) != rx:
            return 2
        t = b[0]
        need = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}
        if t not in need:
            return 7
        if need[t] != ln:
            return 8
        seq = (b[2] << 8) | b[3]
        if self.have:
            d = (seq - self.last) & 0xFFFF
            if d == 0:
                return 5
            if d >= 32768:
                return 6
        return 1

    def write_reg(self, offset, value):
        if offset != 0:
            return
        value &= 0x1FF
        self.byte_reg = value
        self.buf.append(value & 0xFF)
        if value & 0x100:
            cls = self._classify()
            b = self.buf
            self.result = cls
            idx = {1: 0, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5, 7: 6, 8: 6}[cls]
            self.ctr[idx] = (self.ctr[idx] + 1) & 0xFFFF
            if cls == 1:
                ln = b[1]
                pl = b[4:4 + ln]
                pp = (pl + [0] * 6)[:6]
                self.typ = b[0]
                self.seq = (b[2] << 8) | b[3]
                self.last = self.seq
                self.have = 1
                self.pay0 = (pp[0] << 8) | pp[1]
                self.pay1 = (pp[2] << 24) | (pp[3] << 16) | (pp[4] << 8) | pp[5]
            self.buf = []
            self.busy = 0
        else:
            self.busy = 1

    def read_reg(self, offset):
        if offset == 0:
            return self.byte_reg
        if offset == 1:
            return self.result
        if offset == 2:
            return self.typ
        if offset == 3:
            return self.seq
        if offset == 4:
            return self.pay0
        if offset == 5:
            return self.pay1
        if offset == 6:
            return self.last | (self.have << 16)
        if offset == 7:
            return self.busy
        if 0x10 <= offset <= 0x16:
            return self.ctr[offset - 0x10]
        return 0
