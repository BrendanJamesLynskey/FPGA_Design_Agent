"""cocotb bench for the command packet screener (CPS1), checked against model.py.

The design is reached through the test shell over UART_TXD_IN / UART_RXD_OUT (window 0x80 + register offset).
"""
import random
import sys
import zlib
from pathlib import Path

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402

CLKS = 8
TIMEOUT = 4000
PARAMS = dict(CLKS_PER_BIT=CLKS, TIMEOUT_CYCLES=TIMEOUT)

LIGHT = [1, 7, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16]
FULL = [0, 1, 2, 3, 4, 5, 6, 7, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16]
NEED = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}


def build(typ, ln, seq, payload, crc_ok=True, flip=0x00010000):
    body = [typ, ln, (seq >> 8) & 0xFF, seq & 0xFF] + list(payload)
    crc = zlib.crc32(bytes(body))
    if not crc_ok:
        crc ^= flip
    return body + list(crc.to_bytes(4, "little"))


def good_pkt(typ, seq, rng=None, crc_ok=True):
    rng = rng or random
    pl = [rng.randrange(256) for _ in range(NEED[typ])]
    return build(typ, NEED[typ], seq, pl, crc_ok)


def xor8(b):
    r = 0
    for x in b:
        r ^= x
    return r


class Env:
    def __init__(self, dut):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        self.m = model.Model(**PARAMS)
        self.rx = []

    async def start(self):
        d = self.dut
        d.UART_TXD_IN.value = 1
        d.CPU_RESETN.value = 0
        cocotb.start_soon(Clock(self.clk, 10, "ns").start())
        await ClockCycles(self.clk, 6)
        d.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 10)
        self.m.reset()
        cocotb.start_soon(self.monitor())

    async def monitor(self):
        d = self.dut
        while True:
            await RisingEdge(self.clk)
            try:
                v = int(d.UART_RXD_OUT.value)
            except ValueError:
                continue
            if v != 0:
                continue
            await ClockCycles(self.clk, CLKS + CLKS // 2)
            val = 0
            for i in range(8):
                val |= int(d.UART_RXD_OUT.value) << i
                await ClockCycles(self.clk, CLKS)
            if int(d.UART_RXD_OUT.value) == 1:
                self.rx.append(val)

    async def hard_reset(self):
        self.dut.CPU_RESETN.value = 0
        await ClockCycles(self.clk, 6)
        self.dut.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 10)
        self.m.reset()

    async def send_byte(self, b):
        d = self.dut
        bits = [0] + [(b >> i) & 1 for i in range(8)] + [1]
        for v in bits:
            d.UART_TXD_IN.value = v
            await ClockCycles(self.clk, CLKS)

    async def txn(self, cmd, addr, data=0):
        body = [cmd, addr] + list(data.to_bytes(4, "little"))
        frame = [0xA5] + body + [xor8(body)]
        self.rx.clear()
        for b in frame:
            await self.send_byte(b)
        for _ in range(200):
            if len(self.rx) >= 7:
                break
            await ClockCycles(self.clk, CLKS * 2)
        assert len(self.rx) == 7, f"no response to {frame}: {self.rx}"
        r = list(self.rx)
        assert r[0] == 0x5A and xor8(r[1:6]) == r[6], f"bad response {r}"
        await ClockCycles(self.clk, CLKS)
        return r[1], int.from_bytes(bytes(r[2:6]), "little")

    async def shell_read(self, addr):
        st, v = await self.txn(1, addr)
        assert st == 0, f"read 0x{addr:02X} status {st}"
        return v

    async def rd(self, off):
        return await self.shell_read(0x80 + off)

    async def wr(self, off, val):
        st, _ = await self.txn(2, 0x80 + off, val)
        assert st == 0, f"write window 0x{off:02X} status {st}"
        self.m.write_reg(off, val)

    async def send_packet(self, data, end=True):
        for i, b in enumerate(data):
            last = end and i == len(data) - 1
            await self.wr(0, b | (0x100 if last else 0))

    def check_led(self, tag=""):
        exp = self.m.step()["LED"]
        got = int(self.dut.LED.value)
        assert got == exp, f"{tag} LED {got:04x} expected {exp:04x}"

    async def check(self, full=False, tag=""):
        self.check_led(tag)
        for o in (FULL if full else LIGHT):
            got = await self.rd(o)
            exp = self.m.read_reg(o)
            assert got == exp, f"{tag} reg 0x{o:02X} got {got:#x} expected {exp:#x}"
        self.check_led(tag)

    async def packet(self, data, full=False, tag="", expect=None):
        await self.send_packet(data)
        if expect is not None:
            assert self.m.read_reg(1) == expect, f"{tag}: model result {self.m.read_reg(1)} != planned {expect}"
        await self.check(full, tag)
        assert self.m.read_reg(7) == 0


async def setup(dut):
    e = Env(dut)
    await e.start()
    return e


# req: REQ-21, REQ-20, REQ-20B, REQ-19, REQ-19B
@cocotb.test()
async def test_smoke_reset_design_id(dut):
    e = await setup(dut)
    assert await e.shell_read(0x00) == 0x43505331
    assert int(dut.LED.value) == 0
    await e.check(full=True, tag="reset")
    for o in FULL:
        assert e.m.read_reg(o) == 0


# req: REQ-23
@cocotb.test()
async def test_baud_rate(dut):
    e = await setup(dut)
    res = []

    async def measure():
        while True:
            await RisingEdge(e.clk)
            if int(dut.UART_RXD_OUT.value) == 0:
                n = 0
                while int(dut.UART_RXD_OUT.value) == 0:
                    n += 1
                    await RisingEdge(e.clk)
                res.append(n)
                return

    cocotb.start_soon(measure())
    assert await e.shell_read(0x00) == 0x43505331
    # response byte 0x5A: start bit and bit 0 are both low = two bit times
    assert res and abs(res[0] - 2 * CLKS) <= 1, f"low time {res} expected {2 * CLKS}"


# req: REQ-11, REQ-12, REQ-12B, REQ-14, REQ-15, REQ-16, REQ-17, REQ-18B, REQ-19, REQ-19B
@cocotb.test()
async def test_good_packets(dut):
    e = await setup(dut)
    rng = random.Random(11)
    seq = 0x12AB
    for typ in (1, 2, 3, 4, 5, 2, 1):
        await e.packet(good_pkt(typ, seq, rng), full=True, tag=f"good type {typ}", expect=1)
        seq += 1
    # value field must be zero after a no-value good packet (previous was type 1, 2 payload bytes)
    await e.packet(good_pkt(3, seq, rng), full=True, tag="no value", expect=1)
    assert e.m.read_reg(5) == 0
    assert (await e.rd(5)) == 0
    # LED: sequence low byte on 15:8
    assert int(dut.LED.value) >> 8 == seq & 0xFF
    assert int(dut.LED.value) & 0xFF == 8


# req: REQ-18, REQ-18B, REQ-16, REQ-16B
@cocotb.test()
async def test_busy_and_idle(dut):
    e = await setup(dut)
    pkt = good_pkt(2, 5, random.Random(3))
    await e.wr(0, pkt[0])
    assert (await e.rd(7)) == 1
    assert (await e.rd(0)) == pkt[0]
    await e.wr(0, pkt[1])
    assert (await e.rd(7)) == 1
    # idle longer than the shell timeout: the screener must not end the packet
    await ClockCycles(e.clk, 3 * TIMEOUT)
    assert (await e.rd(7)) == 1
    assert (await e.rd(1)) == 0
    for b in pkt[2:-1]:
        await e.wr(0, b)
    assert (await e.rd(7)) == 1
    await e.wr(0, pkt[-1] | 0x100)
    assert (await e.rd(0)) == pkt[-1] | 0x100
    await e.check(full=True, tag="after end")
    assert (await e.rd(7)) == 0 and e.m.read_reg(1) == 1
    # first byte after an end flag starts a new packet
    await e.wr(0, 0x55)
    assert (await e.rd(7)) == 1
    await e.wr(0, 0x100 | 0x66)
    await e.check(full=True, tag="2-byte pkt")
    assert e.m.read_reg(1) == 3
    # single-byte packet
    await e.packet([0x01], full=False, tag="1 byte", expect=3)
    # a good packet follows undisturbed
    await e.packet(good_pkt(1, 6, random.Random(4)), full=True, tag="follow", expect=1)


# req: REQ-01, REQ-02, REQ-17, REQ-16, REQ-13
@cocotb.test()
async def test_too_long(dut):
    e = await setup(dut)
    rng = random.Random(21)
    await e.packet(good_pkt(1, 10, rng), full=True, tag="seed good", expect=1)
    cases = [
        build(1, 9, 11, [1] * 9),                      # length above 8, valid crc
        build(1, 9, 11, [1] * 9, crc_ok=False),        # bad crc too: long wins
        build(2, 0xFF, 11, [7] * 6),                   # length 255
        [1, 9, 0, 11],                                  # exactly 4 bytes, len 9
        [0, 0xFF, 1, 2, 3],                             # 5 bytes, len 255
        build(2, 6, 11, [1] * 6) + [0xAA],              # one extra byte
        build(3, 0, 11, []) + [0, 0, 0],                # 3 extra
        build(2, 8, 11, [1] * 8) + [9],                 # len 8 with extra byte
        build(3, 0, 11, [], crc_ok=False) + [5],        # extra + bad crc
        build(9, 0, 11, []) + [5],                      # extra + bad type
        build(1, 8, 11, [2] * 8),                       # len 8 exact, bad length (not long)
        build(3, 0, 10, [1] * 9),                       # len 0 with 9 payload-like bytes
    ]
    for i, c in enumerate(cases):
        await e.packet(c, full=(i % 4 == 0), tag=f"long case {i}")
    assert e.m.read_reg(0x13) >= 9


# req: REQ-03, REQ-04, REQ-17, REQ-16, REQ-13
@cocotb.test()
async def test_too_short(dut):
    e = await setup(dut)
    rng = random.Random(22)
    await e.packet(good_pkt(1, 20, rng), full=True, tag="seed good", expect=1)
    valid = good_pkt(2, 21, rng)
    cases = [
        [0x02],
        [0x02, 0xFF],
        [0x02, 0xFF, 0x00],
        [0x01, 0x09, 0x00],              # 3 bytes with len above 8 is short
        [0, 0, 0],
        [1, 2, 3, 4],                    # 4 bytes, len 2: short
        [3, 0, 0, 1, 0, 0, 0],           # 7 bytes, len 0 (need 8): short
        valid[:-1],                      # one byte short
        valid[:-2],
        valid[:4],
        good_pkt(3, 22, rng)[:-1],       # len 0, 7 bytes
        build(1, 2, 22, [1, 2], crc_ok=False)[:-1],
    ]
    for i, c in enumerate(cases):
        await e.packet(c, full=(i % 4 == 0), tag=f"short case {i}")
    assert e.m.read_reg(0x12) == len(cases)
    # exactly length+8 bytes is not short
    await e.packet(good_pkt(1, 30, rng), full=True, tag="exact", expect=1)


# req: REQ-05, REQ-13, REQ-17
@cocotb.test()
async def test_bad_check(dut):
    e = await setup(dut)
    rng = random.Random(23)
    await e.packet(good_pkt(1, 40, rng), full=True, tag="seed good", expect=1)
    for i in range(4):  # flip a bit in each check byte
        c = good_pkt(2, 41, rng)
        c[-4 + i] ^= 1 << (i * 2)
        await e.packet(c, full=True, tag=f"crc byte {i}", expect=2)
    # flip a body byte (type/len/seq/payload)
    for pos in (0, 1, 2, 3, 4, 9):
        c = good_pkt(2, 41, rng)
        c[pos] ^= 0x10
        await e.packet(c, full=False, tag=f"body flip {pos}")
    # bad check beats bad type, bad length and repeat
    await e.packet(build(9, 0, 99, [], crc_ok=False), tag="badtype+badcrc", expect=2)
    await e.packet(build(1, 0, 99, [], crc_ok=False), tag="badlen+badcrc", expect=2)
    await e.packet(build(1, 2, 40, [1, 2], crc_ok=False), tag="repeat+badcrc", expect=2)
    await e.check(full=True)


# req: REQ-06, REQ-07, REQ-17, REQ-13
@cocotb.test()
async def test_unknown(dut):
    e = await setup(dut)
    rng = random.Random(24)
    await e.packet(good_pkt(1, 100, rng), full=True, tag="seed good", expect=1)
    for t in (0, 6, 0x80, 0xFF):
        await e.packet(build(t, 0, 101, []), full=True, tag=f"type {t}", expect=7)
    await e.packet(build(0, 8, 101, [1] * 8), tag="type 0 len 8", expect=7)
    await e.packet(build(7, 2, 101, [1, 2]), tag="type 7 len 2", expect=7)
    # bad length for each type
    bad = {1: (0, 1, 3, 6, 8), 2: (0, 2, 5, 7, 8), 3: (1, 2, 6), 4: (0, 1, 6), 5: (1, 2, 8)}
    for t, lens in bad.items():
        for ln in lens:
            await e.packet(build(t, ln, 101, [rng.randrange(256) for _ in range(ln)]),
                           full=(ln == lens[0]), tag=f"type {t} len {ln}", expect=8)
    # unknown beats repeat/stale
    await e.packet(build(9, 0, 100, []), tag="badtype repeat", expect=7)
    await e.packet(build(1, 0, 100, []), tag="badlen repeat", expect=8)
    await e.packet(build(9, 0, 100 + 40000, []), tag="badtype stale", expect=7)
    await e.packet(build(2, 3, 100 + 40000, [1, 2, 3]), tag="badlen stale", expect=8)
    # unknown doesn't consume the sequence: seq 101 is still good
    await e.packet(good_pkt(3, 101, rng), full=True, tag="still good", expect=1)


# req: REQ-08, REQ-09, REQ-10, REQ-11, REQ-17, REQ-12B, REQ-20C
@cocotb.test()
async def test_sequence_rules(dut):
    e = await setup(dut)
    rng = random.Random(25)
    # first packet after reset is good with any sequence number
    for first in (0xFFFF, 0x0000, 0x8000, 0x1234):
        await e.hard_reset()
        await e.packet(good_pkt(5, first, rng), full=True, tag=f"first {first:#x}", expect=1)
        assert (await e.rd(6)) == (1 << 16) | first
        await e.packet(good_pkt(5, first, rng), full=True, tag="repeat", expect=5)
    await e.hard_reset()
    last = 0xFFFF
    await e.packet(good_pkt(3, last, rng), full=True, tag="first", expect=1)
    steps = [0, 0x8000, 0xFFFF, 0x8001, 1, 0x7FFF, 0x8000, 0, 1, 0x7FFF, 0x4000, 0xC000, 2]
    for i, d in enumerate(steps):
        last_now = e.m.read_reg(6) & 0xFFFF
        seq = (last_now + d) & 0xFFFF
        exp = 5 if d == 0 else (6 if d >= 0x8000 else 1)
        await e.packet(good_pkt(rng.choice([1, 2, 3, 4, 5]), seq, rng), full=True,
                       tag=f"delta {d:#x}", expect=exp)
    assert e.m.read_reg(0x14) >= 2 and e.m.read_reg(0x15) >= 3


# req: REQ-20, REQ-20B, REQ-20C, REQ-20D, REQ-19, REQ-19B
@cocotb.test()
async def test_reset_behaviour(dut):
    e = await setup(dut)
    rng = random.Random(26)
    await e.packet(good_pkt(2, 0x1234, rng), full=True, expect=1)
    await e.packet(good_pkt(2, 0x1234, rng), expect=5)
    await e.packet(good_pkt(2, 0x1235, rng, crc_ok=False), expect=2)
    await e.packet([1, 2], expect=3)
    await e.packet(build(1, 9, 1, [0] * 9), expect=4)
    await e.packet(build(9, 0, 0x1236, []), expect=7)
    await e.packet(build(1, 0, 0x1236, []), expect=8)
    await e.packet(good_pkt(2, 0x1234 + 0x9000, rng), expect=6)
    await e.check(full=True, tag="before reset")
    assert int(dut.LED.value) >> 8 == 0x34
    pkt = good_pkt(1, 0x1234, rng)
    for b in pkt[:6]:
        await e.wr(0, b)
    assert (await e.rd(7)) == 1
    await e.hard_reset()
    await e.check(full=True, tag="after reset")
    assert int(dut.LED.value) == 0
    for o in FULL:
        assert e.m.read_reg(o) == 0
    # packet in progress was discarded: a whole packet now decodes as a fresh one
    await e.packet(pkt, full=True, tag="fresh after reset", expect=1)
    # a second partial packet, reset, again
    for b in good_pkt(2, 0x1240, rng)[:9]:
        await e.wr(0, b)
    await e.hard_reset()
    await e.packet([0x01, 0x02], full=True, tag="2 bytes after reset", expect=3)
    # first-packet state restored: the same seq is accepted again
    await e.packet(pkt, full=True, tag="same seq after reset", expect=1)


# req: REQ-13
@cocotb.test()
async def test_unmapped_and_ro_writes(dut):
    e = await setup(dut)
    rng = random.Random(27)
    await e.packet(good_pkt(2, 77, rng), full=True, expect=1)
    for o in (8, 0x0F, 0x17, 0x20, 0x7F):
        assert (await e.rd(o)) == 0, f"unmapped 0x{o:02X}"
    for o in (1, 2, 3, 4, 5, 6, 7, 0x10, 0x13, 0x16, 8, 0x17):
        st, _ = await e.txn(2, 0x80 + o, 0xFFFFFFFF)
        assert st == 0
    await e.check(full=True, tag="after ro writes")
    # BYTE register reads back the last 9 bits written
    await e.wr(0, 0x1AB)
    assert (await e.rd(0)) == 0x1AB
    await e.check(full=True, tag="byte")


# req: REQ-15, REQ-13, REQ-17
@cocotb.test()
async def test_counters_independent(dut):
    e = await setup(dut)
    rng = random.Random(28)
    seq = 1
    makers = [
        lambda s: good_pkt(2, s, rng),                       # good
        lambda s: good_pkt(2, s, rng, crc_ok=False),         # bad check
        lambda s: [1, 2, 3],                                 # short
        lambda s: build(1, 9, s, [1] * 9),                   # long
        lambda s: good_pkt(2, e.m.read_reg(6) & 0xFFFF, rng),  # repeat
        lambda s: good_pkt(2, (e.m.read_reg(6) + 0x9000) & 0xFFFF, rng),  # stale
        lambda s: build(9, 0, s, []),                        # bad type
    ]
    # make sure the first packet is good, then distinct counts 1..7 for each class
    for idx in range(7):
        for _ in range(idx + 1):
            seq += 1
            await e.packet(makers[idx](seq), tag=f"class {idx}")
    await e.check(full=True, tag="final")
    ctrs = [e.m.read_reg(0x10 + i) for i in range(7)]
    assert ctrs == [1, 2, 3, 4, 5, 6, 7], ctrs
    # good-then-bad on type or length goes to the 7th counter
    await e.packet(build(1, 0, seq + 5, []), tag="bad len")
    assert e.m.read_reg(0x16) == 8
    await e.check(full=True, tag="final2")


def random_packet(e, rng):
    last = e.m.read_reg(6)
    have = last >> 16
    last &= 0xFFFF
    if have:
        d = rng.choice([0, 1, 2, 0x7FFF, 0x8000, 0x8001, 0xFFFF, rng.randrange(65536)])
        seq = (last + d) & 0xFFFF
    else:
        seq = rng.randrange(65536)
    kind = rng.choice(["good", "good", "good", "crc", "type", "len", "long", "extra", "short", "trunc", "raw"])
    t = rng.choice([1, 2, 3, 4, 5])
    if kind == "good":
        return good_pkt(t, seq, rng)
    if kind == "crc":
        return good_pkt(t, seq, rng, crc_ok=False)
    if kind == "type":
        return build(rng.choice([0, 6, 7, 0x40, 0xFF]), rng.randrange(9),
                     seq, [rng.randrange(256) for _ in range(8)][:0] or [0] * 0)[:0] or \
            (lambda ln: build(rng.choice([0, 6, 7, 0x40, 0xFF]), ln, seq, [rng.randrange(256) for _ in range(ln)]))(rng.randrange(9))
    if kind == "len":
        ln = rng.choice([x for x in range(9) if x != NEED[t]])
        return build(t, ln, seq, [rng.randrange(256) for _ in range(ln)])
    if kind == "long":
        ln = rng.randrange(9, 256)
        return build(t, ln, seq, [rng.randrange(256) for _ in range(rng.randrange(0, 12))])
    if kind == "extra":
        return good_pkt(t, seq, rng) + [rng.randrange(256) for _ in range(rng.randrange(1, 4))]
    if kind == "short":
        return [rng.randrange(256) for _ in range(rng.randrange(1, 4))]
    if kind == "trunc":
        p = good_pkt(t, seq, rng)
        return p[:rng.randrange(4, len(p))]
    return [rng.randrange(256) for _ in range(rng.randrange(4, 13))]


# req: REQ-01, REQ-02, REQ-03, REQ-04, REQ-05, REQ-06, REQ-07, REQ-08, REQ-09, REQ-10, REQ-11, REQ-12, REQ-12B, REQ-13, REQ-14, REQ-15, REQ-16, REQ-16B, REQ-17, REQ-18, REQ-18B, REQ-19, REQ-19B, REQ-22
@cocotb.test()
async def test_random_traffic(dut):
    e = await setup(dut)
    seed = getattr(cocotb, "RANDOM_SEED", 1) or 1
    rng = random.Random(seed)
    for i in range(36):
        if i == 18:
            await e.hard_reset()
            await e.check(full=True, tag="mid reset")
        p = random_packet(e, rng)
        # sometimes look at BUSY in the middle of the packet
        if len(p) > 2 and rng.random() < 0.3:
            await e.send_packet(p[:2], end=False)
            assert (await e.rd(7)) == 1
            await e.send_packet(p[2:])
            await e.check(full=(i % 6 == 0), tag=f"rand {i}")
        else:
            await e.packet(p, full=(i % 6 == 0), tag=f"rand {i}")
    await e.check(full=True, tag="random end")
