# v2_e_cmd_exec architecture

Command executor and register file on the Nexys A7-100T (xc7a100tcsg324-1), driven through the UART test shell.

## Block diagram

```text
 CPU_RESETN --> [rst_sync 2FF] --> rst (active high, sync)
                                      |
 UART_TXD_IN --> [fpga_shell] <-- CLK100MHZ (100 MHz, single domain)
 UART_RXD_OUT <-- [fpga_shell]
                     | win_addr/wr/rd/wdata ; win_rdata (1 cycle after rd)
                     v
              [window_regs: TYP P0 P1 GO CODE TLM RDATA REFUSED TICK BANK0..7]
                     |
                     v
              [cmd_exec] <--> [reg_bank: ID SCRATCH0..2 CMDS ERRS PERIOD UPTIME]
                                   |
                                   +--> [led_out] --> LED[15:0]
```

## Clock plan

One clock domain: CLK100MHZ, 100 MHz (10 ns), no MMCM. All state is synchronous. CPU_RESETN is the only
asynchronous input besides the UART receive line; it passes a two-flop synchroniser, is inverted once to
active high, and resets all state synchronously. The shell synchronises UART_TXD_IN itself.

## Pin list

| Port | Dir | Width | Role |
|---|---|---|---|
| CLK100MHZ | in | 1 | 100 MHz system clock |
| CPU_RESETN | in | 1 | CPU RESET button, active low |
| UART_TXD_IN | in | 1 | USB-UART from host (FPGA receive) |
| UART_RXD_OUT | out | 1 | USB-UART to host (FPGA transmit) |
| LED | out | 16 | LED[7:0]=ERRS[7:0], LED[15:8]=CMDS[7:0] |

## Resources

Predicted 400..1200 LUT, 350..900 FF, 0 BRAM, 0 DSP, including the shell.
