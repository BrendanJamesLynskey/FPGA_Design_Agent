"""cocotb bench for v2_e_cmd_exec: everything goes through the UART test shell (window 0x80+offset) and is
compared with model.py."""
import os
import random
import sys
from functools import reduce
from pathlib import Path

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from model import Model  # noqa: E402

CB = 8
PARAMS = dict(CLKS_PER_BIT=CB, TIMEOUT_CYCLES=2000)
WIN = 0x80
ID = 0x55445031

CMDS, ERRS, PERIOD, UPTIME, TLM = 4, 5, 6, 7, 8  # indices into snapshot (bank n = index n)


class Env:
    def __init__(self, dut):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        self.m = None


async def start(dut):
    cocotb.start_soon(Clock(dut.CLK100MHZ, 10, "ns").start())
    dut.UART_TXD_IN.value = 1
    dut.CPU_RESETN.value = 0
    env = Env(dut)
    await ClockCycles(env.clk, 10)
    dut.CPU_RESETN.value = 1
    await ClockCycles(env.clk, 10)
    env.m = Model(**PARAMS)
    env.m.step({"CPU_RESETN": 0})
    env.m.step({"CPU_RESETN": 1})
    return env


async def pulse_reset(env, cycles=10):
    env.dut.CPU_RESETN.value = 0
    env.m.step({"CPU_RESETN": 0})
    await ClockCycles(env.clk, cycles)
    env.dut.CPU_RESETN.value = 1
    env.m.step({"CPU_RESETN": 1})
    await ClockCycles(env.clk, 10)


async def tx_byte(env, b):
    bits = [0] + [(b >> i) & 1 for i in range(8)] + [1]
    for v in bits:
        env.dut.UART_TXD_IN.value = v
        await ClockCycles(env.clk, CB)


async def rx_byte(env, limit=200 * CB):
    for _ in range(limit):
        await RisingEdge(env.clk)
        if int(env.dut.UART_RXD_OUT.value) == 0:
            break
    else:
        raise AssertionError("no response start bit")
    await ClockCycles(env.clk, CB // 2)
    val = 0
    for i in range(8):
        await ClockCycles(env.clk, CB)
        val |= int(env.dut.UART_RXD_OUT.value) << i
    await ClockCycles(env.clk, CB)
    assert int(env.dut.UART_RXD_OUT.value) == 1, "stop bit low"
    return val


async def xact(env, cmd, addr, data=0):
    body = [cmd, addr] + list(data.to_bytes(4, "little"))
    frame = [0xA5] + body + [reduce(lambda a, b: a ^ b, body, 0)]
    for b in frame:
        await tx_byte(env, b)
    resp = [await rx_byte(env) for _ in range(7)]
    assert resp[0] == 0x5A, f"bad response sync {resp}"
    assert reduce(lambda a, b: a ^ b, resp[1:6], 0) == resp[6], f"bad response checksum {resp}"
    await ClockCycles(env.clk, 4)
    return resp[1], int.from_bytes(bytes(resp[2:6]), "little")


def check_led(env):
    exp = env.m.step()["LED"]
    got = int(env.dut.LED.value)
    assert got == exp, f"LED {got:#06x} != model {exp:#06x}"


async def hw_read(env, off):
    st, data = await xact(env, 1, WIN + off)
    assert st == 0, f"read {off:#x} status {st}"
    exp = env.m.read_reg(off)
    assert data == exp, f"read {off:#x}: {data:#x} != model {exp:#x}"
    check_led(env)
    return data


async def hw_write(env, off, val):
    st, _ = await xact(env, 2, WIN + off, val)
    assert st == 0, f"write {off:#x} status {st}"
    env.m.write_reg(off, val)
    check_led(env)


async def command(env, typ, p0, p1=0, rdata=True):
    m = env.m
    for off, val, cur in ((0, typ, m.typ), (1, p0, m.p0), (2, p1, m.p1)):
        if val != cur:
            await hw_write(env, off, val)
    await hw_write(env, 3, 0)
    code = await hw_read(env, 4)
    rd = await hw_read(env, 5) if rdata else None
    return code, rd


async def snapshot(env):
    vals = [await hw_read(env, 0x10 + i) for i in range(8)]
    vals.append(await hw_read(env, 8))
    return vals


def diff(a, b):
    return {i: (a[i], b[i]) for i in range(len(a)) if a[i] != b[i]}


# req: REQ-01, REQ-02, REQ-17, REQ-20, REQ-22, REQ-25
@cocotb.test()
async def test_reset_smoke(dut):
    env = await start(dut)
    s = await snapshot(env)
    assert s == [ID, 0, 0, 0, 0, 0, 100, 0, 0], s
    for off in (0, 1, 2, 4, 5):
        assert await hw_read(env, off) == 0
    assert int(dut.LED.value) == 0


# req: REQ-01, REQ-26, REQ-04
@cocotb.test()
async def test_id_readonly(dut):
    env = await start(dut)
    code, rd = await command(env, 2, 0, 0xDEADBEEF)
    assert code == 5 and rd == 0
    await hw_write(env, 0x10, 0x1234)  # window write into the bank: no effect
    s = await snapshot(env)
    assert s[0] == ID and s[ERRS] == 1 and s[CMDS] == 0


# req: REQ-03, REQ-27, REQ-09
@cocotb.test()
async def test_write_scratch_and_staging(dut):
    env = await start(dut)
    await hw_write(env, 0, 0xFFA5)  # TYP is 8 bits
    await hw_write(env, 1, 0x1ABCD)  # P0 is 16 bits
    await hw_write(env, 2, 0xFFFFFFFF)
    for off in (0, 1, 2, 3):
        await hw_read(env, off)
    env.m.write_reg(0, 0)
    vals = {1: 0xFFFFFFFF, 2: 0xA5A55A5A, 3: 0x80000001}
    for r, v in vals.items():
        code, rd = await command(env, 2, r, v)
        assert code == 0 and rd == 0
    s = await snapshot(env)
    assert s[1:4] == [0xFFFFFFFF, 0xA5A55A5A, 0x80000001], s
    assert s[CMDS] == 3 and s[ERRS] == 0
    code, _ = await command(env, 2, 2, 0)  # overwrite with zero
    assert code == 0
    assert await hw_read(env, 0x12) == 0


# req: REQ-04, REQ-28, REQ-10, REQ-30, REQ-11
@cocotb.test()
async def test_write_refused(dut):
    env = await start(dut)
    for r, v in ((1, 11), (2, 22), (3, 33)):
        await command(env, 2, r, v, rdata=False)
    await hw_write(env, 6, 9)
    await command(env, 4, 7, rdata=False)
    before = await snapshot(env)
    assert before[1:4] == [11, 22, 33] and before[PERIOD] == 7 and before[UPTIME] == 9 and before[TLM] == 1
    for r in (0, 4, 5, 6, 7):
        code, rd = await command(env, 2, r, 0x11111111 * (r + 1))
        assert code == 5 and rd == 0, (r, code, rd)
    after = await snapshot(env)
    assert diff(before, after) == {ERRS: (0, 5)}, diff(before, after)


# req: REQ-05, REQ-10, REQ-30
@cocotb.test()
async def test_unknown_register(dut):
    env = await start(dut)
    await command(env, 2, 1, 0x77, rdata=False)
    before = await snapshot(env)
    n = 0
    for typ, r in ((1, 8), (1, 0x100), (1, 0xFFFF), (2, 8), (2, 0x100)):
        code, rd = await command(env, typ, r, 0x55)
        assert code == 3 and rd == 0, (typ, r, code, rd)
        n += 1
    after = await snapshot(env)
    assert diff(before, after) == {ERRS: (0, n)}, diff(before, after)


# req: REQ-06, REQ-10, REQ-30
@cocotb.test()
async def test_unknown_type(dut):
    env = await start(dut)
    before = await snapshot(env)
    n = 0
    for typ in (0, 6, 7, 0x80, 0xFF):
        code, rd = await command(env, typ, 1, 5)
        assert code == 1 and rd == 0, (typ, code, rd)
        n += 1
    after = await snapshot(env)
    assert diff(before, after) == {ERRS: (0, n)}, diff(before, after)


# req: REQ-07, REQ-08, REQ-09, REQ-29, REQ-11, REQ-27
@cocotb.test()
async def test_read_commands_and_counters(dut):
    env = await start(dut)
    await hw_write(env, 6, 3)
    cm = er = 0
    code, rd = await command(env, 1, 4)
    assert code == 0 and rd == cm  # CMDS before counting
    cm += 1
    code, rd = await command(env, 1, 4)
    assert rd == cm
    cm += 1
    code, rd = await command(env, 1, 5)
    assert rd == er
    cm += 1
    code, rd = await command(env, 9, 0)  # failure
    assert code == 1 and rd == 0
    er += 1
    code, rd = await command(env, 1, 5)
    assert code == 0 and rd == er
    cm += 1
    expect = {0: ID, 1: 0, 2: 0, 3: 0, 6: 100, 7: 3}
    for r, v in expect.items():
        code, rd = await command(env, 1, r)
        assert code == 0 and rd == v, (r, rd)
        cm += 1
    # non-read successes and refused commands give read data 0
    code, rd = await command(env, 3, 0)
    assert code == 0 and rd == 0
    code, rd = await command(env, 2, 1, 5)
    assert code == 0 and rd == 0
    code, rd = await command(env, 1, 9)
    assert code == 3 and rd == 0
    cm += 2
    er += 1
    s = await snapshot(env)
    assert s[CMDS] == cm and s[ERRS] == er


# req: REQ-12, REQ-31, REQ-13, REQ-32, REQ-14, REQ-15, REQ-16, REQ-09
@cocotb.test()
async def test_status_telemetry(dut):
    env = await start(dut)
    await command(env, 2, 1, 42, rdata=False)
    b = await snapshot(env)
    code, _ = await command(env, 3, 0, rdata=False)
    assert code == 0
    a = await snapshot(env)
    assert diff(b, a) == {CMDS: (1, 2)}, diff(b, a)

    code, rd = await command(env, 4, 0)  # start, period unchanged
    assert code == 0 and rd == 0
    assert await hw_read(env, 0x16) == 100 and await hw_read(env, 8) == 1
    await command(env, 5, 0, rdata=False)
    assert await hw_read(env, 8) == 0
    for p, exp in ((1, 4), (3, 4), (4, 4), (5, 5), (0xFFFF, 0xFFFF)):
        code, _ = await command(env, 4, p, rdata=False)
        assert code == 0
        assert await hw_read(env, 0x16) == exp, (p, exp)
        assert await hw_read(env, 8) == 1
    await command(env, 5, 0, rdata=False)
    assert await hw_read(env, 8) == 0
    await command(env, 4, 0, rdata=False)  # param1 == 0 keeps 0xFFFF
    assert await hw_read(env, 0x16) == 0xFFFF and await hw_read(env, 8) == 1
    s = await snapshot(env)
    assert s[ERRS] == 0 and s[1:4] == [42, 0, 0]


# req: REQ-18, REQ-19, REQ-10
@cocotb.test()
async def test_tick_and_refused(dut):
    env = await start(dut)
    up = 0
    for n in (0, 255, 1, 0x100, 0x1A5, 77):
        await hw_write(env, 6, n)
        up += n & 0xFF
        assert await hw_read(env, 0x17) == up, (n, up)
    for v in (0, 0xFFFFFFFF, 5):
        await hw_write(env, 7, v)
    s = await snapshot(env)
    assert s[ERRS] == 3 and s[CMDS] == 0 and s[UPTIME] == up
    code, rd = await command(env, 1, 7)  # read UPTIME through a command
    assert code == 0 and rd == up


# req: REQ-21, REQ-33, REQ-10, REQ-09
@cocotb.test()
async def test_led(dut):
    env = await start(dut)
    await hw_write(env, 0, 3)
    er = cm = 0
    for i in range(20):
        await hw_write(env, 7, i)
        er += 1
        assert int(dut.LED.value) == ((cm << 8) | er)
        await hw_write(env, 3, 0)
        cm += 1
        assert int(dut.LED.value) == ((cm << 8) | er)


# req: REQ-22, REQ-02, REQ-17, REQ-21, REQ-33
@cocotb.test()
async def test_reset_midway(dut):
    env = await start(dut)
    for r, v in ((1, 0xDEAD), (2, 0xBEEF), (3, 0xF00D)):
        await command(env, 2, r, v, rdata=False)
    await hw_write(env, 6, 9)
    await hw_write(env, 7, 0)
    await command(env, 4, 7, rdata=False)
    await command(env, 1, 4)
    s = await snapshot(env)
    assert s[1:4] == [0xDEAD, 0xBEEF, 0xF00D] and s[PERIOD] == 7 and s[TLM] == 1 and s[UPTIME] == 9
    assert int(dut.LED.value) != 0
    await pulse_reset(env)
    assert int(dut.LED.value) == 0
    s = await snapshot(env)
    assert s == [ID, 0, 0, 0, 0, 0, 100, 0, 0], s
    for off in (0, 1, 2, 4, 5):
        assert await hw_read(env, off) == 0


# req: REQ-23
@cocotb.test()
async def test_baud_rate(dut):
    env = await start(dut)
    body = [1, WIN + 0x10, 0, 0, 0, 0]
    frame = [0xA5] + body + [reduce(lambda a, b: a ^ b, body, 0)]
    for b in frame:
        await tx_byte(env, b)
    for _ in range(200 * CB):
        await RisingEdge(env.clk)
        if int(dut.UART_RXD_OUT.value) == 0:
            break
    else:
        raise AssertionError("no response")
    low = 1
    while True:
        await RisingEdge(env.clk)
        if int(dut.UART_RXD_OUT.value) != 0:
            break
        low += 1
    # sync byte 0x5A: start bit and bit 0 are both low
    assert abs(low - 2 * CB) <= 1, f"low time {low}, expected {2 * CB}"
    await ClockCycles(env.clk, 20 * CB)  # let the rest of the response finish


# req: REQ-20
@cocotb.test()
async def test_unmapped_window(dut):
    env = await start(dut)
    for off in (3, 6, 7, 9, 0x0A, 0x18, 0x1F, 0x40, 0x7F):
        assert await hw_read(env, off) == 0
    before = await snapshot(env)
    for off in (4, 5, 8, 0x10, 0x17, 0x20):
        await hw_write(env, off, 0xCAFE0001)
    after = await snapshot(env)
    assert before == after
    assert await hw_read(env, 4) == 0 and await hw_read(env, 5) == 0


# req: REQ-01, REQ-03, REQ-04, REQ-05, REQ-06, REQ-09, REQ-10, REQ-11, REQ-14, REQ-15, REQ-18, REQ-19, REQ-20, REQ-21, REQ-33, REQ-29, REQ-30, REQ-28
@cocotb.test()
async def test_random_commands(dut):
    env = await start(dut)
    rng = random.Random(getattr(cocotb, "RANDOM_SEED", 1))
    types = [1, 1, 2, 2, 3, 4, 5, 0, 6, 255]

    def p0():
        return rng.choice([0, 1, 2, 3, 4, 5, 6, 7, 7, 8, 0x100, 0xFFFF, rng.randrange(0x10000)])

    def p1():
        return rng.choice([0, 1, 0xFFFFFFFF, rng.getrandbits(32)])

    for _ in range(40):
        t = rng.choice(types)
        a, b = p0(), p1()
        if t in (4,) and rng.random() < 0.5:
            a = rng.choice([0, 1, 3, 4, 5, 100, 0xFFFF])
        code, rd = await command(env, t, a, b)
        exp_code = 0
        if t in (1, 2) and a >= 8:
            exp_code = 3
        elif t == 2 and (a == 0 or a >= 4):
            exp_code = 5
        elif t not in (1, 2, 3, 4, 5):
            exp_code = 1
        assert code == exp_code, (t, a, code)
        if not (t == 1 and code == 0):
            assert rd == 0
        r = rng.random()
        if r < 0.2:
            await hw_write(env, 6, rng.randrange(256))
        elif r < 0.35:
            await hw_write(env, 7, rng.getrandbits(32))
        elif r < 0.5:
            await hw_read(env, 0x10 + rng.randrange(8))
    await snapshot(env)
