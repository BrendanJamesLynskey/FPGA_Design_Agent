// Port-only checker for v2_e_cmd_exec_top.
`include "v_macros.svh"

module v2_e_cmd_exec_checker (
    input logic        clk,
    input logic        rst,
    input logic [15:0] led,
    input logic        rxd
);
  logic seen_rst = 1'b0;
  logic past_ok = 1'b0;
  always @(posedge clk) begin
    past_ok <= 1'b1;
    if (rst) seen_rst <= 1'b1;
  end

  // one command or one refused write moves only one of the two counters per cycle
  `V_SAME(A_led_one_counter, 1'b1, !((led[7:0] != $past(led[7:0])) && (led[15:8] != $past(led[15:8])))) // req: REQ-21, REQ-33

  `V_COVER(C_led_errs_nonzero, led[7:0] != 8'h00) // req: REQ-21
  `V_COVER(C_led_cmds_nonzero, led[15:8] != 8'h00) // req: REQ-33
  `V_COVER(C_uart_tx_active, rxd == 1'b0) // req: REQ-23
endmodule
