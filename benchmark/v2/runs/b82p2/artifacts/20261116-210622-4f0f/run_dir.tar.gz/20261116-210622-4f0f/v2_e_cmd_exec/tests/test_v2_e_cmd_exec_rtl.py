import sys
from pathlib import Path

DESIGN_DIR = Path(__file__).resolve().parents[1]
for _p in DESIGN_DIR.parents:
    if (_p / "flow").is_dir():
        sys.path.insert(0, str(_p))
        break
sys.path.insert(0, str(DESIGN_DIR))

from flow import cocotb_run  # noqa: E402

PARAMS = dict(CLKS_PER_BIT=8, TIMEOUT_CYCLES=2000)
SEEDS = (1, 2, 3)


def test_v2_e_cmd_exec_rtl():
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN_DIR / "rtl").glob("*.sv"))
    for seed in SEEDS:
        res = cocotb_run.run(
            "v2_e_cmd_exec",
            "v2_e_cmd_exec_top",
            sources,
            "cmd_exec_bench",
            DESIGN_DIR / "tests",
            parameters=PARAMS,
            seed=seed,
        )
        if isinstance(res, bool):
            assert res
