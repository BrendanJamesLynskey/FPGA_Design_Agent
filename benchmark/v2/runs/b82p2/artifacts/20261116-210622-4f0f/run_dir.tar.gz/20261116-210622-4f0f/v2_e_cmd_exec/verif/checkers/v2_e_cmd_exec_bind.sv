bind v2_e_cmd_exec_top v2_e_cmd_exec_checker u_cmd_exec_checker (
    .clk(CLK100MHZ),
    .rst(~CPU_RESETN),
    .led(LED),
    .rxd(UART_RXD_OUT)
);
