class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000, BUILD_STAMP=0,
                 ID_VALUE=1430540337, PERIOD_RESET=100, PERIOD_MIN=4, NUM_REGS=8):
        self.p = dict(ID_VALUE=ID_VALUE, PERIOD_RESET=PERIOD_RESET,
                      PERIOD_MIN=PERIOD_MIN, NUM_REGS=NUM_REGS)
        self.inputs = {"CPU_RESETN": 1, "UART_TXD_IN": 1}
        self.reset()

    def reset(self):
        self.scratch = [0, 0, 0]
        self.cmds = 0
        self.errs = 0
        self.period = self.p["PERIOD_RESET"]
        self.uptime = 0
        self.tlm = 0
        self.typ = 0
        self.p0 = 0
        self.p1 = 0
        self.code = 0
        self.rdata = 0

    def _bank(self, n):
        if n == 0:
            return self.p["ID_VALUE"] & 0xFFFFFFFF
        if 1 <= n <= 3:
            return self.scratch[n - 1]
        return [self.cmds, self.errs, self.period, self.uptime][n - 4] if 4 <= n <= 7 else 0

    def _go(self):
        t, r, v = self.typ, self.p0, self.p1
        code = 0
        rd = 0
        ok = True
        if t == 1:
            if r >= 8:
                code = 3
            else:
                rd = self._bank(r)
        elif t == 2:
            if r >= 8:
                code = 3
            elif r == 0 or r >= 4:
                code = 5
            else:
                self.scratch[r - 1] = v & 0xFFFFFFFF
        elif t == 3:
            pass
        elif t == 4:
            if r != 0:
                self.period = max(r, self.p["PERIOD_MIN"])
            self.tlm = 1
        elif t == 5:
            self.tlm = 0
        else:
            code = 1
        self.code = code
        self.rdata = rd if code == 0 else 0
        if code == 0:
            self.cmds = (self.cmds + 1) & 0xFFFFFFFF
        else:
            self.errs = (self.errs + 1) & 0xFFFFFFFF

    def step(self, inputs=None):
        if inputs:
            self.inputs.update(inputs)
        if not self.inputs.get("CPU_RESETN", 1):
            self.reset()
        return {"UART_RXD_OUT": 1,
                "LED": ((self.cmds & 0xFF) << 8) | (self.errs & 0xFF)}

    def read_reg(self, offset):
        if offset == 0:
            return self.typ
        if offset == 1:
            return self.p0
        if offset == 2:
            return self.p1
        if offset == 4:
            return self.code & 7
        if offset == 5:
            return self.rdata
        if offset == 8:
            return self.tlm
        if 0x10 <= offset <= 0x17:
            return self._bank(offset - 0x10)
        return 0

    def write_reg(self, offset, value):
        if offset == 0:
            self.typ = value & 0xFF
        elif offset == 1:
            self.p0 = value & 0xFFFF
        elif offset == 2:
            self.p1 = value & 0xFFFFFFFF
        elif offset == 3:
            self._go()
        elif offset == 6:
            self.uptime = (self.uptime + (value & 0xFF)) & 0xFFFFFFFF
        elif offset == 7:
            self.errs = (self.errs + 1) & 0xFFFFFFFF
