// Port-only cover checker for v2_e_cmd_exec_top.
`include "v_macros.svh"

module cmd_exec_checker (
  input logic        clk,
  input logic        rst,
  input logic [15:0] LED,
  input logic        tx
);
  logic seen_rst = 1'b0;
  logic past_ok = 1'b1;
  always @(posedge clk) if (rst) seen_rst <= 1'b1;

  `V_COVER(C_errs_nonzero, LED[7:0] != 8'd0)   // req: REQ-21
  `V_COVER(C_cmds_nonzero, LED[15:8] != 8'd0)  // req: REQ-21b
  `V_COVER(C_tx_low, !tx)                      // req: REQ-23
endmodule
