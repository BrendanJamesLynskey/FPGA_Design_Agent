# v2_e_cmd_exec architecture

Command executor and register file on the Nexys A7-100T (xc7a100tcsg324-1), controlled through the test shell UART window.

## Block diagram

```text
 UART_TXD_IN --> [fpga_shell] --win_addr/wr/rd/wdata--> [cmd_exec_core] --> LED[15:0]
 UART_RXD_OUT <--            <--win_rdata (1 cycle)---   regs, executor,
                                                         CMDS/ERRS/UPTIME
 CPU_RESETN --> [reset_sync, 2-FF, async assert, sync release] --> rst (active high) to all
 CLK100MHZ ---> single clock domain
```

Window map: 0x00 TYP, 0x01 P0, 0x02 P1, 0x03 GO (write runs command), 0x04 CODE, 0x05 RDATA, 0x06 TICK, 0x07 REFUSED, 0x08 TLM, 0x10..0x17 BANK0..7.
Command executes in one cycle after GO; counters update the cycle after go; LED = ERRS[7:0], CMDS[7:0] straight from registers.
Telemetry period is stored and gated only.

## Clock plan

One domain: CLK100MHZ, 100 MHz (10 ns), board pin E3. No MMCM, no derived clocks, no CDC except the reset input.
Reset: CPU_RESETN (active low, async button) is synchronised once in the top by a 2-FF reset synchroniser and inverted once to an active-high synchronous reset used everywhere inside.

## Pin list

| Port | Dir | Width | Board resource |
|---|---|---|---|
| CLK100MHZ | in | 1 | E3 100 MHz clock |
| CPU_RESETN | in | 1 | red CPU RESET button, active low |
| UART_TXD_IN | in | 1 | USB-UART into FPGA (C4) |
| UART_RXD_OUT | out | 1 | USB-UART out of FPGA (D4) |
| LED | out | 16 | LED[7:0]=ERRS low byte, LED[15:8]=CMDS low byte |

## Resources

Predicted 500-1000 LUT, 400-800 FF, 0 BRAM, 0 DSP (shell UART plus 32-bit counters and register file).
