bind v2_e_cmd_exec_top cmd_exec_checker u_cmd_exec_checker (
  .clk(CLK100MHZ), .rst(~CPU_RESETN), .LED(LED), .tx(UART_RXD_OUT));
