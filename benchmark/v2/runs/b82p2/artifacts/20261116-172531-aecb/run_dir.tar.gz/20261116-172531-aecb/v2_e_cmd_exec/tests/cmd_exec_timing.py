"""Timing-intent smoke test: the design runs functionally on the 10 ns (100 MHz) clock.
Setup slack itself is closed by the post_route:setup analysis gate."""
import cocotb

from cmd_exec_bench import make_env, ID


# req: REQ-24
@cocotb.test()
async def test_clock_100mhz_smoke(dut):
    e = await make_env(dut)
    await e.rd(16, ID)
    code, rdata = await e.command(1, 0, 0)
    assert code == 0 and rdata == ID
