"""cocotb bench for v2_e_cmd_exec: every access goes through the shell UART (window 0x80+offset),
and every value is compared with model.py (and, for key facts, with literals from spec.yaml)."""
import os
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model as model_mod  # noqa: E402

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ClockCycles, FallingEdge, RisingEdge  # noqa: E402
from cocotb.utils import get_sim_time  # noqa: E402

CPB = 8  # CLKS_PER_BIT used by the bench (same value in the pytest entry and the model)
WIN = 0x80
ID = 0x55445031
M32 = 0xFFFFFFFF


def xor8(bs):
    r = 0
    for b in bs:
        r ^= b
    return r


class Env:
    def __init__(self, dut):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        self.m = model_mod.Model(CLKS_PER_BIT=CPB)
        self.rx = []
        self.rx_bad_stop = 0
        self.exp_led = 0

    async def start(self):
        d = self.dut
        d.UART_TXD_IN.value = 1
        d.CPU_RESETN.value = 0
        cocotb.start_soon(Clock(self.clk, 10, "ns").start())
        await ClockCycles(self.clk, 10)
        d.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 10)
        self.m.reset()
        self.exp_led = 0
        cocotb.start_soon(self._monitor())

    async def _monitor(self):
        while True:
            await FallingEdge(self.dut.UART_RXD_OUT)
            await ClockCycles(self.clk, CPB // 2)
            v = 0
            for i in range(8):
                await ClockCycles(self.clk, CPB)
                v |= (int(self.dut.UART_RXD_OUT.value) & 1) << i
            await ClockCycles(self.clk, CPB)
            if int(self.dut.UART_RXD_OUT.value) != 1:
                self.rx_bad_stop += 1
            self.rx.append(v)

    async def send_byte(self, b):
        for bit in [0] + [(b >> i) & 1 for i in range(8)] + [1]:
            self.dut.UART_TXD_IN.value = bit
            await ClockCycles(self.clk, CPB)

    async def transact(self, cmd, addr, data=0):
        body = bytes([cmd, addr]) + (data & M32).to_bytes(4, "little")
        req = bytes([0xA5]) + body + bytes([xor8(body)])
        self.rx.clear()
        for b in req:
            await self.send_byte(b)
        for _ in range(300):
            if len(self.rx) >= 7:
                break
            await ClockCycles(self.clk, CPB)
        assert len(self.rx) >= 7, "no response from the shell"
        await ClockCycles(self.clk, CPB)
        assert len(self.rx) == 7, f"response has {len(self.rx)} bytes"
        assert self.rx_bad_stop == 0, "response byte with a low stop bit"
        f = bytes(self.rx)
        assert f[0] == 0x5A, f"bad sync {f.hex()}"
        assert xor8(f[1:6]) == f[6], f"bad response checksum {f.hex()}"
        return f[1], int.from_bytes(f[2:6], "little")

    def step_model(self):
        out = self.m.step()
        self.exp_led = out["LED"]

    def check_led(self):
        got = int(self.dut.LED.value)
        assert got == self.exp_led, f"LED {got:#06x} != model {self.exp_led:#06x}"

    async def wr(self, off, val):
        st, data = await self.transact(2, WIN + off, val)
        assert st == 0, f"write window {off}: status {st}"
        assert data == (val & M32), f"write echo {data:#x} != {val:#x}"
        self.m.write_reg(off, val)
        self.step_model()
        await ClockCycles(self.clk, 2)
        self.check_led()

    async def rd(self, off, expect=None):
        st, data = await self.transact(1, WIN + off)
        assert st == 0, f"read window {off}: status {st}"
        exp = self.m.read_reg(off)
        assert data == exp, f"window {off}: dut {data:#x} model {exp:#x}"
        if expect is not None:
            assert data == expect, f"window {off}: dut {data:#x} expected {expect:#x}"
        self.check_led()
        return data

    async def snapshot(self):
        out = []
        for i in range(8):
            out.append(await self.rd(16 + i))
        return out

    async def command(self, typ, p0, p1):
        for off, val in ((0, typ), (1, p0), (2, p1)):
            if self.m.read_reg(off) != val:
                await self.wr(off, val)
        await self.wr(3, 0)
        code = await self.rd(4)
        rdata = await self.rd(5)
        return code, rdata


async def make_env(dut):
    e = Env(dut)
    await e.start()
    return e


# req: REQ-01, REQ-02, REQ-02b, REQ-02c, REQ-02d, REQ-02e, REQ-20
@cocotb.test()
async def test_reset_values(dut):
    e = await make_env(dut)
    snap = await e.snapshot()
    assert snap == [ID, 0, 0, 0, 0, 0, 100, 0], [hex(x) for x in snap]
    for off in (0, 1, 2, 3, 4, 5, 8):
        await e.rd(off, 0)
    assert int(dut.LED.value) == 0


# req: REQ-03, REQ-03b, REQ-14, REQ-20
@cocotb.test()
async def test_write_scratch(dut):
    e = await make_env(dut)
    vals = {1: 0xDEADBEEF, 2: 0x12345678, 3: 0xFFFFFFFF}
    for n, v in vals.items():
        code, rdata = await e.command(2, n, v)
        assert code == 0 and rdata == 0
        await e.rd(16 + n, v)
    await e.rd(20, 3)
    code, _ = await e.command(2, 2, 0xA5A5A5A5)
    assert code == 0
    snap = await e.snapshot()
    assert snap[:4] == [ID, 0xDEADBEEF, 0xA5A5A5A5, 0xFFFFFFFF]
    assert snap[4] == 4 and snap[5] == 0
    code, _ = await e.command(2, 1, 0)
    assert code == 0
    await e.rd(17, 0)


# req: REQ-04, REQ-04b, REQ-15, REQ-15b, REQ-16
@cocotb.test()
async def test_write_refused(dut):
    e = await make_env(dut)
    for n, v in ((1, 0x11111111), (2, 0x22222222), (3, 0x33333333)):
        await e.command(2, n, v)
    await e.wr(6, 7)
    prev = await e.snapshot()
    assert prev[1:4] == [0x11111111, 0x22222222, 0x33333333] and prev[7] == 7
    errs = 0
    for n in (0, 4, 5, 6, 7):
        code, rdata = await e.command(2, n, 0xCAFE0000 + n)
        errs += 1
        assert code == 5 and rdata == 0
        snap = await e.snapshot()
        exp = list(prev)
        exp[5] = errs
        assert snap == exp, f"reg {n}: {snap} vs {exp}"
        await e.rd(4, 5)
        await e.rd(5, 0)
    assert int(dut.LED.value) == (3 << 8) | 5


# req: REQ-05, REQ-06, REQ-14, REQ-16
@cocotb.test()
async def test_read_cmd(dut):
    e = await make_env(dut)
    await e.command(2, 1, 0x11111111)
    await e.command(2, 3, 0x33333333)
    await e.wr(6, 9)
    await e.wr(7, 0)
    await e.wr(2, 0xFFFFFFFF)  # param2 must be ignored by reads
    cmds, errs = 2, 1
    for n in range(8):
        code, rdata = await e.command(1, n, 0xFFFFFFFF)
        exp = [ID, 0x11111111, 0, 0x33333333, cmds, errs, 100, 9][n]
        assert code == 0, f"read {n}: code {code}"
        assert rdata == exp, f"read {n}: {rdata:#x} != {exp:#x}"
        cmds += 1
    await e.rd(20, cmds)
    # read data is cleared by a following non-read command
    code, rdata = await e.command(3, 0, 0)
    assert code == 0 and rdata == 0
    await e.command(1, 0, 0)
    code, rdata = await e.command(1, 8, 0)
    assert code == 3 and rdata == 0


# req: REQ-07, REQ-08, REQ-15, REQ-15b, REQ-16
@cocotb.test()
async def test_error_cmds(dut):
    e = await make_env(dut)
    await e.command(2, 1, 0xAAAA5555)
    await e.command(2, 2, 0x0000BEEF)
    await e.wr(2, 0x13572468)
    await e.wr(6, 3)
    code, rdata = await e.command(1, 0, 0)
    assert code == 0 and rdata == ID
    base = await e.snapshot()
    errs = 0
    cases = [(1, 8, 3), (2, 8, 3), (1, 9, 3), (2, 0xFFFF, 3), (1, 0x0100, 3), (2, 0x0101, 3),
             (0, 1, 1), (6, 1, 1), (7, 0, 1), (0x80, 2, 1), (0xFF, 3, 1), (9, 8, 1)]
    for typ, p0, exp_code in cases:
        code, rdata = await e.command(typ, p0, 0x13572468)
        errs += 1
        assert code == exp_code, f"type {typ} p0 {p0}: code {code}"
        assert rdata == 0, f"type {typ} p0 {p0}: rdata {rdata:#x}"
        await e.rd(21, errs)
    snap = await e.snapshot()
    exp = list(base)
    exp[5] = errs
    assert snap == exp, f"{snap} vs {exp}"


# req: REQ-09, REQ-09b, REQ-09c, REQ-10, REQ-10b, REQ-11, REQ-11b, REQ-12, REQ-12b, REQ-13, REQ-14, REQ-19
@cocotb.test()
async def test_status_telemetry(dut):
    e = await make_env(dut)
    await e.command(2, 1, 0x0BADF00D)
    await e.wr(6, 4)
    before = await e.snapshot()
    code, rdata = await e.command(3, 0x55, 0xAA55AA55)
    assert code == 0 and rdata == 0
    after = await e.snapshot()
    exp = list(before)
    exp[4] += 1
    assert after == exp
    await e.rd(8, 0)
    period = 100
    tlm = 0
    steps = [(4, 0), (5, 0x77), (4, 2), (5, 0), (4, 3), (4, 4), (4, 5), (4, 0), (5, 0),
             (4, 0xFFFF), (4, 1), (5, 5), (5, 5), (4, 0), (4, 0x1000), (4, 0)]
    for typ, p0 in steps:
        code, rdata = await e.command(typ, p0, 0)
        assert code == 0 and rdata == 0, f"type {typ} p0 {p0}: code {code} rdata {rdata}"
        if typ == 4:
            tlm = 1
            if p0 != 0:
                period = max(p0, 4)
        else:
            tlm = 0
        await e.rd(8, tlm)
        await e.rd(22, period)
    await e.rd(20, before[4] + 1 + len(steps))


# req: REQ-17, REQ-18
@cocotb.test()
async def test_tick_refused(dut):
    e = await make_env(dut)
    up = 0
    for v in (5, 255, 0, 1, 0x1FF, 128):
        await e.wr(6, v)
        up += v & 0xFF
        await e.rd(23, up)
    errs = 0
    for v in (0, 0xFFFFFFFF, 5, 0x100):
        await e.wr(7, v)
        errs += 1
        await e.rd(21, errs)
    await e.rd(20, 0)
    await e.rd(23, up)
    await e.rd(4, 0)
    await e.rd(5, 0)
    await e.rd(8, 0)
    assert int(dut.LED.value) == errs


# req: REQ-21, REQ-21b
@cocotb.test()
async def test_led_outputs(dut):
    e = await make_env(dut)
    assert int(dut.LED.value) == 0
    await e.command(3, 0, 0)
    assert int(dut.LED.value) == 0x0100
    for i in range(1, 12):
        await e.wr(3, 0)
        assert int(dut.LED.value) == ((1 + i) << 8), f"cmds {i}"
    for i in range(1, 9):
        await e.wr(7, 0)
        assert int(dut.LED.value) == (12 << 8) | i
    await e.command(0, 0, 0)  # failed command: ERRS +1
    assert int(dut.LED.value) == (12 << 8) | 9
    await e.rd(20, 12)
    await e.rd(21, 9)


# req: REQ-22, REQ-19
@cocotb.test()
async def test_reset_mid(dut):
    e = await make_env(dut)
    resets = [0, 1, 2, 3, 4, 5, 8]

    async def pulse():
        dut.CPU_RESETN.value = 0
        await ClockCycles(e.clk, 6)
        assert int(dut.LED.value) == 0
        assert int(dut.UART_RXD_OUT.value) == 1
        dut.CPU_RESETN.value = 1
        await ClockCycles(e.clk, 6)
        e.m.reset()
        e.exp_led = 0

    async def all_reset():
        snap = await e.snapshot()
        assert snap == [ID, 0, 0, 0, 0, 0, 100, 0], [hex(x) for x in snap]
        for off in resets:
            if off != 3:
                await e.rd(off, 0)
        assert int(dut.LED.value) == 0

    # phase A: nonzero read data
    await e.command(2, 1, 0x77777777)
    code, rdata = await e.command(1, 0, 0)
    assert rdata == ID
    await pulse()
    await all_reset()
    # phase B: dirty everything, end with a failed command (code 1)
    await e.command(2, 1, 0x1234)
    await e.command(2, 2, 0x5678)
    await e.command(2, 3, 0x9ABC)
    await e.wr(6, 200)
    await e.wr(7, 1)
    await e.command(4, 9, 0)
    await e.rd(8, 1)
    await e.rd(22, 9)
    code, _ = await e.command(9, 0, 0)
    assert code == 1
    await pulse()
    await all_reset()
    # the design works after reset
    code, rdata = await e.command(1, 0, 0)
    assert code == 0 and rdata == ID


# req: REQ-23
@cocotb.test()
async def test_uart_baud(dut):
    e = await make_env(dut)
    widths = []

    async def meas():
        await FallingEdge(dut.UART_RXD_OUT)
        t0 = get_sim_time("ns")
        await RisingEdge(dut.UART_RXD_OUT)
        widths.append(round((get_sim_time("ns") - t0) / 10.0))

    cocotb.start_soon(meas())
    await e.rd(16, ID)
    # first response byte 0x5A: start bit + bit0 are both low = 2 bit times
    assert widths and abs(widths[0] - 2 * CPB) <= 1, f"low pulse {widths} cycles, expected {2 * CPB}"
    await e.rd(22, 100)


# req: REQ-01, REQ-03, REQ-04, REQ-05, REQ-06, REQ-07, REQ-08, REQ-09, REQ-10, REQ-11, REQ-12, REQ-13, REQ-14, REQ-15, REQ-16, REQ-17, REQ-18, REQ-19, REQ-20, REQ-21, REQ-21b
@cocotb.test()
async def test_random_commands(dut):
    e = await make_env(dut)
    seed = getattr(cocotb, "RANDOM_SEED", 1) or 1
    rnd = random.Random(seed)
    dut._log.info(f"random seed {seed}")

    def p1_val():
        return rnd.choice([0, 1, M32, rnd.getrandbits(32), rnd.getrandbits(32)])

    types = [1, 1, 1, 2, 2, 2, 3, 4, 4, 5, 0, 6, 7, 0xFF, 0x80]
    for _ in range(20):
        kind = rnd.random()
        if kind < 0.75:
            typ = rnd.choice(types)
            if typ in (1, 2):
                p0 = rnd.choice([0, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 8, 9, 0x100, 0xFFFF,
                                 rnd.randint(8, 0xFFFF)])
            elif typ == 4:
                p0 = rnd.choice([0, 1, 2, 3, 4, 5, 0xFFFF, rnd.getrandbits(16)])
            else:
                p0 = rnd.getrandbits(16)
            await e.command(typ, p0, p1_val())
        elif kind < 0.85:
            await e.wr(6, rnd.choice([0, 1, 255, rnd.randint(0, 255)]))
        elif kind < 0.95:
            await e.wr(7, p1_val())
        else:
            await e.rd(rnd.choice([8, 16, 17, 18, 19, 20, 21, 22, 23]))
    snap = await e.snapshot()
    for i in range(8):
        assert snap[i] == e.m.read_reg(16 + i)
    await e.rd(8)
    await e.rd(4)
    await e.rd(5)
