M32 = 0xFFFFFFFF


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000, BUILD_STAMP=0,
                 ID_VALUE=1430540337, PERIOD_RESET=100, PERIOD_MIN=4, NUM_REGS=8):
        self.CLKS_PER_BIT = CLKS_PER_BIT
        self.TIMEOUT_CYCLES = TIMEOUT_CYCLES
        self.BUILD_STAMP = BUILD_STAMP
        self.ID_VALUE = ID_VALUE
        self.PERIOD_RESET = PERIOD_RESET
        self.PERIOD_MIN = PERIOD_MIN
        self.NUM_REGS = NUM_REGS
        self.reset()

    def reset(self):
        self.typ = 0
        self.p0 = 0
        self.p1 = 0
        self.code = 0
        self.rdata = 0
        self.tlm = 0
        self.bank = [self.ID_VALUE & M32, 0, 0, 0, 0, 0, self.PERIOD_RESET & M32, 0]
        self._go = False
        self._tick = None
        self._refused = 0
        self._in = {}

    def write_reg(self, offset, value):
        if offset == 0:
            self.typ = value & 0xFF
        elif offset == 1:
            self.p0 = value & 0xFFFF
        elif offset == 2:
            self.p1 = value & M32
        elif offset == 3:
            self._go = True
        elif offset == 6:
            self._tick = (self._tick or 0) + (value & 0xFF)
        elif offset == 7:
            self._refused += 1

    def read_reg(self, offset):
        if offset == 0:
            return self.typ
        if offset == 1:
            return self.p0
        if offset == 2:
            return self.p1
        if offset == 4:
            return self.code & 7
        if offset == 5:
            return self.rdata
        if offset == 8:
            return self.tlm
        if 16 <= offset < 24:
            return self.bank[offset - 16]
        return 0

    def _leds(self):
        return ((self.bank[4] & 0xFF) << 8) | (self.bank[5] & 0xFF)

    def step(self, inputs=None):
        if inputs:
            self._in.update(inputs)
            if "CPU_RESETN" in inputs and not inputs["CPU_RESETN"]:
                self.reset()
                self._in = {"CPU_RESETN": 0}
                return {"UART_RXD_OUT": 1, "LED": 0}
        b = self.bank
        cmds_inc = 0
        errs_inc = self._refused
        uptime_inc = self._tick or 0
        if self._go:
            t, p1, p2 = self.typ, self.p0, self.p1
            code = 0
            data = 0
            if t == 1:
                if p1 < 8:
                    data = b[p1]
                else:
                    code = 3
            elif t == 2:
                if p1 >= 8:
                    code = 3
                elif p1 in (1, 2, 3):
                    b[p1] = p2
                else:
                    code = 5
            elif t == 3:
                pass
            elif t == 4:
                if p1 != 0:
                    b[6] = max(p1, self.PERIOD_MIN)
                self.tlm = 1
            elif t == 5:
                self.tlm = 0
            else:
                code = 1
            self.code = code
            self.rdata = data
            if code == 0:
                cmds_inc = 1
            else:
                errs_inc += 1
        b[4] = (b[4] + cmds_inc) & M32
        b[5] = (b[5] + errs_inc) & M32
        b[7] = (b[7] + uptime_inc) & M32
        self._go = False
        self._tick = None
        self._refused = 0
        return {"UART_RXD_OUT": 1, "LED": self._leds()}
