import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from flow import cocotb_run  # noqa: E402

# CLKS_PER_BIT is shortened for simulation speed; the bench and the model use the same value.
PARAMS = {"CLKS_PER_BIT": 8}


def test_v2_e_cmd_exec_rtl():
    test_dir = Path(__file__).resolve().parent
    design_dir = test_dir.parent
    sources = cocotb_run.SHELL_RTL + sorted((design_dir / "rtl").glob("*.sv"))
    for seed in (1, 2, 3):
        cocotb_run.run("v2_e_cmd_exec", "v2_e_cmd_exec_top", sources,
                       "cmd_exec_bench,cmd_exec_timing",
                       test_dir, parameters=PARAMS, seed=seed)
