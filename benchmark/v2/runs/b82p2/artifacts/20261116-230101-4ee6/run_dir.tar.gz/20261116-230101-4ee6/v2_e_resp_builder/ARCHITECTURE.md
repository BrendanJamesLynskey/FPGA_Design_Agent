# v2_e_resp_builder architecture

Reply frame builder with CRC-32 on Nexys A7-100T (xc7a100tcsg324-1), single 100 MHz clock domain.

## Block diagram

```text
 UART_TXD_IN --> +-----------+ win_*  +-----------------------------+
                 | fpga_shell|<------>| resp_regs                   |
 UART_RXD_OUT <--+-----------+        |  TYPE STATUS SEQ IDX        |
                                      |  payload[24] cnt, overflow  |
                                      |  reply buf[33], LEN         |
                                      +--------+--------------------+
                                               | build start
                                      +--------v--------+   +-------+
                                      | resp_builder FSM|-->| crc32 |
                                      +-----------------+   +-------+
                 LED[7:0]=LEN, LED[15:8]=reply status  <-- resp_regs
```

## Clock plan
One clock domain: CLK100MHZ, 100 MHz, no MMCM, no CDC. CPU_RESETN (active low, synchronous) is inverted once at the top into an active-high internal reset; the button input is registered through a 2-FF synchroniser stage before use.

## Reset
Synchronous, active high inside. Resets control state (counts, flags, TYPE/STATUS/SEQ/IDX, length); datapath buffer is not reset, reads are masked by length.

## Pin list
- CLK100MHZ: input, 100 MHz clock
- CPU_RESETN: input, active-low reset
- UART_TXD_IN: input, host to FPGA
- UART_RXD_OUT: output, FPGA to host
- LED[15:0]: output, LED[7:0] reply length, LED[15:8] reply status byte

## Resources
About 250-700 LUT, 250-550 FF, 0-1 BRAM, 0 DSP.
