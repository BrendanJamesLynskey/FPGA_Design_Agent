"""cocotb bench for v2_e_resp_builder: drives the shell UART, compares every read with model.py."""
import random
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ClockCycles, FallingEdge, RisingEdge  # noqa: E402

CPB = 8  # CLKS_PER_BIT override (same value passed to the model)
WIN = 0x80
SETTLE = 70  # model cycles after a write (build finishes in <= 64 clocks)
DESIGN_ID = 1381188145


def expected_reply(t, s, q, p):
    b = bytes([0x80 | (t & 0x7F), s & 0xFF, (q >> 8) & 0xFF, q & 0xFF, len(p)]) + bytes(p)
    return list(b + (zlib.crc32(b) & 0xFFFFFFFF).to_bytes(4, "little"))


class Bench:
    def __init__(self, dut):
        self.dut = dut
        self.m = model.Model(CLKS_PER_BIT=CPB)
        self.out = self.m._outputs() if hasattr(self.m, "_outputs") else {}
        # independent shadow of the architectural state (not from the model)
        self.t = self.s = self.q = 0
        self.p = []
        self.reply = []

    async def start(self):
        cocotb.start_soon(Clock(self.dut.CLK100MHZ, 10, units="ns").start())
        self.dut.UART_TXD_IN.value = 1
        await self.reset()

    async def reset(self):
        d = self.dut
        d.CPU_RESETN.value = 0
        await ClockCycles(d.CLK100MHZ, 5)
        d.CPU_RESETN.value = 1
        await ClockCycles(d.CLK100MHZ, 5)
        self.out = self.m.step({"CPU_RESETN": 0})
        self.t = self.s = self.q = 0
        self.p = []
        self.reply = []

    # ---- UART ----
    async def send(self, byte):
        d = self.dut
        bits = [0] + [(byte >> i) & 1 for i in range(8)] + [1]
        for b in bits:
            d.UART_TXD_IN.value = b
            await ClockCycles(d.CLK100MHZ, CPB)

    async def recv_byte(self):
        d = self.dut
        await FallingEdge(d.UART_RXD_OUT)
        await ClockCycles(d.CLK100MHZ, CPB + CPB // 2)
        v = 0
        for i in range(8):
            v |= int(d.UART_RXD_OUT.value) << i
            await ClockCycles(d.CLK100MHZ, CPB)
        return v

    async def recv_frame(self):
        return [await self.recv_byte() for _ in range(7)]

    async def txn(self, cmd, addr, data=0, bad_chk=False):
        body = bytes([cmd, addr]) + (data & 0xFFFFFFFF).to_bytes(4, "little")
        chk = 0
        for x in body:
            chk ^= x
        if bad_chk:
            chk ^= 0x5A
        rx = cocotb.start_soon(self.recv_frame())
        for x in [0xA5] + list(body) + [chk]:
            await self.send(x)
        fr = await rx
        assert fr[0] == 0x5A, f"bad response sync {fr}"
        c = 0
        for x in fr[1:6]:
            c ^= x
        assert c == fr[6], f"bad response checksum {fr}"
        return fr[1], int.from_bytes(bytes(fr[2:6]), "little")

    # ---- register access ----
    async def wr(self, off, val):
        st, _ = await self.txn(2, WIN + off, val)
        assert st == 0, f"write status {st} at offset {off}"
        self.m.write_reg(off, val)
        for _ in range(SETTLE):
            self.out = self.m.step({"CPU_RESETN": 1})
        # independent shadow
        if off == 0:
            self.t = val & 0x7F
        elif off == 1:
            self.s = val & 0xFF
        elif off == 2:
            self.q = val & 0xFFFF
        elif off == 3:
            if len(self.p) < 24:
                self.p.append(val & 0xFF)
        elif off == 4:
            self.reply = expected_reply(self.t, self.s, self.q, self.p)
            self.rs = self.s
            self.p = []

    async def rd(self, off):
        st, v = await self.txn(1, WIN + off)
        assert st == 0, f"read status {st} at offset {off}"
        return v

    async def chk(self, off):
        v = await self.rd(off)
        e = self.m.read_reg(off)
        assert v == e, f"reg {off}: dut {v:#x} model {e:#x}"
        return v

    def chk_led(self):
        led = int(self.dut.LED.value)
        e = self.out["LED"]
        assert led == e, f"LED dut {led:#x} model {e:#x}"
        assert (led & 0xFF) == len(self.reply)
        if not self.reply:
            assert (led >> 8) == 0

    async def chk_all(self):
        for off in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9):
            await self.chk(off)
        self.chk_led()

    async def read_reply(self, indices=None):
        n = len(self.reply)
        idxs = indices if indices is not None else range(n + 2)
        for i in idxs:
            await self.wr(5, i)
            v = await self.chk(6)
            exp = self.reply[i] if i < n else 0
            assert v == exp, f"BYTE[{i}] {v:#x} != {exp:#x}"
        assert await self.chk(7) == n


# req: REQ-20, REQ-24, REQ-25, REQ-26, REQ-32, REQ-22
@cocotb.test()
async def test_smoke_reset_id(dut):
    b = Bench(dut)
    await b.start()
    # DESIGN_ID through the shell register 0x00
    st, v = await b.txn(1, 0x00)
    assert st == 0 and v == DESIGN_ID, f"design id {v:#x}"
    # bad checksum is rejected, then the shell still works
    st, v = await b.txn(1, 0x00, bad_chk=True)
    assert st == 1 and v == 0
    st, v = await b.txn(1, 0x00)
    assert st == 0 and v == DESIGN_ID
    await b.chk_all()
    for off in (7, 6, 8, 9):
        assert await b.rd(off) == 0
    assert int(dut.LED.value) == 0


# req: REQ-08, REQ-29, REQ-03, REQ-28, REQ-09, REQ-17, REQ-25
@cocotb.test()
async def test_register_widths(dut):
    b = Bench(dut)
    await b.start()
    await b.wr(0, 0xFF)
    assert await b.chk(0) == 0x7F
    await b.wr(1, 0x1A5)
    assert await b.chk(1) == 0xA5
    await b.wr(2, 0x1234ABCD)
    assert await b.chk(2) == 0xABCD
    await b.wr(5, 0xFF)
    assert await b.chk(5) == 0x7F
    await b.wr(0, 0x15)
    assert await b.chk(0) == 0x15
    # write-only registers read 0, unmapped read 0
    await b.wr(3, 0x77)
    assert await b.rd(3) == 0
    await b.wr(4, 0xDEAD)
    assert await b.rd(4) == 0
    for off in (10, 11, 0x20, 0x7E):
        assert await b.rd(off) == 0, off
    # writes to RO / unmapped registers do nothing
    await b.wr(7, 0x55)
    await b.wr(10, 0x55)
    await b.chk_all()


# req: REQ-01, REQ-02, REQ-03, REQ-28, REQ-04, REQ-06, REQ-07, REQ-13, REQ-31, REQ-14, REQ-15, REQ-17, REQ-18, REQ-20, REQ-22, REQ-23, REQ-32, REQ-09
@cocotb.test()
async def test_build_empty(dut):
    b = Bench(dut)
    await b.start()
    await b.wr(0, 0xF3)
    await b.wr(1, 0xC9)
    await b.wr(2, 0xBEEF)
    await b.wr(4, 0)
    assert await b.chk(7) == 9
    assert await b.chk(8) == 0
    assert await b.chk(9) == 0
    await b.read_reply()
    b.chk_led()
    assert int(dut.LED.value) == (0xC9 << 8) | 9
    # registers kept across the build
    assert await b.chk(0) == 0x73
    assert await b.chk(1) == 0xC9
    assert await b.chk(2) == 0xBEEF
    # a second build with a 1-byte payload
    await b.wr(3, 0x1AB)
    assert await b.chk(9) == 1
    await b.wr(4, 1)
    assert await b.chk(9) == 0
    await b.read_reply()
    assert await b.chk(7) == 10
    b.chk_led()


# req: REQ-05, REQ-04, REQ-06, REQ-07, REQ-10, REQ-12, REQ-13, REQ-21, REQ-31, REQ-16, REQ-01
@cocotb.test()
async def test_build_full_payload(dut):
    b = Bench(dut)
    await b.start()
    await b.wr(0, 0x2A)
    await b.wr(1, 0x00)
    await b.wr(2, 0xFF00)
    for i in range(24):
        await b.wr(3, (i * 37 + 11) & 0xFF)
        assert await b.chk(9) == i + 1
        if i % 8 == 7:
            assert await b.chk(8) == 0
    await b.wr(4, 0)
    assert await b.chk(9) == 0
    assert await b.chk(8) == 0
    assert await b.chk(7) == 33
    await b.read_reply()
    b.chk_led()
    assert int(dut.LED.value) == 33


# req: REQ-11, REQ-30, REQ-12, REQ-16, REQ-21, REQ-31, REQ-13, REQ-05, REQ-15
@cocotb.test()
async def test_overflow(dut):
    b = Bench(dut)
    await b.start()
    for i in range(24):
        await b.wr(3, 0x10 + i)
    assert await b.chk(8) == 0
    await b.wr(3, 0xEE)  # 25th: dropped, sets overflow
    assert await b.chk(8) == 2
    assert await b.chk(9) == 24
    await b.wr(3, 0xEF)
    assert await b.chk(9) == 24
    assert await b.chk(8) == 2
    await b.wr(4, 0)
    assert await b.chk(8) == 0
    assert await b.chk(9) == 0
    assert await b.chk(7) == 33
    assert 0xEE not in b.reply[5:29]
    await b.read_reply(range(0, 35, 1))
    # overflow after reset is cleared too
    await b.wr(3, 1)
    await b.reset()
    await b.chk_all()


# req: REQ-19, REQ-09, REQ-22, REQ-23
@cocotb.test()
async def test_reply_stable(dut):
    b = Bench(dut)
    await b.start()
    await b.wr(0, 5)
    await b.wr(1, 0x42)
    await b.wr(2, 0x0102)
    await b.wr(3, 0xAA)
    await b.wr(3, 0xBB)
    await b.wr(4, 0)
    before = list(b.reply)
    await b.read_reply()
    led = int(dut.LED.value)
    # change registers and payload: reply must not change until the next build
    await b.wr(0, 0x7E)
    await b.wr(1, 0x99)
    await b.wr(2, 0xFFFF)
    await b.wr(3, 0x11)
    assert int(dut.LED.value) == led
    assert b.reply == before
    await b.read_reply()
    assert int(dut.LED.value) == led
    await b.wr(4, 0)
    assert b.reply != before
    await b.read_reply()
    b.chk_led()


# req: REQ-24, REQ-20, REQ-32, REQ-22, REQ-23, REQ-13, REQ-31
@cocotb.test()
async def test_reset_clears_state(dut):
    b = Bench(dut)
    await b.start()
    await b.wr(0, 0x33)
    await b.wr(1, 0x44)
    await b.wr(2, 0x5566)
    await b.wr(5, 3)
    await b.wr(3, 9)
    await b.wr(4, 0)
    await b.wr(3, 7)
    assert int(dut.LED.value) != 0
    await b.reset()
    await b.chk_all()
    assert int(dut.LED.value) == 0
    for off in (0, 1, 2, 5, 6, 7, 8, 9):
        assert await b.rd(off) == 0
    for i in (0, 3, 4, 8, 12):
        await b.wr(5, i)
        assert await b.rd(6) == 0


# req: REQ-01, REQ-02, REQ-03, REQ-28, REQ-04, REQ-05, REQ-06, REQ-07, REQ-08, REQ-29, REQ-09, REQ-10, REQ-11, REQ-30, REQ-12, REQ-13, REQ-31, REQ-14, REQ-15, REQ-16, REQ-17, REQ-18, REQ-19, REQ-21, REQ-22, REQ-23, REQ-32, REQ-24
@cocotb.test()
async def test_random_traffic(dut):
    rnd = random.Random(cocotb.RANDOM_SEED)
    b = Bench(dut)
    await b.start()
    for rnum in range(3):
        for _ in range(rnd.randint(0, 3)):
            off = rnd.choice((0, 1, 2))
            await b.wr(off, rnd.getrandbits(32) if rnd.random() < 0.7 else rnd.choice((0, 0xFF, 0x7F, 0x80, 0xFFFF)))
        n = rnd.choice((0, 1, 5, 23, 24, 25, 26))
        for _ in range(n):
            await b.wr(3, rnd.getrandbits(32))
            if rnd.random() < 0.15:
                await b.chk(9)
                await b.chk(8)
        await b.chk(9)
        await b.chk(8)
        await b.wr(4, rnd.getrandbits(32))
        await b.chk(8)
        await b.chk(9)
        n = len(b.reply)
        idxs = [0, 1, 4, n - 5, n - 1, n, n + 1, rnd.randrange(0, 128)] + [rnd.randrange(0, n + 3) for _ in range(2)]
        await b.read_reply([i for i in idxs if 0 <= i < 128])
        for off in (0, 1, 2, 5):
            await b.chk(off)
        b.chk_led()
        if rnum == 1 and rnd.random() < 0.7:
            await b.wr(3, 0x5A)
            await b.reset()
            await b.chk_all()
    await b.chk_all()
