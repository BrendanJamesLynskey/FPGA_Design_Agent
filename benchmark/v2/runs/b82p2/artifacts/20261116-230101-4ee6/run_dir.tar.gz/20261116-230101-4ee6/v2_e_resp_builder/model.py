import zlib


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000, BUILD_STAMP=0,
                 MAX_PAYLOAD=24, BUILD_MAX_CYCLES=64, DESIGN_ID=1381188145,
                 MAX_REPLY_BYTES=33):
        self.CLKS_PER_BIT = CLKS_PER_BIT
        self.TIMEOUT_CYCLES = TIMEOUT_CYCLES
        self.BUILD_STAMP = BUILD_STAMP
        self.MAX_PAYLOAD = MAX_PAYLOAD
        self.BUILD_MAX_CYCLES = BUILD_MAX_CYCLES
        self.DESIGN_ID = DESIGN_ID
        self.MAX_REPLY_BYTES = MAX_REPLY_BYTES
        self.reset()

    def reset(self):
        self.type = 0
        self.status = 0
        self.seq = 0
        self.idx = 0
        self.payload = []
        self.overflow = 0
        self.building = 0
        self.count = 0
        self.snap = None
        self.reply = []
        self.rstatus = 0

    def _outputs(self):
        return {"UART_RXD_OUT": 1,
                "LED": ((self.rstatus & 0xFF) << 8) | (len(self.reply) & 0xFF)}

    def step(self, inputs=None):
        if inputs and "CPU_RESETN" in inputs and inputs["CPU_RESETN"] == 0:
            self.reset()
            return self._outputs()
        if self.building:
            self.count -= 1
            if self.count <= 0:
                t, s, q, p = self.snap
                b = bytes([0x80 | t, s, (q >> 8) & 0xFF, q & 0xFF, len(p)]) + bytes(p)
                c = zlib.crc32(b) & 0xFFFFFFFF
                b += c.to_bytes(4, "little")
                self.reply = list(b)
                self.rstatus = s
                self.payload = []
                self.overflow = 0
                self.building = 0
        return self._outputs()

    def write_reg(self, offset, value):
        if offset == 0:
            self.type = value & 0x7F
        elif offset == 1:
            self.status = value & 0xFF
        elif offset == 2:
            self.seq = value & 0xFFFF
        elif offset == 3:
            if self.building:
                return
            if len(self.payload) < self.MAX_PAYLOAD:
                self.payload.append(value & 0xFF)
            else:
                self.overflow = 1
        elif offset == 4:
            if self.building:
                return
            self.building = 1
            self.snap = (self.type, self.status, self.seq, list(self.payload))
            self.count = 2 + len(self.payload)
        elif offset == 5:
            self.idx = value & 0x7F

    def read_reg(self, offset):
        if offset == 0:
            return self.type
        if offset == 1:
            return self.status
        if offset == 2:
            return self.seq
        if offset == 5:
            return self.idx
        if offset == 6:
            return self.reply[self.idx] if self.idx < len(self.reply) else 0
        if offset == 7:
            return len(self.reply)
        if offset == 8:
            return self.building | (self.overflow << 1)
        if offset == 9:
            return len(self.payload)
        if offset == 0xFF:
            return self.DESIGN_ID
        return 0
