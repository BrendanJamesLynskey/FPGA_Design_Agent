"""pytest entry: runs the cocotb bench on the RTL for several seeds."""
from pathlib import Path

from flow import cocotb_run

DESIGN_DIR = Path(__file__).resolve().parents[1]


def test_v2_e_resp_builder_rtl():
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN_DIR / "rtl").glob("*.sv"))
    for seed in (1, 2, 3):
        cocotb_run.run(
            "v2_e_resp_builder",
            "v2_e_resp_builder_top",
            sources,
            "resp_builder_bench",
            DESIGN_DIR / "tests",
            parameters={"CLKS_PER_BIT": 8},
            seed=seed,
        )
