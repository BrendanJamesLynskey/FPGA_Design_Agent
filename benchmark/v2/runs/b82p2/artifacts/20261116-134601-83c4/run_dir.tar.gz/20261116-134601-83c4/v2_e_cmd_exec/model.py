M32 = 0xFFFFFFFF


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000, BUILD_STAMP=0,
                 ID_VALUE=1430540337, PERIOD_RESET=100, PERIOD_MIN=4, NUM_REGS=8):
        self.CLKS_PER_BIT = CLKS_PER_BIT
        self.TIMEOUT_CYCLES = TIMEOUT_CYCLES
        self.BUILD_STAMP = BUILD_STAMP
        self.ID_VALUE = ID_VALUE
        self.PERIOD_RESET = PERIOD_RESET
        self.PERIOD_MIN = PERIOD_MIN
        self.NUM_REGS = NUM_REGS
        self.reset()

    def reset(self):
        self.typ = 0
        self.p0 = 0
        self.p1 = 0
        self.code = 0
        self.rdata = 0
        self.tlm = 0
        self.bank = [self.ID_VALUE, 0, 0, 0, 0, 0, self.PERIOD_RESET, 0]
        self.inputs = {"CPU_RESETN": 1, "UART_TXD_IN": 1}

    def step(self, inputs=None):
        if inputs:
            self.inputs.update(inputs)
        if not self.inputs.get("CPU_RESETN", 1):
            self.reset()
            self.inputs["CPU_RESETN"] = 0
        return {
            "UART_RXD_OUT": 1,
            "LED": ((self.bank[4] & 0xFF) << 8) | (self.bank[5] & 0xFF),
        }

    def _go(self):
        t = self.typ & 0xFF
        r = self.p0 & 0xFFFF
        v = self.p1 & M32
        code = 0
        rd = 0
        b = self.bank
        if t == 1:
            if r >= self.NUM_REGS:
                code = 3
            else:
                rd = b[r]
        elif t == 2:
            if r >= self.NUM_REGS:
                code = 3
            elif r in (1, 2, 3):
                b[r] = v
            else:
                code = 5
        elif t == 3:
            pass
        elif t == 4:
            if r != 0:
                b[6] = max(r, self.PERIOD_MIN)
            self.tlm = 1
        elif t == 5:
            self.tlm = 0
        else:
            code = 1
        self.code = code
        self.rdata = rd
        if code == 0:
            b[4] = (b[4] + 1) & M32
        else:
            b[5] = (b[5] + 1) & M32

    def read_reg(self, offset):
        if offset == 0:
            return self.typ
        if offset == 1:
            return self.p0
        if offset == 2:
            return self.p1
        if offset == 4:
            return self.code & 7
        if offset == 5:
            return self.rdata
        if offset == 8:
            return self.tlm
        if 16 <= offset < 24:
            return self.bank[offset - 16]
        return 0

    def write_reg(self, offset, value):
        if offset == 0:
            self.typ = value & 0xFF
        elif offset == 1:
            self.p0 = value & 0xFFFF
        elif offset == 2:
            self.p1 = value & M32
        elif offset == 3:
            self._go()
        elif offset == 6:
            self.bank[7] = (self.bank[7] + (value & 0xFF)) & M32
        elif offset == 7:
            self.bank[5] = (self.bank[5] + 1) & M32
