# Architecture: v2_e_cmd_exec (command executor and register file, ID CXR1)

Board: Nexys A7-100T, xc7a100tcsg324-1. Top: `v2_e_cmd_exec_top`.

## Block diagram

```text
 UART_TXD_IN --> [fpga_shell] --win_addr/wr/rd/wdata--> [cmd_exec] --> [led_out] --> LED[15:0]
 UART_RXD_OUT <--[ (uart)    ] <--------win_rdata------- [ regs,   ]
                      ^ rst                                 ^ rst
 CPU_RESETN --> [reset_sync] -- active-high rst (one polarity inside) --+
 CLK100MHZ ---------------------- single clock domain, all blocks
```

- fpga_shell: UART 115200 8N1 (CLKS_PER_BIT 868, TIMEOUT_CYCLES 100000), DESIGN_ID "CXR1"-style ID_VALUE, BUILD_STAMP passed from top parameter.
- cmd_exec: window registers TYP 0x00, P0 0x01, P1 0x02, GO 0x03, CODE 0x04, RDATA 0x05, TICK 0x06, REFUSED 0x07, TLM 0x08, BANK0..7 at 0x10..0x17. GO executes the staged command; result, read data and counters update within 2 cycles. Register-number check comes first (>=8 gives 3), then read-only check (0,4..7 gives 5). Failed commands change only ERRS. Counters wrap at 2^32. win_rdata registered (valid one cycle after win_rd).
- led_out: registered copy of ERRS[7:0] and CMDS[7:0].

## Clock plan

One domain: CLK100MHZ, 100 MHz (10 ns), constrained on the port. No derived clocks, no MMCM. The only crossings are the asynchronous inputs: CPU_RESETN through a reset synchroniser (async assert, sync release; active-high internally) and UART_TXD_IN through a 2-FF synchroniser inside the shell. Resets are synchronous elsewhere; only control and counter registers are reset, not datapath.

## Pin list

| Port | Dir | Width | Pin / role |
|---|---|---|---|
| CLK100MHZ | in | 1 | E3, 100 MHz clock |
| CPU_RESETN | in | 1 | C12, active-low reset button |
| UART_TXD_IN | in | 1 | C4, host to FPGA |
| UART_RXD_OUT | out | 1 | D4, FPGA to host |
| LED | out | 16 | LED[7:0]=ERRS low byte, LED[15:8]=CMDS low byte |

Pins come from the master XDC via board_constraints; I/O timing lines (input delay on CPU_RESETN and UART_TXD_IN, output delay on UART_RXD_OUT and LED, or false paths since these are asynchronous human/serial IO) are added in design.xdc with a comment per group.

## Resource prediction

LUT 250-800, FF 300-800 (shell about 250 FF; design about 350 FF: 3x32 scratch, P0/P1, TYP, PERIOD, CMDS/ERRS/UPTIME, RDATA, CODE, TLM, LED regs), BRAM 0, DSP 0. Spec limit under 600 each.
