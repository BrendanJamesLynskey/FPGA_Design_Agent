`include "v_macros.svh"

module v2_e_cmd_exec_chk (
    input wire clk,
    input wire rst,
    input wire rxd,
    input wire [15:0] led
);
  reg seen_rst = 1'b0;
  reg past_ok = 1'b0;
  always @(posedge clk) begin
    past_ok <= 1'b1;
    if (rst) seen_rst <= 1'b1;
  end

  `V_SAME(A_led_known, 1'b1, !$isunknown(led))  // req: REQ-27, REQ-28
  `V_SAME(A_rxd_known, 1'b1, !$isunknown(rxd))  // req: REQ-30
  `V_COVER(C_led_err, led[7:0] != 8'h00)  // req: REQ-27
  `V_COVER(C_led_cmds, led[15:8] != 8'h00)  // req: REQ-28
  `V_COVER(C_tx_active, !rxd)  // req: REQ-30
endmodule

bind v2_e_cmd_exec_top v2_e_cmd_exec_chk u_v2_chk (
    .clk(CLK100MHZ),
    .rst(~CPU_RESETN),
    .rxd(UART_RXD_OUT),
    .led(LED)
);
