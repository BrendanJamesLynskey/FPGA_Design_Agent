import sys
from pathlib import Path

import pytest

DESIGN = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(DESIGN))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from flow import cocotb_run  # noqa: E402

PARAMS = {"CLKS_PER_BIT": 8, "TIMEOUT_CYCLES": 3000}


@pytest.mark.parametrize("seed", [1, 2, 3])
def test_v2_e_cmd_exec_rtl(seed):
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN / "rtl").glob("*.sv"))
    cocotb_run.run(
        "v2_e_cmd_exec",
        "v2_e_cmd_exec_top",
        sources,
        "cmd_exec_bench",
        DESIGN / "tests",
        parameters=PARAMS,
        seed=seed,
    )
