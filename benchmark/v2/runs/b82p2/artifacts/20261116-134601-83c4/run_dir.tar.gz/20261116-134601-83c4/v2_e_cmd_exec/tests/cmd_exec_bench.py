"""cocotb bench for v2_e_cmd_exec: every access goes through the test shell UART (PROTOCOL.md 1.1).

Register offset o of the design is shell address 0x80 + o. Every value read is compared with model.py.
"""
import random
import sys
from pathlib import Path

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402

CPB = 8
TIMEOUT = 3000
PARAMS = {"CLKS_PER_BIT": CPB, "TIMEOUT_CYCLES": TIMEOUT}

M32 = 0xFFFFFFFF
ID = 0x55445031

# register offsets
TYP, P0, P1, GO, CODE, RDATA, TICK, REFUSED, TLM, BANK = 0, 1, 2, 3, 4, 5, 6, 7, 8, 16


def _seed():
    s = getattr(cocotb, "RANDOM_SEED", None)
    return 1 if s is None else int(s)


def _clock(dut):
    try:
        clk = Clock(dut.CLK100MHZ, 10, unit="ns")
    except TypeError:
        clk = Clock(dut.CLK100MHZ, 10, units="ns")
    cocotb.start_soon(clk.start())


class Env:
    def __init__(self, dut):
        self.dut = dut
        self.m = model.Model(**PARAMS)
        self.clk = dut.CLK100MHZ
        self.first_samples = None

    async def cycles(self, n):
        await ClockCycles(self.clk, n)

    async def reset(self, hold=8):
        d = self.dut
        d.UART_TXD_IN.value = 1
        d.CPU_RESETN.value = 0
        await self.cycles(hold)
        d.CPU_RESETN.value = 1
        await self.cycles(10)
        self.m.reset()

    async def start(self):
        _clock(self.dut)
        self.dut.UART_TXD_IN.value = 1
        self.dut.CPU_RESETN.value = 0
        await self.cycles(2)
        await self.reset()

    # ---- UART -------------------------------------------------------------
    async def tx_byte(self, b):
        bits = [0] + [(b >> i) & 1 for i in range(8)] + [1]
        for v in bits:
            self.dut.UART_TXD_IN.value = v
            await self.cycles(CPB)

    async def rx_byte(self, limit=60000):
        n = 0
        while int(self.dut.UART_RXD_OUT.value) == 1:
            await RisingEdge(self.clk)
            n += 1
            assert n < limit, "no response byte from the design"
        samples = [int(self.dut.UART_RXD_OUT.value)]
        for _ in range(10 * CPB - 1):
            await RisingEdge(self.clk)
            samples.append(int(self.dut.UART_RXD_OUT.value))
        bits = [samples[k * CPB + CPB // 2] for k in range(10)]
        assert bits[0] == 0, "start bit"
        assert bits[9] == 1, "stop bit"
        val = sum(bits[1 + i] << i for i in range(8))
        return val, samples

    async def xfer(self, cmd, addr, data=0):
        body = bytes([cmd, addr]) + (data & M32).to_bytes(4, "little")
        chk = 0
        for x in body:
            chk ^= x
        for b in bytes([0xA5]) + body + bytes([chk]):
            await self.tx_byte(b)
        self.dut.UART_TXD_IN.value = 1
        got = []
        for i in range(7):
            v, s = await self.rx_byte()
            if i == 0:
                self.first_samples = s
            got.append(v)
        assert got[0] == 0x5A, f"response sync {got[0]:#x}"
        c = 0
        for x in got[1:6]:
            c ^= x
        assert c == got[6], "response checksum"
        await self.cycles(20)
        return got[1], int.from_bytes(bytes(got[2:6]), "little")

    # ---- register window --------------------------------------------------
    async def wr(self, off, v):
        st, d = await self.xfer(2, 0x80 + off, v)
        assert st == 0, f"window write status {st}"
        assert d == (v & M32), f"write echo {d:#x} != {v:#x}"
        self.m.write_reg(off, v)

    async def rd(self, off, expect=None):
        st, d = await self.xfer(1, 0x80 + off, 0)
        assert st == 0, f"window read status {st}"
        exp = self.m.read_reg(off) if expect is None else expect
        assert d == exp, f"read off {off}: got {d:#x} expected {exp:#x}"
        return d

    async def check_led(self):
        exp = self.m.step({"CPU_RESETN": 1})["LED"]
        got = int(self.dut.LED.value)
        assert got == exp, f"LED {got:#06x} expected {exp:#06x}"

    async def cmd(self, t, r=0, v=0, code=None, rdata=None, quick=False):
        m = self.m
        if m.typ != t:
            await self.wr(TYP, t)
        if m.p0 != r:
            await self.wr(P0, r)
        if m.p1 != v:
            await self.wr(P1, v)
        await self.wr(GO, 0)
        await self.cycles(4)
        await self.check_led()
        if quick:
            return None, None
        c = await self.rd(CODE)
        d = await self.rd(RDATA)
        if code is not None:
            assert c == code, f"result code {c} expected {code}"
        if rdata is not None:
            assert d == rdata, f"read data {d:#x} expected {rdata:#x}"
        return c, d

    async def bank(self, which=range(8)):
        out = []
        for i in which:
            out.append(await self.rd(BANK + i))
        return out


async def setup(dut):
    e = Env(dut)
    await e.start()
    return e


# req: REQ-01, REQ-03, REQ-04, REQ-05, REQ-29, REQ-31, REQ-32
@cocotb.test()
async def test_reset_values(dut):
    e = await setup(dut)
    b = await e.bank()
    assert b[0] == ID
    assert b[1:4] == [0, 0, 0]
    assert b[4] == 0 and b[5] == 0 and b[7] == 0
    assert b[6] == 100
    for o in (TYP, P0, P1, CODE, RDATA, TLM, GO, TICK, REFUSED):
        await e.rd(o, expect=0)
    for o in (9, 12, 15, 24, 0x7F):  # unmapped offsets read zero
        await e.rd(o, expect=0)
    await e.wr(9, 0x1234)  # write to an unmapped offset has no effect
    await e.rd(9, expect=0)
    await e.wr(BANK + 1, 0x55)  # write to a read-only window register has no effect
    await e.rd(BANK + 1, expect=0)
    await e.wr(CODE, 7)
    await e.rd(CODE, expect=0)
    assert int(dut.LED.value) == 0


# req: REQ-06, REQ-07, REQ-16
@cocotb.test()
async def test_scratch_write_read(dut):
    e = await setup(dut)
    for vals in ([0xDEADBEEF, 0x12345678, 0xA5A5A5A5], [M32, 0, 0x80000001]):
        for r, v in zip((1, 2, 3), vals):
            await e.cmd(2, r, v, code=0, rdata=0)
            assert (await e.rd(BANK + r)) == v
        for r, v in zip((1, 2, 3), vals):
            await e.cmd(1, r, 0, code=0, rdata=v)
    await e.rd(TYP)
    await e.rd(P0)
    await e.rd(P1)


# req: REQ-02, REQ-08, REQ-09, REQ-13, REQ-14, REQ-16
@cocotb.test()
async def test_write_readonly(dut):
    e = await setup(dut)
    for r, v in ((1, 0x11111111), (2, 0x22222222), (3, 0x33333333)):
        await e.cmd(2, r, v, quick=True)
    await e.cmd(4, 77, quick=True)
    before = await e.bank()
    assert before[1:4] == [0x11111111, 0x22222222, 0x33333333]
    assert before[4] == 4 and before[5] == 0 and before[6] == 77
    for n, r in enumerate((0, 4, 5, 6, 7), start=1):
        await e.cmd(2, r, 0xCAFEF00D, code=5, rdata=0)
        assert (await e.rd(BANK + 5)) == n
    after = await e.bank()
    assert after[0] == ID and after[1:4] == before[1:4] and after[6] == 77
    assert after[4] == 4 and after[5] == 5 and after[7] == 0
    await e.rd(TLM, expect=1)


# req: REQ-10, REQ-13, REQ-14, REQ-16
@cocotb.test()
async def test_unknown_register(dut):
    e = await setup(dut)
    await e.cmd(2, 1, 0xABCD1234, quick=True)
    await e.cmd(4, 9, quick=True)
    n = 0
    for t in (1, 2):
        for r in (8, 9, 0xFFFF):
            await e.cmd(t, r, 0x55AA55AA, code=3, rdata=0)
            n += 1
    await e.cmd(2, 0x8000, 7, code=3, rdata=0)
    n += 1
    b = await e.bank()
    assert b[5] == n and b[4] == 2
    assert b[1] == 0xABCD1234 and b[2] == 0 and b[3] == 0 and b[6] == 9
    await e.rd(TLM, expect=1)


# req: REQ-11, REQ-13, REQ-14, REQ-16
@cocotb.test()
async def test_unknown_type(dut):
    e = await setup(dut)
    await e.cmd(2, 2, 0x600D, quick=True)
    await e.cmd(1, 2, code=0, rdata=0x600D)  # RDATA nonzero before the failures
    n = 0
    for t in (0, 6, 7, 0x80, 0xFF):
        await e.cmd(t, 2, 5, code=1, rdata=0)
        n += 1
    b = await e.bank()
    assert b[5] == n and b[4] == 2 and b[2] == 0x600D and b[6] == 100
    await e.rd(TLM, expect=0)


# req: REQ-12, REQ-17, REQ-18, REQ-19, REQ-16
@cocotb.test()
async def test_status_command(dut):
    e = await setup(dut)
    await e.cmd(2, 3, 0x0BADCAFE, quick=True)
    await e.cmd(4, 12, quick=True)
    await e.cmd(1, 0, code=0, rdata=ID)  # RDATA = ID now
    b0 = await e.bank()
    await e.cmd(3, 0, 0, code=0, rdata=0)
    b1 = await e.bank()
    assert b1[4] == b0[4] + 1
    assert b1[5] == b0[5] == 0
    assert b1[1:4] == b0[1:4] and b1[6] == 12
    await e.rd(TLM, expect=1)


# req: REQ-12, REQ-15, REQ-16, REQ-13
@cocotb.test()
async def test_read_counts(dut):
    e = await setup(dut)
    await e.cmd(3, quick=True)
    await e.cmd(3, quick=True)
    await e.cmd(1, 9, quick=True)  # fails: ERRS = 1
    await e.cmd(1, 0xF0, quick=True)  # fails: ERRS = 2
    assert (await e.rd(BANK + 4)) == 2
    await e.cmd(1, 4, code=0, rdata=2)  # read CMDS returns the count before counting
    assert (await e.rd(BANK + 4)) == 3
    assert (await e.rd(BANK + 5)) == 2
    await e.cmd(1, 5, code=0, rdata=2)  # read ERRS returns the count before this command
    assert (await e.rd(BANK + 5)) == 2
    assert (await e.rd(BANK + 4)) == 4
    await e.cmd(1, 7, code=0, rdata=0)
    await e.cmd(1, 6, code=0, rdata=100)
    await e.cmd(1, 1, code=0, rdata=0)


# req: REQ-20, REQ-21, REQ-22, REQ-23, REQ-24, REQ-16, REQ-12
@cocotb.test()
async def test_telemetry(dut):
    e = await setup(dut)
    await e.cmd(4, 0, code=0, rdata=0)
    await e.rd(TLM, expect=1)
    await e.rd(BANK + 6, expect=100)  # zero keeps PERIOD
    await e.cmd(5, 0, code=0, rdata=0)
    await e.rd(TLM, expect=0)
    await e.cmd(5, 0, quick=True)
    await e.rd(TLM, expect=0)
    for p, exp in ((1, 4), (2, 4), (3, 4), (4, 4), (5, 5), (200, 200), (0xFFFF, 0xFFFF), (0, 0xFFFF)):
        await e.cmd(4, p, quick=True)
        await e.rd(TLM, expect=1)
        await e.rd(BANK + 6, expect=exp)
        await e.cmd(5, 0, quick=True)
        await e.rd(TLM, expect=0)
        await e.rd(BANK + 6, expect=exp)
    b = await e.bank([4, 5])
    assert b[1] == 0


# req: REQ-25, REQ-26, REQ-13
@cocotb.test()
async def test_tick_refused(dut):
    e = await setup(dut)
    total = 0
    for n in (0, 1, 255, 100, 7):
        await e.wr(TICK, n)
        total += n
        await e.rd(BANK + 7, expect=total)
    for v in (0, M32, 5):
        await e.wr(REFUSED, v)
    await e.rd(BANK + 5, expect=3)
    await e.rd(BANK + 4, expect=0)
    await e.check_led()
    assert int(dut.LED.value) == 3
    await e.rd(BANK + 7, expect=total)


# req: REQ-27, REQ-28
@cocotb.test()
async def test_led(dut):
    e = await setup(dut)
    await e.wr(TYP, 3)
    for i in range(1, 21):
        await e.wr(GO, 0)
        await e.cycles(4)
        led = int(dut.LED.value)
        assert (led >> 8) == i and (led & 0xFF) == 0, f"LED {led:#x} after {i} status commands"
        await e.check_led()
    for i in range(1, 6):
        await e.wr(REFUSED, 1)
        await e.cycles(4)
        led = int(dut.LED.value)
        assert (led & 0xFF) == i and (led >> 8) == 20
    await e.wr(TYP, 9)  # unknown type: error
    await e.wr(GO, 0)
    await e.cycles(4)
    assert int(dut.LED.value) == (20 << 8) | 6
    await e.rd(BANK + 4, expect=20)
    await e.rd(BANK + 5, expect=6)


# req: REQ-29, REQ-03, REQ-04, REQ-05, REQ-01
@cocotb.test()
async def test_reset_midrun(dut):
    e = await setup(dut)
    await e.cmd(2, 1, 0x1111, quick=True)
    await e.cmd(2, 3, 0x3333, quick=True)
    await e.cmd(4, 33, quick=True)
    await e.cmd(1, 1, code=0, rdata=0x1111)
    await e.wr(TICK, 200)
    await e.wr(REFUSED, 0)
    await e.cmd(9, quick=True)
    await e.rd(TLM, expect=1)
    assert int(dut.LED.value) != 0
    dut.CPU_RESETN.value = 0
    await e.cycles(5)
    dut.CPU_RESETN.value = 1
    await e.cycles(10)
    e.m.reset()
    await e.check_led()
    assert int(dut.LED.value) == 0
    b = await e.bank()
    assert b == [ID, 0, 0, 0, 0, 0, 100, 0]
    for o in (TYP, P0, P1, CODE, RDATA, TLM):
        await e.rd(o, expect=0)
    await e.cmd(3, code=0, rdata=0)
    await e.rd(BANK + 4, expect=1)


# req: REQ-30
@cocotb.test()
async def test_uart_baud(dut):
    e = await setup(dut)
    await e.rd(BANK + 0, expect=ID)
    s = e.first_samples  # response sync byte 0x5A: start + bit0 are both low = 2 bit times
    low = 0
    while low < len(s) and s[low] == 0:
        low += 1
    assert abs(low - 2 * CPB) <= 1, f"low time {low} cycles, expected {2 * CPB}"
    bits = [s[k * CPB + CPB // 2] for k in range(10)]
    assert bits == [0, 0, 1, 0, 1, 1, 0, 1, 0, 1]  # 0x5A, LSB first
    await e.rd(BANK + 6, expect=100)


# req: REQ-01, REQ-02, REQ-06, REQ-08, REQ-10, REQ-11, REQ-12, REQ-13, REQ-14, REQ-15, REQ-16, REQ-20, REQ-21, REQ-22, REQ-23, REQ-24, REQ-25, REQ-26, REQ-27, REQ-28
@cocotb.test()
async def test_random_commands(dut):
    e = await setup(dut)
    rng = random.Random(_seed())
    types = [1, 1, 2, 2, 2, 3, 4, 4, 5, 0, 6, 0xFF, 0x42]
    regs = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0xFFFF, rng.randrange(10, 0xFFFF)]
    vals = [0, 1, M32, 0x80000000, rng.getrandbits(32), rng.getrandbits(32)]
    ps = [0, 1, 2, 3, 4, 5, 100, 0xFFFF, rng.randrange(6, 0xFFFF)]
    for _ in range(14):
        t = rng.choice(types)
        r = rng.choice(ps) if t == 4 else rng.choice(regs)
        v = rng.choice(vals)
        if rng.random() < 0.12:
            await e.wr(TICK, rng.randrange(256))
        if rng.random() < 0.12:
            await e.wr(REFUSED, rng.choice(vals))
        await e.cmd(t, r, v)
        if rng.random() < 0.4:
            await e.rd(BANK + rng.randrange(8))
        if rng.random() < 0.3:
            await e.rd(TLM)
    await e.bank()
    await e.rd(TLM)
