"""Pytest entry: builds the RTL with the test shell and runs the cocotb bench (tests/udp_bench.py)
against model.py, once per seed."""
import sys
from pathlib import Path

import pytest

DESIGN_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(DESIGN_DIR))
for _p in DESIGN_DIR.parents:
    if (_p / "flow").is_dir():
        sys.path.insert(0, str(_p))
        break

from flow import cocotb_run  # noqa: E402

PARAMETERS = {"CLKS_PER_BIT": 8}


@pytest.mark.parametrize("seed", [1, 2, 3])
def test_v2_e_udp_endpoint_rtl(seed):
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN_DIR / "rtl").glob("*.sv"))
    cocotb_run.run(
        "v2_e_udp_endpoint",
        "v2_e_udp_endpoint_top",
        sources,
        "udp_bench",
        DESIGN_DIR / "tests",
        parameters=PARAMETERS,
        seed=seed,
    )
