
## models by role (profile single)

clarify: claude_code claude-sonnet-5-5 (medium); model: claude_code claude-sonnet-5-5 (medium); tests: claude_code claude-sonnet-5-5 (medium); rtl: claude_code claude-sonnet-5-5 (medium). Interview oracle: openai/gpt-6-luna (fixed). The stage machine is plain code.

<!-- who-did-what:start -->
## Who did what

| # | who | stage | what | detail |
|---|---|---|---|---|
| 1 | agent | clarify | stage 0 work, visit 1 | 5 files in the design |
| 2 | agent | clarify | stage 0 work, visit 2 | 5 files in the design |
| 3 | auto | clarify | interview | answered: What is the shell register map (offset, width, reset value and access of every register)? -> IN: offset 0x00, WO, reset 0: [7:0] packet byte, [8] end flag STAT: offset 0x09, |
| 4 | auto | clarify | interview | defaulted: Which counter takes a packet refused with status 4, equal to the last accepted number versus older? -> Equal goes to repeated number, older (1..32767 behind) goes to out-of-order. |
| 5 | auto | clarify | interview | defaulted: What happens when TICK is written while ticks are still pending? -> The new count is added to the pending count, saturating at 65535. |
| 6 | auto | clarify | interview | answered: Does a command with a wrong length for its type, such as read with length 0, use up its sequence number? -> No. A command with a wrong length for its type is refused at the length check, w |
| 7 | auto | clarify | interview | defaulted: Do statuses 1, 2, 3 and 5 all increment the type/length/register/access counter? -> Yes, all four increment that one counter. |
| 8 | auto | clarify | interview | defaulted: Does a write to a read-only register count as a command carried out? -> No, it is refused with status 5 and counted as an error. |
| 9 | auto | clarify | interview | defaulted: How is the busy bit defined? -> Busy is 1 from the end-flag byte until the reply is built, and while pending tic |
| 10 | auto | clarify | approved (review off) |  |
| 11 | agent | board-and-device-planning | stage 1 work, visit 1 | 7 files in the design |
| 12 | agent | board-and-device-planning | stage 1 work, visit 2 | 8 files in the design |
| 13 | auto | board-and-device-planning | approved (review off) |  |
| 14 | auto | board-and-device-planning | architecture approved | source: agent |
| 15 | agent | rtl-design-creation | stage 2 work, visit 1 | 18 files in the design |
| 16 | agent | rtl-design-creation | stage 2 work, visit 2 | 18 files in the design |
| 17 | agent | rtl-design-creation | stage 2 work, visit 3 | 18 files in the design |
| 18 | agent | rtl-design-creation | stage 2 work, visit 4 | 18 files in the design |
| 19 | agent | rtl-design-creation | stage 2 work, visit 5 | 18 files in the design |
| 20 | agent | rtl-design-creation | stage 2 work, visit 6 | 18 files in the design |

owner: 0, agent: 10, auto: 10
<!-- who-did-what:end -->

## review 00 clarify

approve by auto (gates fail)

## review 00 clarify

approve by auto (gates pass)

## review 01 board-and-device-planning

approve by auto (gates fail)

## review 01 board-and-device-planning

approve by auto (gates pass)

## architecture approval

approved (auto); written by the agent; sha256 05d07451b6b4

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)

## review 02 rtl-design-creation

approve by auto (gates fail)
