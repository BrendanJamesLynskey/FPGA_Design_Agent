"""cocotb bench for v2_e_udp_endpoint: every window access goes through the board UART shell
(PROTOCOL.md 1.1), every value is compared with model.Model."""
import random
import sys
import zlib
from pathlib import Path

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, FallingEdge, RisingEdge

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402,F401
from model import Model  # noqa: E402

CLKS = 8
PARAMS = {"CLKS_PER_BIT": CLKS}
ID_WORD = 0x55445031

OFF_IN, OFF_TICK, OFF_RLEN, OFF_RIDX, OFF_RWORD = 0, 1, 2, 3, 4
OFF_TLEN, OFF_TIDX, OFF_TWORD, OFF_TAKE, OFF_STAT = 5, 6, 7, 8, 9


def xor8(b):
    r = 0
    for x in b:
        r ^= x
    return r


def pkt(typ, seq, payload=b"", ln=None, crc=None):
    payload = bytes(payload)
    ln = len(payload) if ln is None else ln
    body = bytes([typ & 0xFF, ln & 0xFF, (seq >> 8) & 0xFF, seq & 0xFF]) + payload
    c = (zlib.crc32(body) & 0xFFFFFFFF) if crc is None else (crc & 0xFFFFFFFF)
    return body + c.to_bytes(4, "little")


def rd_pkt(r, seq):
    # read carries 2 payload bytes (announced size 2); the model takes the register from byte 0
    return pkt(1, seq, bytes([r, 0]))


def wr_pkt(r, v, seq):
    # write carries 6 payload bytes: register byte, 32-bit value high first, one pad byte
    return pkt(2, seq, bytes([r]) + (v & 0xFFFFFFFF).to_bytes(4, "big") + b"\x00")


def st_pkt(seq):
    return pkt(3, seq)


def start_pkt(p, seq):
    return pkt(4, seq, (p & 0xFFFF).to_bytes(2, "big"))


def stop_pkt(seq):
    return pkt(5, seq)


def check_rep(res, typ, status, seq, payload=None):
    rlen, data = res
    assert rlen >= 9, f"reply length {rlen}"
    assert data[0] == ((typ | 0x80) & 0xFF), f"reply type {data[0]:02x}"
    assert data[1] == status, f"reply status {data[1]} expected {status}"
    assert ((data[2] << 8) | data[3]) == seq, "reply sequence"
    if len(data) >= rlen:
        assert data[4] == rlen - 9, "reply length byte"
        crc = zlib.crc32(bytes(data[:rlen - 4])) & 0xFFFFFFFF
        assert int.from_bytes(bytes(data[rlen - 4:rlen]), "little") == crc, "reply CRC-32"
        if payload is not None:
            assert bytes(data[5:rlen - 4]) == bytes(payload), f"payload {bytes(data[5:rlen-4]).hex()}"
    return data


def parse_status(data):
    p = bytes(data[5:22])
    assert len(p) == 17
    vals = [int.from_bytes(p[2 * i:2 * i + 2], "big") for i in range(8)]
    return vals, p[16]


def check_frame(fr, seq, uptime, cmds, refused):
    assert len(fr) == 17, f"frame length {len(fr)}"
    assert fr[0] == 0xC0 and fr[1] == 0 and fr[4] == 8
    assert ((fr[2] << 8) | fr[3]) == seq, f"frame seq {(fr[2] << 8) | fr[3]} expected {seq}"
    assert int.from_bytes(fr[5:9], "big") == uptime, f"frame uptime {int.from_bytes(fr[5:9], 'big')} exp {uptime}"
    assert int.from_bytes(fr[9:11], "big") == cmds & 0xFFFF
    assert int.from_bytes(fr[11:13], "big") == refused & 0xFFFF
    assert int.from_bytes(fr[13:17], "little") == (zlib.crc32(bytes(fr[:13])) & 0xFFFFFFFF)


class Bench:
    def __init__(self, dut):
        self.dut = dut
        self.m = Model(**PARAMS)
        self.rxq = []
        self.lows = []
        self.seq = 0x0100
        self.clk = dut.CLK100MHZ

    def ns(self, delta=1):
        self.seq = (self.seq + delta) & 0xFFFF
        return self.seq

    # ---- bring-up
    async def start(self):
        d = self.dut
        d.UART_TXD_IN.value = 1
        d.CPU_RESETN.value = 0
        try:
            ck = Clock(d.CLK100MHZ, 10, unit="ns")
        except TypeError:
            ck = Clock(d.CLK100MHZ, 10, units="ns")
        cocotb.start_soon(ck.start())
        await ClockCycles(self.clk, 10)
        d.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 10)
        self.m.reset()
        cocotb.start_soon(self.rx_mon())
        cocotb.start_soon(self.edge_mon())
        await ClockCycles(self.clk, 4)

    async def do_reset(self):
        self.dut.CPU_RESETN.value = 0
        await ClockCycles(self.clk, 6)
        self.dut.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 6)
        self.m.reset()
        self.rxq.clear()

    # ---- UART
    async def rx_mon(self):
        d = self.dut
        while True:
            await FallingEdge(d.UART_RXD_OUT)
            await ClockCycles(self.clk, CLKS // 2)
            if int(d.UART_RXD_OUT.value) != 0:
                continue
            b = 0
            for i in range(8):
                await ClockCycles(self.clk, CLKS)
                b |= int(d.UART_RXD_OUT.value) << i
            await ClockCycles(self.clk, CLKS)
            self.rxq.append((b, int(d.UART_RXD_OUT.value)))

    async def edge_mon(self):
        run = 0
        while True:
            await RisingEdge(self.clk)
            try:
                v = int(self.dut.UART_RXD_OUT.value)
            except ValueError:
                continue
            if v == 0:
                run += 1
            elif run:
                self.lows.append(run)
                run = 0

    async def tx_byte(self, b):
        bits = [0] + [(b >> i) & 1 for i in range(8)] + [1]
        for bit in bits:
            self.dut.UART_TXD_IN.value = bit
            await ClockCycles(self.clk, CLKS)

    async def transact(self, cmd, addr, data=0):
        body = bytes([cmd, addr]) + (data & 0xFFFFFFFF).to_bytes(4, "little")
        frame = bytes([0xA5]) + body + bytes([xor8(body)])
        self.rxq.clear()
        for x in frame:
            await self.tx_byte(x)
        n = 0
        while len(self.rxq) < 7:
            await ClockCycles(self.clk, CLKS)
            n += 1
            assert n < 300, "no response from the shell"
        await ClockCycles(self.clk, CLKS)
        rsp = [x for x, _ in self.rxq[:7]]
        assert all(s == 1 for _, s in self.rxq[:7]), "stop bit low"
        assert rsp[0] == 0x5A, f"response sync {rsp[0]:02x}"
        assert xor8(rsp[1:6]) == rsp[6], "response checksum"
        return rsp[1], int.from_bytes(bytes(rsp[2:6]), "little")

    async def win_write(self, off, val):
        st, _ = await self.transact(2, 0x80 + off, val)
        assert st == 0, f"window write status {st}"

    async def win_read(self, off):
        st, v = await self.transact(1, 0x80 + off)
        assert st == 0, f"window read status {st}"
        return v

    async def rd_cmp(self, off):
        got = await self.win_read(off)
        exp = self.m.read_reg(off)
        assert got == exp, f"window reg {off}: rtl {got:#x} model {exp:#x}"
        return got

    async def check_led(self):
        exp = self.m.step()["LED"]
        got = int(self.dut.LED.value)
        assert got == exp, f"LED rtl {got} model {exp}"

    # ---- packets and ticks
    async def send_bytes(self, pk):
        pk = bytes(pk)
        for i, x in enumerate(pk):
            v = x | (0x100 if i == len(pk) - 1 else 0)
            await self.win_write(OFF_IN, v)
            self.m.write_reg(OFF_IN, v)

    async def reply(self, extra=0, light=False):
        rlen = await self.rd_cmp(OFF_RLEN)
        n = (rlen + 3) // 4
        if light:
            n = min(n, 1)
        n += extra
        raw = b""
        for i in range(n):
            await self.win_write(OFF_RIDX, i)
            self.m.write_reg(OFF_RIDX, i)
            w = await self.rd_cmp(OFF_RWORD)
            raw += w.to_bytes(4, "big")
        if not light:
            assert all(x == 0 for x in raw[rlen:]), "bytes past the reply end are not 0"
        await self.check_led()
        return rlen, raw[:rlen]

    async def send(self, pk, mode="full", extra=0):
        await self.send_bytes(pk)
        if mode == "none":
            return None
        if mode == "len":
            rlen = await self.rd_cmp(OFF_RLEN)
            await self.check_led()
            return rlen, b""
        return await self.reply(extra=extra, light=(mode == "light"))

    async def read_r(self, r, seq=None, extra=0):
        seq = self.ns() if seq is None else seq
        res = await self.send(rd_pkt(r, seq), "full", extra)
        data = check_rep(res, 1, 0, seq)
        assert res[0] == 13
        return int.from_bytes(bytes(data[5:9]), "big")

    async def tick(self, n):
        await self.win_write(OFF_TICK, n)
        self.m.write_reg(OFF_TICK, n)
        for _ in range(n):
            self.m.step()

    async def take(self):
        await self.win_write(OFF_TAKE, 0)
        self.m.write_reg(OFF_TAKE, 0)

    async def tel_frame(self, extra=1):
        tlen = await self.rd_cmp(OFF_TLEN)
        n = (tlen + 3) // 4 + extra
        raw = b""
        for i in range(n):
            await self.win_write(OFF_TIDX, i)
            self.m.write_reg(OFF_TIDX, i)
            w = await self.rd_cmp(OFF_TWORD)
            raw += w.to_bytes(4, "big")
        assert all(x == 0 for x in raw[tlen:]), "bytes past the frame end are not 0"
        return raw[:tlen]


# req: REQ-02, REQ-04, REQ-07, REQ-08, REQ-40, REQ-41, REQ-42, REQ-43, REQ-44, REQ-45, REQ-46
@cocotb.test()
async def test_reset_values_and_identification(dut):
    b = Bench(dut)
    await b.start()
    for off in (OFF_RLEN, OFF_RIDX, OFF_RWORD, OFF_TLEN, OFF_TIDX, OFF_TWORD, OFF_STAT):
        assert await b.rd_cmp(off) == 0, f"reset value of window reg {off}"
    assert int(dut.LED.value) == 0
    assert await b.read_r(0, extra=1) == ID_WORD
    assert await b.read_r(1) == 0
    assert await b.read_r(2) == 0
    assert await b.read_r(3) == 0
    assert await b.read_r(4) == 4        # four commands carried out before this read
    assert await b.read_r(5) == 0
    assert await b.read_r(6) == 100
    assert await b.read_r(7) == 0
    assert int(dut.LED.value) == 8
    assert await b.rd_cmp(OFF_RLEN) == 13
    await b.win_write(OFF_RIDX, 5)
    assert await b.win_read(OFF_RIDX) == 5
    b.m.write_reg(OFF_RIDX, 5)
    await b.win_write(OFF_RIDX, 0x1FF)
    assert await b.win_read(OFF_RIDX) == 0x7F
    await b.win_write(OFF_RIDX, 0)
    b.m.write_reg(OFF_RIDX, 0x1FF)
    b.m.write_reg(OFF_RIDX, 0)
    assert await b.rd_cmp(OFF_STAT) == 0


# req: REQ-04, REQ-05, REQ-45, REQ-50
@cocotb.test()
async def test_scratch_registers(dut):
    b = Bench(dut)
    await b.start()
    vals = {1: 0xDEADBEEF, 2: 0x00000001, 3: 0xFFFFFFFF}
    for r, v in vals.items():
        s = b.ns()
        res = await b.send(wr_pkt(r, v, s), "full")
        check_rep(res, 2, 0, s, b"")
    for r, v in vals.items():
        assert await b.read_r(r) == v
    s = b.ns()
    check_rep(await b.send(wr_pkt(2, 0x80000000, s), "full"), 2, 0, s, b"")
    assert await b.read_r(1) == 0xDEADBEEF
    assert await b.read_r(2) == 0x80000000
    assert await b.read_r(3) == 0xFFFFFFFF
    assert int(dut.LED.value) == 3 + 3 + 1 + 3


# req: REQ-03, REQ-14, REQ-15, REQ-20, REQ-21, REQ-22, REQ-19, REQ-18, REQ-06, REQ-04
@cocotb.test()
async def test_register_errors(dut):
    b = Bench(dut)
    await b.start()
    cases = [(2, 0, 5), (2, 4, 5), (2, 5, 5), (2, 6, 5), (2, 7, 5), (1, 8, 3),
             (2, 8, 3), (1, 255, 3), (2, 9, 3), (1, 0x80, 3)]
    s = None
    for typ, reg, st in cases:
        s = b.ns()
        p = rd_pkt(reg, s) if typ == 1 else wr_pkt(reg, 7, s)
        check_rep(await b.send(p, "light"), typ, st, s)
    # the failed packet used up its number: same number again is a repeat
    check_rep(await b.send(rd_pkt(0, s), "light"), 1, 4, s)
    s = b.ns()
    assert await b.read_r(0, s) == ID_WORD
    assert await b.read_r(5) == 11
    assert await b.read_r(4) == 2
    assert await b.read_r(6) == 100
    s = b.ns()
    data = check_rep(await b.send(st_pkt(s), "full"), 3, 0, s)
    vals, on = parse_status(data)
    assert vals == [4, 0, 0, 0, 1, 0, 10, 0] and on == 0, vals
    assert await b.read_r(5) == 11


# req: REQ-06, REQ-22, REQ-10
@cocotb.test()
async def test_read_counts_before_counted(dut):
    b = Bench(dut)
    await b.start()
    assert await b.read_r(4) == 0
    assert await b.read_r(4) == 1
    for p in (bytes([3]), bytes([3, 0, 0]), bytes([1, 2, 3])):
        assert (await b.send(p, "len"))[0] == 0
    assert await b.read_r(5) == 3
    assert await b.read_r(5) == 3
    s = b.ns()
    check_rep(await b.send(pkt(0x42, s), "light"), 0x42, 1, s)
    assert await b.read_r(5) == 4
    assert await b.read_r(4) == 5


# req: REQ-09, REQ-19, REQ-21, REQ-22, REQ-40
@cocotb.test()
async def test_drop_too_long(dut):
    b = Bench(dut)
    await b.start()
    s0 = b.ns()
    check_rep(await b.send(st_pkt(s0), "light"), 3, 0, s0)
    s = b.ns()
    # each packet has more bytes than announced or announces more than 8
    bad = [pkt(3, s, bytes(9)), pkt(2, s, bytes(3), ln=2), pkt(3, s, b"\x00\x00", ln=1),
           pkt(2, s, bytes(12), ln=8), pkt(3, s, bytes(11), ln=200)]
    for p in bad:
        res = await b.send(p, "len")
        assert res[0] == 0, "reply to a too-long packet"
    data = check_rep(await b.send(st_pkt(s), "full"), 3, 0, s)
    vals, _ = parse_status(data)
    assert vals == [1, 0, 0, 5, 0, 0, 0, 0], vals
    assert await b.read_r(5) == 5


# req: REQ-10, REQ-19, REQ-21, REQ-22, REQ-40
@cocotb.test()
async def test_drop_too_short(dut):
    b = Bench(dut)
    await b.start()
    s0 = b.ns()
    check_rep(await b.send(st_pkt(s0), "light"), 3, 0, s0)
    s = b.ns()
    bad = [bytes([3]), bytes([3, 0, 0]), bytes([1, 0, 0]), bytes([3, 0, 0, 0]),
           pkt(1, s, bytes([2]), ln=2), pkt(3, s)[:-1], pkt(2, s, bytes(6))[:-3],
           pkt(3, s, b"", ln=8)]
    for p in bad:
        res = await b.send(p, "len")
        assert res[0] == 0, "reply to a too-short packet"
    data = check_rep(await b.send(st_pkt(s), "full"), 3, 0, s)
    vals, _ = parse_status(data)
    assert vals == [1, 0, 8, 0, 0, 0, 0, 0], vals


# req: REQ-11, REQ-19, REQ-21, REQ-22, REQ-40
@cocotb.test()
async def test_drop_bad_crc(dut):
    b = Bench(dut)
    await b.start()
    s0 = b.ns()
    check_rep(await b.send(st_pkt(s0), "light"), 3, 0, s0)
    s = b.ns()
    good = zlib.crc32(bytes([3, 0, s >> 8, s & 0xFF])) & 0xFFFFFFFF
    tam = bytearray(rd_pkt(0, s))
    tam[4] ^= 1
    bad = [pkt(3, s, crc=good ^ 1), pkt(3, s, crc=good ^ 0x80000000), pkt(3, s, crc=good ^ 0xFFFFFFFF),
           bytes(tam), pkt(9, s, crc=0x12345678), pkt(1, s, crc=0xDEADBEEF)]
    for p in bad:
        res = await b.send(p, "len")
        assert res[0] == 0, "reply to a bad-check packet"
    data = check_rep(await b.send(st_pkt(s), "full"), 3, 0, s)
    vals, _ = parse_status(data)
    assert vals == [1, 6, 0, 0, 0, 0, 0, 0], vals


# req: REQ-12, REQ-13, REQ-19, REQ-21, REQ-22, REQ-23
@cocotb.test()
async def test_type_and_length_errors(dut):
    b = Bench(dut)
    await b.start()
    s0 = b.ns()
    check_rep(await b.send(st_pkt(s0), "light"), 3, 0, s0)
    s = b.ns()
    for t, ln in ((0, 0), (6, 0), (0x81, 0), (0xC0, 2)):
        p = pkt(t, s, bytes(ln))
        check_rep(await b.send(p, "light"), t, 1, s)
    for t, ln in ((1, 0), (1, 3), (2, 2), (2, 8), (3, 1), (4, 0), (4, 3), (5, 2)):
        p = pkt(t, s, bytes(ln))
        check_rep(await b.send(p, "light"), t, 2, s)
    # none of them used up the number
    assert await b.read_r(0, s) == ID_WORD
    s = b.ns()
    data = check_rep(await b.send(st_pkt(s), "full"), 3, 0, s)
    vals, _ = parse_status(data)
    assert vals == [2, 0, 0, 0, 0, 0, 12, 0], vals


# req: REQ-16, REQ-17, REQ-18, REQ-20, REQ-21
@cocotb.test()
async def test_sequence_rules(dut):
    b = Bench(dut)
    await b.start()
    seqs = [0xFFFE, 0xFFFF, 0x0000, 0x0000, 0xFFFF, 0x0001, 0x8000, 0x0000, 0x8000, 0x0001,
            0x8001, 0x0000, 0x7FFF, 0xFFFF, 0x7FFF, 0x7FFE, 0x8000]
    last = None
    rep = ooo = ok_n = 0
    for s in seqs:
        d = None
        if last is None:
            ok = True
        else:
            d = (s - last) & 0xFFFF
            ok = 1 <= d <= 32767
        check_rep(await b.send(st_pkt(s), "light"), 3, 0 if ok else 4, s)
        if ok:
            last = s
            ok_n += 1
        elif d == 0:
            rep += 1
        else:
            ooo += 1
    s = (last + 5) & 0xFFFF
    data = check_rep(await b.send(st_pkt(s), "full"), 3, 0, s)
    vals, _ = parse_status(data)
    assert vals == [ok_n, 0, 0, 0, rep, ooo, 0, 0], vals


# req: REQ-01, REQ-21, REQ-25, REQ-26, REQ-27, REQ-41, REQ-23
@cocotb.test()
async def test_status_reply(dut):
    b = Bench(dut)
    await b.start()
    s = b.ns()
    data = check_rep(await b.send(st_pkt(s), "full", extra=1), 3, 0, s)
    assert parse_status(data) == ([0] * 8, 0)
    check_rep(await b.send(rd_pkt(0, s), "light"), 1, 4, s)          # repeat
    s_old = b.ns(-1)
    check_rep(await b.send(rd_pkt(0, s_old), "light"), 1, 4, s_old)  # older
    s = b.ns(2)
    check_rep(await b.send(pkt(0x33, s), "light"), 0x33, 1, s)        # type error
    assert (await b.send(bytes([1, 2]), "len"))[0] == 0               # short
    assert (await b.send(pkt(3, s, bytes(9)), "len"))[0] == 0         # long
    assert (await b.send(pkt(3, s, crc=5), "len"))[0] == 0            # bad check
    s = b.ns()
    data = check_rep(await b.send(st_pkt(s), "full"), 3, 0, s)
    assert len(data) == 26
    vals, on = parse_status(data)
    assert vals == [1, 1, 1, 1, 1, 1, 1, 0] and on == 0, vals
    s = b.ns()
    await b.send(start_pkt(4, s), "light")
    await b.tick(4)
    s = b.ns()
    data = check_rep(await b.send(st_pkt(s), "full"), 3, 0, s)
    vals, on = parse_status(data)
    assert vals[0] == 3 and vals[7] == 1 and on == 1, vals


# req: REQ-01, REQ-23, REQ-24, REQ-28, REQ-41
@cocotb.test()
async def test_reply_format(dut):
    b = Bench(dut)
    await b.start()
    s = b.ns()
    check_rep(await b.send(rd_pkt(0, s), "full", extra=1), 1, 0, s, ID_WORD.to_bytes(4, "big"))
    s = b.ns()
    check_rep(await b.send(wr_pkt(2, 0x01020304, s), "full"), 2, 0, s, b"")
    s = b.ns()
    res = await b.send(st_pkt(s), "full")
    check_rep(res, 3, 0, s)
    assert res[0] == 26
    s = b.ns()
    check_rep(await b.send(start_pkt(10, s), "full"), 4, 0, s, b"")
    s = b.ns()
    check_rep(await b.send(stop_pkt(s), "full"), 5, 0, s, b"")
    s = b.ns()
    check_rep(await b.send(pkt(7, s, b"\x01"), "full"), 7, 1, s, b"")
    s = b.ns()
    check_rep(await b.send(rd_pkt(9, s), "full"), 1, 3, s, b"")
    s = b.ns(30000)
    check_rep(await b.send(wr_pkt(1, 5, s), "full"), 2, 0, s, b"")
    assert await b.read_r(1) == 5


# req: REQ-29, REQ-30, REQ-31, REQ-43, REQ-07
@cocotb.test()
async def test_telemetry_period(dut):
    b = Bench(dut)
    await b.start()
    for p, exp in ((0, 100), (1, 4), (3, 4), (0, 4), (5, 5), (0, 5), (4, 4), (300, 300)):
        s = b.ns()
        check_rep(await b.send(start_pkt(p, s), "light"), 4, 0, s)
        assert await b.rd_cmp(OFF_STAT) == 1
        assert await b.read_r(6) == exp, f"period after start {p}"


# req: REQ-31, REQ-32, REQ-33, REQ-34, REQ-35, REQ-38, REQ-42, REQ-43, REQ-51, REQ-52, REQ-53
@cocotb.test()
async def test_telemetry_frames(dut):
    b = Bench(dut)
    await b.start()
    assert await b.tel_frame() == b""
    s = b.ns()
    check_rep(await b.send(start_pkt(4, s), "light"), 4, 0, s)
    assert await b.rd_cmp(OFF_STAT) == 1
    await b.tick(3)
    assert await b.rd_cmp(OFF_TLEN) == 0
    await b.tick(1)
    fr = await b.tel_frame()
    check_frame(fr, 0, 4, 1, 0)
    await b.win_write(OFF_TIDX, 2)
    assert await b.win_read(OFF_TIDX) == 2
    b.m.write_reg(OFF_TIDX, 2)
    await b.tick(8)                       # two frames fall due while one is held
    assert await b.tel_frame(extra=0) == fr
    s = b.ns()
    check_rep(await b.send(rd_pkt(0, s), "light"), 1, 0, s)
    assert (await b.send(pkt(3, s, crc=1), "len"))[0] == 0
    await b.take()
    assert await b.rd_cmp(OFF_TLEN) == 0
    await b.tick(3)
    assert await b.rd_cmp(OFF_TLEN) == 0
    await b.tick(1)
    check_frame(await b.tel_frame(), 1, 16, 2, 1)
    s = b.ns()
    data = check_rep(await b.send(st_pkt(s), "full"), 3, 0, s)
    vals, on = parse_status(data)
    assert vals[0] == 2 and vals[7] == 2 and on == 1, vals
    # a start restarts the tick count
    await b.take()
    await b.tick(3)
    s = b.ns()
    check_rep(await b.send(start_pkt(5, s), "light"), 4, 0, s)
    await b.tick(4)
    assert await b.rd_cmp(OFF_TLEN) == 0
    await b.tick(1)
    check_frame(await b.tel_frame(), 2, 24, 4, 1)


# req: REQ-35, REQ-36, REQ-37, REQ-38, REQ-43, REQ-52, REQ-46
@cocotb.test()
async def test_telemetry_stop_take_sequence(dut):
    b = Bench(dut)
    await b.start()
    s = b.ns()
    check_rep(await b.send(start_pkt(4, s), "light"), 4, 0, s)
    await b.tick(4)
    assert await b.rd_cmp(OFF_TLEN) == 17
    s = b.ns()
    check_rep(await b.send(stop_pkt(s), "light"), 5, 0, s)
    assert await b.rd_cmp(OFF_TLEN) == 0
    assert await b.rd_cmp(OFF_STAT) == 0
    await b.tick(8)
    assert await b.rd_cmp(OFF_TLEN) == 0
    await b.take()
    s = b.ns()
    check_rep(await b.send(start_pkt(0, s), "light"), 4, 0, s)
    await b.tick(4)
    fr = await b.tel_frame()
    check_frame(fr, 1, 16, 3, 0)
    await b.take()
    s = b.ns()
    check_rep(await b.send(stop_pkt(s), "light"), 5, 0, s)
    s = b.ns()
    check_rep(await b.send(start_pkt(4, s), "light"), 4, 0, s)
    await b.tick(4)
    check_frame(await b.tel_frame(), 2, 20, 5, 0)
    s = b.ns()
    data = check_rep(await b.send(st_pkt(s), "full"), 3, 0, s)
    vals, on = parse_status(data)
    assert vals[7] == 3 and on == 1, vals
    # only reset clears the sequence number and the frame count
    await b.do_reset()
    assert await b.rd_cmp(OFF_TLEN) == 0
    s = b.ns()
    check_rep(await b.send(start_pkt(4, s), "light"), 4, 0, s)
    await b.tick(4)
    check_frame(await b.tel_frame(), 0, 4, 1, 0)
    s = b.ns()
    data = check_rep(await b.send(st_pkt(s), "full"), 3, 0, s)
    vals, on = parse_status(data)
    assert vals[7] == 1 and on == 1, vals


# req: REQ-08, REQ-39, REQ-44
@cocotb.test()
async def test_tick_register(dut):
    b = Bench(dut)
    await b.start()
    total = 0
    for n in (0, 1, 255, 0, 7):
        await b.tick(n)
        assert await b.rd_cmp(OFF_STAT) == 0     # not busy, telemetry off
        total += n
        assert await b.read_r(7) == total


# req: REQ-28, REQ-40, REQ-44, REQ-49
@cocotb.test()
async def test_back_to_back_packets(dut):
    b = Bench(dut)
    await b.start()
    s = b.ns()
    await b.send(rd_pkt(0, s), "none")
    s = b.ns()
    await b.send(rd_pkt(1, s), "none")
    s = b.ns()
    res = await b.send(rd_pkt(6, s), "full")
    check_rep(res, 1, 0, s, (100).to_bytes(4, "big"))
    assert (await b.send(bytes([1, 2, 3]), "len"))[0] == 0
    assert await b.rd_cmp(OFF_STAT) == 0
    s = b.ns()
    res = await b.send(rd_pkt(0, s), "full")
    check_rep(res, 1, 0, s, ID_WORD.to_bytes(4, "big"))
    assert (await b.send(pkt(3, s, crc=0), "len"))[0] == 0
    s = b.ns()
    check_rep(await b.send(st_pkt(s), "light"), 3, 0, s)


# req: REQ-17, REQ-46, REQ-04, REQ-07, REQ-08, REQ-36, REQ-45
@cocotb.test()
async def test_reset_clears_state(dut):
    b = Bench(dut)
    await b.start()
    s = b.ns()
    check_rep(await b.send(wr_pkt(1, 0x1234, s), "light"), 2, 0, s)
    assert (await b.send(bytes([1]), "len"))[0] == 0
    s = b.ns()
    check_rep(await b.send(start_pkt(7, s), "light"), 4, 0, s)
    await b.tick(7)
    assert await b.rd_cmp(OFF_TLEN) == 17
    await b.win_write(OFF_RIDX, 3)
    b.m.write_reg(OFF_RIDX, 3)
    await b.win_write(OFF_TIDX, 2)
    b.m.write_reg(OFF_TIDX, 2)
    for x in (1, 2, 3):                    # part packet in the input buffer
        await b.win_write(OFF_IN, x)
        b.m.write_reg(OFF_IN, x)
    assert int(dut.LED.value) == 2
    old = b.seq
    await b.do_reset()
    assert int(dut.LED.value) == 0
    for off in (OFF_RLEN, OFF_RIDX, OFF_RWORD, OFF_TLEN, OFF_TIDX, OFF_TWORD, OFF_STAT):
        assert await b.rd_cmp(off) == 0
    # first packet after reset: any number, here the one used before reset
    assert await b.read_r(1, old) == 0
    assert await b.read_r(4) == 1
    assert await b.read_r(5) == 0
    assert await b.read_r(6) == 100
    assert await b.read_r(7) == 0
    s = b.ns()
    data = check_rep(await b.send(st_pkt(s), "full"), 3, 0, s)
    vals, on = parse_status(data)
    assert vals == [5, 0, 0, 0, 0, 0, 0, 0] and on == 0, vals


# req: REQ-47
@cocotb.test()
async def test_uart_baud(dut):
    b = Bench(dut)
    await b.start()
    for off in (OFF_RLEN, OFF_STAT, OFF_TLEN):
        await b.rd_cmp(off)
    await b.win_write(OFF_RIDX, 1)
    b.m.write_reg(OFF_RIDX, 1)
    assert b.lows, "no activity on UART_RXD_OUT"
    assert all(x % CLKS == 0 for x in b.lows), f"low runs not a multiple of CLKS_PER_BIT: {b.lows}"
    assert min(b.lows) == CLKS


# req: REQ-41, REQ-46
@cocotb.test()
async def test_unmapped_registers(dut):
    b = Bench(dut)
    await b.start()
    s = b.ns()
    check_rep(await b.send(rd_pkt(0, s), "full"), 1, 0, s)
    for off in (OFF_IN, OFF_TICK, OFF_TAKE, 10, 11, 0x20, 0x7F):
        assert await b.win_read(off) == 0, f"unmapped/WO offset {off} read"
    for off in (OFF_RLEN, OFF_RWORD, OFF_TLEN, OFF_TWORD, OFF_STAT, 10, 0x20, 0x7F):
        await b.win_write(off, 0xFFFFFFFF)
        b.m.write_reg(off, 0xFFFFFFFF)
    assert await b.rd_cmp(OFF_RLEN) == 13
    assert await b.rd_cmp(OFF_TLEN) == 0
    assert await b.rd_cmp(OFF_STAT) == 0
    await b.reply(extra=1)


# req: REQ-01, REQ-09, REQ-10, REQ-11, REQ-12, REQ-13, REQ-14, REQ-15, REQ-16, REQ-19, REQ-21, REQ-22, REQ-32, REQ-33
@cocotb.test()
async def test_random_traffic(dut):
    rng = random.Random(int(getattr(cocotb, "RANDOM_SEED", 1)))
    b = Bench(dut)
    await b.start()
    b.seq = rng.randrange(65536)
    for i in range(14):
        k = rng.random()
        full = (i % 5 == 4)
        if k < 0.70:
            typ = rng.choice([1, 1, 2, 2, 3, 4, 5, rng.choice([0, 6, 9, 0x81])])
            reg = rng.choice([0, 1, 2, 3, 4, 5, 6, 7, 8, 200])
            val = rng.choice([0, 1, 0xFFFFFFFF, rng.getrandbits(32)])
            per = rng.choice([0, 1, 4, 5, 9, rng.randrange(1, 30)])
            payload = {1: bytes([reg, 0]), 2: bytes([reg]) + val.to_bytes(4, "big") + b"\x00",
                       4: per.to_bytes(2, "big")}.get(typ, b"")
            if rng.random() < 0.15:
                if rng.random() < 0.5:
                    payload = payload + bytes([rng.randrange(256)])
                else:
                    payload = payload[:-1]
            delta = rng.choice([1, 1, 1, 2, 0, 0xFFFF, 32767, 32768, rng.randrange(65536)])
            s = b.ns(delta)
            p = pkt(typ, s, payload)
            if k >= 0.5:                            # corruptions
                c = rng.choice(["crc", "cut", "extra"])
                if c == "crc":
                    p = pkt(typ, s, payload, crc=rng.getrandbits(32))
                elif c == "cut":
                    p = p[:rng.randrange(1, len(p))]
                else:
                    p = (p + bytes(rng.randrange(256) for _ in range(rng.randrange(1, 5))))[:22]
            await b.send(p, "full" if full else "light")
        elif k < 0.85:
            await b.tick(rng.randrange(0, 12))
        elif k < 0.93:
            await b.take()
        elif k < 0.96:
            await b.do_reset()
        else:
            p = bytes(rng.randrange(256) for _ in range(rng.randrange(1, 12)))
            await b.send(p, "len")
        await b.rd_cmp(OFF_STAT)
        await b.rd_cmp(OFF_TLEN)
    s = b.ns()
    await b.send(st_pkt(s), "full")
    await b.tel_frame()
