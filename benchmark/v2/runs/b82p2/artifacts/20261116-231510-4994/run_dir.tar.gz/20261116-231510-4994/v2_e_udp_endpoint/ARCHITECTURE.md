# v2_e_udp_endpoint architecture

Payload-level UDP-style command and telemetry endpoint on the Nexys A7-100T. Host bytes arrive through the UART test shell register window (IN register, bit 8 = end flag). The endpoint checks, executes and answers each packet, and sends periodic telemetry frames.

## Block diagram

```text
 UART_TXD_IN --> [ fpga_shell ] <-- win_* --> [ reg_window ]
 UART_RXD_OUT <--                                 |   |   |
                                      IN byte     |   |   +-- TICK n --> [ telemetry ]
                                                  v   |                   tick gen, period,
                                           [ rx_parser ] -- crc32           held frame buffer
                                                  | pass                          ^
                                                  v                               | counts
                                           [ cmd_exec ] -- R0..R7, counters ------+
                                                  |                |
                                                  v                +--> LED[15:0] (commands carried out)
                                         [ reply_builder ] -- crc32
                                                  |
                                          reply buffer --> RLEN / RWORD (RIDX)
                                          frame buffer --> TLEN / TWORD (TIDX)

 CPU_RESETN --> [ reset_sync ] --> active-high sync reset to all blocks
```

Flow per packet: bytes are stored (max 8 payload + 8 header/trailer) while a running CRC is updated. At the end-flag byte the parser applies the refusal order (too long, too short, bad check, then type, length, sequence, register/access). Silent drops only increment counters. Accepted or replied packets go to cmd_exec, which updates state and the reply builder emits at most 26 bytes (status reply) in well under 100 clocks (one byte per clock plus CRC). The parser is free again once the end-flag byte is handled, because the reply is built from latched fields.

Telemetry: a tick (from TICK writes, one per clock for n clocks, pending count saturating at 65535, or the free uptime tick) counts R7. While on, every period-th tick builds an 17-byte frame into a single hold buffer if empty, otherwise the frame is dropped. TAKE or stop clears it.

## Clock plan

One clock domain: CLK100MHZ, 100 MHz, all logic synchronous. No derived clocks, no MMCM. No clock-domain crossings except the asynchronous CPU_RESETN button, which passes a reset synchroniser (async assert is not used: the input is registered by two flops, synchronous release) and is then used as one active-high synchronous reset. UART_TXD_IN is handled inside fpga_shell.

## Reset

CPU_RESETN (active low) is inverted once in the top and synchronised; all control, counters, sequence and telemetry state use that synchronous active-high reset. Datapath buffers (reply and frame bytes) are not reset.

## Pin list

| Port | Dir | Width | Board resource |
|---|---|---|---|
| CLK100MHZ | in | 1 | 100 MHz clock |
| CPU_RESETN | in | 1 | CPU RESET button, active low |
| UART_TXD_IN | in | 1 | USB-UART host to FPGA |
| UART_RXD_OUT | out | 1 | USB-UART FPGA to host |
| LED | out | 16 | LED[15:0] |

I/O timing: buttons and UART are asynchronous, so input delays are set with comments in design.xdc; LED output delays likewise.

## Resources (prediction)

LUT 700–2500, FF 600–2500, BRAM 0–1 (buffers may map to distributed RAM or one tile), DSP 0.
