import zlib


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000000, BUILD_STAMP=0,
                 ID_WORD=1430540337, DEFAULT_PERIOD=100, MIN_PERIOD=4,
                 MAX_PAYLOAD=8, REG_COUNT=8, REPLY_BUILD_CYCLES=100):
        self.ID_WORD = ID_WORD
        self.DEFAULT_PERIOD = DEFAULT_PERIOD
        self.MIN_PERIOD = MIN_PERIOD
        self.MAX_PAYLOAD = MAX_PAYLOAD
        self.REG_COUNT = REG_COUNT
        self.reset()

    def reset(self):
        self.scratch = [0, 0, 0]
        self.cmds = 0
        self.refused = 0
        self.c_crc = 0
        self.c_short = 0
        self.c_long = 0
        self.c_rep = 0
        self.c_ooo = 0
        self.c_tle = 0
        self.period = self.DEFAULT_PERIOD
        self.uptime = 0
        self.last_seq = None
        self.buf = []
        self.reply = b""
        self.pending = 0
        self.tel_on = 0
        self.tcount = 0
        self.frame = None
        self.fseq = 0
        self.fcount = 0
        self.ridx = 0
        self.tidx = 0

    # ---- helpers
    @staticmethod
    def _crc(b):
        return zlib.crc32(bytes(b)) & 0xFFFFFFFF

    def _seal(self, b):
        b = bytes(b)
        return b + self._crc(b).to_bytes(4, "little")

    def _refuse(self, attr):
        setattr(self, attr, (getattr(self, attr) + 1) & 0xFFFFFFFF)
        self.refused = (self.refused + 1) & 0xFFFFFFFF

    def _mkreply(self, typ, status, seq, payload=b""):
        body = bytes([(typ | 0x80) & 0xFF, status, (seq >> 8) & 0xFF, seq & 0xFF,
                      len(payload)]) + bytes(payload)
        self.reply = self._seal(body)

    def _process(self):
        b = self.buf
        self.buf = []
        n = len(b)
        self.reply = b""
        if n < 4:
            self._refuse("c_short")
            return
        ln = b[1]
        if ln > self.MAX_PAYLOAD or n > 8 + ln:
            self._refuse("c_long")
            return
        if n < 8 + ln:
            self._refuse("c_short")
            return
        if int.from_bytes(bytes(b[-4:]), "little") != self._crc(b[:-4]):
            self._refuse("c_crc")
            return
        typ = b[0]
        seq = (b[2] << 8) | b[3]
        pl = b[4:4 + ln]
        need = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}
        if typ not in need:
            self._refuse("c_tle")
            self._mkreply(typ, 1, seq)
            return
        if ln != need[typ]:
            self._refuse("c_tle")
            self._mkreply(typ, 2, seq)
            return
        if self.last_seq is not None:
            d = (seq - self.last_seq) & 0xFFFF
            if not (1 <= d <= 32767):
                self._refuse("c_rep" if d == 0 else "c_ooo")
                self._mkreply(typ, 4, seq)
                return
        self.last_seq = seq
        payload = b""
        if typ in (1, 2):
            r = pl[0]
            if r >= self.REG_COUNT:
                self._refuse("c_tle")
                self._mkreply(typ, 3, seq)
                return
            if typ == 1:
                v = self._readr(r)
                payload = (v & 0xFFFFFFFF).to_bytes(4, "big")
            else:
                if r not in (1, 2, 3):
                    self._refuse("c_tle")
                    self._mkreply(typ, 5, seq)
                    return
                self.scratch[r - 1] = int.from_bytes(bytes(pl[1:5]), "big")
        elif typ == 3:
            m = 0xFFFF
            vals = [self.cmds, self.c_crc, self.c_short, self.c_long,
                    self.c_rep, self.c_ooo, self.c_tle, self.fcount]
            payload = b"".join((v & m).to_bytes(2, "big") for v in vals) + bytes([self.tel_on])
        elif typ == 4:
            p = (pl[0] << 8) | pl[1]
            if p != 0:
                self.period = max(p, self.MIN_PERIOD)
            self.tel_on = 1
            self.tcount = 0
        elif typ == 5:
            self.tel_on = 0
            self.frame = None
        self.cmds = (self.cmds + 1) & 0xFFFFFFFF
        self._mkreply(typ, 0, seq, payload)

    def _readr(self, r):
        if r == 0:
            return self.ID_WORD
        if r in (1, 2, 3):
            return self.scratch[r - 1]
        if r == 4:
            return self.cmds
        if r == 5:
            return self.refused
        if r == 6:
            return self.period
        if r == 7:
            return self.uptime
        return 0

    def _tick(self):
        self.uptime = (self.uptime + 1) & 0xFFFFFFFF
        if self.tel_on:
            self.tcount += 1
            if self.tcount >= self.period:
                self.tcount = 0
                if self.frame is None:
                    body = (bytes([0xC0, 0, (self.fseq >> 8) & 0xFF, self.fseq & 0xFF, 8])
                            + self.uptime.to_bytes(4, "big")
                            + (self.cmds & 0xFFFF).to_bytes(2, "big")
                            + (self.refused & 0xFFFF).to_bytes(2, "big"))
                    self.frame = self._seal(body)
                    self.fseq = (self.fseq + 1) & 0xFFFF
                    self.fcount = (self.fcount + 1) & 0xFFFF

    @staticmethod
    def _word(data, i):
        seg = bytes(data[4 * i:4 * i + 4])
        seg = seg + bytes(4 - len(seg))
        return int.from_bytes(seg, "big")

    # ---- API
    def step(self, inputs=None):
        if self.pending > 0:
            self.pending -= 1
            self._tick()
        return {"UART_RXD_OUT": 1, "LED": self.cmds & 0xFFFF}

    def write_reg(self, offset, value):
        if offset == 0:
            self.buf.append(value & 0xFF)
            if value & 0x100:
                self._process()
        elif offset == 1:
            self.pending = min(65535, self.pending + (value & 0xFF))
        elif offset == 3:
            self.ridx = value & 0x7F
        elif offset == 6:
            self.tidx = value & 0x7F
        elif offset == 8:
            self.frame = None

    def read_reg(self, offset):
        if offset == 2:
            return len(self.reply)
        if offset == 3:
            return self.ridx
        if offset == 4:
            return self._word(self.reply, self.ridx)
        if offset == 5:
            return len(self.frame) if self.frame else 0
        if offset == 6:
            return self.tidx
        if offset == 7:
            return self._word(self.frame or b"", self.tidx)
        if offset == 9:
            return self.tel_on | ((1 if self.pending > 0 else 0) << 1)
        return 0
