// bind of the port-only checker onto the top
bind v2_e_resp_builder_top v2_e_resp_builder_checker u_chk (
    .clk (CLK100MHZ),
    .rst (~CPU_RESETN),
    .LED (LED)
);
