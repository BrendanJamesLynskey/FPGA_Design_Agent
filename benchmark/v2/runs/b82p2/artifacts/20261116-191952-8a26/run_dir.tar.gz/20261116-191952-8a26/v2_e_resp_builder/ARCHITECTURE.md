# v2_e_resp_builder architecture

Reply frame builder on the Nexys A7-100T (xc7a100tcsg324-1). A host writes TYPE, STATUS, SEQ and payload bytes
through the UART test shell, writes BUILD, and reads the reply back byte by byte (IDX/BYTE). Single 100 MHz clock.

## Block diagram

```text
 UART_TXD_IN --> [ fpga_shell ] --win_addr/wr/rd/wdata--> [ resp_regs ] --> LED[15:0]
 UART_RXD_OUT <-- [ (uart rx/tx,  ] <--win_rdata--------- [ payload(24) ]
                  [  shell core)  ]                       [ TYPE/STATUS/SEQ/IDX ]
                                                              |  start / params
                                                              v
                                                       [ resp_builder ]
                                                       FSM + CRC-32 + reply buffer(33 x 8)
 CPU_RESETN --> [xpm_cdc_async_rst] --> rst (active high, sync) to all blocks
 CLK100MHZ --> all registers
```

## Blocks

- resp_regs: write decode (TYPE 7 bits, STATUS, SEQ, PBYTE append/overflow, BUILD, IDX), read mux (TYPE, STATUS,
  SEQ, IDX, STAT, PLEN, LEN, BYTE, others 0). BUILD and PBYTE writes are ignored while building.
- resp_builder: on BUILD, one byte per clock: byte0..4, payload, 4 CRC bytes (reflected CRC-32, init and final
  xor 0xFFFFFFFF). Worst case 33 bytes + setup, well under 64 clocks. The new reply is written to a staging path
  and length is committed at the end, so the previous reply stays readable until completion. At completion the
  payload count and overflow flag are cleared and building drops. The reply buffer is distributed RAM or
  registers; BYTE read is combinational from IDX (the shell allows one cycle).
- LED[7:0] = reply length, LED[15:8] = reply status byte, both 0 when no reply.

## Clock plan

One clock domain: CLK100MHZ, 100 MHz, constrained at 10 ns. No MMCM, no derived clocks.
Reset: CPU_RESETN (active low, asynchronous button) passes through xpm_cdc_async_rst (asynchronous assert,
synchronous release), is inverted once to an active-high synchronous reset used inside. UART_TXD_IN is
synchronised by a 2-FF synchroniser in the shell receiver.

## Pin list

| Port | Dir | Width | Board resource |
|---|---|---|---|
| CLK100MHZ | in | 1 | 100 MHz oscillator |
| CPU_RESETN | in | 1 | CPU reset button, active low |
| UART_TXD_IN | in | 1 | USB-UART, host to FPGA (C4) |
| UART_RXD_OUT | out | 1 | USB-UART, FPGA to host (D4) |
| LED | out | 16 | LED[15:0] |

## Resource prediction

LUT 350 to 1000, FF 350 to 900 (including the shell), BRAM 0 to 1, DSP 0.
