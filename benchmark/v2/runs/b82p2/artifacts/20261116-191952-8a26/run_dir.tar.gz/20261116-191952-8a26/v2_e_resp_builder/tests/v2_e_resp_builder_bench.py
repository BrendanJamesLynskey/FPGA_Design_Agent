"""cocotb bench for v2_e_resp_builder: every access goes through the shell UART (PROTOCOL.md),
window address = 0x80 + register offset.  Results are compared with model.py and, for the reply
bytes, with an independent zlib computation."""
import random
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402
from model import Model  # noqa: E402

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ClockCycles, RisingEdge  # noqa: E402

C = 8            # CLKS_PER_BIT used in simulation (same value given to flow.cocotb_run and the model)
TIMEOUT = 1500   # TIMEOUT_CYCLES used in simulation
PARAMS = dict(CLKS_PER_BIT=C, TIMEOUT_CYCLES=TIMEOUT)

TYPE, STATUS, SEQ, PBYTE, BUILD, IDX, BYTE, LEN, STAT, PLEN = 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
ID_VALUE = 0x52534231


def ref_reply(t, s, q, p):
    b = bytes([0x80 | (t & 0x7F), s & 0xFF, (q >> 8) & 0xFF, q & 0xFF, len(p)]) + bytes(p)
    return b + zlib.crc32(b).to_bytes(4, "little")


def seed_value():
    return int(getattr(cocotb, "RANDOM_SEED", 1))


class Bench:
    def __init__(self, dut):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        self.m = Model(**PARAMS)
        self.cyc = 0
        self.led = None
        self.changes = []
        self.tx_end = 0
        self.ops = 0

    async def start(self):
        dut = self.dut
        try:
            clk = Clock(dut.CLK100MHZ, 10, unit="ns")
        except TypeError:
            clk = Clock(dut.CLK100MHZ, 10, units="ns")
        cocotb.start_soon(clk.start())
        dut.UART_TXD_IN.value = 1
        dut.CPU_RESETN.value = 0
        await ClockCycles(self.clk, 10)
        dut.CPU_RESETN.value = 1
        cocotb.start_soon(self._mon())
        await ClockCycles(self.clk, 20)
        self.m.reset()

    async def _mon(self):
        while True:
            await RisingEdge(self.clk)
            self.cyc += 1
            try:
                x = int(self.dut.LED.value)
            except ValueError:
                continue
            if x != self.led:
                self.led = x
                self.changes.append((self.cyc, x))

    async def reset(self, cycles=4):
        self.dut.CPU_RESETN.value = 0
        await ClockCycles(self.clk, cycles)
        self.dut.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 20)
        self.m.reset()

    # ---- UART ----
    async def send_byte(self, b):
        self.dut.UART_TXD_IN.value = 0
        await ClockCycles(self.clk, C)
        for i in range(8):
            self.dut.UART_TXD_IN.value = (b >> i) & 1
            await ClockCycles(self.clk, C)
        self.dut.UART_TXD_IN.value = 1
        await ClockCycles(self.clk, C)

    def rxd(self):
        return int(self.dut.UART_RXD_OUT.value)

    async def recv_byte(self, timeout):
        for _ in range(timeout):
            await RisingEdge(self.clk)
            if self.rxd() == 0:
                break
        else:
            raise AssertionError("no response byte from the shell")
        await ClockCycles(self.clk, C // 2)
        assert self.rxd() == 0, "start bit not low at mid-bit"
        v = 0
        for i in range(8):
            await ClockCycles(self.clk, C)
            v |= self.rxd() << i
        await ClockCycles(self.clk, C)
        assert self.rxd() == 1, "stop bit not high"
        return v

    async def send_frame(self, cmd, addr, data):
        body = bytes([cmd, addr]) + (data & 0xFFFFFFFF).to_bytes(4, "little")
        chk = 0
        for x in body:
            chk ^= x
        for b in bytes([0xA5]) + body + bytes([chk]):
            await self.send_byte(b)
        self.tx_end = self.cyc

    async def xact(self, cmd, addr, data=0):
        await self.send_frame(cmd, addr, data)
        resp = []
        for i in range(7):
            resp.append(await self.recv_byte(6000 if i == 0 else 40 * C))
        assert resp[0] == 0x5A, f"bad response sync {resp}"
        chk = 0
        for x in resp[1:6]:
            chk ^= x
        assert chk == resp[6], f"bad response checksum {resp}"
        await ClockCycles(self.clk, 2 * C)
        self.ops += 1
        return resp[1], int.from_bytes(bytes(resp[2:6]), "little")

    # ---- register access ----
    async def wr(self, off, val):
        st, _ = await self.xact(2, 0x80 + off, val)
        assert st == 0, f"write to window offset {off} returned status {st}"
        self.m.write_reg(off, val)
        if off == BUILD:
            for _ in range(100):
                self.m.step()

    async def rd(self, off):
        st, d = await self.xact(1, 0x80 + off, 0)
        assert st == 0, f"read of window offset {off} returned status {st}"
        return d

    async def rd_check(self, off):
        got = await self.rd(off)
        exp = self.m.read_reg(off)
        assert got == exp, f"offset {off}: DUT {got:#x} model {exp:#x}"
        return got

    def check_led(self):
        exp = self.m.step()["LED"]
        assert self.led == exp, f"LED DUT {self.led:#06x} model {exp:#06x}"

    async def check_all(self, extra=(10, 0x20, 0x7F)):
        for off in [TYPE, STATUS, SEQ, PBYTE, BUILD, IDX, BYTE, LEN, STAT, PLEN] + list(extra):
            await self.rd_check(off)
        self.check_led()

    async def build(self):
        """Write BUILD; check the LED (reply replaced) timing: within 64 clocks of the write."""
        old = self.led
        n0 = len(self.changes)
        await self.wr(BUILD, 1)
        exp = self.m.step()["LED"]
        await ClockCycles(self.clk, 5)
        new = self.changes[n0:]
        if exp != old:
            assert new, "LED did not change after BUILD"
            assert new[0][0] >= self.tx_end - C - 2, "reply replaced before the BUILD write arrived"
            assert new[-1][0] <= self.tx_end + 64 + 20, f"build not complete within 64 clocks ({new[-1][0] - self.tx_end})"
        assert self.led == exp, f"LED after build DUT {self.led:#06x} model {exp:#06x}"
        # building flag and flags cleared once complete
        stat = await self.rd(STAT)
        assert stat == 0, f"STAT after build = {stat:#x}"
        assert await self.rd(PLEN) == 0, "COUNT not cleared by build"

    async def read_reply(self, n):
        out = []
        for i in range(n):
            await self.wr(IDX, i)
            out.append(await self.rd(BYTE))
        return out


# req: REQ-20, REQ-24, REQ-25, REQ-26, REQ-29
@cocotb.test()
async def test_reset_and_identity(dut):
    b = Bench(dut)
    await b.start()
    assert await b.rd(0) == 0 or True  # shell DESIGN_ID address 0x00 is below the window
    st, d = await b.xact(1, 0x00, 0)
    assert st == 0 and d == ID_VALUE, f"ID {d:#x}"
    await b.check_all()
    assert b.led == 0, "LED not 0 with no reply"
    assert await b.rd(LEN) == 0
    assert await b.rd(BYTE) == 0


# req: REQ-01, REQ-02, REQ-03, REQ-04, REQ-05, REQ-06, REQ-07, REQ-13, REQ-14, REQ-15, REQ-16, REQ-21, REQ-22, REQ-23
@cocotb.test()
async def test_basic_build(dut):
    b = Bench(dut)
    await b.start()
    await b.wr(TYPE, 3)
    await b.wr(STATUS, 0x5A)
    await b.wr(SEQ, 0x1234)
    for p in (1, 2, 3):
        await b.wr(PBYTE, p)
    assert await b.rd(PLEN) == 3
    assert await b.rd(STAT) == 0
    assert b.led == 0, "reply visible before build"
    await b.build()
    exp = ref_reply(3, 0x5A, 0x1234, [1, 2, 3])
    assert exp[0] == 0x83
    assert await b.rd(LEN) == len(exp) == 12
    got = await b.read_reply(len(exp))
    assert bytes(got) == exp, f"reply {bytes(got).hex()} expected {exp.hex()}"
    assert await b.rd(BYTE) == exp[-1]
    assert b.led == (12 | (0x5A << 8)), f"LED {b.led:#x}"
    await b.check_all()
    # second build with a different payload: previous reply readable until replaced, then new
    await b.wr(TYPE, 0x41)
    await b.wr(STATUS, 0x01)
    await b.wr(SEQ, 0xBEEF)
    pl = [0xFF, 0x00, 0x80, 0x7F, 0x55, 0xAA]
    for p in pl:
        await b.wr(PBYTE, p)
    await b.build()
    exp2 = ref_reply(0x41, 1, 0xBEEF, pl)
    got = await b.read_reply(len(exp2))
    assert bytes(got) == exp2, f"reply {bytes(got).hex()} expected {exp2.hex()}"
    assert b.led == (len(exp2) | (1 << 8))


# req: REQ-08, REQ-09, REQ-17
@cocotb.test()
async def test_type_mask_hold(dut):
    b = Bench(dut)
    await b.start()
    await b.wr(TYPE, 0xFF)
    assert await b.rd(TYPE) == 0x7F, "TYPE must keep 7 bits"
    await b.wr(STATUS, 0x1A5)
    assert await b.rd(STATUS) == 0xA5
    await b.wr(SEQ, 0xFFFF1234)
    assert await b.rd(SEQ) == 0x1234
    await b.build()
    exp = ref_reply(0x7F, 0xA5, 0x1234, [])
    assert exp[0] == 0xFF
    got = await b.read_reply(9)
    assert bytes(got) == exp
    assert await b.rd(LEN) == 9
    # values hold across builds
    await b.build()
    assert await b.rd(TYPE) == 0x7F and await b.rd(STATUS) == 0xA5 and await b.rd(SEQ) == 0x1234
    got = await b.read_reply(9)
    assert bytes(got) == exp
    # reply unchanged while registers change without a build
    await b.wr(TYPE, 5)
    await b.wr(STATUS, 0x11)
    await b.wr(SEQ, 0x0102)
    await b.wr(PBYTE, 9)
    led = b.led
    got = await b.read_reply(10)
    assert bytes(got[:9]) == exp and got[9] == 0
    assert b.led == led
    await b.build()
    exp2 = ref_reply(5, 0x11, 0x0102, [9])
    assert bytes(await b.read_reply(10)) == exp2


# req: REQ-10, REQ-11, REQ-12, REQ-13, REQ-14, REQ-06, REQ-21
@cocotb.test()
async def test_overflow(dut):
    b = Bench(dut)
    await b.start()
    pl = [(i * 7 + 1) & 0xFF for i in range(24)]
    await b.wr(TYPE, 0x12)
    await b.wr(STATUS, 0x80)
    await b.wr(SEQ, 0x00FF)
    for i, p in enumerate(pl):
        await b.wr(PBYTE, 0x1200 + p if i % 2 else p)
    assert await b.rd(PLEN) == 24
    assert await b.rd(STAT) == 0, "overflow flag set too early"
    await b.wr(PBYTE, 0xEE)
    assert await b.rd(PLEN) == 24, "COUNT exceeded 24 / changed on overflow"
    assert await b.rd(STAT) == 2, "overflow flag not set"
    await b.wr(PBYTE, 0xDD)
    assert await b.rd(PLEN) == 24
    assert await b.rd(STAT) == 2
    await b.build()   # also checks STAT == 0 and PLEN == 0 after
    exp = ref_reply(0x12, 0x80, 0x00FF, pl)
    assert len(exp) == 33
    assert await b.rd(LEN) == 33
    got = await b.read_reply(33)
    assert bytes(got) == exp, f"reply {bytes(got).hex()} expected {exp.hex()}"
    assert b.led == (33 | (0x80 << 8))
    # after the clear a new payload byte is accepted again
    await b.wr(PBYTE, 1)
    assert await b.rd(PLEN) == 1


# req: REQ-18, REQ-19, REQ-20, REQ-17, REQ-16
@cocotb.test()
async def test_index_readback_unmapped(dut):
    b = Bench(dut)
    await b.start()
    assert await b.rd(LEN) == 0
    await b.wr(IDX, 0)
    assert await b.rd(BYTE) == 0
    await b.wr(IDX, 3)
    assert await b.rd(BYTE) == 0, "BYTE must be 0 before the first build"
    # first reply: long, with non-zero data everywhere
    await b.wr(TYPE, 0x7E)
    await b.wr(STATUS, 0xFF)
    await b.wr(SEQ, 0xFFFF)
    for i in range(10):
        await b.wr(PBYTE, 0xF0 + i)
    await b.build()
    assert await b.rd(LEN) == 19
    # second reply: short, stale bytes must not leak
    await b.wr(TYPE, 1)
    await b.wr(STATUS, 2)
    await b.wr(SEQ, 0x0304)
    await b.wr(PBYTE, 0xAB)
    await b.build()
    exp = ref_reply(1, 2, 0x0304, [0xAB])
    assert await b.rd(LEN) == 10
    for i in (0, 4, 5, 6, 9, 10, 11, 15, 18, 19, 33, 64, 127):
        await b.wr(IDX, i)
        got = await b.rd(BYTE)
        want = exp[i] if i < len(exp) else 0
        assert got == want, f"BYTE[{i}] = {got:#x}, expected {want:#x}"
        await b.rd_check(BYTE)
    await b.wr(IDX, 0x80 | 7)
    assert await b.rd(IDX) == 7, "IDX keeps 7 bits"
    await b.wr(IDX, 0x7F)
    assert await b.rd(IDX) == 0x7F
    # write-only registers read 0
    assert await b.rd(BUILD) == 0
    assert await b.rd(PBYTE) == 0
    # read-only and unmapped offsets ignore writes
    for off in (LEN, STAT, PLEN, BYTE, 10, 0x20, 0x7F):
        await b.xact(2, 0x80 + off, 0x55)
    assert await b.rd(LEN) == 10
    assert await b.rd(PLEN) == 0
    assert await b.rd(STAT) == 0
    await b.wr(IDX, 1)
    assert await b.rd(BYTE) == 2
    for off in (10, 0x20, 0x7F):
        assert await b.rd(off) == 0
    await b.check_all()


# req: REQ-25, REQ-24, REQ-20, REQ-13, REQ-14
@cocotb.test()
async def test_reset_clears(dut):
    b = Bench(dut)
    await b.start()
    await b.wr(TYPE, 0x33)
    await b.wr(STATUS, 0xC3)
    await b.wr(SEQ, 0xABCD)
    await b.wr(PBYTE, 0x99)
    await b.build()
    assert b.led != 0
    await b.wr(IDX, 5)
    for i in range(25):
        await b.wr(PBYTE, i + 1)
    assert await b.rd(STAT) == 2
    assert await b.rd(PLEN) == 24
    await b.reset(3)
    assert b.led == 0, f"LED after reset {b.led:#x}"
    for off in (TYPE, STATUS, SEQ, IDX, BYTE, LEN, STAT, PLEN):
        got = await b.rd(off)
        assert got == 0, f"offset {off} = {got:#x} after reset"
    await b.check_all()
    # a fresh build after reset carries nothing over
    await b.build()
    exp = ref_reply(0, 0, 0, [])
    assert bytes(await b.read_reply(9)) == exp
    assert await b.rd(BYTE) == exp[8]


# req: REQ-27
@cocotb.test()
async def test_baud_rate(dut):
    """The response's first byte 0x5A starts 0,0 (start bit + D0): the low run is 2 bit times.
    The simulation uses CLKS_PER_BIT = C (parameter override); the 868 default is checked on hardware."""
    b = Bench(dut)
    await b.start()
    await b.send_frame(1, 0x00, 0)
    for _ in range(6000):
        await RisingEdge(b.clk)
        if b.rxd() == 0:
            break
    else:
        raise AssertionError("no response")
    run = 1
    while True:
        await RisingEdge(b.clk)
        if b.rxd() != 0:
            break
        run += 1
    assert abs(run - 2 * C) <= 2, f"low run {run} clocks, expected {2 * C} (CLKS_PER_BIT {C})"
    await ClockCycles(b.clk, 15 * C * 10)
    st, d = await b.xact(1, 0x00, 0)
    assert st == 0 and d == ID_VALUE


# req: REQ-01, REQ-03, REQ-04, REQ-05, REQ-06, REQ-07, REQ-09, REQ-10, REQ-11, REQ-13, REQ-14, REQ-15, REQ-17, REQ-18, REQ-19, REQ-21, REQ-22, REQ-23
@cocotb.test()
async def test_random_traffic(dut):
    b = Bench(dut)
    await b.start()
    rng = random.Random(seed_value())
    dut._log.info(f"random seed {seed_value()}")
    builds = 0
    while b.ops < 110:
        r = rng.random()
        if r < 0.10:
            await b.wr(rng.choice([TYPE, STATUS, SEQ]), rng.getrandbits(32))
        elif r < 0.35:
            await b.wr(PBYTE, rng.getrandbits(32))
        elif r < 0.39:
            for _ in range(rng.randint(20, 27)):
                await b.wr(PBYTE, rng.getrandbits(8))
            await b.rd_check(STAT)
            await b.rd_check(PLEN)
        elif r < 0.50:
            await b.build()
            builds += 1
            n = await b.rd_check(LEN)
            full = ref_reply_from_model(b)
            for i in sorted({0, 1, 2, 3, 4, n - 1, n - 4, rng.randrange(n), n, n + rng.randrange(1, 40)}):
                if 0 <= i < 128:
                    await b.wr(IDX, i)
                    got = await b.rd_check(BYTE)
                    assert got == (full[i] if i < len(full) else 0)
        elif r < 0.65:
            await b.wr(IDX, rng.getrandbits(8))
            await b.rd_check(BYTE)
        elif r < 0.75:
            await b.wr(rng.choice([LEN, STAT, PLEN, BYTE, 10, 0x40]), rng.getrandbits(32)) if False else \
                await b.xact(2, 0x80 + rng.choice([LEN, STAT, PLEN, BYTE, 10, 0x40]), rng.getrandbits(32))
        else:
            await b.rd_check(rng.choice([TYPE, STATUS, SEQ, IDX, LEN, STAT, PLEN, BYTE, BUILD, PBYTE]))
    await b.build()
    await b.check_all()


def ref_reply_from_model(b):
    """Reply bytes as the model holds them, cross-checked against the independent zlib builder."""
    m = b.m
    out = list(m.reply)
    assert bytes(out) == ref_reply(out[0] & 0x7F, out[1], (out[2] << 8) | out[3], out[5:5 + out[4]])
    return out
