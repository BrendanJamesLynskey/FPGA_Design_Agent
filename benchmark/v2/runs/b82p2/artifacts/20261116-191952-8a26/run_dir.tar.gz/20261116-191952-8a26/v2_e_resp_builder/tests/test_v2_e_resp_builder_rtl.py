"""Pytest entry: runs the cocotb bench against the RTL for several seeds."""
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
DESIGN_DIR = HERE.parents[1]
for p in HERE.parents:
    if (p / "flow").is_dir():
        sys.path.insert(0, str(p))
        break
sys.path.insert(0, str(DESIGN_DIR))
sys.path.insert(0, str(HERE.parent))

import flow.cocotb_run as cocotb_run  # noqa: E402

PARAMETERS = {"CLKS_PER_BIT": 8, "TIMEOUT_CYCLES": 1500}   # same values as PARAMS in the bench
SEEDS = (1, 2, 3)


def test_v2_e_resp_builder_rtl():
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN_DIR / "rtl").glob("*.sv"))
    for seed in SEEDS:
        res = cocotb_run.run(
            "v2_e_resp_builder",
            "v2_e_resp_builder_top",
            sources,
            "v2_e_resp_builder_bench",
            HERE.parent,
            parameters=PARAMETERS,
            seed=seed,
        )
        if isinstance(res, bool):
            assert res, f"cocotb run failed for seed {seed}"
        elif hasattr(res, "passed"):
            assert res.passed, f"cocotb run failed for seed {seed}"
