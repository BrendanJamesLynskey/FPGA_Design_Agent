import zlib


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000, BUILD_STAMP=0,
                 MAX_PAYLOAD=24, BUILD_MAX_CYCLES=64, DESIGN_ID=1381188145):
        self.MAX_PAYLOAD = MAX_PAYLOAD
        self.BUILD_MAX_CYCLES = BUILD_MAX_CYCLES
        self.DESIGN_ID = DESIGN_ID
        self.inputs = {}
        self.reset()

    def reset(self):
        self.type = 0
        self.status = 0
        self.seq = 0
        self.idx = 0
        self.payload = []
        self.overflow = 0
        self.building = 0
        self.cnt = 0
        self.snap = None
        self.reply = []

    def _complete(self):
        t, s, q, p = self.snap
        b = bytes([0x80 | t, s, (q >> 8) & 0xFF, q & 0xFF, len(p)]) + bytes(p)
        c = zlib.crc32(b) & 0xFFFFFFFF
        b += c.to_bytes(4, 'little')
        self.reply = list(b)
        self.payload = []
        self.overflow = 0
        self.building = 0

    def step(self, inputs=None):
        if inputs:
            self.inputs.update(inputs)
        if self.inputs.get('CPU_RESETN', 1) == 0:
            self.reset()
        elif self.building:
            self.cnt -= 1
            if self.cnt <= 0:
                self._complete()
        return self._outs()

    def _outs(self):
        n = len(self.reply)
        led = (n & 0xFF) | ((self.reply[1] << 8) if n else 0)
        return {'UART_RXD_OUT': 1, 'LED': led}

    def write_reg(self, offset, value):
        if offset == 0:
            self.type = value & 0x7F
        elif offset == 1:
            self.status = value & 0xFF
        elif offset == 2:
            self.seq = value & 0xFFFF
        elif offset == 3:
            if self.building:
                return
            if len(self.payload) < self.MAX_PAYLOAD:
                self.payload.append(value & 0xFF)
            else:
                self.overflow = 1
        elif offset == 4:
            if self.building:
                return
            self.snap = (self.type, self.status, self.seq, list(self.payload))
            self.building = 1
            self.cnt = min(9 + len(self.payload), self.BUILD_MAX_CYCLES)
        elif offset == 5:
            self.idx = value & 0x7F

    def read_reg(self, offset):
        if offset == 0:
            return self.type
        if offset == 1:
            return self.status
        if offset == 2:
            return self.seq
        if offset == 5:
            return self.idx
        if offset == 6:
            return self.reply[self.idx] if self.idx < len(self.reply) else 0
        if offset == 7:
            return len(self.reply)
        if offset == 8:
            return self.building | (self.overflow << 1)
        if offset == 9:
            return len(self.payload)
        return 0
