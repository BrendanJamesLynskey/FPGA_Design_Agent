// Port-only checker for v2_e_resp_builder_top (bound by v2_e_resp_builder_bind.sv).
`include "v_macros.svh"
module v2_e_resp_builder_checker (
    input wire        clk,
    input wire        rst,
    input wire [15:0] LED
);
    reg seen_rst = 1'b0;
    reg past_ok  = 1'b0;
    always @(posedge clk) begin
        past_ok <= 1'b1;
        if (rst) seen_rst <= 1'b1;
    end

    // reply length is 0 (no reply) or 9..33
    `V_SAME(A_len_range, 1'b1, (LED[7:0] == 8'd0) || (LED[7:0] >= 8'd9 && LED[7:0] <= 8'd33)) // req: REQ-22

    `V_COVER(C_no_reply, LED == 16'd0) // req: REQ-24
    `V_COVER(C_reply_present, LED[7:0] != 8'd0) // req: REQ-22
    `V_COVER(C_reply_status_nonzero, LED[15:8] != 8'd0) // req: REQ-23
    `V_COVER(C_reply_max, LED[7:0] == 8'd33) // req: REQ-22
endmodule
