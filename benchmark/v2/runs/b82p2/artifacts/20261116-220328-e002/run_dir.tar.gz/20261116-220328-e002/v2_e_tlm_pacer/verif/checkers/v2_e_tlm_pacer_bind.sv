bind v2_e_tlm_pacer_top v2_e_tlm_pacer_checker u_pacer_chk (
    .clk(CLK100MHZ),
    .rst(~CPU_RESETN),
    .led(LED),
    .txd(UART_RXD_OUT)
);
