"""pytest entry: runs the cocotb bench (tests/pacer_bench.py) against rtl/*.sv for each seed."""
from pathlib import Path

import pytest

from flow import cocotb_run

DESIGN = Path(__file__).resolve().parents[1]
# same values as CPB / TIMEOUT in pacer_bench.py
PARAMS = {"CLKS_PER_BIT": 6, "TIMEOUT_CYCLES": 2000}


@pytest.mark.parametrize("seed", [1, 2, 3])
def test_rtl(seed):
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN / "rtl").glob("*.sv"))
    cocotb_run.run(
        "v2_e_tlm_pacer",
        "v2_e_tlm_pacer_top",
        sources,
        "pacer_bench",
        Path(__file__).resolve().parent,
        parameters=PARAMS,
        seed=seed,
    )
