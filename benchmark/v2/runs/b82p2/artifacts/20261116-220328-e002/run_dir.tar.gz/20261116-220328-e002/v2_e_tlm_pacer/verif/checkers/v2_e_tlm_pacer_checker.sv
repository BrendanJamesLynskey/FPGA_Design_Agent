// Port-only checker: covers that the bench reached LED activity and UART responses.
`include "v_macros.svh"
module v2_e_tlm_pacer_checker (
    input logic        clk,
    input logic        rst,
    input logic [15:0] led,
    input logic        txd
);
  logic seen_rst = 1'b0;
  always @(posedge clk) if (rst) seen_rst <= 1'b1;

  `V_COVER(C_led_nonzero, led != 16'd0)          // req: REQ-18
  `V_COVER(C_led_changes, led != $past(led))     // req: REQ-18
  `V_COVER(C_uart_resp_active, txd == 1'b0)      // req: REQ-20
endmodule
