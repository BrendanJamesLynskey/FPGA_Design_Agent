"""cocotb bench for v2_e_tlm_pacer: every register access goes over the UART test shell and is
compared with model.py.  The model is advanced at transaction level (a TICK write of n steps the model n
times; a UART transaction is longer than the 255-clock burst, so the DUT has finished by the next access)."""
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ClockCycles, RisingEdge  # noqa: E402

CPB = 6            # CLKS_PER_BIT override (the entry passes the same value)
TIMEOUT = 2000     # TIMEOUT_CYCLES override
WIN = 0x80

CTRL, REQ, EFF, TICK, TAKE, STAT, FRAMES, OVR, CNT = 0, 1, 2, 3, 4, 5, 6, 7, 8


class Env:
    def __init__(self, dut):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        self.m = model.Model(CLKS_PER_BIT=CPB, TIMEOUT_CYCLES=TIMEOUT)
        self.cycle = 0
        self.mon_on = False
        self.led_events = []

    async def start(self):
        cocotb.start_soon(Clock(self.clk, 10, "ns").start())
        self.dut.CPU_RESETN.value = 0
        self.dut.UART_TXD_IN.value = 1
        await ClockCycles(self.clk, 4)

    async def reset(self):
        self.dut.CPU_RESETN.value = 0
        self.dut.UART_TXD_IN.value = 1
        await ClockCycles(self.clk, 6)
        self.dut.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 12)
        self.m.reset()

    # ---- UART ----
    async def tx_byte(self, b):
        for bit in [0] + [(b >> i) & 1 for i in range(8)] + [1]:
            self.dut.UART_TXD_IN.value = bit
            await ClockCycles(self.clk, CPB)

    async def rx_byte(self):
        n = 0
        while int(self.dut.UART_RXD_OUT.value) == 1:
            await RisingEdge(self.clk)
            n += 1
            assert n < 5000, "no response from the shell"
        await ClockCycles(self.clk, CPB // 2)
        assert int(self.dut.UART_RXD_OUT.value) == 0, "start bit lost"
        v = 0
        for i in range(8):
            await ClockCycles(self.clk, CPB)
            v |= int(self.dut.UART_RXD_OUT.value) << i
        await ClockCycles(self.clk, CPB)
        assert int(self.dut.UART_RXD_OUT.value) == 1, "stop bit low"
        return v

    async def xact(self, cmd, addr, data=0):
        body = bytes([cmd, addr]) + (data & 0xFFFFFFFF).to_bytes(4, "little")
        chk = 0
        for b in body:
            chk ^= b
        for b in bytes([0xA5]) + body + bytes([chk]):
            await self.tx_byte(b)
        resp = [await self.rx_byte() for _ in range(7)]
        await ClockCycles(self.clk, CPB)
        assert resp[0] == 0x5A, f"bad sync {resp}"
        c = 0
        for b in resp[1:6]:
            c ^= b
        assert c == resp[6], f"bad response checksum {resp}"
        return resp[1], int.from_bytes(bytes(resp[2:6]), "little")

    # ---- model-checked register access ----
    async def write(self, off, val):
        st, _ = await self.xact(2, WIN + off, val)
        assert st == 0, f"write {off} status {st}"
        self.m.write_reg(off, val)
        if off == TICK:
            for _ in range(val & 0xFF):
                self.m.step()

    async def raw_read(self, off):
        st, d = await self.xact(1, WIN + off)
        assert st == 0, f"read {off} status {st}"
        return d

    async def read(self, off):
        d = await self.raw_read(off)
        exp = self.m.read_reg(off)
        assert d == exp, f"reg {off}: dut {d:#x} model {exp:#x}"
        led = int(self.dut.LED.value)
        assert led == self.m.read_reg(FRAMES), f"LED {led:#x} != FRAMES {self.m.read_reg(FRAMES):#x}"
        return d

    async def read_all(self):
        return [await self.read(o) for o in range(9)]

    async def monitor(self):
        last = int(self.dut.LED.value)
        while self.mon_on:
            await RisingEdge(self.clk)
            self.cycle += 1
            v = int(self.dut.LED.value)
            if v != last:
                self.led_events.append((self.cycle, v))
                last = v


async def setup(dut):
    env = Env(dut)
    await env.start()
    await env.reset()
    return env


# req: REQ-01, REQ-15, REQ-16
@cocotb.test()
async def test_reset_values(dut):
    env = await setup(dut)
    vals = await env.read_all()
    # CTRL, REQ, EFF, TICK, TAKE, STAT, FRAMES, OVR, CNT
    assert vals == [0, 100, 100, 0, 0, 0, 0, 0, 0], vals
    assert int(dut.LED.value) == 0
    # build some state, then CPU_RESETN clears everything including the totals
    await env.write(REQ, 10)
    await env.write(CTRL, 1)
    await env.write(TICK, 25)
    vals = await env.read_all()
    assert vals[FRAMES] == 1 and vals[OVR] == 1 and vals[CNT] == 5 and vals[STAT] == 3, vals
    await env.reset()
    vals = await env.read_all()
    assert vals == [0, 100, 100, 0, 0, 0, 0, 0, 0], vals
    assert int(dut.LED.value) == 0


# req: REQ-19, REQ-20
@cocotb.test()
async def test_design_id(dut):
    env = await setup(dut)
    st, d = await env.xact(1, 0x00)
    assert st == 0 and d == 0x544C5031, hex(d)
    assert d.to_bytes(4, "big") == b"TLP1"
    st, d = await env.xact(1, 0x01)
    assert st == 0 and d == 0x00010001


# req: REQ-20, REQ-21, REQ-07, REQ-23
@cocotb.test()
async def test_register_access(dut):
    env = await setup(dut)
    for v in (0x0000, 0xFFFF, 0xA5A5, 0x5A5A, 0x0001, 0x8000, 100):
        await env.write(REQ, v)
        assert await env.read(REQ) == v
        await env.read(EFF)           # disabled: EFF is latched, not live
    await env.write(CTRL, 1)
    assert await env.read(CTRL) == 1
    await env.write(CTRL, 0)
    assert await env.read(CTRL) == 0
    # write-only registers read 0
    await env.write(TAKE, 0xFFFF)
    await env.write(TICK, 0)
    assert await env.read(TAKE) == 0
    assert await env.read(TICK) == 0
    # read-only registers drop writes
    for off in (EFF, STAT, FRAMES, OVR, CNT):
        await env.write(off, 0xFFFF)
    await env.read_all()
    # unmapped window offsets read 0 and drop writes
    for off in (9, 0x10, 0x55, 0x7F):
        st, d = await env.xact(2, WIN + off, 0xFFFFFFFF)
        assert st == 0
        st, d = await env.xact(1, WIN + off)
        assert st == 0 and d == 0, (off, d)
    await env.read_all()
    # PERIOD_MIN default 4 observed through EFF
    await env.write(REQ, 1)
    await env.write(CTRL, 1)
    assert await env.read(EFF) == 4


# req: REQ-03, REQ-04, REQ-05, REQ-15, REQ-16
@cocotb.test()
async def test_enable_disable(dut):
    env = await setup(dut)
    await env.write(REQ, 10)
    await env.write(CTRL, 1)
    await env.write(TICK, 35)        # frames 1, overruns 2, cnt 5
    v = await env.read_all()
    assert v[FRAMES] == 1 and v[OVR] == 2 and v[CNT] == 5 and v[STAT] == 3, v
    await env.write(CTRL, 1)         # already enabled: no restart
    assert await env.read(CNT) == 5
    await env.write(CTRL, 0)         # disable: waiting flag and CNT cleared, totals kept
    v = await env.read_all()
    assert v[FRAMES] == 1 and v[OVR] == 2 and v[CNT] == 0 and v[STAT] == 0, v
    # while disabled ticks leave everything unchanged
    for n in (1, 7, 255):
        await env.write(TICK, n)
        v2 = await env.read_all()
        assert v2 == v, (v2, v)
    # TAKE while disabled changes nothing
    await env.write(TAKE, 1)
    assert await env.read_all() == v
    # enable again: counter set to 0, flag was cleared so a frame is held again
    await env.write(CTRL, 1)
    assert await env.read(CNT) == 0
    await env.write(TICK, 10)
    v = await env.read_all()
    assert v[FRAMES] == 2 and v[OVR] == 2 and v[STAT] == 3, v
    # disable/enable with CNT mid-count: enable restarts at 0
    await env.write(TICK, 4)
    assert await env.read(CNT) == 4
    await env.write(CTRL, 0)
    await env.write(CTRL, 1)
    assert await env.read(CNT) == 0
    await env.read_all()


# req: REQ-06, REQ-07, REQ-08
@cocotb.test()
async def test_period_rules(dut):
    env = await setup(dut)
    for r in (0, 1, 3, 4, 5, 6, 0xFFFF, 100):
        await env.write(CTRL, 0)
        await env.write(REQ, r)
        await env.read(EFF)
        await env.write(CTRL, 1)
        eff = await env.read(EFF)
        assert eff == max(r, 4), (r, eff)
    # REQ write while disabled does not change EFF
    await env.write(CTRL, 0)
    await env.write(REQ, 20)
    assert await env.read(EFF) == 100
    await env.write(CTRL, 1)
    assert await env.read(EFF) == 20
    # REQ write during counting: EFF and the count in progress are untouched until the wrap
    await env.write(TICK, 5)
    await env.write(REQ, 6)
    assert await env.read(EFF) == 20 and await env.read(CNT) == 5
    await env.write(TICK, 14)
    assert await env.read(EFF) == 20 and await env.read(CNT) == 19
    await env.write(TICK, 1)         # wrap: new request loaded
    assert await env.read(EFF) == 6 and await env.read(CNT) == 0
    # request below PERIOD_MIN is raised at the next wrap
    await env.write(REQ, 1)
    assert await env.read(EFF) == 6
    await env.write(TICK, 6)
    assert await env.read(EFF) == 4 and await env.read(CNT) == 0
    await env.write(TICK, 3)
    assert await env.read(CNT) == 3
    await env.write(REQ, 50)
    await env.write(TICK, 1)
    assert await env.read(EFF) == 50
    await env.read_all()


# req: REQ-09, REQ-10, REQ-11, REQ-12
@cocotb.test()
async def test_frame_hold(dut):
    env = await setup(dut)
    await env.write(REQ, 4)
    await env.write(CTRL, 1)
    await env.write(TICK, 3)
    v = await env.read_all()
    assert v[STAT] == 2 and v[FRAMES] == 0
    await env.write(TICK, 1)         # first frame: held
    v = await env.read_all()
    assert v[STAT] == 3 and v[FRAMES] == 1 and v[OVR] == 0, v
    await env.write(TICK, 4)         # frame due while waiting: dropped
    v = await env.read_all()
    assert v[STAT] == 3 and v[FRAMES] == 1 and v[OVR] == 1, v
    await env.write(TICK, 8)
    v = await env.read_all()
    assert v[FRAMES] == 1 and v[OVR] == 3, v
    await env.write(TAKE, 1)         # take clears the flag only
    v2 = await env.read_all()
    assert v2[STAT] == 2 and v2[FRAMES] == 1 and v2[OVR] == 3 and v2[CNT] == v[CNT], v2
    await env.write(TAKE, 1)         # take with flag 0: no register changes
    assert await env.read_all() == v2
    await env.write(TICK, 2)
    await env.write(TAKE, 0)         # take mid-count, flag 0
    v3 = await env.read_all()
    assert v3[CNT] == 2 and v3[STAT] == 2
    await env.write(TICK, 2)         # next frame held again after the take
    v = await env.read_all()
    assert v[STAT] == 3 and v[FRAMES] == 2 and v[OVR] == 3, v
    await env.write(TAKE, 1)
    await env.write(TICK, 4)         # the frame is held after the take
    v = await env.read_all()
    assert v[STAT] == 3 and v[FRAMES] == 3 and v[OVR] == 3, v


# req: REQ-02, REQ-09, REQ-10
@cocotb.test()
async def test_frames_per_100_ticks(dut):
    env = await setup(dut)
    await env.write(CTRL, 1)
    assert await env.read(EFF) == 100
    total = 0
    for i in range(50):
        await env.write(TICK, 200)
        total += 200
        f = await env.read(FRAMES)
        o = await env.read(OVR)
        assert f + o == total // 100, (total, f, o)
        if i % 5 == 4:
            await env.write(TAKE, 1)
    assert total == 10000
    await env.read_all()


# req: REQ-02, REQ-20
@cocotb.test()
async def test_counter_stepwise(dut):
    env = await setup(dut)
    await env.write(REQ, 6)
    await env.write(CTRL, 1)
    for i in range(1, 20):
        await env.write(TICK, 1)
        c = await env.read(CNT)
        assert 0 <= c < 6 and c == i % 6, (i, c)
        if i % 6 == 0:
            f = await env.read(FRAMES)
            o = await env.read(OVR)
            assert f + o == i // 6


# req: REQ-17, REQ-18
@cocotb.test()
async def test_tick_burst_latency(dut):
    env = await setup(dut)

    async def measure(req):
        await env.reset()
        await env.write(REQ, req)
        await env.write(CTRL, 1)
        env.led_events = []
        env.cycle = 0
        env.mon_on = True
        cocotb.start_soon(env.monitor())
        await RisingEdge(env.clk)
        start = env.cycle
        await env.write(TICK, 8)
        env.mon_on = False
        await RisingEdge(env.clk)
        assert [v for _, v in env.led_events] == [1], env.led_events
        await env.read_all()
        return env.led_events[0][0] - start

    ta = await measure(4)    # frame on tick 4
    tb = await measure(8)    # frame on tick 8
    assert tb - ta == 4, (ta, tb)
    # n ticks produce exactly n counts, for boundary n
    await env.reset()
    await env.write(CTRL, 1)
    done = 0
    for n in (0, 1, 2, 255, 0, 3):
        await env.write(TICK, n)
        done += n
        assert await env.read(CNT) == done % 100


# req: REQ-18, REQ-09
@cocotb.test()
async def test_led_follows_frames(dut):
    env = await setup(dut)
    await env.write(REQ, 4)
    await env.write(CTRL, 1)
    for i in range(12):
        await env.write(TICK, 4)
        assert int(dut.LED.value) == i + 1
        assert await env.read(FRAMES) == i + 1
        await env.write(TAKE, 1)
    await env.write(CTRL, 0)
    assert int(dut.LED.value) == 12
    await env.write(CTRL, 1)
    assert int(dut.LED.value) == 12
    await env.read_all()


# req: REQ-14, REQ-16, REQ-10
@cocotb.test()
async def test_overruns_wrap(dut):
    env = await setup(dut)
    await env.write(REQ, 4)
    await env.write(CTRL, 1)
    n = 0
    while env.m.read_reg(OVR) < 65520:
        await env.write(TICK, 255)
        n += 1
        if n % 256 == 0:
            await env.read(OVR)
    for _ in range(24):
        await env.write(TICK, 4)
        await env.read(OVR)
        await env.read(FRAMES)
    assert env.m.read_reg(OVR) < 24
    await env.read_all()


def _candidates(dut, key, depth=2):
    out = []

    def walk(h, d):
        try:
            kids = list(h)
        except Exception:
            return
        for c in kids:
            try:
                nm = c._name.lower() if hasattr(c, "_name") else str(c).lower()
            except Exception:
                continue
            try:
                w = len(c)
            except Exception:
                w = 0
            if key in nm and "over" not in nm and w == 16:
                out.append(c)
            if d > 0:
                walk(c, d - 1)

    walk(dut, depth)
    return out


# req: REQ-13, REQ-15
@cocotb.test()
async def test_frames_wrap(dut):
    env = await setup(dut)
    done = False
    for cand in _candidates(dut, "frames")[:6]:
        await env.reset()
        await env.write(REQ, 4)
        await env.write(CTRL, 1)
        try:
            cand.value = 0xFFFF
        except Exception:
            continue
        await ClockCycles(env.clk, 3)
        if await env.raw_read(FRAMES) != 0xFFFF:
            continue
        done = True
        assert int(dut.LED.value) == 0xFFFF
        await env.xact(2, WIN + TICK, 4)          # frame due, flag 0: FRAMES wraps to 0
        await ClockCycles(env.clk, 300)
        assert await env.raw_read(FRAMES) == 0
        assert await env.raw_read(OVR) == 0
        assert await env.raw_read(STAT) == 3
        assert int(dut.LED.value) == 0
        await env.xact(2, WIN + TAKE, 1)
        await env.xact(2, WIN + TICK, 4)
        await ClockCycles(env.clk, 300)
        assert await env.raw_read(FRAMES) == 1
        break
    if not done:
        dut._log.warning("FRAMES register not reachable for deposit: wrap not checked directly")
        await env.reset()
        await env.write(REQ, 4)
        await env.write(CTRL, 1)
        for _ in range(20):
            await env.write(TICK, 4)
            await env.write(TAKE, 1)
        await env.read_all()


# req: REQ-01, REQ-02, REQ-03, REQ-04, REQ-05, REQ-06, REQ-07, REQ-08, REQ-09, REQ-10, REQ-11, REQ-12, REQ-15, REQ-16, REQ-17, REQ-18, REQ-20, REQ-21
@cocotb.test()
async def test_random_traffic(dut):
    env = await setup(dut)
    rnd = random.Random(getattr(cocotb, "RANDOM_SEED", 1))
    await env.write(REQ, 6)
    await env.write(CTRL, 1)
    for _ in range(170):
        r = rnd.random()
        if r < 0.35:
            await env.write(TICK, rnd.choice([0, 1, 2, 3, 4, 5, 7, 16, 50, 255, rnd.randint(0, 255)]))
        elif r < 0.5:
            await env.write(REQ, rnd.choice([0, 1, 3, 4, 5, 6, 8, 13, 40, 100, 0xFFFF, rnd.randint(0, 300)]))
        elif r < 0.6:
            await env.write(CTRL, rnd.randint(0, 1))
        elif r < 0.7:
            await env.write(TAKE, rnd.getrandbits(8))
        elif r < 0.75:
            await env.write(rnd.choice([EFF, STAT, FRAMES, OVR, CNT, 9, 0x20]), rnd.getrandbits(16))
        else:
            await env.read(rnd.randrange(0, 9))
    await env.read_all()
