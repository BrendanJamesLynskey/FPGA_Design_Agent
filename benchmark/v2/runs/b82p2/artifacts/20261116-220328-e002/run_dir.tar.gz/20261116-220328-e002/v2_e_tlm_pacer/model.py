class Model:
    def __init__(self, PERIOD_MIN=4, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000,
                 BUILD_STAMP=0, PERIOD_RESET=100, DESIGN_ID=1414287409):
        self.PERIOD_MIN = PERIOD_MIN
        self.PERIOD_RESET = PERIOD_RESET
        self.DESIGN_ID = DESIGN_ID
        self.reset()

    def reset(self):
        self.en = 0
        self.req = self.PERIOD_RESET & 0xFFFF
        self.eff = max(self.req, self.PERIOD_MIN) if False else self.PERIOD_RESET & 0xFFFF
        self.cnt = 0
        self.wait = 0
        self.frames = 0
        self.over = 0
        self.pending = 0

    def _load(self):
        self.eff = max(self.req, self.PERIOD_MIN) & 0xFFFF

    def step(self, inputs=None):
        if self.pending > 0:
            self.pending -= 1
            if self.en:
                self.cnt += 1
                if self.cnt >= self.eff:
                    self.cnt = 0
                    self._load()
                    if self.wait:
                        self.over = (self.over + 1) & 0xFFFF
                    else:
                        self.wait = 1
                        self.frames = (self.frames + 1) & 0xFFFF
        return {"UART_RXD_OUT": 1, "LED": self.frames}

    def read_reg(self, offset):
        if offset == 0:
            return self.en
        if offset == 1:
            return self.req
        if offset == 2:
            return self.eff
        if offset == 5:
            return self.wait | (self.en << 1)
        if offset == 6:
            return self.frames
        if offset == 7:
            return self.over
        if offset == 8:
            return self.cnt
        return 0

    def write_reg(self, offset, value):
        if offset == 0:
            new = value & 1
            if new and not self.en:
                self.cnt = 0
                self._load()
            elif self.en and not new:
                self.wait = 0
                self.cnt = 0
            self.en = new
        elif offset == 1:
            self.req = value & 0xFFFF
        elif offset == 3:
            self.pending = value & 0xFF
        elif offset == 4:
            self.wait = 0
