# Architecture: v2_e_tlm_pacer (Telemetry pacer)

## Block diagram

```text
 CPU_RESETN --> [rst_sync xpm_cdc_async_rst] --rst(active high)--+
                                                                 v
 UART_TXD_IN --> [ fpga_shell ] --win_addr/wr/rd/wdata--> [ tlm_pacer_core ]
 UART_RXD_OUT <--[ (UART 115200)] <--win_rdata------------[  CTRL REQ EFF TICK ]
                                                          [  TAKE STAT CNT     ]
                                                          [  FRAMES OVERRUNS   ]
                                                                 |
                                                           frames[15:0] --> LED[15:0]
 CLK100MHZ --> all logic (single domain)
```

tlm_pacer_core: TICK write loads a down-counter that emits n one-clock ticks on the following n clocks. While enabled each tick advances CNT; when CNT reaches EFF it returns to 0 and a frame falls due. EFF is reloaded from max(REQ, PERIOD_MIN) at enable 0 to 1 and at each wrap. A due frame sets the waiting flag and increments FRAMES if the flag is 0 (after any same-clock TAKE), otherwise it increments OVERRUNS. Disable clears the flag and CNT and keeps the totals. Reads return one cycle after win_rd. Window offsets: CTRL 0, REQ 1, EFF 2, TICK 3, TAKE 4, STAT 5, FRAMES 6, OVERRUNS 7, CNT 8. The ID reads 0x544C5031.

## Clock plan

One clock domain, CLK100MHZ at 100 MHz (E3), used directly with no MMCM. CPU_RESETN is asynchronous and is synchronised once by rst_sync into an active-high synchronous reset. All resets are synchronous and the reset clears everything, including the totals. UART_TXD_IN is sampled inside the shell's receiver.

## Pin list

| Port | Dir | Pin | Note |
|---|---|---|---|
| CLK100MHZ | in | E3 | 100 MHz clock |
| CPU_RESETN | in | C12 | active-low reset button |
| UART_TXD_IN | in | C4 | host to FPGA |
| UART_RXD_OUT | out | D4 | FPGA to host |
| LED[15:0] | out | board LEDs | FRAMES total |

Parameters: PERIOD_MIN 4, CLKS_PER_BIT 868, TIMEOUT_CYCLES 100000, DESIGN_ID 0x544C5031, BUILD_STAMP set by the flow.

## Predicted resources

LUT 150 to 450, FF 150 to 380, BRAM 0, DSP 0. Timing is easy at 100 MHz with 16-bit counters.
