class Model:
    def __init__(self, PERIOD_MIN=4, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000,
                 BUILD_STAMP=0, PERIOD_RESET=100):
        self.PERIOD_MIN = PERIOD_MIN
        self.CLKS_PER_BIT = CLKS_PER_BIT
        self.TIMEOUT_CYCLES = TIMEOUT_CYCLES
        self.BUILD_STAMP = BUILD_STAMP
        self.PERIOD_RESET = PERIOD_RESET
        self.inp = {"CPU_RESETN": 1, "UART_TXD_IN": 1}
        self.reset()

    def _eff(self):
        return max(self.req, self.PERIOD_MIN)

    def reset(self):
        self.enable = 0
        self.req = self.PERIOD_RESET & 0xFFFF
        self.eff = self._eff()
        self.pending = 0
        self.frames = 0
        self.overruns = 0
        self.cnt = 0
        self.ticks = 0
        self.take = 0

    def _outputs(self):
        return {"UART_RXD_OUT": 1, "LED": self.frames & 0xFFFF}

    def step(self, inputs=None):
        if inputs:
            self.inp.update(inputs)
        if not self.inp.get("CPU_RESETN", 1):
            self.reset()
            return self._outputs()
        if self.take:
            self.pending = 0
            self.take = 0
        if self.ticks > 0:
            self.ticks -= 1
            if self.enable:
                self.cnt += 1
                if self.cnt >= self.eff:
                    self.cnt = 0
                    self.eff = self._eff()
                    if self.pending:
                        self.overruns = (self.overruns + 1) & 0xFFFF
                    else:
                        self.pending = 1
                        self.frames = (self.frames + 1) & 0xFFFF
        return self._outputs()

    def read_reg(self, offset):
        if offset == 0:
            return self.enable
        if offset == 1:
            return self.req
        if offset == 2:
            return self.eff
        if offset == 5:
            return self.pending | (self.enable << 1)
        if offset == 6:
            return self.frames
        if offset == 7:
            return self.overruns
        if offset == 8:
            return self.cnt
        return 0

    def write_reg(self, offset, value):
        if offset == 0:
            v = value & 1
            if v and not self.enable:
                self.enable = 1
                self.cnt = 0
                self.eff = self._eff()
            elif not v and self.enable:
                self.enable = 0
                self.cnt = 0
                self.pending = 0
        elif offset == 1:
            self.req = value & 0xFFFF
        elif offset == 3:
            self.ticks = value & 0xFF
        elif offset == 4:
            self.take = 1
