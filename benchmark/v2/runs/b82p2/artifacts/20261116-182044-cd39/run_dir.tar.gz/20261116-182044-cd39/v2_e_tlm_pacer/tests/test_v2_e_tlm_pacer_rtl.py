"""Pytest entry: runs the cocotb bench (tests/tlm_pacer_bench.py) on the RTL for each seed."""
import sys
from pathlib import Path

DESIGN = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(DESIGN))
for _p in DESIGN.parents:
    if (_p / "flow").is_dir():
        sys.path.insert(0, str(_p))
        break

from flow import cocotb_run  # noqa: E402

# Same values as CPB / TIMEOUT in tlm_pacer_bench.py (and the model there).
PARAMS = {"CLKS_PER_BIT": 8, "TIMEOUT_CYCLES": 2000}
SEEDS = (1, 2, 3)


def test_v2_e_tlm_pacer_rtl():
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN / "rtl").glob("*.sv"))
    for seed in SEEDS:
        cocotb_run.run(
            "v2_e_tlm_pacer",
            "v2_e_tlm_pacer_top",
            sources,
            "tlm_pacer_bench",
            Path(__file__).resolve().parent,
            parameters=PARAMS,
            seed=seed,
        )
