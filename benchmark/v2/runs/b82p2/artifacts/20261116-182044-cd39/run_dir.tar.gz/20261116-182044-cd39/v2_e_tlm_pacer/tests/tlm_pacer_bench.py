"""cocotb bench for v2_e_tlm_pacer: every check goes through the test shell on the UART and is compared with model.py.

The bench runs the shell with CLKS_PER_BIT = 8 and TIMEOUT_CYCLES = 2000 (the pytest entry passes the same values
to the RTL) so that a register access takes about 1300 clocks instead of 130000.
"""
import os
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ClockCycles, FallingEdge, RisingEdge  # noqa: E402
from cocotb.utils import get_sim_time  # noqa: E402

CPB = 8
TIMEOUT = 2000
M_PARAMS = dict(CLKS_PER_BIT=CPB, TIMEOUT_CYCLES=TIMEOUT)

CTRL, REQ, EFF, TICK, TAKE, STAT, FRAMES, OVERRUNS, CNT = range(9)
WIN = 0x80
DESIGN_ID = 0x544C5031


def _xor(bs):
    r = 0
    for b in bs:
        r ^= b
    return r


class Env:
    def __init__(self, dut):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        self.m = model.Model(**M_PARAMS)
        self.rx = []
        self.eff_valid = True

    async def start(self):
        dut = self.dut
        try:
            c = Clock(dut.CLK100MHZ, 10, unit="ns")
        except TypeError:
            c = Clock(dut.CLK100MHZ, 10, units="ns")
        cocotb.start_soon(c.start())
        dut.UART_TXD_IN.value = 1
        dut.CPU_RESETN.value = 0
        await ClockCycles(self.clk, 8)
        self.m.step({"CPU_RESETN": 0, "UART_TXD_IN": 1})
        dut.CPU_RESETN.value = 1
        self.m.step({"CPU_RESETN": 1})
        await ClockCycles(self.clk, 40)
        self.m.step()
        cocotb.start_soon(self.monitor())
        self.eff_valid = True

    async def reset(self, cycles=6):
        self.dut.CPU_RESETN.value = 0
        await ClockCycles(self.clk, cycles)
        for _ in range(cycles):
            self.m.step({"CPU_RESETN": 0})
        self.dut.CPU_RESETN.value = 1
        self.m.step({"CPU_RESETN": 1})
        await ClockCycles(self.clk, 40)
        self.rx.clear()
        self.eff_valid = True

    async def monitor(self):
        rxd = self.dut.UART_RXD_OUT
        while True:
            await FallingEdge(rxd)
            await ClockCycles(self.clk, CPB // 2)
            if int(rxd.value) != 0:
                continue
            v = 0
            for i in range(8):
                await ClockCycles(self.clk, CPB)
                v |= int(rxd.value) << i
            await ClockCycles(self.clk, CPB)
            self.rx.append(v)

    async def send_byte(self, b):
        bits = [0] + [(b >> i) & 1 for i in range(8)] + [1]
        for bit in bits:
            self.dut.UART_TXD_IN.value = bit
            await ClockCycles(self.clk, CPB)

    async def txn(self, cmd, addr, data=0):
        body = [cmd, addr] + list(data.to_bytes(4, "little"))
        req = [0xA5] + body + [_xor(body)]
        self.rx.clear()
        for b in req:
            await self.send_byte(b)
        for _ in range(600):
            if len(self.rx) >= 7:
                break
            await ClockCycles(self.clk, 16)
        assert len(self.rx) == 7, f"no/short response {self.rx} to {req}"
        resp = list(self.rx[:7])
        self.rx.clear()
        assert resp[0] == 0x5A, f"bad sync {resp}"
        assert _xor(resp[1:6]) == resp[6], f"bad response checksum {resp}"
        await ClockCycles(self.clk, 4 * CPB)
        return resp[1], int.from_bytes(bytes(resp[2:6]), "little")

    async def shell_read(self, addr):
        st, d = await self.txn(1, addr)
        assert st == 0, f"shell read 0x{addr:02X} status {st}"
        return d

    async def wr(self, off, val):
        st, _ = await self.txn(2, WIN + off, val)
        assert st == 0, f"write offset {off} status {st}"
        self.m.write_reg(off, val)
        if off == REQ and not (self.m.enable):
            self.eff_valid = False
        if off == CTRL and (val & 1):
            self.eff_valid = True
        if off == TICK:
            for _ in range(260):
                self.m.step()
        else:
            for _ in range(3):
                self.m.step()

    async def rd(self, off):
        st, d = await self.txn(1, WIN + off)
        assert st == 0, f"read offset {off} status {st}"
        led = int(self.dut.LED.value)
        assert led == self.m.frames, f"LED {led} != frame total {self.m.frames}"
        return d

    async def expect(self, off, lit=None):
        got = await self.rd(off)
        exp = self.m.read_reg(off)
        assert got == exp, f"reg {off}: RTL {got} model {exp}"
        if lit is not None:
            assert got == lit, f"reg {off}: RTL {got} expected literal {lit}"
        return got

    async def snapshot(self):
        regs = [CTRL, REQ, STAT, FRAMES, OVERRUNS, CNT]
        out = {}
        for r in regs:
            out[r] = await self.expect(r)
        if self.eff_valid:
            out[EFF] = await self.expect(EFF)
        return out


async def setup(dut):
    env = Env(dut)
    await env.start()
    return env


# req: REQ-06, REQ-07, REQ-21, REQ-22, REQ-23, REQ-24, REQ-30, REQ-31, REQ-35, REQ-36, REQ-37
@cocotb.test()
async def test_reset_defaults(dut):
    env = await setup(dut)
    lits = {CTRL: 0, REQ: 100, EFF: 100, TICK: 0, TAKE: 0, STAT: 0, FRAMES: 0, OVERRUNS: 0, CNT: 0}
    for off, lit in lits.items():
        await env.expect(off, lit)
    assert int(dut.LED.value) == 0
    # unmapped offsets read 0
    for off in (9, 0x10, 0x7F):
        got = await env.rd(off)
        assert got == 0, f"unmapped {off} reads {got}"


# req: REQ-25, REQ-26
@cocotb.test()
async def test_uart_baud_and_id(dut):
    env = await setup(dut)
    widths = []

    async def measure():
        await FallingEdge(dut.UART_RXD_OUT)
        t0 = get_sim_time("ns")
        await RisingEdge(dut.UART_RXD_OUT)
        widths.append((get_sim_time("ns") - t0) / 10.0)

    cocotb.start_soon(measure())
    body = [1, 0, 0, 0, 0, 0]
    req = [0xA5] + body + [_xor(body)]
    env.rx.clear()
    for b in req:
        await env.send_byte(b)
    for _ in range(600):
        if len(env.rx) >= 7:
            break
        await ClockCycles(env.clk, 16)
    resp = list(env.rx[:7])
    exp_body = [0x00, 0x31, 0x50, 0x4C, 0x54]
    assert resp == [0x5A] + exp_body + [_xor(exp_body)], f"design id response {[hex(x) for x in resp]}"
    # 0x5A LSB first: start 0, bit0 0 => low for two bit times
    assert widths and abs(widths[0] - 2 * CPB) <= 1, f"low pulse {widths} clocks, expected {2 * CPB}"
    await ClockCycles(env.clk, 4 * CPB)
    assert await env.shell_read(0) == DESIGN_ID


# req: REQ-02, REQ-03, REQ-04, REQ-05, REQ-19, REQ-22, REQ-30, REQ-32, REQ-33, REQ-01
@cocotb.test()
async def test_enable_counting(dut):
    env = await setup(dut)
    await env.wr(REQ, 10)
    await env.wr(CTRL, 1)
    await env.expect(STAT, 2)
    await env.expect(CTRL, 1)
    await env.expect(CNT, 0)
    await env.expect(EFF, 10)
    await env.wr(TICK, 3)
    await env.expect(CNT, 3)
    await env.wr(CTRL, 1)  # already enabled: no restart
    await env.expect(CNT, 3)
    await env.expect(STAT, 2)
    await env.wr(TICK, 4)
    await env.expect(CNT, 7)
    await env.wr(TICK, 3)  # wrap: frame due
    await env.expect(CNT, 0)
    await env.expect(FRAMES, 1)
    await env.expect(OVERRUNS, 0)
    await env.expect(STAT, 3)
    await env.wr(TICK, 10)  # second frame while pending: overrun
    await env.expect(CNT, 0)
    await env.expect(FRAMES, 1)
    await env.expect(OVERRUNS, 1)
    await env.wr(TICK, 4)
    await env.expect(CNT, 4)
    # switch off: counter, pending cleared; totals unchanged
    await env.wr(CTRL, 0)
    await env.expect(CNT, 0)
    await env.expect(STAT, 0)
    await env.expect(FRAMES, 1)
    await env.expect(OVERRUNS, 1)
    await env.expect(CTRL, 0)
    # stopped: ticks do not count
    await env.wr(TICK, 5)
    await env.expect(CNT, 0)
    await env.expect(FRAMES, 1)
    # switch on again from zero, totals survive
    await env.wr(CTRL, 1)
    await env.expect(CNT, 0)
    await env.expect(STAT, 2)
    await env.expect(FRAMES, 1)
    await env.expect(OVERRUNS, 1)
    await env.wr(TICK, 2)
    await env.expect(CNT, 2)
    # switch off while counting with pending set and totals non-zero
    await env.wr(TICK, 8)
    await env.expect(STAT, 3)
    await env.expect(FRAMES, 2)
    await env.wr(CTRL, 0)
    await env.expect(STAT, 0)
    await env.expect(FRAMES, 2)
    await env.expect(CNT, 0)
    # off while already off does nothing
    await env.wr(CTRL, 0)
    await env.expect(CNT, 0)
    await env.expect(FRAMES, 2)
    await env.expect(OVERRUNS, 1)


# req: REQ-08, REQ-09, REQ-10, REQ-11, REQ-06
@cocotb.test()
async def test_period_changes(dut):
    env = await setup(dut)
    # below PERIOD_MIN -> EFF = 4, REQ reads as written
    await env.wr(REQ, 3)
    await env.expect(REQ, 3)
    await env.wr(CTRL, 1)
    await env.expect(EFF, 4)
    await env.wr(TICK, 3)
    await env.expect(CNT, 3)
    await env.expect(FRAMES, 0)
    await env.wr(TICK, 1)
    await env.expect(CNT, 0)
    await env.expect(FRAMES, 1)
    await env.wr(CTRL, 0)
    # REQ = 0 -> 4
    await env.wr(REQ, 0)
    await env.wr(CTRL, 1)
    await env.expect(EFF, 4)
    await env.wr(CTRL, 0)
    # boundary: REQ = PERIOD_MIN
    await env.wr(REQ, 4)
    await env.wr(CTRL, 1)
    await env.expect(EFF, 4)
    await env.wr(CTRL, 0)
    # REQ = PERIOD_MIN + 1
    await env.wr(REQ, 5)
    await env.wr(CTRL, 1)
    await env.expect(EFF, 5)
    await env.wr(TICK, 4)
    await env.expect(CNT, 4)
    await env.wr(TICK, 1)
    await env.expect(CNT, 0)
    await env.wr(CTRL, 0)
    # large REQ
    await env.wr(REQ, 0xFFFF)
    await env.wr(CTRL, 1)
    await env.expect(EFF, 0xFFFF)
    await env.wr(CTRL, 0)
    # change while counting is not seen until the wrap
    await env.wr(REQ, 6)
    await env.wr(CTRL, 1)
    await env.expect(EFF, 6)
    await env.wr(TICK, 2)
    await env.wr(REQ, 10)
    await env.expect(REQ, 10)
    await env.expect(EFF, 6)
    await env.wr(TICK, 3)
    await env.expect(EFF, 6)
    await env.expect(CNT, 5)
    await env.wr(TICK, 1)
    await env.expect(CNT, 0)
    await env.expect(EFF, 10)
    await env.wr(TICK, 9)
    await env.expect(CNT, 9)
    await env.wr(TICK, 1)
    await env.expect(CNT, 0)
    # request below minimum while counting applies at the wrap as 4
    await env.wr(REQ, 1)
    await env.expect(EFF, 10)
    await env.wr(TICK, 10)
    await env.expect(EFF, 4)
    await env.expect(CNT, 0)
    await env.wr(TICK, 3)
    await env.expect(CNT, 3)
    await env.wr(TICK, 1)
    await env.expect(CNT, 0)


# req: REQ-12, REQ-13, REQ-14, REQ-15, REQ-16, REQ-22, REQ-34, REQ-38
@cocotb.test()
async def test_pending_and_take(dut):
    env = await setup(dut)
    await env.wr(REQ, 4)
    await env.wr(CTRL, 1)
    await env.wr(TICK, 4)
    await env.expect(FRAMES, 1)
    await env.expect(STAT, 3)
    await env.wr(TICK, 4)  # due while pending: overrun, frame total unchanged
    await env.expect(FRAMES, 1)
    await env.expect(OVERRUNS, 1)
    await env.expect(STAT, 3)
    await env.wr(TICK, 8)
    await env.expect(FRAMES, 1)
    await env.expect(OVERRUNS, 3)
    await env.wr(TAKE, 0)
    await env.expect(STAT, 2)
    await env.expect(FRAMES, 3 - 2)
    # TAKE with nothing pending changes no state
    await env.wr(TICK, 2)
    before = await env.snapshot()
    await env.wr(TAKE, 1)
    after = await env.snapshot()
    assert before == after, f"TAKE with nothing pending changed state {before} -> {after}"
    # next due frame after a take is held (take applied first, new frame held)
    await env.wr(TICK, 2)
    await env.expect(FRAMES, 2)
    await env.expect(STAT, 3)
    await env.expect(OVERRUNS, 3)
    await env.wr(TAKE, 0xFFFF)
    await env.expect(STAT, 2)
    # take just before a frame falls due: held afterwards
    await env.wr(TICK, 3)
    await env.wr(TAKE, 0)
    await env.wr(TICK, 1)
    await env.expect(STAT, 3)
    await env.expect(FRAMES, 3)
    await env.expect(CNT, 0)


# req: REQ-20, REQ-03
@cocotb.test()
async def test_tick_register(dut):
    env = await setup(dut)
    await env.wr(TICK, 7)  # disabled: no counting
    await env.expect(CNT, 0)
    await env.wr(REQ, 300)
    await env.wr(CTRL, 1)
    await env.expect(EFF, 300)
    await env.wr(TICK, 0)
    await env.expect(CNT, 0)
    await env.wr(TICK, 1)
    await env.expect(CNT, 1)
    await env.wr(TICK, 0)
    await env.expect(CNT, 1)
    await env.wr(TICK, 2)
    await env.expect(CNT, 3)
    await env.wr(TICK, 255)
    await env.expect(CNT, 258)
    await env.wr(TICK, 41)
    await env.expect(CNT, 299)
    await env.expect(FRAMES, 0)
    await env.wr(TICK, 1)
    await env.expect(CNT, 0)
    await env.expect(FRAMES, 1)
    await env.wr(TICK, 128)
    await env.expect(CNT, 128)


# req: REQ-01, REQ-20, REQ-23, REQ-14, REQ-13
@cocotb.test()
async def test_period_100_10000_ticks(dut):
    env = await setup(dut)
    await env.expect(EFF, 100)
    await env.wr(CTRL, 1)
    total = 0
    for i in range(40):
        await env.wr(TAKE, 0)
        await env.wr(TICK, 250)
        total += 250
        assert int(dut.LED.value) == env.m.frames
        assert env.m.frames == i + 1
    assert total == 10000
    frames = await env.expect(FRAMES, 40)
    over = await env.expect(OVERRUNS)
    assert frames + over == 100, f"frames due {frames + over} != 100 over 10000 ticks"
    await env.expect(CNT, 0)
    await env.expect(STAT, 3)


# req: REQ-17, REQ-28, REQ-23
@cocotb.test()
async def test_frames_total_width(dut):
    # A frame needs a TAKE (one shell access) before the next can be held, so wrapping 65536 frames is out of
    # reach of the shell in simulation; the total is compared with the model up to 260 frames (past the 8-bit
    # boundary) with LED checked after every frame.
    env = await setup(dut)
    await env.wr(REQ, 4)
    await env.wr(CTRL, 1)
    for i in range(260):
        await env.wr(TICK, 4)
        assert int(dut.LED.value) == env.m.frames == i + 1, f"LED {int(dut.LED.value)} at frame {i + 1}"
        await env.wr(TAKE, 0)
    await env.expect(FRAMES, 260)
    await env.expect(OVERRUNS, 0)
    await env.expect(STAT, 2)


# req: REQ-18, REQ-29, REQ-13
@cocotb.test()
async def test_overrun_total_wrap(dut):
    env = await setup(dut)
    await env.wr(REQ, 4)
    await env.wr(CTRL, 1)
    await env.wr(TICK, 4)  # frame held, pending stays set from here
    await env.expect(FRAMES, 1)
    guard = 0
    while env.m.overruns < 65400:
        await env.wr(TICK, 255)
        assert int(dut.LED.value) == 1
        guard += 1
        assert guard < 1500
    await env.expect(OVERRUNS)
    while env.m.overruns < 65530:
        await env.wr(TICK, 4)
        guard += 1
        assert guard < 2000
    while env.m.overruns < 65535:
        await env.wr(TICK, 1)
    await env.expect(OVERRUNS, 65535)
    await env.expect(FRAMES, 1)
    await env.wr(TICK, 4)  # one more overrun: wraps to 0
    await env.expect(OVERRUNS, 0)
    await env.expect(FRAMES, 1)
    await env.expect(STAT, 3)
    await env.wr(TICK, 4)
    await env.expect(OVERRUNS, 1)


# req: REQ-19, REQ-24, REQ-31, REQ-35, REQ-36, REQ-37, REQ-06, REQ-07
@cocotb.test()
async def test_reset_clears(dut):
    env = await setup(dut)
    await env.wr(REQ, 7)
    await env.wr(CTRL, 1)
    await env.wr(TICK, 24)
    await env.expect(FRAMES, 1)
    await env.expect(OVERRUNS, 2)
    await env.expect(CNT, 3)
    await env.expect(STAT, 3)
    await env.expect(EFF, 7)
    await env.reset()
    for off, lit in {CTRL: 0, REQ: 100, EFF: 100, STAT: 0, FRAMES: 0, OVERRUNS: 0, CNT: 0}.items():
        await env.expect(off, lit)
    assert int(dut.LED.value) == 0
    # disabled after reset: ticks do not count
    await env.wr(TICK, 5)
    await env.expect(CNT, 0)
    # totals survive switch-off but not reset
    await env.wr(REQ, 4)
    await env.wr(CTRL, 1)
    await env.wr(TICK, 8)
    await env.expect(FRAMES, 1)
    await env.expect(OVERRUNS, 1)
    await env.wr(CTRL, 0)
    await env.expect(FRAMES, 1)
    await env.expect(OVERRUNS, 1)
    await env.reset(2)
    await env.expect(FRAMES, 0)
    await env.expect(OVERRUNS, 0)
    await env.expect(REQ, 100)
    await env.expect(EFF, 100)


# req: REQ-21, REQ-22
@cocotb.test()
async def test_ro_and_unmapped(dut):
    env = await setup(dut)
    await env.wr(REQ, 6)
    await env.wr(CTRL, 1)
    await env.wr(TICK, 8)
    snap = await env.snapshot()
    # writes to read-only and unmapped registers are dropped
    for off, val in ((EFF, 77), (STAT, 0), (FRAMES, 5), (OVERRUNS, 9), (CNT, 4), (9, 3), (0x20, 0x55), (0x7F, 1)):
        st, _ = await env.txn(2, WIN + off, val)
        assert st == 0, f"window write {off} status {st}"
    snap2 = await env.snapshot()
    assert snap == snap2, f"read-only write changed state {snap} -> {snap2}"
    for off in (TICK, TAKE, 9, 0x20, 0x7F):
        assert await env.rd(off) == 0


# req: REQ-01, REQ-02, REQ-03, REQ-04, REQ-05, REQ-08, REQ-09, REQ-11, REQ-13, REQ-14, REQ-15, REQ-16, REQ-19, REQ-20, REQ-21, REQ-22, REQ-23, REQ-30, REQ-32, REQ-33, REQ-34, REQ-38
@cocotb.test()
async def test_random_traffic(dut):
    seed = getattr(cocotb, "RANDOM_SEED", 1)
    rng = random.Random(seed)
    env = await setup(dut)
    reqs = [0, 1, 3, 4, 5, 6, 8, 13, 100]
    ticks = [0, 1, 2, 3, 5, 7, 20, 40, 255]
    ro = [EFF, STAT, FRAMES, OVERRUNS, CNT, 9, 0x40]
    for _ in range(110):
        op = rng.choices(["en", "dis", "req", "tick", "take", "ro"], weights=[2, 2, 3, 8, 3, 1])[0]
        if op == "en":
            await env.wr(CTRL, 1)
        elif op == "dis":
            await env.wr(CTRL, 0)
        elif op == "req":
            await env.wr(REQ, rng.choice(reqs))
        elif op == "tick":
            await env.wr(TICK, rng.choice(ticks))
        elif op == "take":
            await env.wr(TAKE, rng.getrandbits(8))
        else:
            off = rng.choice(ro)
            st, _ = await env.txn(2, WIN + off, rng.getrandbits(16))
            assert st == 0
            env.m.write_reg(off, 0)  # model ignores; keeps lockstep
        for off in rng.sample([CTRL, STAT, FRAMES, OVERRUNS, CNT], 3):
            await env.expect(off)
        if env.eff_valid and rng.random() < 0.5:
            await env.expect(EFF)
    await env.snapshot()
