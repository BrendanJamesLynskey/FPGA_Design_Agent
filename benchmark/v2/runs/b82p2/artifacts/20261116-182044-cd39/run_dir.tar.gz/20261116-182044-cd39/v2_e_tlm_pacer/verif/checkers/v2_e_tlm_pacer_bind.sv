// Binds the port-only checker onto the top module.
bind v2_e_tlm_pacer_top v2_e_tlm_pacer_checker u_chk (
    .clk(CLK100MHZ),
    .rst(~CPU_RESETN),
    .led(LED),
    .txd(UART_RXD_OUT),
    .rxd(UART_TXD_IN)
);
