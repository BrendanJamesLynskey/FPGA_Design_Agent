# v2_e_tlm_pacer architecture

A telemetry pacer: while enabled, a counter advances on each tick and wraps at the period in force. Each wrap makes a frame fall due. At most one frame waits. The registers are reached through the `fpga_shell` UART window.

## Block diagram

```text
 CPU_RESETN --> [rst_sync] --rst--+
                                  v
 UART_TXD_IN --> [ fpga_shell ] <-win_*-> [ pacer_core ] --> LED[15:0]
 UART_RXD_OUT <--[            ]            |  CTRL REQ EFF TICK TAKE
                                           |  STAT FRAMES OVERRUNS CNT
 CLK100MHZ ---------------- all registers (single domain)
```

Core: TICK write of n loads a down counter and emits one tick pulse per clock for n clocks. While enabled, each tick increments CNT. When CNT+1 reaches EFF, CNT returns to 0 and a frame falls due. A TAKE write clears pending first, then the due frame sets pending and FRAMES increments. If pending is still set, OVERRUNS increments instead. EFF = max(REQ, PERIOD_MIN), latched at switch-on and at each wrap. Disabling clears CNT and pending and leaves the totals alone. Only reset clears the totals.

## Clock plan

One domain: CLK100MHZ at 100 MHz, with no MMCM. CPU_RESETN is the only asynchronous input. It passes through a two-flop synchroniser (asynchronous assert, synchronous release) and is active high inside the design. The UART RX input goes to the shell, which synchronises it.

## Pin list

| Port | Dir | Board resource |
|---|---|---|
| CLK100MHZ | in | 100 MHz clock |
| CPU_RESETN | in | CPU RESET button, active low |
| UART_TXD_IN | in | USB-UART host to FPGA |
| UART_RXD_OUT | out | USB-UART FPGA to host |
| LED[15:0] | out | LEDs, frame total |

## Resources

About 150 to 450 LUTs, 150 to 400 FFs, 0 BRAM, 0 DSP.
