// Port-only checker for v2_e_tlm_pacer_top: cover points on the visible activity.
`include "v_macros.svh"

module v2_e_tlm_pacer_checker (
    input wire        clk,
    input wire        rst,
    input wire [15:0] led,
    input wire        txd,
    input wire        rxd
);
    reg seen_rst = 1'b0;
    reg past_ok  = 1'b0;
    always @(posedge clk) begin
        past_ok <= 1'b1;
        if (rst) seen_rst <= 1'b1;
    end

    `V_COVER(C_led_nonzero, led != 16'h0000)  // req: REQ-23
    `V_COVER(C_uart_rx_active, rxd == 1'b0)   // req: REQ-25
    `V_COVER(C_uart_tx_active, txd == 1'b0)   // req: REQ-25
endmodule
