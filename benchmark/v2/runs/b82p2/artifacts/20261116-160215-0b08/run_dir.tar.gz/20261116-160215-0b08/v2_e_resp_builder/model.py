import zlib


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000, BUILD_STAMP=0,
                 MAX_PAYLOAD=24, BUILD_MAX_CYCLES=64, DESIGN_ID=1381188145):
        self.maxp = MAX_PAYLOAD
        self.reset()

    def reset(self):
        self.type = 0
        self.status = 0
        self.seq = 0
        self.payload = []
        self.overflow = 0
        self.building = 0
        self.cnt = 0
        self.pending = []
        self.reply = []
        self.idx = 0
        self.rst_n = 1

    def step(self, inputs=None):
        inputs = inputs or {}
        if "CPU_RESETN" in inputs:
            self.rst_n = inputs["CPU_RESETN"] & 1
        if not self.rst_n:
            self.reset()
            self.rst_n = 0
        elif self.building:
            self.cnt -= 1
            if self.cnt <= 0:
                self.reply = self.pending
                self.building = 0
                self.payload = []
                self.overflow = 0
        return {"UART_RXD_OUT": 1, "LED": self._led()}

    def _led(self):
        if not self.reply:
            return 0
        return (len(self.reply) & 0xFF) | (self.reply[1] << 8)

    def write_reg(self, offset, value):
        if offset == 0:
            self.type = value & 0x7F
        elif offset == 1:
            self.status = value & 0xFF
        elif offset == 2:
            self.seq = value & 0xFFFF
        elif offset == 3:
            if self.building:
                return
            if len(self.payload) < self.maxp:
                self.payload.append(value & 0xFF)
            else:
                self.overflow = 1
        elif offset == 4:
            if self.building:
                return
            b = [0x80 | self.type, self.status, self.seq >> 8, self.seq & 0xFF,
                 len(self.payload)] + list(self.payload)
            c = zlib.crc32(bytes(b)) & 0xFFFFFFFF
            b += [(c >> (8 * i)) & 0xFF for i in range(4)]
            self.pending = b
            self.building = 1
            self.cnt = len(b)
        elif offset == 5:
            self.idx = value & 0xFF

    def read_reg(self, offset):
        if offset == 0:
            return self.type
        if offset == 1:
            return self.status
        if offset == 2:
            return self.seq
        if offset == 5:
            return self.idx
        if offset == 6:
            return self.reply[self.idx] if self.idx < len(self.reply) else 0
        if offset == 7:
            return len(self.reply)
        if offset == 8:
            return self.building | (self.overflow << 1)
        if offset == 9:
            return len(self.payload)
        return 0
