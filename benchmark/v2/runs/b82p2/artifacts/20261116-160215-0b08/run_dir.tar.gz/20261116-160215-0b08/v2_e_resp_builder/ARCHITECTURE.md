# v2_e_resp_builder architecture

Reply frame builder: host writes TYPE, STATUS, SEQ and up to 24 payload bytes through the test-shell register window. A BUILD write assembles a 9..33 byte reply with a zlib CRC-32, read back through IDX/BYTE.

## Block diagram

```text
 UART_TXD_IN --> [fpga_shell] --win_*--> [regs: TYPE STATUS SEQ IDX, payload 24B, PLEN, STAT]
 UART_RXD_OUT <-- [fpga_shell] <--rdata--     |  BUILD write (capture)
                                              v
 CPU_RESETN --> [reset_sync 2ff] --rst--> [builder: byte-serial CRC-32] --> [reply store 33B + LEN]
                                                                              |-> BYTE read (IDX)
                                                                              '-> LED[7:0]=LEN, LED[15:8]=status
```

## Clock plan

One clock domain: CLK100MHZ (100 MHz, 10 ns), no MMCM. CPU_RESETN is asynchronous and active low; it passes through a two-flop synchroniser (async assert is not needed, synchronous release) and is inverted once into an active-high synchronous reset used by all registers. UART_TXD_IN is synchronised by the shell.

Build timing: header 5 bytes, payload N bytes, CRC 4 bytes, one byte per clock, so at most 33 clocks plus setup, under the 64-clock limit. The reply store is replaced only at completion, so the previous reply stays readable.

## Register map (window offsets)

0 TYPE RW[6:0], 1 STATUS RW, 2 SEQ RW[15:0], 3 PBYTE WO, 4 BUILD WO, 5 IDX RW[7:0], 6 BYTE RO, 7 LEN RO, 8 STAT RO (bit0 building, bit1 overflow), 9 PLEN RO. Others read 0. DESIGN_ID 0x52534231 via the shell.

## Pin list

| Port | Dir | Board resource |
|---|---|---|
| CLK100MHZ | in | 100 MHz clock |
| CPU_RESETN | in | CPU RESET button, active low |
| UART_TXD_IN | in | USB-UART from host |
| UART_RXD_OUT | out | USB-UART to host |
| LED[15:0] | out | LEDs: [7:0] length, [15:8] status |

## Resource prediction

LUT 350-900, FF 450-900 (reply store 264 FF, payload 192 FF, CRC 32, shell UART), BRAM 0, DSP 0.
