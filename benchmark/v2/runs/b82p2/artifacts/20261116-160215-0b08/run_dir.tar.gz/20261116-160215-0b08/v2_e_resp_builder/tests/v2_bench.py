"""cocotb bench for v2_e_resp_builder: every access goes through the shell UART (window 0x80+offset)
and is compared with model.Model (blind reference), plus independent zlib checks of the reply."""
import random
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ClockCycles, RisingEdge  # noqa: E402

CPB = 8          # CLKS_PER_BIT used in the bench (flow passes the same value)
TMO = 2000       # TIMEOUT_CYCLES
WIN = 0x80
DESIGN_ID = 0x52534231


def mk_model():
    return model.Model(CLKS_PER_BIT=CPB, TIMEOUT_CYCLES=TMO)


class Bench:
    def __init__(self, dut):
        self.dut = dut
        self.m = mk_model()
        self.first_low = None

    async def start(self):
        d = self.dut
        cocotb.start_soon(Clock(d.CLK100MHZ, 10, "ns").start())
        d.UART_TXD_IN.value = 1
        await self.reset()

    async def reset(self):
        d = self.dut
        d.CPU_RESETN.value = 0
        await ClockCycles(d.CLK100MHZ, 6)
        self.m.step({"CPU_RESETN": 0})
        d.CPU_RESETN.value = 1
        self.m.step({"CPU_RESETN": 1})
        await ClockCycles(d.CLK100MHZ, 8)

    # ---- UART ----
    async def send_byte(self, b):
        d = self.dut
        for bit in [0] + [(b >> i) & 1 for i in range(8)] + [1]:
            d.UART_TXD_IN.value = bit
            await ClockCycles(d.CLK100MHZ, CPB)

    async def recv_byte(self):
        d = self.dut
        n = 0
        while int(d.UART_RXD_OUT.value) != 0:
            await RisingEdge(d.CLK100MHZ)
            n += 1
            assert n < 6000, "no response start bit"
        samples = [0]
        for _ in range(10 * CPB - 1):
            await RisingEdge(d.CLK100MHZ)
            samples.append(int(d.UART_RXD_OUT.value))
        lead = 0
        while lead < len(samples) and samples[lead] == 0:
            lead += 1
        self.first_low = lead
        assert samples[CPB // 2] == 0, "start bit"
        v = 0
        for i in range(8):
            v |= samples[(i + 1) * CPB + CPB // 2] << i
        assert samples[9 * CPB + CPB // 2] == 1, "stop bit"
        return v

    async def txn(self, cmd, addr, data=0):
        body = [cmd, addr] + list(data.to_bytes(4, "little"))
        chk = 0
        for x in body:
            chk ^= x
        for b in [0xA5] + body + [chk]:
            await self.send_byte(b)
        resp = []
        for _ in range(7):
            resp.append(await self.recv_byte())
        x = 0
        for v in resp[1:6]:
            x ^= v
        assert resp[0] == 0x5A, f"resp sync {resp}"
        assert x == resp[6], f"resp chk {resp}"
        assert resp[1] == 0, f"shell status {resp[1]} for cmd {cmd:#x} addr {addr:#x}"
        return int.from_bytes(bytes(resp[2:6]), "little")

    # ---- register access with model compare ----
    async def wr(self, off, val):
        await self.txn(2, WIN + off, val & 0xFFFFFFFF)
        self.m.write_reg(off, val & 0xFFFFFFFF)
        if off == 4:
            for _ in range(70):
                self.m.step()

    async def rd(self, off):
        got = await self.txn(1, WIN + off)
        exp = self.m.read_reg(off)
        assert got == exp, f"read off {off:#x}: rtl {got:#x} model {exp:#x}"
        return got

    def check_led(self):
        exp = self.m.step()["LED"]
        got = int(self.dut.LED.value)
        assert got == exp, f"LED rtl {got:#x} model {exp:#x}"
        return got

    async def read_reply(self):
        n = await self.rd(7)
        out = []
        for i in range(n):
            await self.wr(5, i)
            out.append(await self.rd(6))
        await self.wr(5, n)
        assert await self.rd(6) == 0
        self.check_led()
        return out

    async def all_regs(self):
        for off in range(0, 10):
            await self.rd(off)
        self.check_led()


def check_reply(rep, typ, status, seq, payload):
    exp = [0x80 | (typ & 0x7F), status & 0xFF, (seq >> 8) & 0xFF, seq & 0xFF, len(payload)] + list(payload)
    c = zlib.crc32(bytes(exp)) & 0xFFFFFFFF
    exp += [(c >> (8 * i)) & 0xFF for i in range(4)]
    assert len(rep) == 9 + len(payload), f"len {len(rep)}"
    assert list(rep) == exp, f"reply {bytes(rep).hex()} expected {bytes(exp).hex()}"


async def new_bench(dut):
    b = Bench(dut)
    await b.start()
    return b


async def build_and_check(b, typ, status, seq, payload):
    await b.wr(0, typ)
    await b.wr(1, status)
    await b.wr(2, seq)
    for p in payload:
        await b.wr(3, p)
    assert await b.rd(9) == len(payload)
    await b.wr(4, 1)
    assert await b.rd(8) == 0
    assert await b.rd(9) == 0
    rep = await b.read_reply()
    check_reply(rep, typ, status, seq, payload)
    assert await b.rd(7) == 9 + len(payload)
    return rep


# req: REQ-16, REQ-19c, REQ-20, REQ-18, REQ-12
@cocotb.test()
async def test_reset_smoke(dut):
    b = await new_bench(dut)
    await b.all_regs()
    assert int(dut.LED.value) == 0
    assert await b.rd(7) == 0
    assert await b.rd(6) == 0
    assert int(dut.UART_RXD_OUT.value) == 1


# req: REQ-21
@cocotb.test()
async def test_design_id(dut):
    b = await new_bench(dut)
    got = await b.txn(1, 0x00)
    assert got == DESIGN_ID, hex(got)


# req: REQ-22
@cocotb.test()
async def test_uart_baud(dut):
    b = await new_bench(dut)
    # raw request: read SHELL_VERSION; response starts 0x5A = start bit + bit0 both low
    await b.send_byte(0xA5)
    for x in (0x01, 0x01, 0x00, 0, 0, 0):
        await b.send_byte(x)
    await b.send_byte(0x00)
    await b.recv_byte()
    assert b.first_low == 2 * CPB, f"start+bit0 low {b.first_low} cycles, expected {2 * CPB}"
    for _ in range(6):
        await b.recv_byte()


# req: REQ-07, REQ-07b, REQ-08, REQ-08b, REQ-20
@cocotb.test()
async def test_config_regs(dut):
    b = await new_bench(dut)
    for off, val in ((0, 0xFF), (1, 0x1FF), (2, 0x12345), (0, 0x03), (1, 0xA5), (2, 0xBEEF)):
        await b.wr(off, val)
        await b.rd(off)
    assert await b.rd(0) == 0x03
    assert await b.rd(1) == 0xA5
    assert await b.rd(2) == 0xBEEF
    await b.wr(0, 0x80)
    assert await b.rd(0) == 0
    await b.wr(0, 0x7F)
    assert await b.rd(0) == 0x7F
    # values hold while other registers and payload are written
    await b.wr(3, 1)
    await b.wr(5, 0x55)
    await b.all_regs()
    assert await b.rd(0) == 0x7F and await b.rd(1) == 0xA5 and await b.rd(2) == 0xBEEF


# req: REQ-01, REQ-02, REQ-03, REQ-04, REQ-06, REQ-17, REQ-19, REQ-19b, REQ-12, REQ-12b, REQ-11b
@cocotb.test()
async def test_build_empty(dut):
    b = await new_bench(dut)
    await b.wr(0, 3)
    await b.wr(1, 0x5A)
    await b.wr(2, 0x1234)
    await b.wr(4, 0)
    assert await b.rd(8) == 0
    rep = await b.read_reply()
    check_reply(rep, 3, 0x5A, 0x1234, [])
    assert rep[0] == 0x83
    assert int(dut.LED.value) == (0x5A << 8) | 9
    await b.reset()
    await build_and_check(b, 0, 0, 0, [])
    assert int(dut.LED.value) == 9
    await build_and_check(b, 0xFF, 0xFF, 0xFFFF, [])
    assert int(dut.LED.value) == (0xFF << 8) | 9


# req: REQ-04, REQ-05, REQ-06, REQ-09, REQ-17, REQ-18, REQ-12, REQ-12b, REQ-11b
@cocotb.test()
async def test_build_payload(dut):
    b = await new_bench(dut)
    await build_and_check(b, 0x41, 0x01, 0x00FF, [0xDE])
    await build_and_check(b, 0x7E, 0x80, 0xFF00, [i * 7 & 0xFF for i in range(5)])
    # wide PBYTE value keeps low byte only
    await b.wr(3, 0x1234)
    await b.wr(3, 0x00)
    await b.wr(4, 1)
    rep = await b.read_reply()
    assert rep[5:7] == [0x34, 0x00]


# req: REQ-09, REQ-10, REQ-10b, REQ-04, REQ-05, REQ-06, REQ-12, REQ-12b, REQ-17, REQ-18
@cocotb.test()
async def test_payload_full_overflow(dut):
    b = await new_bench(dut)
    pl = [(0x11 * (i + 1)) & 0xFF for i in range(24)]
    await b.wr(0, 9)
    await b.wr(1, 0xC3)
    await b.wr(2, 0xA55A)
    for p in pl:
        await b.wr(3, p)
    assert await b.rd(9) == 24
    assert await b.rd(8) == 0
    await b.wr(3, 0xEE)  # overflow
    assert await b.rd(9) == 24
    assert await b.rd(8) == 2
    await b.wr(3, 0xEF)
    assert await b.rd(9) == 24
    assert await b.rd(8) == 2
    await b.wr(4, 1)
    assert await b.rd(8) == 0
    assert await b.rd(9) == 0
    rep = await b.read_reply()
    check_reply(rep, 9, 0xC3, 0xA55A, pl)
    assert len(rep) == 33
    assert await b.rd(7) == 33
    assert int(dut.LED.value) == (0xC3 << 8) | 33
    # payload is accepted again after completion
    await b.wr(3, 0x77)
    assert await b.rd(9) == 1


# req: REQ-13, REQ-03, REQ-08b, REQ-12, REQ-19, REQ-19b, REQ-17
@cocotb.test()
async def test_reply_hold(dut):
    b = await new_bench(dut)
    rep1 = await build_and_check(b, 5, 0x11, 0x2222, [1, 2, 3])
    led1 = int(dut.LED.value)
    # change everything but do not build: reply and LED stay
    await b.wr(0, 0x66)
    await b.wr(1, 0x99)
    await b.wr(2, 0x4321)
    for p in (9, 8, 7, 6):
        await b.wr(3, p)
    rep = await b.read_reply()
    assert rep == rep1
    assert int(dut.LED.value) == led1
    await b.wr(4, 1)
    rep2 = await b.read_reply()
    check_reply(rep2, 0x66, 0x99, 0x4321, [9, 8, 7, 6])
    assert int(dut.LED.value) == (0x99 << 8) | 13
    # a build of fewer bytes replaces a longer reply entirely
    await b.wr(4, 1)
    rep3 = await b.read_reply()
    check_reply(rep3, 0x66, 0x99, 0x4321, [])
    assert await b.rd(6) == 0


# req: REQ-14, REQ-15, REQ-17, REQ-06
@cocotb.test()
async def test_idx_readback(dut):
    b = await new_bench(dut)
    # before any build every index reads 0
    for i in (0, 1, 0xFF):
        await b.wr(5, i)
        assert await b.rd(6) == 0
    rep = await build_and_check(b, 2, 3, 4, [0xAA, 0xBB])
    n = len(rep)
    for i in (n - 1, n, n + 1, 0x7F, 0x80, 0xFF, 0x100 + 2):
        await b.wr(5, i)
        assert await b.rd(5) == i & 0xFF
        exp = rep[i & 0xFF] if (i & 0xFF) < n else 0
        assert await b.rd(6) == exp
    await b.wr(5, 0)
    assert await b.rd(6) == 0x82
    await b.wr(5, 0x1FF)
    assert await b.rd(5) == 0xFF


# req: REQ-20, REQ-16, REQ-19c, REQ-12, REQ-12b
@cocotb.test()
async def test_reset_clears(dut):
    b = await new_bench(dut)
    await build_and_check(b, 0x21, 0x32, 0x4321, [1, 2])
    assert int(dut.LED.value) != 0
    await b.wr(0, 0x55)
    await b.wr(1, 0x66)
    await b.wr(2, 0x7788)
    await b.wr(5, 3)
    for i in range(25):  # overflow + full payload
        await b.wr(3, i)
    assert await b.rd(8) == 2
    await b.reset()
    await b.all_regs()
    assert int(dut.LED.value) == 0
    assert await b.rd(7) == 0 and await b.rd(9) == 0 and await b.rd(8) == 0
    await b.wr(5, 0)
    assert await b.rd(6) == 0
    # fully functional after reset
    await build_and_check(b, 1, 2, 3, [4])
    # reset again with an existing reply: reply data absent afterwards
    await b.reset()
    for i in range(0, 12):
        await b.wr(5, i)
        assert await b.rd(6) == 0


# req: REQ-18, REQ-09
@cocotb.test()
async def test_unmapped_and_ro(dut):
    b = await new_bench(dut)
    await build_and_check(b, 1, 2, 3, [4, 5])
    await b.wr(0, 0x10)
    await b.wr(3, 0x33)
    for off in (0x0A, 0x0B, 0x10, 0x40, 0x7E, 0x7F):
        assert await b.rd(off) == 0
        await b.wr(off, 0xFFFFFFFF)
        assert await b.rd(off) == 0
    # writes to read-only offsets change nothing
    for off in (6, 7, 8, 9):
        await b.wr(off, 0xFF)
    await b.all_regs()
    assert await b.rd(7) == 11
    assert await b.rd(9) == 1
    # PBYTE and BUILD read 0
    assert await b.rd(3) == 0
    assert await b.rd(4) == 0
    await b.all_regs()


# req: REQ-01, REQ-02, REQ-03, REQ-04, REQ-05, REQ-06, REQ-07, REQ-07b, REQ-08, REQ-09, REQ-10, REQ-10b, REQ-11b, REQ-12, REQ-12b, REQ-13, REQ-14, REQ-15, REQ-17, REQ-18, REQ-19, REQ-19b, REQ-19c, REQ-20
@cocotb.test()
async def test_random_traffic(dut):
    seed = int(getattr(cocotb, "RANDOM_SEED", 1))
    rnd = random.Random(seed)
    b = await new_bench(dut)
    vals = [0, 1, 0x7F, 0x80, 0xFF, 0xFFFF, 0xFFFFFFFF]
    for _ in range(55):
        r = rnd.random()
        if r < 0.10:
            await b.wr(0, rnd.choice(vals + [rnd.getrandbits(32)]))
        elif r < 0.18:
            await b.wr(1, rnd.choice(vals + [rnd.getrandbits(32)]))
        elif r < 0.26:
            await b.wr(2, rnd.choice(vals + [rnd.getrandbits(32)]))
        elif r < 0.50:
            await b.wr(3, rnd.getrandbits(8) if rnd.random() < 0.8 else rnd.getrandbits(32))
        elif r < 0.60:
            await b.wr(4, rnd.getrandbits(32))
            await b.rd(8)
            await b.rd(9)
            n = await b.rd(7)
            for i in rnd.sample(range(n + 2), min(4, n + 2)):
                await b.wr(5, i)
                await b.rd(6)
            b.check_led()
        elif r < 0.68:
            await b.wr(5, rnd.choice([0, 1, 8, 9, 32, 33, 34, 0x7F, 0xFF, rnd.getrandbits(32)]))
            await b.rd(6)
        elif r < 0.70:
            await b.reset()
            await b.all_regs()
        elif r < 0.75:
            await b.wr(rnd.choice([6, 7, 8, 9, 0x0A, 0x30]), rnd.getrandbits(32))
        else:
            await b.rd(rnd.choice(list(range(10)) + [0x0A, 0x7F]))
    await b.all_regs()
    rep = await b.read_reply()
    if rep:
        assert zlib.crc32(bytes(rep[:-4])) & 0xFFFFFFFF == int.from_bytes(bytes(rep[-4:]), "little")
        assert rep[4] == len(rep) - 9
