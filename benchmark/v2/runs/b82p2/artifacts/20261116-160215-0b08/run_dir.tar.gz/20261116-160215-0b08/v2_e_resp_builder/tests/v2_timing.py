"""Timing-related smoke check at the 10 ns (100 MHz) clock: a build completes within 64 clocks."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import cocotb  # noqa: E402
from v2_bench import new_bench, check_reply  # noqa: E402


# req: REQ-23
@cocotb.test()
async def test_timing_clock_smoke(dut):
    # Clock runs at the 100 MHz period (10 ns); the post_route:setup analysis gate carries
    # the actual WNS evidence, this checks the design works at that clock with back-to-back builds.
    b = await new_bench(dut)
    for n in (0, 24):
        pl = list(range(n))
        await b.wr(0, 3)
        for p in pl:
            await b.wr(3, p)
        await b.wr(4, 1)
        assert await b.rd(8) == 0
        rep = await b.read_reply()
        check_reply(rep, 3, 0, 0, pl)
