import sys
from pathlib import Path

DESIGN = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(DESIGN))
sys.path.insert(0, str(DESIGN / "tests"))
for _p in DESIGN.parents:
    if (_p / "flow").is_dir():
        sys.path.insert(0, str(_p))
        break

PARAMS = {"CLKS_PER_BIT": 8, "TIMEOUT_CYCLES": 2000}
SEEDS = (1, 2, 3)


def test_v2_e_resp_builder_rtl():
    import flow.cocotb_run as cr

    sources = cr.SHELL_RTL + sorted((DESIGN / "rtl").glob("*.sv"))
    for seed in SEEDS:
        res = cr.run("v2_e_resp_builder", "v2_e_resp_builder_top", sources,
                     "v2_bench,v2_timing", DESIGN / "tests", parameters=PARAMS, seed=seed)
        if res is False:
            raise AssertionError(f"cocotb run failed for seed {seed}")
