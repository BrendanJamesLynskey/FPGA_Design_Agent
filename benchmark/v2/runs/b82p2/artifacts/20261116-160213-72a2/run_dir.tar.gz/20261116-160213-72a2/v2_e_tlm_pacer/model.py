class Model:
    def __init__(self, PERIOD_MIN=4, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000,
                 BUILD_STAMP=0, PERIOD_RESET=100):
        self.PERIOD_MIN = PERIOD_MIN
        self.PERIOD_RESET = PERIOD_RESET
        self.reset()

    def reset(self):
        self.en = 0
        self.req = self.PERIOD_RESET
        self.eff = self.PERIOD_RESET
        self.waiting = 0
        self.frames = 0
        self.overruns = 0
        self.cnt = 0
        self.burst = 0

    def _tick(self):
        if not self.en:
            return
        if self.cnt + 1 == self.eff:
            self.cnt = 0
            self.eff = max(self.req, self.PERIOD_MIN)
            if self.waiting:
                self.overruns = (self.overruns + 1) & 0xFFFF
            else:
                self.waiting = 1
                self.frames = (self.frames + 1) & 0xFFFF
        else:
            self.cnt = (self.cnt + 1) & 0xFFFF

    def step(self, inputs=None):
        if inputs and "CPU_RESETN" in inputs and not inputs["CPU_RESETN"]:
            self.reset()
        elif self.burst > 0:
            self.burst -= 1
            self._tick()
        return {"LED": self.frames, "UART_RXD_OUT": 1}

    def read_reg(self, offset):
        if offset == 0:
            return self.en
        if offset == 1:
            return self.req
        if offset == 2:
            return self.eff
        if offset == 5:
            return self.waiting | (self.en << 1)
        if offset == 6:
            return self.frames
        if offset == 7:
            return self.overruns
        if offset == 8:
            return self.cnt
        return 0

    def write_reg(self, offset, value):
        if offset == 0:
            v = value & 1
            if v and not self.en:
                self.cnt = 0
                self.eff = max(self.req, self.PERIOD_MIN)
            if not v:
                self.waiting = 0
            self.en = v
        elif offset == 1:
            self.req = value & 0xFFFF
        elif offset == 3:
            self.burst = value & 0xFF
        elif offset == 4:
            self.waiting = 0
