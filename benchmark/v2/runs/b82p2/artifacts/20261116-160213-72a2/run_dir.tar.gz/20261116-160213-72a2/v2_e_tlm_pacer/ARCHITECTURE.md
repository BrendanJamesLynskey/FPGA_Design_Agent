# v2_e_tlm_pacer architecture

## Block diagram

```text
 CLK100MHZ --------------------------------+
 CPU_RESETN --> sync (2ff, active high) -->|
                                           v
 UART_TXD_IN --> [ fpga_shell ] --win_*--> [ pacer_regs ] --> [ tick_gen ] --tick--> [ frame_core ]
 UART_RXD_OUT <--[            ] <-rdata---- [            ] <----------------------- [ counter, waiting,
                                                                                      frames, overruns ]
                                           LED[15:0] <------ frame total
```

## Clock plan

Single domain: CLK100MHZ, 100 MHz. All logic synchronous to it, no CDC.
CPU_RESETN (active low button) is synchronised once into an active-high
synchronous reset used by all state, shell included. Reset is synchronous.

## Pin list

- CLK100MHZ: input, 100 MHz clock
- CPU_RESETN: input, active-low reset button
- LED[15:0]: output, frame total
- UART_TXD_IN: input, host to FPGA
- UART_RXD_OUT: output, FPGA to host

Pins come from the master XDC through board_constraints.

## Resources

About 150 to 450 LUT and FF, 0 BRAM, 0 DSP (shell included).
