"""pytest entry: runs the cocotb bench for several seeds. Seed 4 uses PERIOD_MIN=1 so that the overrun total
can be driven through its 16-bit wrap in a bounded number of cycles."""
import json
import os
import sys
from pathlib import Path

import pytest

DESIGN = Path(__file__).resolve().parents[1]
for _p in [DESIGN, *DESIGN.parents]:
    if (_p / "flow").is_dir():
        sys.path.insert(0, str(_p))
        break
from flow import cocotb_run  # noqa: E402

BASE = dict(PERIOD_MIN=4, CLKS_PER_BIT=6, TIMEOUT_CYCLES=2000, BUILD_STAMP=0, PERIOD_RESET=100)


@pytest.mark.parametrize("seed,pm", [(1, 4), (2, 4), (3, 4), (4, 1)])
def test_rtl(seed, pm):
    params = dict(BASE, PERIOD_MIN=pm)
    os.environ["PACER_PARAMS"] = json.dumps(params)
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN / "rtl").glob("*.sv"))
    cocotb_run.run(
        "v2_e_tlm_pacer",
        "v2_e_tlm_pacer_top",
        sources,
        "v2_e_tlm_pacer_bench",
        DESIGN / "tests",
        parameters=params,
        seed=seed,
    )
