"""cocotb bench for v2_e_tlm_pacer: everything goes through the shell UART (window 0x80+offset),
every register value is compared with model.Model. The tick generator is only advanced by TICK bursts,
so the model is stepped n times after a TICK write (the DUT finishes a burst long before the next UART
transaction can strobe)."""
import json
import os
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import RisingEdge  # noqa: E402
from model import Model  # noqa: E402

DEFAULTS = dict(PERIOD_MIN=4, CLKS_PER_BIT=6, TIMEOUT_CYCLES=2000, BUILD_STAMP=0, PERIOD_RESET=100)
P = dict(DEFAULTS)
if os.environ.get("PACER_PARAMS"):
    P.update(json.loads(os.environ["PACER_PARAMS"]))

CTRL, REQ, EFF, TICK, TAKE, STAT, FRAMES, OVERRUNS, CNT = range(9)
WIN = 0x80


def _xor(bs):
    r = 0
    for b in bs:
        r ^= b
    return r


class Bench:
    def __init__(self, dut):
        self.dut = dut
        self.cpb = P["CLKS_PER_BIT"]
        self.pm = P["PERIOD_MIN"]
        self.m = Model(**P)
        self.cyc = 0
        self.led_chg = None
        self.t_end = 0

    async def _mon(self):
        last = None
        while True:
            await RisingEdge(self.dut.CLK100MHZ)
            self.cyc += 1
            try:
                v = int(self.dut.LED.value)
            except ValueError:
                continue
            if last is not None and v != last and self.led_chg is None:
                self.led_chg = self.cyc
            last = v

    async def clocks(self, n):
        for _ in range(n):
            await RisingEdge(self.dut.CLK100MHZ)

    async def start(self):
        self.dut.UART_TXD_IN.value = 1
        self.dut.CPU_RESETN.value = 0
        cocotb.start_soon(Clock(self.dut.CLK100MHZ, 10, "ns").start())
        cocotb.start_soon(self._mon())
        await self.clocks(8)
        await self.reset()

    async def reset(self, cycles=4):
        self.dut.CPU_RESETN.value = 0
        await self.clocks(cycles)
        self.dut.CPU_RESETN.value = 1
        await self.clocks(10)
        self.m.reset()

    async def _send(self, bs):
        for b in bs:
            bits = [0] + [(b >> i) & 1 for i in range(8)] + [1]
            for bit in bits:
                self.dut.UART_TXD_IN.value = bit
                await self.clocks(self.cpb)
        self.t_end = self.cyc

    async def _recv(self, n=7, limit=20000):
        out = []
        cpb = self.cpb
        for _ in range(n):
            waited = 0
            while int(self.dut.UART_RXD_OUT.value) != 0:
                await self.clocks(1)
                waited += 1
                assert waited < limit, "no UART response"
            await self.clocks(cpb // 2)
            assert int(self.dut.UART_RXD_OUT.value) == 0, "glitch on start bit"
            b = 0
            for k in range(8):
                await self.clocks(cpb)
                b |= int(self.dut.UART_RXD_OUT.value) << k
            await self.clocks(cpb)
            assert int(self.dut.UART_RXD_OUT.value) == 1, "stop bit low"
            out.append(b)
        await self.clocks(cpb + 2)
        return out

    async def xfer(self, cmd, addr, data=0):
        body = bytes([cmd, addr]) + data.to_bytes(4, "little")
        req = bytes([0xA5]) + body + bytes([_xor(body)])
        t = cocotb.start_soon(self._send(req))
        resp = await self._recv()
        await t
        assert resp[0] == 0x5A, f"bad sync {resp}"
        assert _xor(resp[1:6]) == resp[6], f"bad checksum {resp}"
        return resp[1], int.from_bytes(bytes(resp[2:6]), "little")

    async def shell_read(self, addr):
        st, d = await self.xfer(1, addr)
        assert st == 0, f"shell read {addr:#x} status {st}"
        return d

    async def rd(self, off):
        return await self.shell_read(WIN + off)

    async def wr(self, off, val):
        st, _ = await self.xfer(2, WIN + off, val)
        assert st == 0, f"write {off:#x} status {st}"

    async def mw(self, off, val):
        """write the DUT and the model; a TICK burst steps the model n clocks"""
        await self.wr(off, val)
        self.m.write_reg(off, val)
        if off == TICK:
            for _ in range(val & 0xFF):
                self.m.step()

    async def expect(self, off, val):
        got = await self.rd(off)
        assert got == val, f"reg {off}: DUT {got:#x} expected {val:#x}"

    async def chk(self, offs=range(9)):
        for off in offs:
            got = await self.rd(off)
            exp = self.m.read_reg(off)
            assert got == exp, f"reg {off}: DUT {got:#x} model {exp:#x}"
        assert int(self.dut.LED.value) == self.m.frames, f"LED {int(self.dut.LED.value)} != frames {self.m.frames}"


# req: REQ-21, REQ-22, REQ-23, REQ-24, REQ-27
@cocotb.test()
async def test_reset_id(dut):
    b = Bench(dut)
    await b.start()
    assert await b.shell_read(0x00) == 0x544C5031, "design ID is not TLP1"
    assert await b.shell_read(0x01) == 0x00010001
    await b.expect(CTRL, 0)
    await b.expect(REQ, P["PERIOD_RESET"])
    await b.expect(EFF, P["PERIOD_RESET"])
    await b.expect(STAT, 0)
    await b.expect(FRAMES, 0)
    await b.expect(OVERRUNS, 0)
    await b.expect(CNT, 0)
    await b.expect(TICK, 0)
    await b.expect(TAKE, 0)
    await b.chk()
    assert int(dut.LED.value) == 0


# req: REQ-01, REQ-03, REQ-31
@cocotb.test()
async def test_first_frame(dut):
    b = Bench(dut)
    await b.start()
    per = P["PERIOD_RESET"]
    await b.mw(CTRL, 1)
    await b.expect(CNT, 0)
    await b.expect(STAT, 2)
    await b.mw(TICK, 50)
    await b.mw(TICK, per - 51)
    await b.expect(CNT, per - 1)
    await b.expect(FRAMES, 0)
    await b.expect(STAT, 2)
    await b.mw(CTRL, 1)  # enable while enabled: no restart
    await b.expect(CNT, per - 1)
    await b.expect(EFF, per)
    await b.mw(TICK, 1)  # tick number `per` after switch-on
    await b.expect(FRAMES, 1)
    await b.expect(STAT, 3)
    await b.expect(CNT, 0)
    assert int(dut.LED.value) == 1
    await b.chk()


# req: REQ-02
@cocotb.test()
async def test_ten_thousand_ticks(dut):
    b = Bench(dut)
    await b.start()
    await b.mw(CTRL, 1)
    for i in range(50):
        await b.mw(TICK, 200)
        if i % 10 == 9:
            await b.chk([FRAMES, OVERRUNS, CNT, STAT])
        await b.mw(TAKE, 1)
    await b.expect(FRAMES, 50)
    await b.expect(OVERRUNS, 50)  # 100 frames fell due in 10000 ticks: 50 held + 50 dropped
    await b.expect(CNT, 0)
    await b.chk()


# req: REQ-04, REQ-05, REQ-06, REQ-07, REQ-25, REQ-26, REQ-03
@cocotb.test()
async def test_enable_off(dut):
    b = Bench(dut)
    await b.start()
    p = 6
    await b.mw(REQ, p)
    await b.mw(CTRL, 1)
    await b.mw(TICK, 20)  # due at 6, 12, 18
    await b.expect(FRAMES, 1)
    await b.expect(OVERRUNS, 2)
    await b.expect(STAT, 3)
    await b.expect(CNT, 2)
    await b.mw(CTRL, 0)
    await b.expect(STAT, 0)  # waiting cleared, enable 0
    await b.expect(FRAMES, 1)
    await b.expect(OVERRUNS, 2)
    await b.expect(REQ, p)
    await b.expect(EFF, p)
    await b.expect(CNT, 2)
    await b.mw(TICK, 10)  # ticks while disabled: no effect
    await b.expect(CNT, 2)
    await b.expect(FRAMES, 1)
    await b.expect(OVERRUNS, 2)
    await b.expect(STAT, 0)
    await b.mw(CTRL, 0)
    await b.chk()
    await b.mw(CTRL, 1)  # totals survive switch-on, counter cleared
    await b.expect(CNT, 0)
    await b.expect(FRAMES, 1)
    await b.expect(OVERRUNS, 2)
    await b.mw(TICK, p)
    await b.expect(FRAMES, 2)
    await b.expect(OVERRUNS, 2)
    await b.chk()


# req: REQ-08, REQ-09, REQ-10
@cocotb.test()
async def test_period_request(dut):
    b = Bench(dut)
    await b.start()
    pm = b.pm
    cases = sorted({0, 1, max(pm - 1, 0), pm, pm + 1, 0xFFFF})
    for r in cases:
        await b.mw(REQ, r)
        await b.expect(REQ, r)
        await b.mw(CTRL, 1)
        await b.expect(EFF, max(r, pm))
        await b.expect(CNT, 0)
        await b.mw(CTRL, 0)
    await b.mw(REQ, 0x12345)
    await b.expect(REQ, 0x2345)
    await b.mw(REQ, 10)
    await b.expect(EFF, max(0xFFFF, pm))  # disabled: no change until switch-on
    await b.mw(CTRL, 1)
    await b.expect(EFF, 10)
    await b.mw(TICK, 4)
    await b.mw(REQ, 20)
    await b.expect(REQ, 20)
    await b.expect(EFF, 10)  # takes effect at the next wrap only
    await b.mw(TICK, 5)
    await b.expect(EFF, 10)
    await b.expect(CNT, 9)
    await b.mw(TICK, 1)
    await b.expect(EFF, 20)
    await b.expect(CNT, 0)
    await b.mw(TICK, 7)
    await b.mw(REQ, pm)  # lower request mid count
    await b.expect(EFF, 20)
    await b.mw(TICK, 13)
    await b.expect(EFF, pm)
    await b.expect(CNT, 0)
    await b.mw(CTRL, 0)
    await b.mw(REQ, 33)
    await b.expect(EFF, pm)
    await b.mw(CTRL, 1)
    await b.expect(EFF, 33)
    await b.chk()


# req: REQ-11, REQ-12, REQ-13, REQ-14, REQ-15, REQ-16
@cocotb.test()
async def test_frame_hold_take(dut):
    b = Bench(dut)
    await b.start()
    p = 5
    await b.mw(REQ, p)
    await b.mw(CTRL, 1)
    await b.mw(TICK, p)
    await b.expect(STAT, 3)
    await b.expect(FRAMES, 1)
    await b.mw(TAKE, 1)
    await b.expect(STAT, 2)
    await b.expect(FRAMES, 1)
    await b.expect(OVERRUNS, 0)
    before = [await b.rd(o) for o in range(9)]
    await b.mw(TAKE, 0xFFFF)  # nothing waiting: no state change
    after = [await b.rd(o) for o in range(9)]
    assert before == after, f"TAKE with nothing waiting changed state {before} -> {after}"
    await b.chk()
    await b.mw(TICK, p)  # held again
    await b.expect(FRAMES, 2)
    await b.expect(STAT, 3)
    await b.mw(TICK, p)  # dropped
    await b.expect(FRAMES, 2)
    await b.expect(OVERRUNS, 1)
    await b.expect(STAT, 3)
    await b.mw(TICK, 2 * p)
    await b.expect(OVERRUNS, 3)
    await b.expect(FRAMES, 2)
    await b.mw(TAKE, 1)
    await b.expect(STAT, 2)
    await b.mw(TICK, p)  # a frame due right after a take: held, no overrun
    await b.expect(FRAMES, 3)
    await b.expect(OVERRUNS, 3)
    await b.expect(STAT, 3)
    await b.chk()


# req: REQ-19, REQ-20
@cocotb.test()
async def test_tick_burst(dut):
    b = Bench(dut)
    await b.start()
    await b.mw(REQ, 1000)
    await b.mw(CTRL, 1)
    cum = 0
    for n in (0, 1, 2, 7, 255, 255, 200, 0):
        await b.mw(TICK, n)
        cum += n
        await b.expect(CNT, cum)
        await b.expect(FRAMES, 0)
    await b.chk()


# req: REQ-20, REQ-19
@cocotb.test()
async def test_tick_timing(dut):
    """TICK n: the n-th tick (the one that makes the frame fall due) arrives n-1 clocks after the first."""
    b = Bench(dut)
    await b.start()
    lat = {}
    for p in (6, 12, 25):
        await b.mw(CTRL, 0)
        await b.mw(REQ, p)
        await b.mw(CTRL, 1)
        await b.clocks(5)
        b.led_chg = None
        await b.mw(TICK, p)
        assert b.led_chg is not None, "frame never fell due"
        lat[p] = b.led_chg - b.t_end
        assert lat[p] > 0
        await b.expect(FRAMES, b.m.frames)
    assert lat[12] - lat[6] == 6, lat
    assert lat[25] - lat[12] == 13, lat
    await b.chk()


# req: REQ-21
@cocotb.test()
async def test_unmapped(dut):
    b = Bench(dut)
    await b.start()
    await b.mw(REQ, 7)
    await b.mw(CTRL, 1)
    await b.mw(TICK, 15)
    await b.chk()
    for off in (EFF, STAT, FRAMES, OVERRUNS, CNT, 9, 10, 0x20, 0x7F):
        await b.mw(off, 0x55 if off != 0x20 else 0xFFFF)
    await b.chk()
    for off in (9, 10, 0x40, 0x7F):
        await b.expect(off, 0)
    await b.expect(TICK, 0)
    await b.expect(TAKE, 0)
    await b.chk()


# req: REQ-23, REQ-24, REQ-22
@cocotb.test()
async def test_reset_midrun(dut):
    b = Bench(dut)
    await b.start()
    await b.mw(REQ, 5)
    await b.mw(CTRL, 1)
    await b.mw(TICK, 17)
    await b.expect(FRAMES, 1)
    await b.expect(OVERRUNS, 2)
    await b.mw(REQ, 33)
    await b.reset()
    await b.expect(CTRL, 0)
    await b.expect(REQ, P["PERIOD_RESET"])
    await b.expect(EFF, P["PERIOD_RESET"])
    await b.expect(STAT, 0)
    await b.expect(FRAMES, 0)
    await b.expect(OVERRUNS, 0)
    await b.expect(CNT, 0)
    assert int(dut.LED.value) == 0
    await b.mw(TICK, 5)  # disabled after reset
    await b.chk()


# req: REQ-17, REQ-18
@cocotb.test()
async def test_counter_widths(dut):
    """16-bit request field always; the overrun total is driven through its wrap when PERIOD_MIN is 1
    (65536 drops need >65k ticks: only that run is short enough). The frame total needs 65536 TAKE
    transactions over the UART and cannot be wrapped in simulation."""
    b = Bench(dut)
    await b.start()
    await b.mw(REQ, 0xFFFF)
    await b.expect(REQ, 0xFFFF)
    await b.chk()
    if b.pm != 1:
        return
    await b.mw(REQ, 1)
    await b.mw(CTRL, 1)
    for _ in range(257):
        await b.mw(TICK, 255)  # 65535 ticks: 1 held, 65534 dropped
    await b.expect(FRAMES, 1)
    await b.expect(OVERRUNS, 65534)
    await b.mw(TICK, 1)
    await b.expect(OVERRUNS, 65535)
    await b.mw(TICK, 1)
    await b.expect(OVERRUNS, 0)
    await b.mw(TICK, 3)
    await b.expect(OVERRUNS, 3)
    await b.expect(FRAMES, 1)
    await b.chk()


# req: REQ-28
@cocotb.test()
async def test_uart_baud(dut):
    b = Bench(dut)
    await b.start()
    body = bytes([1, WIN + REQ, 0, 0, 0, 0])
    req = bytes([0xA5]) + body + bytes([_xor(body)])
    t = cocotb.start_soon(b._send(req))
    for _ in range(20000):
        await b.clocks(1)
        if int(dut.UART_RXD_OUT.value) == 0:
            break
    else:
        assert False, "no response"
    w = 0
    while int(dut.UART_RXD_OUT.value) == 0:
        await b.clocks(1)
        w += 1
    await t
    # 0x5A LSB first: start bit + bit0 low, then bit1 high
    assert abs(w - 2 * b.cpb) <= 1, f"start+bit0 width {w}, expected {2 * b.cpb}"
    await b.clocks(100 * b.cpb)


# req: REQ-29, REQ-30, REQ-27
@cocotb.test()
async def test_top_smoke(dut):
    b = Bench(dut)
    await b.start()
    name = getattr(dut, "_name", "v2_e_tlm_pacer_top")
    assert "v2_e_tlm_pacer_top" in str(name)
    assert await b.shell_read(0x00) == 0x544C5031
    await b.chk([CTRL, REQ, EFF])


# req: REQ-01, REQ-02, REQ-03, REQ-04, REQ-05, REQ-06, REQ-07, REQ-08, REQ-09, REQ-10, REQ-11, REQ-12, REQ-13, REQ-14, REQ-15, REQ-16, REQ-19, REQ-20, REQ-21, REQ-22, REQ-23, REQ-24, REQ-25, REQ-26, REQ-31
@cocotb.test()
async def test_random_traffic(dut):
    b = Bench(dut)
    await b.start()
    rng = random.Random(cocotb.RANDOM_SEED)
    pm = b.pm
    await b.mw(CTRL, 1)
    for _ in range(70):
        r = rng.random()
        if r < 0.15:
            await b.mw(CTRL, rng.choice([0, 1, 1]))
        elif r < 0.30:
            await b.mw(REQ, rng.choice([0, 1, pm, pm + 1, 5, 6, 8, 11, 13, 40, rng.randrange(0x10000)]))
        elif r < 0.65:
            await b.mw(TICK, rng.choice([0, 1, 2, 3, 5, 9, rng.randrange(0, 40), rng.randrange(0, 40), 255]))
        elif r < 0.80:
            await b.mw(TAKE, rng.randrange(0x10000))
        elif r < 0.84:
            await b.reset()
        else:
            pass
        await b.chk([rng.choice([CTRL, REQ, EFF, STAT, FRAMES, OVERRUNS, CNT, 9, TICK])])
    await b.chk()
