"""Pytest entry: runs the cocotb bench (tests/udp_bench.py) against rtl/*.sv with the shell, three seeds."""
from pathlib import Path

import flow.cocotb_run as cr

DESIGN = Path(__file__).resolve().parents[1]
PARAMS = {"CLKS_PER_BIT": 8, "TIMEOUT_CYCLES": 4000}  # same values as tests/udp_bench.py PARAMS


def _check(res):
    if isinstance(res, bool):
        assert res, "cocotb run failed"
    for attr in ("ok", "success"):
        if hasattr(res, attr):
            assert getattr(res, attr), "cocotb run failed"


def test_udp_endpoint_rtl():
    sources = cr.SHELL_RTL + sorted((DESIGN / "rtl").glob("*.sv"))
    for seed in (1, 2, 3):
        res = cr.run("v2_e_udp_endpoint", "v2_e_udp_endpoint_top", sources, "udp_bench",
                     DESIGN / "tests", parameters=PARAMS, seed=seed)
        _check(res)
