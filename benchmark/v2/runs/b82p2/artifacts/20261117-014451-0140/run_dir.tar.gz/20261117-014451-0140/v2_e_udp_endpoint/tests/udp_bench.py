"""cocotb bench for v2_e_udp_endpoint: every register access goes through the test shell over the UART
(PROTOCOL.md 1.1); the design's window registers are at 0x80 + offset.  Every observation is compared with
model.py, and the spec facts are also asserted independently of the model."""
import os
import random
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402,F401
from model import Model  # noqa: E402

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ClockCycles, Edge, FallingEdge, RisingEdge  # noqa: E402
from cocotb.utils import get_sim_time  # noqa: E402

PARAMS = {"CLKS_PER_BIT": 8, "TIMEOUT_CYCLES": 4000}
N = PARAMS["CLKS_PER_BIT"]
WIN = 0x80
ID_WORD = 0x55445031


# ---------------------------------------------------------------- packet builders
def mk(typ, seq, pay=b"", ln=None, bad_crc=False):
    body = bytes([typ & 0xFF, len(pay) if ln is None else ln, (seq >> 8) & 0xFF, seq & 0xFF]) + bytes(pay)
    crc = bytearray(zlib.crc32(body).to_bytes(4, "little"))
    if bad_crc:
        crc[0] ^= 0x01
    return list(body + bytes(crc))


def rdp(reg):
    return reg.to_bytes(2, "big")


def wrp(reg, val):
    return reg.to_bytes(2, "big") + val.to_bytes(4, "big")


def stp(per):
    return per.to_bytes(2, "big")


def counters(d):
    """Status reply -> [7 counters, frame count, telemetry on]."""
    p = bytes(d[5:5 + 17])
    assert len(p) == 17 and d[4] == 17, "status payload must be 17 bytes"
    return [int.from_bytes(p[2 * i:2 * i + 2], "big") for i in range(8)] + [p[16]]


NEED = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}


class Bench:
    def __init__(self, dut):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        self.m = Model(**PARAMS)
        self.rx = []
        self.led_events = []
        self.t_req_end = 0

    @classmethod
    async def create(cls, dut):
        b = cls(dut)
        await b.start()
        return b

    async def start(self):
        dut = self.dut
        dut.UART_TXD_IN.value = 1
        dut.CPU_RESETN.value = 0
        cocotb.start_soon(Clock(dut.CLK100MHZ, 10, "ns").start())
        await ClockCycles(self.clk, 8)
        dut.CPU_RESETN.value = 1
        self.m.reset()
        await ClockCycles(self.clk, 20)
        cocotb.start_soon(self._rx_mon())
        cocotb.start_soon(self._led_mon())

    async def reset_dut(self, cycles=6):
        self.dut.CPU_RESETN.value = 0
        await ClockCycles(self.clk, cycles)
        self.dut.CPU_RESETN.value = 1
        self.m.reset()
        await ClockCycles(self.clk, 20)
        self.rx.clear()

    # ------------------------------------------------------------ UART
    async def _rx_mon(self):
        rxd = self.dut.UART_RXD_OUT
        while True:
            await FallingEdge(rxd)
            await ClockCycles(self.clk, N // 2)
            if int(rxd.value) != 0:
                continue
            v = 0
            for i in range(8):
                await ClockCycles(self.clk, N)
                v |= int(rxd.value) << i
            await ClockCycles(self.clk, N)
            assert int(rxd.value) == 1, "UART_RXD_OUT stop bit is low"
            self.rx.append(v)

    async def _led_mon(self):
        while True:
            await Edge(self.dut.LED)
            try:
                self.led_events.append((get_sim_time("ns"), int(self.dut.LED.value)))
            except ValueError:
                pass

    async def send_byte(self, v):
        bits = [0] + [(v >> i) & 1 for i in range(8)] + [1]
        for bit in bits:
            self.dut.UART_TXD_IN.value = bit
            await ClockCycles(self.clk, N)

    async def xfer(self, cmd, addr, data=0):
        body = bytes([cmd, addr]) + data.to_bytes(4, "little")
        chk = 0
        for x in body:
            chk ^= x
        req = bytes([0xA5]) + body + bytes([chk])
        self.rx.clear()
        for x in req:
            await self.send_byte(x)
        self.t_req_end = get_sim_time("ns")
        for _ in range(400):
            if len(self.rx) >= 7:
                break
            await ClockCycles(self.clk, N)
        await ClockCycles(self.clk, N)
        resp = bytes(self.rx)
        assert len(resp) == 7, f"shell answered {len(resp)} bytes to {req.hex()}"
        assert resp[0] == 0x5A, "bad response sync"
        c = 0
        for x in resp[1:6]:
            c ^= x
        assert c == resp[6], "bad response checksum"
        return resp[1], int.from_bytes(resp[2:6], "little")

    async def rd(self, off):
        st, d = await self.xfer(1, WIN + off)
        assert st == 0, f"window read {off} gave shell status {st}"
        return d

    async def wr(self, off, val):
        st, _ = await self.xfer(2, WIN + off, val)
        assert st == 0, f"window write {off} gave shell status {st}"
        self.m.write_reg(off, val)

    async def push(self, data, end=True):
        for i, b in enumerate(data):
            last = end and i == len(data) - 1
            await self.wr(0, b | (0x100 if last else 0))

    async def tick(self, n):
        await self.wr(1, n)
        for _ in range(n):
            self.m.step()

    # ------------------------------------------------------------ model helpers
    def mbytes(self, which):
        m = self.m
        lenreg, idxreg, wreg = (2, 3, 4) if which == "r" else (5, 6, 7)
        n = m.read_reg(lenreg)
        save = m.read_reg(idxreg)
        out = b""
        for i in range((n + 3) // 4):
            m.write_reg(idxreg, i)
            out += m.read_reg(wreg).to_bytes(4, "big")
        m.write_reg(idxreg, save)
        return out[:n]

    def check_led(self):
        got = int(self.dut.LED.value)
        exp = self.m.step()["LED"]
        assert got == exp, f"LED {got} != commands carried out {exp}"
        return got

    async def check_len(self, which):
        reg = 2 if which == "r" else 5
        n = await self.rd(reg)
        assert n == self.m.read_reg(reg), f"length reg {reg}: {n} != {self.m.read_reg(reg)}"
        return n

    async def check_buf(self, which, extra=False):
        lenreg, idxreg, wreg = (2, 3, 4) if which == "r" else (5, 6, 7)
        n = await self.rd(lenreg)
        assert n == self.m.read_reg(lenreg), f"length reg {lenreg}: {n} != model {self.m.read_reg(lenreg)}"
        words = (n + 3) // 4
        data = b""
        for i in range(words + (1 if extra else 0)):
            await self.wr(idxreg, i)
            w = await self.rd(wreg)
            assert w == self.m.read_reg(wreg), f"word {i} of reg {wreg}: {w:#x} != model {self.m.read_reg(wreg):#x}"
            if i < words:
                data += w.to_bytes(4, "big")
            else:
                assert w == 0, "word past the end must read 0"
        data = data[:n]
        if n:
            assert n >= 9
            assert zlib.crc32(data[:-4]).to_bytes(4, "little") == data[-4:], "CRC trailer != zlib.crc32"
        assert data == self.mbytes(which)
        return data

    async def raw(self, pk, expect=None, extra=False, typ=None, seq=None):
        await self.push(pk)
        data = await self.check_buf("r", extra)
        self.check_led()
        if expect == "silent":
            assert len(data) == 0, "packet must get no reply"
        elif expect is not None:
            assert len(data) >= 9, "expected a reply"
            assert data[1] == expect, f"status {data[1]} != {expect}"
        if len(data):
            if typ is not None:
                assert data[0] == ((typ | 0x80) & 0xFF)
            if seq is not None:
                assert int.from_bytes(data[2:4], "big") == seq
            assert data[4] == len(data) - 9
        return data

    async def cmd(self, typ, seq, pay=b"", ln=None, bad_crc=False, extra=False, expect=None):
        return await self.raw(mk(typ, seq, pay, ln, bad_crc), expect=expect, extra=extra, typ=typ, seq=seq)

    async def regval(self, reg, seq):
        d = await self.cmd(1, seq, rdp(reg), expect=0)
        assert len(d) == 13
        return int.from_bytes(d[5:9], "big")

    async def stat(self, seq):
        d = await self.cmd(3, seq, expect=0)
        return counters(d)


async def frame_check(b, seq_exp, ticks_exp, fresh=True, ref_exp=0):
    d = await b.check_buf("t", extra=True)
    assert len(d) == 17, f"frame length {len(d)}"
    assert d[0] == 0xC0 and d[1] == 0 and d[4] == 8
    assert int.from_bytes(d[2:4], "big") == seq_exp, "frame sequence"
    assert int.from_bytes(d[5:9], "big") == ticks_exp, "frame tick count"
    if fresh:
        assert int.from_bytes(d[9:11], "big") == int(b.dut.LED.value), "commands in frame"
        assert int.from_bytes(d[11:13], "big") == ref_exp, "refused in frame"
    return d


# ---------------------------------------------------------------- tests
# req: REQ-09, REQ-13, REQ-14, REQ-18, REQ-19, REQ-45, REQ-54, REQ-55
@cocotb.test()
async def test_reset_values(dut):
    b = await Bench.create(dut)
    for off in (2, 3, 4, 5, 6, 7, 9, 10, 11):
        got = await b.rd(off)
        assert got == b.m.read_reg(off) == 0, f"reset value of window offset {off}: {got}"
    assert int(dut.LED.value) == 0
    s = 0x1234  # first packet after reset: any number
    exp = [(0, ID_WORD), (1, 0), (2, 0), (3, 0), (6, 100), (7, 0), (4, 6), (5, 0)]
    for reg, val in exp:
        d = await b.cmd(1, s, rdp(reg), expect=0, extra=(reg == 0))
        assert int.from_bytes(d[5:9], "big") == val, f"reg {reg} = {d[5:9].hex()} expected {val:#x}"
        s += 1
    assert int(dut.LED.value) == 8
    assert await b.rd(9) == 0  # telemetry off, not busy


# req: REQ-02, REQ-03, REQ-05, REQ-07, REQ-12, REQ-50
@cocotb.test()
async def test_refusal_counters(dut):
    b = await Bench.create(dut)
    s = 0x0100
    prev = await b.stat(s)
    last = s
    assert prev[0] == 0  # counts before this command is counted
    cases = [
        ("short", 2, lambda s, l: mk(1, s, rdp(0))[:3]),
        ("long", 3, lambda s, l: mk(1, s, rdp(0), ln=9)),
        ("badcrc", 1, lambda s, l: mk(1, s, rdp(0), bad_crc=True)),
        ("unknown type", 6, lambda s, l: mk(9, s)),
        ("wrong length", 6, lambda s, l: mk(1, s, b"\0\0\0")),
        ("repeated", 4, lambda s, l: mk(1, l, rdp(0))),
        ("out of order", 5, lambda s, l: mk(1, (l - 5) & 0xFFFF, rdp(0))),
        ("write read-only", 6, lambda s, l: mk(2, s, wrp(0, 5))),
        ("unknown register", 6, lambda s, l: mk(1, s, rdp(9))),
    ]
    nref = 0
    for name, idx, bld in cases:
        s += 1
        await b.raw(bld(s, last))
        nref += 1
        s += 1
        cur = await b.stat(s)
        last = s
        delta = [c - p for c, p in zip(cur, prev)]
        exp = [0] * 9
        exp[0] = 1  # the previous status command
        exp[idx] += 1
        assert delta == exp, f"{name}: counters delta {delta} expected {exp}"
        prev = cur
    s += 1
    assert await b.regval(5, s) == nref  # refused-packets register


# req: REQ-02, REQ-03, REQ-04, REQ-05, REQ-06, REQ-20, REQ-21
@cocotb.test()
async def test_refusal_order(dut):
    b = await Bench.create(dut)
    s = 0x0200
    await b.cmd(3, s, expect=0)
    last = s
    cases = [
        ("one byte", "silent", lambda s, l: [0x00]),
        ("three bytes", "silent", lambda s, l: mk(1, s, rdp(0))[:3]),
        ("header only", "silent", lambda s, l: mk(1, s, rdp(0))[:4]),
        ("cut before crc complete", "silent", lambda s, l: mk(1, s, rdp(0))[:-2]),
        ("cut and bad crc", "silent", lambda s, l: mk(1, s, rdp(0), bad_crc=True)[:-1]),
        ("extra bytes", "silent", lambda s, l: mk(3, s) + [0, 0]),
        ("len 9 and bad crc", "silent", lambda s, l: mk(1, s, rdp(0), ln=9, bad_crc=True)),
        ("len 200 short", "silent", lambda s, l: mk(1, s, rdp(0), ln=200)),
        ("bad crc unknown type", "silent", lambda s, l: mk(9, s, bad_crc=True)),
        ("unknown type wrong len", 1, lambda s, l: mk(9, s, b"\1\2\3")),
        ("unknown type 6", 1, lambda s, l: mk(6, s)),
        ("unknown type 255", 1, lambda s, l: mk(255, s)),
        ("wrong len read", 2, lambda s, l: mk(1, s, b"\0\0\0")),
        ("wrong len write", 2, lambda s, l: mk(2, s, b"\0\0")),
        ("wrong len status", 2, lambda s, l: mk(3, s, b"\0")),
        ("wrong len start", 2, lambda s, l: mk(4, s, b"")),
        ("wrong len stop", 2, lambda s, l: mk(5, s, b"\0\0")),
        ("wrong len beats repeated", 2, lambda s, l: mk(1, l, b"\0")),
        ("repeated beats unknown register", 4, lambda s, l: mk(1, l, rdp(9))),
        ("old beats read-only write", 4, lambda s, l: mk(2, (l - 1) & 0xFFFF, wrp(0, 1))),
    ]
    for name, exp, bld in cases:
        s += 1
        await b.raw(bld(s, last), expect=exp)
    await b.stat(s + 1)


# req: REQ-08, REQ-09, REQ-10, REQ-11, REQ-12, REQ-49
@cocotb.test()
async def test_sequence_rule(dut):
    b = await Bench.create(dut)
    s0 = 0xFFF0
    await b.cmd(2, s0, wrp(1, 0xAAAA5555), expect=0)  # first packet: any number
    await b.cmd(2, s0, wrp(1, 0x11111111), expect=4)  # repeated
    await b.cmd(2, (s0 - 1) & 0xFFFF, wrp(1, 0x22222222), expect=4)  # old
    await b.cmd(1, 0x0000, rdp(1), expect=0)  # wraps: difference 0x10
    assert await b.regval(1, 0x0001) == 0xAAAA5555  # refused writes changed nothing
    last = 0x0001
    nxt = (last + 32767) & 0xFFFF
    await b.cmd(1, nxt, rdp(0), expect=0)  # difference 32767 is new
    last = nxt
    await b.cmd(1, (last + 32768) & 0xFFFF, rdp(0), expect=4)  # 32768 is old
    await b.cmd(1, (last + 32769) & 0xFFFF, rdp(0), expect=4)
    await b.cmd(1, (last + 1) & 0xFFFF, rdp(0), expect=0)  # a refused number was not consumed
    last = (last + 1) & 0xFFFF
    await b.cmd(2, (last + 1) & 0xFFFF, wrp(4, 1), expect=5)  # fails after sequence: consumed
    last = (last + 1) & 0xFFFF
    await b.cmd(1, last, rdp(0), expect=4)
    await b.cmd(1, (last + 1) & 0xFFFF, rdp(9), expect=3)  # unknown register: consumed
    last = (last + 1) & 0xFFFF
    await b.cmd(1, last, rdp(0), expect=4)
    c = await b.stat((last + 1) & 0xFFFF)
    assert c[4] == 3 and c[5] == 3 and c[6] == 2  # repeated, out of order, other


# req: REQ-15, REQ-18, REQ-19, REQ-39
@cocotb.test()
async def test_registers_scratch(dut):
    b = await Bench.create(dut)
    s = 0x2000
    pats = [(1, 0xDEADBEEF), (2, 0), (3, 0xFFFFFFFF)]
    for r, v in pats:
        d = await b.cmd(2, s, wrp(r, v), expect=0)
        assert len(d) == 9
        s += 1
    for r, v in pats:
        assert await b.regval(r, s) == v
        s += 1
    a = await b.regval(4, s)
    c = await b.regval(4, s + 1)
    assert c == a + 1, "read of reg 4 returns the count before that read is counted"
    s += 2
    r1 = await b.regval(5, s)
    r2 = await b.regval(5, s + 1)
    assert r1 == r2 == 0
    await b.cmd(1, s + 2, rdp(9), expect=3)
    assert await b.regval(5, s + 3) == 1
    assert await b.regval(6, s + 4) == 100


# req: REQ-07, REQ-16, REQ-17, REQ-50
@cocotb.test()
async def test_registers_refused(dut):
    b = await Bench.create(dut)
    s = 0x2100
    for r in (0, 4, 5, 6, 7):
        await b.cmd(2, s, wrp(r, 0x1234), expect=5)
        s += 1
    await b.cmd(1, s, rdp(8), expect=3)
    await b.cmd(2, s + 1, wrp(255, 1), expect=3)
    await b.cmd(1, s + 2, (0x0100).to_bytes(2, "big"), expect=3)
    s += 3
    assert await b.regval(0, s) == ID_WORD  # the failed write changed nothing
    c = await b.stat(s + 1)
    assert c[6] == 8 and c[0] == 1 and c[1:6] == [0] * 5


# req: REQ-01, REQ-20, REQ-21, REQ-22, REQ-23, REQ-51
@cocotb.test()
async def test_reply_formats(dut):
    b = await Bench.create(dut)
    s = 0x3000
    c1 = await b.stat(s)
    assert c1 == [0] * 9  # shows counts before the status command is counted
    c2 = await b.stat(s + 1)
    assert c2[0] == 1 and c2[1:] == [0] * 8
    await b.cmd(1, s + 2, rdp(0), expect=0)
    d = await b.cmd(4, s + 3, stp(0), expect=0)
    assert len(d) == 9
    d = await b.cmd(5, s + 4, expect=0)
    assert len(d) == 9
    d = await b.cmd(2, s + 5, wrp(1, 7), expect=0)
    assert len(d) == 9
    d = await b.cmd(0x42, s + 6, expect=1)
    assert d[0] == 0xC2
    await b.cmd(3, s + 7, b"\0", expect=2)
    await b.raw(mk(1, s + 8, rdp(0), bad_crc=True), expect="silent")
    c3 = await b.stat(s + 9)
    assert c3[0] == 6 and c3[1] == 1 and c3[6] == 2 and c3[8] == 0
    assert await b.regval(5, s + 10) == 3


# req: REQ-19, REQ-27, REQ-28, REQ-29, REQ-30, REQ-44
@cocotb.test()
async def test_telemetry_period(dut):
    b = await Bench.create(dut)
    s = 0x3100
    await b.cmd(4, s, stp(0), expect=0)  # period 0 keeps 100, turns on
    s += 1
    assert (await b.rd(9)) & 1 == 1
    assert await b.regval(6, s) == 100
    s += 1
    for per, want in [(1, 4), (3, 4), (4, 4), (7, 7), (0, 7)]:
        await b.cmd(4, s, stp(per), expect=0)
        assert await b.regval(6, s + 1) == want, f"period {per}"
        s += 2
    c = await b.stat(s)
    assert c[8] == 1 and c[7] == 0


# req: REQ-30, REQ-31, REQ-32, REQ-33, REQ-34, REQ-37, REQ-42, REQ-43, REQ-52, REQ-53
@cocotb.test()
async def test_telemetry_frames(dut):
    b = await Bench.create(dut)
    s = 0x3200
    await b.cmd(4, s, stp(7), expect=0)
    s += 1
    await b.tick(6)
    assert await b.rd(5) == 0  # not yet due
    await b.tick(1)
    assert await b.rd(5) == 17
    f1 = await frame_check(b, 0, 7)
    await b.tick(7)
    await b.tick(14)  # due while held: dropped
    c = await b.stat(s)
    s += 1
    assert c[7] == 1 and c[8] == 1
    f1b = await frame_check(b, 0, 7, fresh=False)
    assert f1b == f1, "held frame is not replaced"
    await b.wr(8, 0)  # take
    assert await b.rd(5) == 0
    await b.tick(7)
    await frame_check(b, 1, 35)
    c = await b.stat(s)
    s += 1
    assert c[7] == 2
    await b.wr(8, 1)
    await b.tick(3)
    await b.cmd(4, s, stp(0), expect=0)  # restarts the period count
    s += 1
    await b.tick(6)
    assert await b.rd(5) == 0, "start restarts the tick count"
    await b.tick(1)
    await frame_check(b, 2, 45)


# req: REQ-12, REQ-35, REQ-36, REQ-44, REQ-53
@cocotb.test()
async def test_telemetry_stop_refused(dut):
    b = await Bench.create(dut)
    s = 0x3300
    await b.cmd(4, s, stp(7), expect=0)
    s += 1
    await b.tick(7)
    assert await b.rd(5) == 17
    await b.cmd(4, s, stp(0), expect=0)  # start keeps the held frame
    s += 1
    assert await b.rd(5) == 17
    await b.cmd(5, s - 1, expect=4)  # repeated number: refused, telemetry unchanged
    assert (await b.rd(9)) & 1 == 1 and await b.rd(5) == 17
    await b.raw(mk(5, s, bad_crc=True), expect="silent")
    assert (await b.rd(9)) & 1 == 1 and await b.rd(5) == 17
    await b.cmd(4, (s - 3) & 0xFFFF, stp(50), expect=4)
    assert await b.regval(6, s) == 7
    s += 1
    await b.cmd(5, s, expect=0)
    s += 1
    assert (await b.rd(9)) & 1 == 0 and await b.rd(5) == 0  # stop: off, frame discarded
    await b.tick(21)
    assert await b.rd(5) == 0
    c = await b.stat(s)
    s += 1
    assert c[7] == 1 and c[8] == 0
    await b.cmd(4, s, stp(7), expect=0)
    await b.tick(7)
    await frame_check(b, 1, 35, ref_exp=3)  # sequence not cleared by stop
    c = await b.stat(s + 1)
    assert c[7] == 2 and c[8] == 1


# req: REQ-31, REQ-38, REQ-39
@cocotb.test()
async def test_ticks(dut):
    b = await Bench.create(dut)
    s = 0x3400
    total = 0
    for n in (0, 1, 10, 255):
        await b.tick(n)
        total += n
        assert await b.regval(7, s) == total
        s += 1
    await b.cmd(4, s, stp(4), expect=0)
    s += 1
    await b.tick(3)
    assert await b.rd(5) == 0
    await b.tick(1)
    assert await b.rd(5) == 17
    await frame_check(b, 0, total + 4)


# req: REQ-40, REQ-41, REQ-42, REQ-43
@cocotb.test()
async def test_readback_words(dut):
    b = await Bench.create(dut)
    s = 0x3500
    d = await b.cmd(3, s, expect=0, extra=True)
    assert len(d) == 26
    await b.wr(3, 6)
    assert await b.rd(4) == int.from_bytes(d[24:26] + b"\0\0", "big")
    for idx in (7, 8, 127):
        await b.wr(3, idx)
        assert await b.rd(4) == 0
    await b.wr(3, 0xFF)
    assert await b.rd(3) == 0x7F
    await b.raw(mk(1, s + 1, rdp(0), bad_crc=True), expect="silent")
    assert await b.rd(2) == 0
    await b.wr(3, 0)
    assert await b.rd(4) == 0
    assert await b.rd(5) == 0
    assert await b.rd(7) == 0
    await b.cmd(4, s + 2, stp(4), expect=0)
    await b.tick(4)
    fr = await frame_check(b, 0, 4, ref_exp=1)
    await b.wr(6, 4)
    assert await b.rd(7) == fr[16] << 24
    await b.wr(6, 5)
    assert await b.rd(7) == 0
    await b.wr(6, 0xFF)
    assert await b.rd(6) == 0x7F
    await b.wr(3, 2)
    await b.wr(6, 1)
    assert await b.rd(3) == 2 and await b.rd(6) == 1
    assert await b.rd(4) == b.m.read_reg(4) and await b.rd(7) == b.m.read_reg(7)
    for off in (2, 4, 5, 7, 9, 10, 0x20):  # read-only and unmapped: writes ignored
        await b.wr(off, 0xFFFFFFFF)
    for off in (2, 3, 4, 5, 6, 7, 9, 10, 11, 0x7F):
        assert await b.rd(off) == b.m.read_reg(off), f"offset {off} after ignored writes"
    assert await b.rd(10) == 0 and await b.rd(0x7F) == 0


# req: REQ-25, REQ-45
@cocotb.test()
async def test_led_and_latency(dut):
    b = await Bench.create(dut)
    s = 0x3600
    for i in range(4):
        b.led_events.clear()
        await b.push(mk(1, s + i, rdp(0)))
        assert b.led_events, "LED did not change for a carried-out command"
        dt = b.led_events[0][0] - b.t_req_end
        assert dt <= 1250, f"command counted {dt} ns after the end-flag byte"
        assert b.led_events[0][1] == i + 1
        await b.check_buf("r")
        assert int(dut.LED.value) == i + 1
    b.led_events.clear()
    await b.push(mk(1, s + 4, rdp(0), bad_crc=True))
    await b.check_len("r")
    assert not b.led_events and int(dut.LED.value) == 4


# req: REQ-47
@cocotb.test()
async def test_baud_rate(dut):
    b = await Bench.create(dut)
    pulse = {}

    async def watch():
        await FallingEdge(dut.UART_RXD_OUT)
        t0 = get_sim_time("ns")
        await RisingEdge(dut.UART_RXD_OUT)
        pulse["w"] = get_sim_time("ns") - t0

    cocotb.start_soon(watch())
    await b.rd(2)
    # first response byte 0x5A: start bit and data bit 0 are both low = two bit times
    assert abs(pulse["w"] - 2 * N * 10) <= 10, f"low pulse {pulse['w']} ns, bit time {N} clocks"


# req: REQ-09, REQ-35, REQ-46, REQ-54
@cocotb.test()
async def test_reset_midway(dut):
    b = await Bench.create(dut)
    s = 0x0500
    await b.cmd(2, s, wrp(1, 0x1234), expect=0)
    await b.cmd(4, s + 1, stp(5), expect=0)
    await b.tick(5)
    assert await b.rd(5) == 17
    await b.raw(mk(1, s + 2, rdp(0), bad_crc=True), expect="silent")
    await b.wr(3, 5)
    await b.wr(6, 2)
    assert int(dut.LED.value) == 2
    await b.push([1, 0, 0], end=False)  # partial packet lost by the reset
    await b.reset_dut()
    assert int(dut.LED.value) == 0
    for off in (2, 3, 4, 5, 6, 7, 9):
        assert await b.rd(off) == 0, f"offset {off} after reset"
    assert await b.regval(1, s) == 0  # first packet after reset: same number accepted
    assert await b.regval(7, s + 1) == 0
    assert await b.regval(6, s + 2) == 100
    c = await b.stat(s + 3)
    assert c == [3, 0, 0, 0, 0, 0, 0, 0, 0]
    await b.cmd(4, s + 4, stp(4), expect=0)
    await b.tick(4)
    await frame_check(b, 0, 4)


# req: REQ-25, REQ-26, REQ-40
@cocotb.test()
async def test_back_to_back(dut):
    b = await Bench.create(dut)
    s = 0x0800
    await b.push(mk(1, s, rdp(0)))
    await b.push(mk(3, s + 1))  # accepted at once, reply is the second one
    d = await b.check_buf("r")
    assert d[0] == 0x83 and int.from_bytes(d[2:4], "big") == s + 1
    assert counters(d)[0] == 1
    await b.push(mk(1, s + 2, rdp(0)))
    await b.push(mk(1, s + 3, rdp(0), bad_crc=True))
    assert await b.check_len("r") == 0  # no reply for the latest packet
    await b.push(mk(2, s + 4, wrp(2, 5)))
    d = await b.check_buf("r")
    assert d[0] == 0x82 and d[1] == 0
    b.check_led()


# req: REQ-24
@cocotb.test()
async def test_counter_wrap(dut):
    """The refused counters are 16 bits wide.  A full wrap needs 65536 packets, which the UART cannot deliver in
    a bench budget; UDP_FULL_WRAP=1 runs the whole wrap, the default run checks counting up to 20."""
    b = await Bench.create(dut)
    total = 65536 + 3 if os.environ.get("UDP_FULL_WRAP") == "1" else 20
    for _ in range(total):
        await b.push([0x00])
    c = await b.stat(0x0900)
    assert c[2] == total & 0xFFFF
    assert await b.regval(5, 0x0901) == total & 0xFFFF


def rand_valid(rnd, seq):
    typ = rnd.choices([1, 2, 3, 4, 5], [30, 25, 15, 15, 10])[0]
    if typ == 1:
        return mk(1, seq, rdp(rnd.choice([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 300])))
    if typ == 2:
        v = rnd.choice([0, 1, 0xFFFFFFFF, rnd.getrandbits(32)])
        return mk(2, seq, wrp(rnd.choice([0, 1, 2, 3, 3, 4, 5, 6, 7, 8]), v))
    if typ == 3:
        return mk(3, seq)
    if typ == 4:
        return mk(4, seq, stp(rnd.choice([0, 1, 3, 4, 5, 6, 9])))
    return mk(5, seq)


def rand_bad(rnd, seq):
    k = rnd.choice(["crc", "trunc", "extra", "len", "type", "wlen"])
    if k == "crc":
        typ = rnd.choice([1, 3, 5])
        return mk(typ, seq, rdp(rnd.randint(0, 9)) if typ == 1 else b"", bad_crc=True)
    if k == "trunc":
        pk = rand_valid(rnd, seq)
        return pk[:rnd.randint(1, len(pk) - 1)]
    if k == "extra":
        pk = rand_valid(rnd, seq)
        return pk + [rnd.getrandbits(8) for _ in range(rnd.randint(1, 4))]
    if k == "len":
        return mk(1, seq, rdp(0), ln=rnd.randint(9, 255))
    if k == "type":
        return mk(rnd.choice([0, 6, 7, 0x80, 0xFF]), seq, bytes(rnd.getrandbits(8) for _ in range(rnd.randint(0, 3))))
    typ = rnd.choice([1, 2, 3, 4, 5])
    n = rnd.choice([x for x in range(0, 9) if x != NEED[typ]])
    return mk(typ, seq, bytes(rnd.getrandbits(8) for _ in range(n)))


# req: REQ-01, REQ-06, REQ-07, REQ-08, REQ-12, REQ-26, REQ-31, REQ-32, REQ-45
@cocotb.test()
async def test_random_traffic(dut):
    b = await Bench.create(dut)
    rnd = random.Random(cocotb.RANDOM_SEED)
    dut._log.info(f"random seed {cocotb.RANDOM_SEED}")
    seq = rnd.randrange(65536)
    for step in range(15):
        kind = "start" if step == 0 else rnd.choices(["valid", "bad", "old", "tick", "take"], [5, 4, 2, 2, 1])[0]
        if kind == "tick":
            await b.tick(rnd.choice([1, 2, 3, 4, 5, 8]))
            n = await b.check_len("t")
            if n and rnd.random() < 0.4:
                await b.check_buf("t", extra=True)
        elif kind == "take":
            await b.wr(8, 1)
            await b.check_len("t")
        else:
            seq = (seq + rnd.randint(1, 50)) & 0xFFFF
            if kind == "start":
                pk = mk(4, seq, stp(5))
            elif kind == "valid":
                pk = rand_valid(rnd, seq)
            elif kind == "bad":
                pk = rand_bad(rnd, seq)
            else:
                pk = mk(1, (seq - rnd.randint(1, 20)) & 0xFFFF, rdp(rnd.randint(0, 7)))
            await b.raw(pk, extra=rnd.random() < 0.25)
    await b.check_buf("t", extra=True)
    await b.stat((seq + 1) & 0xFFFF)
    assert await b.rd(9) == b.m.read_reg(9)
