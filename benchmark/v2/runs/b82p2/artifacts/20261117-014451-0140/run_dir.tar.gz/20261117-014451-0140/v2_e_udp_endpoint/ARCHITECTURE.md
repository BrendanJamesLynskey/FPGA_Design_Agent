# udp_endpoint architecture

## Block diagram

```text
 CPU_RESETN --> [reset_sync] --rst(active high)--> all blocks
 UART_TXD_IN --> [fpga_shell] <-- win_* --> [regs]
 UART_RXD_OUT <--                              |  IN byte/end flag
                                               v
                                          [pkt_rx + CRC-32] -> [cmd_exec] -> [reply_build] -> reply buffer -> RWORD/RLEN
                                                                    |  ^                         
                                                                    v  |                         
                                                              [telemetry] -> frame buffer -> TWORD/TLEN
 cmd_exec commands-carried-out count --> LED[15:0]
```

## Clock plan

One clock domain: CLK100MHZ, 100 MHz (10 ns), no MMCM. CPU_RESETN is asynchronous and passes through reset_sync (asynchronous assert, synchronous release); inside the design the reset is active high and synchronous. The UART receive input goes through a 2-flop synchroniser in the shell.

## Pin list

- CLK100MHZ: input, 100 MHz system clock
- CPU_RESETN: input, active-low reset button
- UART_TXD_IN: input, USB-UART into FPGA
- UART_RXD_OUT: output, USB-UART out of FPGA
- LED[15:0]: output, commands-carried-out count

## Resource prediction

About 2500 LUT and 2500 FF (range 1200 to 4000 each), no block RAM, no DSP. Reply and frame buffers (about 32 bytes each) sit in registers or distributed RAM, with one byte-wise CRC-32 engine.
