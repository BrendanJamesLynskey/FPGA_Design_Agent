// Port-only checker for v2_e_udp_endpoint_top (bound in udp_checker_bind.sv).
module udp_checker (
  input        clk,
  input        rst,
  input [15:0] LED,
  input        tx,
  input        rx
);
  reg seen_rst = 1'b0;
  reg past_ok  = 1'b0;
  always @(posedge clk) begin
    past_ok <= 1'b1;
    if (rst) seen_rst <= 1'b1;
  end

`include "v_macros.svh"

  `V_NEXT(A_led_step, 1'b1, (LED == $past(LED)) || (LED == ($past(LED) + 16'd1))) // req: REQ-45
  `V_COVER(C_led_nonzero, LED != 16'd0) // req: REQ-45
  `V_COVER(C_led_change, LED != $past(LED)) // req: REQ-45
  `V_COVER(C_tx_start, !tx) // req: REQ-47
  `V_COVER(C_rx_start, !rx) // req: REQ-47
endmodule
