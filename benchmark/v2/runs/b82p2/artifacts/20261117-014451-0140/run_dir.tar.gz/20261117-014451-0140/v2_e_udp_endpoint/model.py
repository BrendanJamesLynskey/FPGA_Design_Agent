import zlib


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000000, BUILD_STAMP=0,
                 ID_WORD=1430540337, MAX_PAYLOAD=8, DEFAULT_PERIOD_TICKS=100,
                 MIN_PERIOD_TICKS=4, REPLY_BUILD_CYCLES=100, TELEMETRY_TYPE=192):
        self.p = dict(ID_WORD=ID_WORD, MAX_PAYLOAD=MAX_PAYLOAD,
                      DEF=DEFAULT_PERIOD_TICKS, MIN=MIN_PERIOD_TICKS,
                      TT=TELEMETRY_TYPE)
        self.inputs = {}
        self.reset()

    def reset(self):
        self.buf = []
        self.scratch = [0, 0, 0]
        self.cnt = [0] * 7  # cmds, badcrc, short, long, repeated, ooo, other
        self.refused = 0
        self.have_last = False
        self.last = 0
        self.period = self.p['DEF']
        self.tel_on = False
        self.tick_count = 0
        self.ticks = 0
        self.pending = 0
        self.held = None
        self.fseq = 0
        self.fcount = 0
        self.reply = b''
        self.ridx = 0
        self.tidx = 0

    # ---- helpers
    @staticmethod
    def _crc(b):
        return zlib.crc32(bytes(b)).to_bytes(4, 'little')

    def _inc(self, i):
        self.cnt[i] = (self.cnt[i] + 1) & 0xFFFF

    def _refuse(self, i):
        self._inc(i)
        self.refused = (self.refused + 1) & 0xFFFF

    def _mk_reply(self, typ, status, seq, payload):
        b = bytes([(typ | 0x80) & 0xFF, status, (seq >> 8) & 0xFF, seq & 0xFF,
                   len(payload)]) + bytes(payload)
        return b + self._crc(b)

    def _process(self):
        pk = self.buf
        self.buf = []
        n = len(pk)
        self.reply = b''
        if n < 4:
            self._refuse(2)
            return
        ln = pk[1]
        if ln > self.p['MAX_PAYLOAD'] or n > 8 + ln:
            self._refuse(3)
            return
        if n < 8 + ln:
            self._refuse(2)
            return
        if self._crc(pk[:-4]) != bytes(pk[-4:]):
            self._refuse(1)
            return
        typ = pk[0]
        seq = (pk[2] << 8) | pk[3]
        pay = pk[4:4 + ln]
        if typ not in (1, 2, 3, 4, 5):
            self._refuse(6)
            self.reply = self._mk_reply(typ, 1, seq, b'')
            return
        need = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}[typ]
        if ln != need:
            self._refuse(6)
            self.reply = self._mk_reply(typ, 2, seq, b'')
            return
        if self.have_last:
            d = (seq - self.last) & 0xFFFF
            if not (1 <= d <= 32767):
                self._refuse(4 if d == 0 else 5)
                self.reply = self._mk_reply(typ, 4, seq, b'')
                return
        self.have_last = True
        self.last = seq
        status = 0
        out = b''
        if typ in (1, 2):
            reg = pay[0] << 8 | pay[1] if False else pay[0]
            # register number is the first payload byte(s): use first byte
            if typ == 1:
                reg = (pay[0] << 8) | pay[1] if False else pay[1] if pay[0] == 0 else 0xFF
            else:
                reg = pay[1] if pay[0] == 0 else 0xFF
            if reg >= 8:
                status = 3
            elif typ == 1:
                out = self._cmd_read(reg).to_bytes(4, 'big')
            else:
                if reg in (1, 2, 3):
                    self.scratch[reg - 1] = int.from_bytes(bytes(pay[2:6]), 'big')
                else:
                    status = 5
            if status:
                self._refuse(6)
                self.reply = self._mk_reply(typ, status, seq, b'')
                return
        elif typ == 3:
            o = b''
            for c in self.cnt:
                o += c.to_bytes(2, 'big')
            o += self.fcount.to_bytes(2, 'big') + bytes([1 if self.tel_on else 0])
            out = o
        elif typ == 4:
            per = (pay[0] << 8) | pay[1]
            if per != 0:
                self.period = max(per, self.p['MIN'])
            self.tel_on = True
            self.tick_count = 0
        elif typ == 5:
            self.tel_on = False
            self.held = None
        self._inc(0)
        self.reply = self._mk_reply(typ, 0, seq, out)

    def _cmd_read(self, reg):
        if reg == 0:
            return self.p['ID_WORD'] & 0xFFFFFFFF
        if reg in (1, 2, 3):
            return self.scratch[reg - 1]
        if reg == 4:
            return self.cnt[0]
        if reg == 5:
            return self.refused
        if reg == 6:
            return self.period
        return self.ticks

    def _tick(self):
        self.ticks = (self.ticks + 1) & 0xFFFFFFFF
        if self.tel_on:
            self.tick_count += 1
            if self.tick_count >= self.period:
                self.tick_count = 0
                if self.held is None:
                    b = bytes([self.p['TT'] & 0xFF, 0, (self.fseq >> 8) & 0xFF,
                               self.fseq & 0xFF, 8]) + self.ticks.to_bytes(4, 'big') \
                        + self.cnt[0].to_bytes(2, 'big') + self.refused.to_bytes(2, 'big')
                    self.held = b + self._crc(b)
                    self.fseq = (self.fseq + 1) & 0xFFFF
                    self.fcount = (self.fcount + 1) & 0xFFFF

    @staticmethod
    def _word(data, i):
        seg = bytes(data[4 * i:4 * i + 4])
        seg = seg + bytes(4 - len(seg))
        return int.from_bytes(seg, 'big')

    # ---- API
    def step(self, inputs=None):
        if inputs:
            self.inputs.update(inputs)
        if self.pending > 0:
            self.pending -= 1
            self._tick()
        return {'UART_RXD_OUT': 1, 'LED': self.cnt[0] & 0xFFFF}

    def read_reg(self, offset):
        if offset == 2:
            return len(self.reply)
        if offset == 3:
            return self.ridx
        if offset == 4:
            return self._word(self.reply, self.ridx)
        if offset == 5:
            return len(self.held) if self.held else 0
        if offset == 6:
            return self.tidx
        if offset == 7:
            return self._word(self.held, self.tidx) if self.held else 0
        if offset == 9:
            return 1 if self.tel_on else 0
        return 0

    def write_reg(self, offset, value):
        if offset == 0:
            self.buf.append(value & 0xFF)
            if value & 0x100:
                self._process()
        elif offset == 1:
            self.pending = value & 0xFF
        elif offset == 3:
            self.ridx = value & 0x7F
        elif offset == 6:
            self.tidx = value & 0x7F
        elif offset == 8:
            self.held = None
