import zlib


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000, BUILD_STAMP=0,
                 ID_WORD=1430540337, MAX_PAYLOAD=8, NUM_REGS=8,
                 TELEMETRY_PERIOD_RESET=100, TELEMETRY_PERIOD_MIN=4,
                 TICK_WRITE_MAX=255, REPLY_BUILD_MAX_CYCLES=100):
        self.p = dict(ID_WORD=ID_WORD, MAX_PAYLOAD=MAX_PAYLOAD, NUM_REGS=NUM_REGS,
                      PRST=TELEMETRY_PERIOD_RESET, PMIN=TELEMETRY_PERIOD_MIN,
                      TMAX=TICK_WRITE_MAX)
        self.reset()

    def reset(self):
        self.buf = []
        self.scratch = [0, 0, 0, 0]
        self.cnt = [0] * 7  # ok, badchk, short, long, repeat, ooo, other
        self.refused = 0
        self.have_last = False
        self.last = 0
        self.period = self.p['PRST']
        self.tele_on = False
        self.tcount = 0
        self.ticks = 0
        self.pending = 0
        self.held = None
        self.fseq = 0
        self.fcount = 0
        self.reply = []
        self.busy = 0
        self.ridx = 0
        self.tidx = 0
        self.inputs = {}

    # ---- helpers
    @staticmethod
    def _crc(b):
        return list(zlib.crc32(bytes(b)).to_bytes(4, 'little'))

    def _refuse(self, i):
        self.cnt[i] = (self.cnt[i] + 1) & 0xFFFFFFFF
        self.refused = (self.refused + 1) & 0xFFFFFFFF

    def _mkreply(self, typ, status, seq, payload):
        b = [(typ | 0x80) & 0xFF, status, seq >> 8, seq & 0xFF, len(payload)] + list(payload)
        return b + self._crc(b)

    def _packet(self, b):
        n = len(b)
        self.reply = []
        if n < 4:
            self._refuse(2)
            return
        ln = b[1]
        if ln > 8 or n > 8 + ln:
            self._refuse(3)
            return
        if n < 8 + ln:
            self._refuse(2)
            return
        if self._crc(b[:-4]) != b[-4:]:
            self._refuse(1)
            return
        typ = b[0]
        seq = (b[2] << 8) | b[3]
        pl = b[4:4 + ln]
        need = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}
        if typ not in need:
            self._refuse(6)
            self.reply = self._mkreply(typ, 1, seq, [])
            return
        if ln != need[typ]:
            self._refuse(6)
            self.reply = self._mkreply(typ, 2, seq, [])
            return
        if self.have_last:
            d = (seq - self.last) & 0xFFFF
            if not (1 <= d <= 32767):
                self._refuse(4 if d == 0 else 5)
                self.reply = self._mkreply(typ, 4, seq, [])
                return
        self.have_last = True
        self.last = seq
        payload = []
        if typ in (1, 2):
            reg = (pl[0] << 8) | pl[1]
            if reg >= 8:
                self._refuse(6)
                self.reply = self._mkreply(typ, 3, seq, [])
                return
            if typ == 2:
                if reg == 0 or reg >= 4:
                    self._refuse(6)
                    self.reply = self._mkreply(typ, 5, seq, [])
                    return
                self.scratch[reg] = int.from_bytes(bytes(pl[2:6]), 'big')
            else:
                v = self._regval(reg)
                payload = list(v.to_bytes(4, 'big'))
        elif typ == 3:
            for c in self.cnt:
                payload += [(c >> 8) & 0xFF, c & 0xFF]
            payload += [(self.fcount >> 8) & 0xFF, self.fcount & 0xFF,
                        1 if self.tele_on else 0]
        elif typ == 4:
            per = (pl[0] << 8) | pl[1]
            if per:
                self.period = max(per, self.p['PMIN'])
            self.tele_on = True
            self.tcount = 0
        elif typ == 5:
            self.tele_on = False
            self.held = None
        self.cnt[0] = (self.cnt[0] + 1) & 0xFFFFFFFF
        self.reply = self._mkreply(typ, 0, seq, payload)

    def _regval(self, r):
        if r == 0:
            return self.p['ID_WORD'] & 0xFFFFFFFF
        if r in (1, 2, 3):
            return self.scratch[r]
        if r == 4:
            return self.cnt[0] & 0xFFFFFFFF
        if r == 5:
            return self.refused & 0xFFFFFFFF
        if r == 6:
            return self.period
        if r == 7:
            return self.ticks & 0xFFFFFFFF
        return 0

    @staticmethod
    def _word(b, i):
        v = 0
        for k in range(4):
            j = 4 * i + k
            v = (v << 8) | (b[j] if j < len(b) else 0)
        return v

    # ---- register window
    def write_reg(self, offset, value):
        value = int(value)
        if offset == 0:
            self.buf.append(value & 0xFF)
            if value & 0x100:
                b = self.buf
                self.buf = []
                self._packet(b)
                self.busy = 1
        elif offset == 1:
            self.pending = min(value & 0xFF, self.p['TMAX'])
        elif offset == 3:
            self.ridx = value & 0x7F
        elif offset == 6:
            self.tidx = value & 0x7F
        elif offset == 8:
            self.held = None

    def read_reg(self, offset):
        if offset == 2:
            return len(self.reply)
        if offset == 3:
            return self.ridx
        if offset == 4:
            return self._word(self.reply, self.ridx)
        if offset == 5:
            return len(self.held) if self.held else 0
        if offset == 6:
            return self.tidx
        if offset == 7:
            return self._word(self.held or [], self.tidx)
        if offset == 9:
            return (1 if self.tele_on else 0) | (2 if self.busy else 0)
        return 0

    # ---- clock
    def step(self, inputs=None):
        if inputs:
            self.inputs.update(inputs)
            if 'CPU_RESETN' in inputs and not inputs['CPU_RESETN']:
                self.reset()
                self.inputs['CPU_RESETN'] = 0
                return self._out()
        if self.busy:
            self.busy = 0
        if self.pending > 0:
            self.pending -= 1
            self.ticks = (self.ticks + 1) & 0xFFFFFFFF
            if self.tele_on:
                self.tcount += 1
                if self.tcount >= self.period:
                    self.tcount = 0
                    if self.held is None:
                        b = [0xC0, 0, self.fseq >> 8, self.fseq & 0xFF, 8]
                        b += list(self.ticks.to_bytes(4, 'big'))
                        c = self.cnt[0] & 0xFFFF
                        r = self.refused & 0xFFFF
                        b += [c >> 8, c & 0xFF, r >> 8, r & 0xFF]
                        self.held = b + self._crc(b)
                        self.fseq = (self.fseq + 1) & 0xFFFF
                        self.fcount = (self.fcount + 1) & 0xFFFF
        return self._out()

    def _out(self):
        return {'UART_RXD_OUT': 1, 'LED': self.cnt[0] & 0xFFFF}
