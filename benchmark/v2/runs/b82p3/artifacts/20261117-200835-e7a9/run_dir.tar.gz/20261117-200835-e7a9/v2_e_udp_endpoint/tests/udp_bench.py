"""cocotb bench for v2_e_udp_endpoint: everything goes through the UART test shell (window 0x80+offset),
and every register value the RTL returns is compared with model.py (and with independent expectations)."""
import random
import sys
import zlib
from pathlib import Path

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from model import Model  # noqa: E402

CPB = 8
PARAMS = {"CLKS_PER_BIT": CPB}
BASE = 0x80
ID_WORD = 0x55445031


def crc(b):
    return list(zlib.crc32(bytes(b)).to_bytes(4, "little"))


def mk(typ, seq, payload=(), ln=None, bad_crc=False):
    payload = list(payload)
    b = [typ & 0xFF, len(payload) if ln is None else ln, (seq >> 8) & 0xFF, seq & 0xFF] + payload
    c = crc(b)
    if bad_crc:
        c[0] ^= 0x5A
    return b + c


def val_of_read(rb):
    return int.from_bytes(bytes(rb[5:9]), "big")


def w32(v):
    return list((v & 0xFFFFFFFF).to_bytes(4, "big"))


def check_frame(fr, seq, ticks, cmds, refs):
    assert len(fr) == 17, fr
    assert fr[0] == 0xC0 and fr[1] == 0 and fr[4] == 8, fr
    assert ((fr[2] << 8) | fr[3]) == seq, (fr, seq)
    assert int.from_bytes(bytes(fr[5:9]), "big") == ticks, (fr, ticks)
    assert int.from_bytes(bytes(fr[9:11]), "big") == cmds & 0xFFFF, (fr, cmds)
    assert int.from_bytes(bytes(fr[11:13]), "big") == refs & 0xFFFF, (fr, refs)
    assert fr[13:] == crc(fr[:13])


class Bench:
    def __init__(self, dut):
        self.dut = dut
        self.m = Model(**PARAMS)
        self.gen = 0
        self.rxq = []
        self.framing_errors = 0
        self._clear()

    def _clear(self):
        self.ok = 0
        self.refused = 0
        self.ticks = 0
        self.exp = [0] * 7
        self.seq = 0x0100
        self.last_acc = None

    def sq(self, step=1):
        self.seq = (self.seq + step) & 0xFFFF
        return self.seq

    # ------------------------------------------------------------- uart
    async def start(self):
        clk = self.dut.CLK100MHZ
        cocotb.start_soon(Clock(clk, 10, "ns").start())
        self.dut.UART_TXD_IN.value = 1
        self.dut.CPU_RESETN.value = 0
        await ClockCycles(clk, 5)
        await self.reset()

    async def reset(self, cycles=12):
        clk = self.dut.CLK100MHZ
        self.gen += 1
        self.dut.UART_TXD_IN.value = 1
        self.dut.CPU_RESETN.value = 0
        await ClockCycles(clk, cycles)
        self.dut.CPU_RESETN.value = 1
        await ClockCycles(clk, 20)
        self.m.reset()
        self.rxq = []
        self._clear()
        cocotb.start_soon(self.rx_monitor(self.gen))
        self.led_ok()

    def rxd(self):
        try:
            return int(self.dut.UART_RXD_OUT.value)
        except ValueError:
            return 1

    async def rx_monitor(self, gen):
        clk = self.dut.CLK100MHZ
        while gen == self.gen:
            await RisingEdge(clk)
            if self.rxd() != 0:
                continue
            await ClockCycles(clk, CPB // 2)
            if self.rxd() != 0:
                continue
            v = 0
            for i in range(8):
                await ClockCycles(clk, CPB)
                v |= self.rxd() << i
            await ClockCycles(clk, CPB)
            if self.rxd() != 1:
                self.framing_errors += 1
            if gen == self.gen:
                self.rxq.append(v)

    async def tx_byte(self, b):
        clk = self.dut.CLK100MHZ
        for bit in [0] + [(b >> i) & 1 for i in range(8)] + [1]:
            self.dut.UART_TXD_IN.value = bit
            await ClockCycles(clk, CPB)

    async def xact(self, cmd, addr, data=0):
        clk = self.dut.CLK100MHZ
        self.rxq.clear()
        body = [cmd, addr] + list((data & 0xFFFFFFFF).to_bytes(4, "little"))
        chk = 0
        for x in body:
            chk ^= x
        for x in [0xA5] + body + [chk]:
            await self.tx_byte(x)
        n = 0
        while len(self.rxq) < 7:
            await ClockCycles(clk, 4)
            n += 1
            assert n < 5000, "no shell response to cmd %02x addr %02x" % (cmd, addr)
        r = list(self.rxq[:7])
        assert r[0] == 0x5A, r
        c = 0
        for x in r[1:6]:
            c ^= x
        assert c == r[6], r
        await ClockCycles(clk, CPB * 2)
        return r[1], int.from_bytes(bytes(r[2:6]), "little")

    # ------------------------------------------------- register window
    async def wr(self, off, val):
        st, _ = await self.xact(2, BASE + off, val)
        assert st == 0, "shell write status %d" % st
        self.m.write_reg(off, val)
        if off == 1:
            for _ in range((val & 0xFF) + 2):
                self.m.step()
        elif off == 0 and (val & 0x100):
            self.m.step()
            self.m.step()

    async def rd(self, off):
        st, d = await self.xact(1, BASE + off)
        assert st == 0, "shell read status %d" % st
        exp = self.m.read_reg(off)
        assert d == exp, "read offset %d: rtl 0x%08x model 0x%08x" % (off, d, exp)
        return d

    def led_ok(self):
        got = int(self.dut.LED.value)
        assert got == (self.ok & 0xFFFF), "LED 0x%04x expected 0x%04x" % (got, self.ok & 0xFFFF)

    # --------------------------------------------------------- packets
    async def push(self, pkt):
        for i, x in enumerate(pkt):
            await self.wr(0, x | (0x100 if i == len(pkt) - 1 else 0))

    async def read_reply(self):
        rlen = await self.rd(2)
        out = []
        for i in range((rlen + 3) // 4):
            if self.m.read_reg(3) != i:
                await self.wr(3, i)
            out += list((await self.rd(4)).to_bytes(4, "big"))
        return out[:rlen]

    def account(self, pkt, rb, cat=None, status=None, count=True):
        if rb:
            assert len(rb) >= 9 and rb[4] == len(rb) - 9, rb
            assert rb[-4:] == crc(rb[:-4]), rb
            assert rb[0] == ((pkt[0] | 0x80) & 0xFF), (pkt, rb)
            assert rb[2:4] == pkt[2:4], (pkt, rb)
            if rb[1] in (0, 3, 5):
                self.last_acc = (pkt[2] << 8) | pkt[3]
                self.seq = self.last_acc       # keep the number generator behind-free after explicit numbers
        if count:
            if (not rb) or rb[1] != 0:
                self.refused += 1
            else:
                self.ok += 1
        if cat is not None:
            self.exp[cat] += 1
            if cat == 0:
                assert rb and rb[1] == 0, ("expected ok", pkt, rb)
            elif cat in (1, 2, 3):
                assert rb == [], ("expected silent drop", pkt, rb)
            else:
                assert rb and rb[1] == status, ("expected status %s" % status, pkt, rb)

    async def send(self, pkt, cat=None, status=None, stat=False):
        await self.push(pkt)
        rb = await self.read_reply()
        if stat:
            await self.rd(9)
        self.account(pkt, rb, cat, status)
        self.led_ok()
        return rb

    async def reg(self, r, seq=None):
        rb = await self.send(mk(1, self.sq() if seq is None else seq, [r >> 8, r & 0xFF]), cat=0)
        assert len(rb) == 13
        return val_of_read(rb)

    async def wreg(self, r, v, cat=0, status=0, seq=None):
        return await self.send(mk(2, self.sq() if seq is None else seq, [r >> 8, r & 0xFF] + w32(v)),
                               cat=cat, status=status)

    async def counts(self, check=True):
        before = list(self.exp)
        rb = await self.send(mk(3, self.sq()), cat=0, status=0)
        assert len(rb) == 26 and rb[4] == 17, rb
        p = rb[5:22]
        cs = [(p[2 * i] << 8) | p[2 * i + 1] for i in range(7)]
        fc = (p[14] << 8) | p[15]
        on = p[16]
        if check:
            assert cs == [x & 0xFFFF for x in before], (cs, before)
        return cs, fc, on

    async def tick(self, n):
        await self.wr(1, n)
        self.ticks += n & 0xFF

    async def held_frame(self):
        n = await self.rd(5)
        out = []
        for i in range((n + 3) // 4):
            if self.m.read_reg(6) != i:
                await self.wr(6, i)
            out += list((await self.rd(7)).to_bytes(4, "big"))
        return out[:n]


async def new_bench(dut):
    b = Bench(dut)
    await b.start()
    return b


# ---------------------------------------------------------------- tests
# req: REQ-18, REQ-22, REQ-23, REQ-26, REQ-45
@cocotb.test()
async def test_reset_values(dut):
    b = await new_bench(dut)
    for off in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0x7F):
        assert await b.rd(off) == 0
    assert await b.reg(0, seq=0xABCD) == ID_WORD
    for r in (1, 2, 3):
        assert await b.reg(r) == 0
    before = b.ok
    assert await b.reg(4) == before
    assert await b.reg(5) == 0
    assert await b.reg(6) == 100
    assert await b.reg(7) == 0


# req: REQ-01, REQ-02, REQ-22, REQ-24, REQ-25, REQ-49
@cocotb.test()
async def test_registers(dut):
    b = await new_bench(dut)
    vals = {1: 0xDEADBEEF, 2: 0xFFFFFFFF, 3: 0x00000001}
    for r, v in vals.items():
        rb = await b.wreg(r, v)
        assert len(rb) == 9 and rb[0] == 0x82
    for r, v in vals.items():
        assert await b.reg(r) == v
    await b.wreg(1, 0x80000000)
    await b.wreg(3, 0)
    assert await b.reg(1) == 0x80000000
    assert await b.reg(2) == 0xFFFFFFFF
    assert await b.reg(3) == 0
    assert await b.reg(0) == ID_WORD
    before = b.ok
    assert await b.reg(4) == before
    assert await b.reg(4) == before + 1
    await b.send(mk(1, b.sq(), [0, 0], bad_crc=True), cat=1)
    await b.send([1, 2], cat=2)
    before = b.refused
    assert before == 2
    assert await b.reg(5) == before
    assert await b.reg(5) == before
    await b.send(mk(9, b.sq()), cat=6, status=1)
    assert await b.reg(5) == before + 1
    b.led_ok()


# req: REQ-11, REQ-16, REQ-17
@cocotb.test()
async def test_ro_writes(dut):
    b = await new_bench(dut)
    await b.wreg(1, 0x1111)
    await b.wreg(2, 0x2222)
    await b.wreg(3, 0x3333)
    await b.tick(5)
    for r in (0, 4, 5, 6, 7):
        rb = await b.wreg(r, 0xA5A5A5A5, cat=6, status=5)
        assert rb[1] == 5 and len(rb) == 9
    for r in (8, 9, 0x100, 0x1FF, 0xFFFF):
        rb = await b.wreg(r, 0x1, cat=6, status=3)
        assert rb[1] == 3
    assert await b.reg(0) == ID_WORD
    assert await b.reg(1) == 0x1111
    assert await b.reg(2) == 0x2222
    assert await b.reg(3) == 0x3333
    before = b.ok
    assert await b.reg(4) == before
    before = b.refused
    assert before == 10
    assert await b.reg(5) == before
    assert await b.reg(6) == 100
    assert await b.reg(7) == 5


# req: REQ-03, REQ-04, REQ-05, REQ-06, REQ-07, REQ-08, REQ-45
@cocotb.test()
async def test_refusal_silent(dut):
    b = await new_bench(dut)
    await b.send(mk(1, b.sq(), [0, 0]), cat=0)
    # too short: under four bytes whatever the bytes
    for pkt in ([0x01], [0x01, 0x00], [0x03, 0x00, 0x00], [0xFF, 0xFF, 0xFF], [0x01, 0xFF]):
        await b.send(pkt, cat=2)
        assert await b.rd(2) == 0
    good = mk(3, b.sq())
    await b.send(good[:4], cat=2)
    await b.send(good[:7], cat=2)
    await b.send(mk(1, b.sq(), [0, 0])[:-1], cat=2)
    await b.send(mk(2, b.sq(), [0, 1, 0, 0, 0, 5])[:11], cat=2)
    # too long
    await b.send(mk(1, b.sq(), [0, 0], ln=9), cat=3)
    await b.send(mk(1, b.sq(), [0] * 9), cat=3)
    await b.send(mk(1, b.sq(), [0, 0], ln=0xFF), cat=3)
    await b.send(good + [0], cat=3)
    await b.send(mk(1, b.sq(), [0, 0]) + [0x55], cat=3)
    await b.send(mk(2, b.sq(), [0, 1, 0, 0, 0, 5]) + [1, 2, 3], cat=3)
    await b.send(list(range(20)), cat=3)
    await b.send([3, 0] + list(range(38)), cat=3)
    await b.send(mk(1, b.sq(), [0, 0], ln=9, bad_crc=True), cat=3)   # too long beats bad check
    await b.send([1, 0xFF, 0, 0, 0], cat=3)
    # bad check
    await b.send(mk(1, b.sq(), [0, 0], bad_crc=True), cat=1)
    await b.send(mk(2, b.sq(), [0, 1, 0, 0, 0, 7], bad_crc=True), cat=1)
    await b.send(mk(3, b.sq(), bad_crc=True), cat=1)
    await b.send(mk(9, b.sq(), bad_crc=True), cat=1)             # bad check beats unknown type
    await b.send(mk(1, b.sq(), [0], bad_crc=True), cat=1)        # bad check beats wrong length
    await b.send(mk(3, b.last_acc, bad_crc=True), cat=1)         # bad check beats repeated number
    p = mk(3, b.sq())
    p[-1] ^= 0x80
    await b.send(p, cat=1)
    # the dropped write did not touch the register; a good packet afterwards still works
    assert await b.reg(1) == 0
    await b.send(mk(3, b.sq()), cat=0)
    await b.counts()


# req: REQ-09, REQ-10, REQ-11, REQ-16, REQ-20, REQ-21
@cocotb.test()
async def test_refusal_status(dut):
    b = await new_bench(dut)
    await b.send(mk(1, b.sq(), [0, 0]), cat=0)
    for t in (0, 6, 0x80, 0xFF, 0xC0, 0x07):
        rb = await b.send(mk(t, b.sq()), cat=6, status=1)
        assert rb[0] == ((t | 0x80) & 0xFF) and rb[1] == 1
    await b.send(mk(9, b.last_acc, [1, 2]), cat=6, status=1)      # type check beats sequence rule
    wl = [(1, []), (1, [0]), (1, [0, 0, 0]), (2, [0, 1, 0, 0, 0]), (2, [0] * 8), (2, [0, 1]),
          (3, [0]), (3, [0, 0]), (4, []), (4, [0]), (4, [0, 1, 2]), (5, [0, 0]), (5, [1])]
    for t, pl in wl:
        rb = await b.send(mk(t, b.sq(), pl), cat=6, status=2)
        assert rb[1] == 2
    await b.send(mk(1, b.last_acc, [0]), cat=6, status=2)         # length check beats sequence rule
    la = b.last_acc
    await b.send(mk(1, la, [0, 0]), cat=4, status=4)
    await b.send(mk(1, la - 1, [0, 0]), cat=5, status=4)
    await b.send(mk(1, la - 7, [0, 0]), cat=5, status=4)
    await b.send(mk(1, la + 0x8000, [0, 0]), cat=5, status=4)
    await b.send(mk(1, la + 40000, [0, 0]), cat=5, status=4)
    await b.send(mk(2, la, [0, 1, 0, 0, 0, 9]), cat=4, status=4)
    await b.send(mk(2, la, [0, 8, 0, 0, 0, 9]), cat=4, status=4)  # sequence beats register check
    await b.send(mk(2, la, [0, 0, 0, 0, 0, 9]), cat=4, status=4)
    for r in (8, 9, 0x100, 0x101, 0xFFFF):
        await b.send(mk(1, b.sq(), [r >> 8, r & 0xFF]), cat=6, status=3)
        await b.send(mk(2, b.sq(), [r >> 8, r & 0xFF, 0, 0, 0, 1]), cat=6, status=3)
    for r in (0, 4, 5, 6, 7):
        await b.send(mk(2, b.sq(), [0, r, 1, 2, 3, 4]), cat=6, status=5)
    await b.send(mk(1, b.sq(1), [0, 1]), cat=0)                   # exactly 1 ahead
    await b.send(mk(1, b.sq(32767), [0, 1]), cat=0)               # exactly 32767 ahead
    await b.counts()
    before = b.refused
    assert await b.reg(5) == before


# req: REQ-12, REQ-18, REQ-19
@cocotb.test()
async def test_sequence(dut):
    b = await new_bench(dut)
    for first, nxt, cat in ((0xFFFF, 0x0000, 0), (0x0000, 0x7FFF, 0), (0x8000, 0x0000, 5),
                            (0x1234, 0x1234, 4), (0x1234, 0x1235, 0), (0x7FFF, 0xFFFF, 5),
                            (0x7FFF, 0xFFFE, 0), (0x0000, 0xFFFF, 5), (0x0000, 0x8001, 5)):
        await b.reset()
        await b.send(mk(1, first, [0, 0]), cat=0)       # first packet takes any number
        if cat == 0:
            await b.send(mk(1, nxt, [0, 0]), cat=0)
        else:
            await b.send(mk(1, nxt, [0, 0]), cat=cat, status=4)
    await b.reset()
    seqs = [0xFFF0, 0xFFF1, 0xFFF1, 0xFFF0, 0x7FF0, 0xFFF0, 0xFFEF, 0x0000, 0x0000, 0x0010]
    last = None
    for s in seqs:
        new = last is None or 1 <= ((s - last) & 0xFFFF) <= 32767
        if new:
            await b.send(mk(1, s, [0, 6]), cat=0)
            last = s
        else:
            d = (s - last) & 0xFFFF
            await b.send(mk(1, s, [0, 6]), cat=4 if d == 0 else 5, status=4)
    await b.counts()
    # a number passing the sequence rule is used up even if the register check fails
    await b.reset()
    s = 0x2000
    await b.send(mk(1, s, [0, 9]), cat=6, status=3)
    await b.send(mk(1, s, [0, 0]), cat=4, status=4)
    await b.send(mk(1, s + 1, [0, 0]), cat=0)
    s = 0x2100
    await b.send(mk(2, s, [0, 4, 0, 0, 0, 1]), cat=6, status=5)
    await b.send(mk(2, s, [0, 1, 0, 0, 0, 1]), cat=4, status=4)
    await b.send(mk(2, s + 1, [0, 1, 0, 0, 0, 1]), cat=0)
    # refused before the sequence rule: the number is not used up
    s = 0x2200
    await b.send(mk(9, s), cat=6, status=1)
    await b.send(mk(1, s, [0, 0]), cat=0)
    s = 0x2300
    await b.send(mk(1, s, [0]), cat=6, status=2)
    await b.send(mk(1, s, [0, 0]), cat=0)
    await b.send(mk(1, s + 5, [0, 0], bad_crc=True), cat=1)
    await b.send(mk(1, s + 5, [0, 0]), cat=0)
    await b.counts()


# req: REQ-13, REQ-14, REQ-15, REQ-20, REQ-21
@cocotb.test()
async def test_sequence_unchanged(dut):
    b = await new_bench(dut)
    s = 0x4000
    await b.wreg(1, 0x11, seq=s)
    await b.send(mk(1, s, [0, 1]), cat=4, status=4)
    await b.send(mk(2, s - 5, [0, 1, 0, 0, 0, 0x22]), cat=5, status=4)
    await b.send(mk(2, s, [0, 1, 0, 0, 0, 0x33]), cat=4, status=4)
    await b.send(mk(2, s + 0x8000, [0, 2, 0, 0, 0, 0x44]), cat=5, status=4)
    # last accepted number unchanged: old number still refused, s+1 still accepted
    await b.send(mk(1, s - 5, [0, 1]), cat=5, status=4)
    await b.send(mk(1, s, [0, 1]), cat=4, status=4)
    assert await b.reg(1, seq=s + 1) == 0x11
    assert await b.reg(2, seq=s + 2) == 0
    before = b.refused
    assert await b.reg(5) == before
    # telemetry state unchanged by refused packets
    await b.send(mk(4, b.sq(), [0, 7]), cat=0)
    await b.tick(7)
    held = await b.held_frame()
    check_frame(held, 0, 7, b.ok, b.refused)
    la = b.last_acc
    await b.send(mk(4, la, [0, 9]), cat=4, status=4)
    await b.send(mk(5, la, []), cat=4, status=4)
    await b.send(mk(5, la - 9, []), cat=5, status=4)
    await b.send(mk(4, la + 0x8000, [0, 20]), cat=5, status=4)
    assert (await b.rd(9)) & 1 == 1
    assert await b.rd(5) == 17
    assert await b.held_frame() == held
    assert await b.reg(6) == 7
    await b.tick(7)
    assert await b.held_frame() == held
    await b.counts()


# req: REQ-02, REQ-04, REQ-06, REQ-08, REQ-20, REQ-21, REQ-27, REQ-28, REQ-29, REQ-58, REQ-59, REQ-60
@cocotb.test()
async def test_status_counters(dut):
    b = await new_bench(dut)
    cs, fc, on = await b.counts()
    assert cs == [0] * 7 and fc == 0 and on == 0
    cs, fc, on = await b.counts()
    assert cs[0] == 1
    for i in range(5):
        await b.send(mk(1, b.sq(), [0, 0], bad_crc=True), cat=1)
    for i in range(6):
        await b.send([0x03, 0x00, 0x01][:1 + i % 3], cat=2)
    for i in range(7):
        await b.send(mk(3, b.sq(), [0] * 9), cat=3)
    la = b.last_acc
    for i in range(2):
        await b.send(mk(3, la), cat=4, status=4)
    for i in range(3):
        await b.send(mk(3, la + 0x8000), cat=5, status=4)
    await b.send(mk(9, b.sq()), cat=6, status=1)
    await b.send(mk(1, b.sq(), [0, 9]), cat=6, status=3)
    await b.send(mk(1, b.sq(), [0]), cat=6, status=2)
    await b.send(mk(2, b.sq(), [0, 5, 0, 0, 0, 0]), cat=6, status=5)
    cs, fc, on = await b.counts()
    assert cs[1:] == [5, 6, 7, 2, 3, 4], cs
    assert fc == 0 and on == 0
    await b.send(mk(4, b.sq(), [0, 4]), cat=0)
    await b.tick(4)
    cs, fc, on = await b.counts()
    assert fc == 1 and on == 1
    await b.send(mk(5, b.sq()), cat=0)
    cs, fc, on = await b.counts()
    assert fc == 1 and on == 0
    assert cs[1:] == [5, 6, 7, 2, 3, 4]
    before = b.ok
    assert await b.reg(4) == before
    before = b.refused
    assert await b.reg(5) == before
    # NOTE: the 16-bit wrap at 65536 needs 65536 packets through the UART shell (~10^8 clocks);
    # the bench compares 16-bit masked values with the model but does not reach the wrap.


# req: REQ-30, REQ-31, REQ-32, REQ-33, REQ-34, REQ-35, REQ-36, REQ-37, REQ-38, REQ-39, REQ-40, REQ-41, REQ-42
# req: REQ-43, REQ-47, REQ-48, REQ-54, REQ-55, REQ-56, REQ-57, REQ-62
@cocotb.test()
async def test_telemetry(dut):
    b = await new_bench(dut)
    assert await b.reg(6) == 100
    await b.send(mk(4, b.sq(), [0, 2]), cat=0, stat=True)
    assert (await b.rd(9)) & 1 == 1
    assert await b.reg(6) == 4                      # 2 -> 4
    await b.tick(3)
    assert await b.rd(5) == 0
    await b.tick(1)
    fr = await b.held_frame()
    check_frame(fr, 0, 4, b.ok, b.refused)
    for idx in (5, 9, 127):
        await b.wr(6, idx)
        assert await b.rd(7) == 0
    await b.tick(4)                                  # falls due while held: dropped
    assert await b.held_frame() == fr
    await b.wr(8, 1)
    assert await b.rd(5) == 0
    await b.tick(4)
    fr3 = await b.held_frame()
    check_frame(fr3, 1, 12, b.ok, b.refused)         # the dropped frame took no sequence number
    cs, fc, on = await b.counts()
    assert fc == 2 and on == 1
    await b.tick(255)                                # many drops
    assert await b.held_frame() == fr3
    cs, fc, on = await b.counts()
    assert fc == 2
    await b.wr(8, 0)
    assert await b.rd(5) == 0
    await b.tick(1)                                  # tick 268, a multiple of 4
    fr = await b.held_frame()
    check_frame(fr, 2, 268, b.ok, b.refused)
    # restart restarts the count; period 0 keeps the period
    await b.wr(8, 0)
    await b.tick(3)
    await b.send(mk(4, b.sq(), [0, 0]), cat=0)
    assert await b.reg(6) == 4
    await b.tick(3)
    assert await b.rd(5) == 0
    await b.tick(1)
    fr = await b.held_frame()
    check_frame(fr, 3, 275, b.ok, b.refused)
    await b.wr(8, 0)
    for per, exp in ((1, 4), (3, 4), (4, 4), (5, 5), (0x0102, 258), (0, 258), (5, 5)):
        await b.send(mk(4, b.sq(), [per >> 8, per & 0xFF]), cat=0)
        assert await b.reg(6) == exp
    assert (await b.rd(9)) & 1 == 1
    await b.tick(4)
    assert await b.rd(5) == 0
    await b.tick(1)
    fr = await b.held_frame()
    check_frame(fr, 4, 280, b.ok, b.refused)
    # stop: off, held frame forgotten, no more frames
    await b.send(mk(5, b.sq()), cat=0)
    assert await b.rd(5) == 0
    assert (await b.rd(9)) & 1 == 0
    await b.tick(20)
    assert await b.rd(5) == 0
    # start again: frame sequence continues (not cleared by stop/start)
    await b.send(mk(4, b.sq(), [0, 0]), cat=0)
    assert await b.reg(6) == 5
    await b.tick(5)
    fr = await b.held_frame()
    check_frame(fr, 5, 305, b.ok, b.refused)
    cs, fc, on = await b.counts()
    assert fc == 6 and on == 1
    await b.send(mk(5, b.sq()), cat=0)
    await b.wr(8, 1)
    await b.tick(255)
    assert await b.rd(5) == 0
    assert await b.reg(7) == b.ticks


# req: REQ-44
@cocotb.test()
async def test_tick(dut):
    b = await new_bench(dut)
    assert await b.reg(7) == 0
    for n in (1, 0, 7, 255, 0x105, 3, 4):
        await b.tick(n)
        assert await b.reg(7) == b.ticks
    assert b.ticks == 1 + 7 + 255 + 5 + 3 + 4
    await b.tick(255)
    await b.tick(255)
    assert await b.reg(7) == b.ticks


# req: REQ-45, REQ-46, REQ-47, REQ-61, REQ-62
@cocotb.test()
async def test_host_interface(dut):
    b = await new_bench(dut)
    await b.wr(3, 0x1FF)
    assert await b.rd(3) == 0x7F
    await b.wr(6, 0x1FF)
    assert await b.rd(6) == 0x7F
    await b.wr(3, 5)
    assert await b.rd(3) == 5
    for off in (10, 11, 0x40, 0x7F):
        assert await b.rd(off) == 0
        await b.wr(off, 0xFFFFFFFF)
    for off in (2, 4, 5, 7, 9):
        await b.wr(off, 0xFFFFFFFF)
    assert await b.rd(3) == 5
    assert await b.rd(6) == 0x7F
    assert await b.rd(2) == 0 and await b.rd(5) == 0 and await b.rd(9) == 0
    assert await b.rd(4) == 0
    rb = await b.send(mk(1, b.sq(), [0, 0]), cat=0)
    assert len(rb) == 13 and val_of_read(rb) == ID_WORD
    assert await b.rd(2) == 13
    for idx in (4, 5, 127):
        await b.wr(3, idx)
        assert await b.rd(4) == 0
    await b.wr(3, 3)
    assert await b.rd(4) >> 24 == rb[12]
    rb = await b.wreg(1, 5)
    assert len(rb) == 9 and await b.rd(2) == 9
    await b.wr(3, 2)
    assert await b.rd(4) == rb[8] << 24
    await b.send([1, 2, 3], cat=2)
    assert await b.rd(2) == 0
    await b.wr(3, 0)
    assert await b.rd(4) == 0
    cs, fc, on = await b.counts()
    assert await b.rd(2) == 26
    await b.wr(3, 6)
    assert (await b.rd(4)) & 0xFFFF == 0
    for idx in (7, 127):
        await b.wr(3, idx)
        assert await b.rd(4) == 0
    await b.send(mk(4, b.sq(), [0, 4]), cat=0)
    await b.tick(4)
    assert await b.rd(5) == 17
    fr = await b.held_frame()
    assert fr[0] == 0xC0
    for idx in (5, 6, 100, 127):
        await b.wr(6, idx)
        assert await b.rd(7) == 0
    await b.wr(8, 1)
    assert await b.rd(5) == 0
    await b.wr(6, 0)
    assert await b.rd(7) == 0


# req: REQ-51, REQ-52, REQ-63
@cocotb.test()
async def test_timing(dut):
    b = await new_bench(dut)
    pk = mk(2, b.sq(), [0, 1, 0, 0, 0x12, 0x34])
    await b.push(pk)
    assert (await b.rd(9)) & 2 == 0                  # reply built long before the next shell access
    assert await b.rd(2) == 9                        # reply ready
    rb = await b.read_reply()
    b.account(pk, rb, 0, 0)
    # first byte of the next packet straight after the end-flag byte, replies not read in between
    A = mk(2, b.sq(), [0, 2, 0, 0, 0, 7])
    B = mk(1, b.sq(), [0, 2])
    await b.push(A)
    await b.push(B)
    rb = await b.read_reply()
    assert val_of_read(rb) == 7
    b.ok += 1
    b.exp[0] += 1
    b.account(B, rb, 0, 0)
    assert (await b.rd(9)) & 2 == 0
    await b.push([0x55])
    C = mk(1, b.sq(), [0, 1])
    await b.push(C)
    rb = await b.read_reply()
    assert val_of_read(rb) == 0x1234
    b.refused += 1
    b.exp[2] += 1
    b.account(C, rb, 0, 0)
    for _ in range(3):
        D = mk(3, b.sq())
        await b.push(D)
        b.ok += 1
        b.exp[0] += 1
    b.last_acc = b.seq
    await b.counts()
    b.led_ok()


# req: REQ-50, REQ-49, REQ-39, REQ-31, REQ-18, REQ-23
@cocotb.test()
async def test_reset(dut):
    b = await new_bench(dut)
    await b.wreg(1, 0x42)
    await b.send(mk(1, b.sq(), [0, 0], bad_crc=True), cat=1)
    await b.send(mk(4, b.sq(), [0, 9]), cat=0)
    await b.tick(9)
    assert await b.rd(5) == 17
    await b.tick(3)
    last = b.last_acc
    assert b.ok > 0
    await b.push([1, 0, 0])                          # part packet in the block
    await b.reset()
    for off in (2, 3, 5, 6, 9):
        assert await b.rd(off) == 0
    b.led_ok()
    assert await b.reg(1, seq=last) == 0             # first packet takes any number; scratch cleared
    before = b.ok
    assert await b.reg(4) == before
    assert await b.reg(5) == 0
    assert await b.reg(6) == 100
    assert await b.reg(7) == 0
    cs, fc, on = await b.counts(check=False)
    assert cs[1:] == [0] * 6 and fc == 0 and on == 0
    await b.send(mk(4, b.sq(), [0, 0]), cat=0)       # period 0 keeps the reset value 100
    await b.tick(99)
    assert await b.rd(5) == 0
    await b.tick(1)
    fr = await b.held_frame()
    check_frame(fr, 0, 100, b.ok, b.refused)
    cs, fc, on = await b.counts(check=False)
    assert fc == 1 and on == 1
    await b.reset()
    assert await b.rd(5) == 0 and await b.rd(9) == 0 and await b.rd(2) == 0
    await b.tick(255)
    assert await b.rd(5) == 0


# req: REQ-53
@cocotb.test()
async def test_clock_100mhz_smoke(dut):
    # Functional smoke at the 10 ns (100 MHz) period; the timing-closure claim itself is the
    # post_route:setup analysis gate. This checks the design works under the nominal clock.
    b = await new_bench(dut)
    assert await b.reg(0, seq=0x0042) == ID_WORD
    await b.send(mk(3, b.sq()), cat=0)
    await b.counts()
    b.led_ok()


def rand_payload(rng, typ):
    if typ == 1:
        return [0, rng.choice([0, 1, 2, 3, 4, 5, 6, 7])]
    if typ == 2:
        return [0, rng.choice([1, 2, 3])] + w32(rng.getrandbits(32))
    if typ == 4:
        return [0, rng.choice([0, 1, 3, 4, 5, 9])]
    return []


async def random_packet(b, rng):
    kinds = ["read", "write", "status", "tstart", "tstop", "badcrc", "short", "long", "unk", "wronglen",
             "badreg", "rowrite", "oldseq"]
    w = [10, 8, 4, 6, 4, 3, 3, 3, 3, 3, 3, 3, 4]
    kind = rng.choices(kinds, w)[0]
    s = b.sq(rng.choice([1, 1, 1, 2, 5]))
    typ_of = {"read": 1, "write": 2, "status": 3, "tstart": 4, "tstop": 5}
    if kind in typ_of:
        t = typ_of[kind]
        pkt = mk(t, s, rand_payload(rng, t))
    elif kind == "badcrc":
        t = rng.choice([1, 2, 3, 4, 5])
        pkt = mk(t, s, rand_payload(rng, t), bad_crc=True)
    elif kind == "short":
        if rng.random() < 0.5:
            pkt = [rng.getrandbits(8) for _ in range(rng.randint(1, 3))]
        else:
            g = mk(2, s, rand_payload(rng, 2))
            pkt = g[:rng.randint(4, len(g) - 1)]
    elif kind == "long":
        if rng.random() < 0.5:
            pkt = mk(1, s, rand_payload(rng, 1)) + [rng.getrandbits(8) for _ in range(rng.randint(1, 12))]
        else:
            pkt = mk(rng.choice([1, 3]), s, [0, 0], ln=rng.randint(9, 255))
    elif kind == "unk":
        pkt = mk(rng.choice([0, 6, 0x40, 0x80, 0xC0, 0xFF]), s,
                 [rng.getrandbits(8) for _ in range(rng.randint(0, 8))])
    elif kind == "wronglen":
        t = rng.choice([1, 2, 3, 4, 5])
        need = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}[t]
        n = rng.choice([x for x in range(0, 9) if x != need])
        pkt = mk(t, s, [rng.getrandbits(8) for _ in range(n)])
    elif kind == "badreg":
        t = rng.choice([1, 2])
        r = rng.choice([8, 9, 0x100, 0x1FF, 0xFFFF])
        pkt = mk(t, s, [r >> 8, r & 0xFF] + ([0, 0, 0, 1] if t == 2 else []))
    elif kind == "rowrite":
        pkt = mk(2, s, [0, rng.choice([0, 4, 5, 6, 7])] + w32(rng.getrandbits(32)))
    else:
        if rng.random() < 0.5:
            pkt = mk(1, rng.getrandbits(16), [0, rng.choice([0, 6, 7])])
        else:
            pkt = mk(3, rng.getrandbits(16))
    await b.send(pkt)


# req: REQ-01, REQ-02, REQ-03, REQ-05, REQ-07, REQ-09, REQ-10, REQ-12, REQ-20, REQ-25, REQ-34, REQ-35, REQ-44
# req: REQ-46, REQ-49
@cocotb.test()
async def test_random_traffic(dut):
    seed = getattr(cocotb, "RANDOM_SEED", 1)
    rng = random.Random(seed)
    b = await new_bench(dut)
    for i in range(36):
        r = rng.random()
        if r < 0.62:
            await random_packet(b, rng)
        elif r < 0.80:
            await b.tick(rng.choice([0, 1, 2, 3, 4, 5, 9, 17, 40, 255]))
            n = await b.rd(5)
            if n and rng.random() < 0.5:
                await b.held_frame()
        elif r < 0.86:
            await b.wr(8, 1)
            await b.rd(5)
        elif r < 0.92:
            await b.wr(rng.choice([3, 6]), rng.getrandbits(9))
            await b.rd(rng.choice([4, 7, 9, 2]))
        elif r < 0.96:
            await b.rd(rng.choice([10, 11, 0x20]))
            await b.wr(rng.choice([2, 4, 5, 7, 9, 10]), rng.getrandbits(32))
        elif r < 0.985:
            await b.reset()
        else:
            await b.counts(check=False)
    await b.counts(check=False)
    before = b.ok
    assert await b.reg(4) == before
    before = b.refused
    assert await b.reg(5) == before
