# v2_e_udp_endpoint architecture

## Block diagram

```text
 CPU_RESETN --> [xpm_cdc_async_rst] --> rst (active high, internal)
 UART_TXD_IN --> [fpga_shell] --win_*--> [pkt_rx + CRC-32] --> [seq_regs/counters] --> LED[15:0]
 UART_RXD_OUT <-- [fpga_shell]              |                        |
                                   [reply_builder]           [tick_gen] --> [telemetry]
                                   reply buffer (regs)       held frame buffer (regs)
 CLK100MHZ drives everything (single domain)
```

Packet bytes arrive through the IN register (bit 8 = end flag). The parser
updates a bitwise/bytewise CRC-32, applies the refusal order, and on the end
flag sets busy while the reply builder fills the reply buffer (at most 100
clocks). Replies and held telemetry frames are read back by word index.

## Clock plan

One clock domain: CLK100MHZ, 100 MHz (10 ns), no MMCM. The only crossings are
the asynchronous CPU_RESETN (xpm_cdc_async_rst, asynchronous assert,
synchronous release) and the asynchronous UART input (2-FF synchroniser in the
shell). Internal reset is active high and synchronous.

## Pin list

| Port | Dir | Pin | Note |
|---|---|---|---|
| CLK100MHZ | in | E3 | 100 MHz clock |
| CPU_RESETN | in | C12 | reset, active low |
| UART_TXD_IN | in | C4 | host to FPGA |
| UART_RXD_OUT | out | D4 | FPGA to host |
| LED[15:0] | out | board LEDs | commands carried out, low 16 bits |

## Resource estimate

LUT 700 to 2500, FF 800 to 2500, 0 BRAM, 0 DSP (buffers in registers, one
CRC-32 engine, 32-bit tick counter).
