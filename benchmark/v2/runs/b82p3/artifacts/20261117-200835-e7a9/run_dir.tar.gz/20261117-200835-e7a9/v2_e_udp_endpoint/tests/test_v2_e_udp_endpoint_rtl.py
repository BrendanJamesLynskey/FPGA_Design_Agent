"""Pytest entry: runs the cocotb bench (tests/udp_bench.py) against the RTL on three seeds."""
from pathlib import Path

import pytest

from flow import cocotb_run

DESIGN_DIR = Path(__file__).resolve().parents[1]
TEST_DIR = Path(__file__).resolve().parent
PARAMS = {"CLKS_PER_BIT": 8}     # same value as udp_bench.PARAMS (the model gets it too)


@pytest.mark.parametrize("seed", [1, 2, 3])
def test_v2_e_udp_endpoint_rtl(seed):
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN_DIR / "rtl").glob("*.sv"))
    cocotb_run.run("v2_e_udp_endpoint", "v2_e_udp_endpoint_top", sources, "udp_bench", TEST_DIR,
                   parameters=PARAMS, seed=seed)
