# v2_e_udp_endpoint architecture

UDP-style command and telemetry endpoint on the Nexys A7-100T. Packet bytes arrive through the test shell register window (IN), are checked, executed, and replies are read back through RWORD. Single clock domain, 100 MHz.

## Block diagram

```text
 CPU_RESETN --> rst_sync (xpm_cdc_async_rst) --> rst (active high)
                                                   |
 UART_TXD_IN --> fpga_shell --win_*--> win_regs --> pkt_rx --> cmd_exec --> reply_buf
 UART_RXD_OUT <--          <--rdata--     ^  |                  |  ^  \--> crc32
                                          |  +--> TICK -> telemetry --> held frame buf
                                          +------ RLEN/RWORD/TLEN/TWORD/STAT
 cmd_exec commands count --> LED[15:0]
```

## Clock plan

One domain: CLK100MHZ, 100 MHz, 10 ns. No derived clocks, no MMCM. The only crossing is the asynchronous CPU_RESETN button into the clock domain through xpm_cdc_async_rst (async assert, sync release). All internal reset is synchronous, active high. The UART input is synchronised inside fpga_shell.

## Design notes

- CRC-32 is byte-serial (one byte per clock), shared across checking and building; the reply is built in well under 100 clocks (at most 16+8 bytes plus CRC).
- Buffers of at most 28 bytes are distributed RAM or registers; block RAM is optional.
- Ticks come only from TICK writes (a down counter, new write replaces the remainder); a frame falls due every period-th tick.
- Datapath registers (buffers, CRC) are not reset; control and counters are.

## Pin list

| Port | Dir | Width | Role |
|---|---|---|---|
| CLK100MHZ | in | 1 | 100 MHz clock |
| CPU_RESETN | in | 1 | reset button, active low |
| UART_TXD_IN | in | 1 | USB-UART host to FPGA |
| UART_RXD_OUT | out | 1 | USB-UART FPGA to host |
| LED | out | 16 | commands-carried-out count |

## Predicted resources

LUT 900 to 3000, FF 800 to 3000, BRAM 0 to 1, DSP 0.
