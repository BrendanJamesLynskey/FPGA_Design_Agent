"""Reference model of the UDP command / telemetry endpoint, written from the request only.

Reply payloads the request does not state (write, telemetry start/stop, error replies) are
returned as None: the bench then does not compare them.
"""
import zlib

ID_WORD = 0x55445031
NEED_LEN = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}


def crc32(b):
    return zlib.crc32(bytes(b)) & 0xFFFFFFFF


def with_crc(body):
    return bytes(body) + crc32(body).to_bytes(4, "little")


def mk(t, seq, payload=b"", ln=None):
    """Command packet: type, length, seq (high byte first), payload, CRC-32 (low byte first)."""
    body = bytes([t, len(payload) if ln is None else ln, (seq >> 8) & 255, seq & 255]) + bytes(payload)
    return with_crc(body)


def rd_pkt(seq, reg):
    return mk(1, seq, reg.to_bytes(2, "big"))


def wr_pkt(seq, reg, val):
    return mk(2, seq, reg.to_bytes(2, "big") + val.to_bytes(4, "big"))


def status_pkt(seq):
    return mk(3, seq)


def tstart_pkt(seq, period):
    return mk(4, seq, period.to_bytes(2, "big"))


def tstop_pkt(seq):
    return mk(5, seq)


class Reply:
    def __init__(self, typ, status, seq, payload):
        self.typ, self.status, self.seq, self.payload = typ, status, seq, payload


class Endpoint:
    def __init__(self):
        self.reset()

    def reset(self):
        self.scratch = [0, 0, 0]
        self.cmds = 0
        self.refused = 0
        self.period = 100
        self.ticks = 0
        self.last_seq = None
        self.c_crc = self.c_short = self.c_long = self.c_rep = self.c_ooo = self.c_err = 0
        self.frames = 0
        self.fseq = 0
        self.tel_on = False
        self.tcnt = 0
        self.held = None

    # ---- time and telemetry
    def tick(self, n):
        for _ in range(n):
            self.ticks = (self.ticks + 1) & 0xFFFFFFFF
            if self.tel_on:
                self.tcnt += 1
                if self.tcnt >= self.period:
                    self.tcnt = 0
                    if self.held is None:
                        body = (bytes([0xC0, 0, (self.fseq >> 8) & 255, self.fseq & 255, 8])
                                + self.ticks.to_bytes(4, "big")
                                + (self.cmds & 0xFFFF).to_bytes(2, "big")
                                + (self.refused & 0xFFFF).to_bytes(2, "big"))
                        self.held = with_crc(body)
                        self.fseq = (self.fseq + 1) & 0xFFFF
                        self.frames = (self.frames + 1) & 0xFFFF

    def take(self):
        self.held = None

    # ---- packets
    def _reg(self, r):
        return {0: ID_WORD, 4: self.cmds & 0xFFFFFFFF, 5: self.refused & 0xFFFFFFFF,
                6: self.period, 7: self.ticks}.get(r, None) if r not in (1, 2, 3) else self.scratch[r - 1]

    def _fail(self, t, seq, status):
        self.refused += 1
        if status in (1, 2, 3, 5):
            self.c_err += 1
        return Reply(t, status, seq, None)

    def packet(self, raw):
        raw = bytes(raw)
        n = len(raw)
        if n < 4:                                   # fewer than four bytes: too short whatever
            self.c_short += 1; self.refused += 1
            return None
        ln = raw[1]
        if ln > 8 or n > 8 + ln:                    # too long
            self.c_long += 1; self.refused += 1
            return None
        if n < 8 + ln:                              # too short
            self.c_short += 1; self.refused += 1
            return None
        if crc32(raw[:-4]) != int.from_bytes(raw[-4:], "little"):
            self.c_crc += 1; self.refused += 1
            return None
        t = raw[0]
        seq = (raw[2] << 8) | raw[3]
        pl = raw[4:4 + ln]
        if t not in NEED_LEN:
            return self._fail(t, seq, 1)
        if ln != NEED_LEN[t]:
            return self._fail(t, seq, 2)
        if self.last_seq is not None:
            d = (seq - self.last_seq) % 65536
            if not 1 <= d <= 32767:
                self.refused += 1
                if d == 0:
                    self.c_rep += 1
                else:
                    self.c_ooo += 1
                return Reply(t, 4, seq, None)
        self.last_seq = seq                         # the number is used up from here on
        payload = b""
        if t in (1, 2):
            reg = (pl[0] << 8) | pl[1]
            if reg >= 8:
                return self._fail(t, seq, 3)
            if t == 2 and reg in (0, 4, 5, 6, 7):
                return self._fail(t, seq, 5)
            if t == 1:
                payload = self._reg(reg).to_bytes(4, "big")
            else:
                self.scratch[reg - 1] = int.from_bytes(pl[2:6], "big")
                payload = None
        elif t == 3:
            vals = [self.cmds, self.c_crc, self.c_short, self.c_long, self.c_rep, self.c_ooo,
                    self.c_err, self.frames]
            payload = b"".join((v & 0xFFFF).to_bytes(2, "big") for v in vals) + bytes([1 if self.tel_on else 0])
        elif t == 4:
            p = (pl[0] << 8) | pl[1]
            if p != 0:
                self.period = max(p, 4)
            self.tel_on = True
            self.tcnt = 0
            payload = None
        elif t == 5:
            self.tel_on = False
            self.held = None
            payload = None
        self.cmds += 1
        return Reply(t, 0, seq, payload)
