import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles

import spec_ref as R
from shell.tests.uart_bfm import UartBfm
from shell.host import protocol as p

PARAMS = {"CLKS_PER_BIT": 8, "TIMEOUT_CYCLES": 2000}

# window offsets (shell address = 0x80 + offset), from the answered register map
IN, TICK, RLEN, RIDX, RWORD, TLEN, TIDX, TWORD, TAKE, STAT = 0, 1, 2, 3, 4, 5, 6, 7, 8, 9


class Host:
    def __init__(self, dut):
        self.dut = dut
        self.bfm = UartBfm(dut.CLK100MHZ, dut.UART_TXD_IN, dut.UART_RXD_OUT, PARAMS["CLKS_PER_BIT"])

    async def xact(self, cmd, off, val=0):
        resp = await self.bfm.transact(p.encode_request(cmd, 0x80 + off, val))
        r = p.decode_response(resp)
        assert r.status == 0, f"shell refused window access offset {off}: status {r.status}"
        return r.data

    async def rd(self, off):
        return await self.xact(1, off)

    async def wr(self, off, val):
        await self.xact(2, off, val)

    async def send_packet(self, raw):
        for i, b in enumerate(raw):
            await self.wr(IN, b | (0x100 if i == len(raw) - 1 else 0))

    async def words(self, idx, word, n):
        out = b""
        for i in range((n + 3) // 4):
            await self.wr(idx, i)
            out += (await self.rd(word)).to_bytes(4, "big")
        return out


async def setup(dut):
    try:
        Clock(dut.CLK100MHZ, 10, unit="ns")
        cl = Clock(dut.CLK100MHZ, 10, unit="ns")
    except TypeError:
        cl = Clock(dut.CLK100MHZ, 10, units="ns")
    cocotb.start_soon(cl.start())
    dut.CPU_RESETN.value = 0
    dut.UART_TXD_IN.value = 1
    await ClockCycles(dut.CLK100MHZ, 20)
    dut.CPU_RESETN.value = 1
    await ClockCycles(dut.CLK100MHZ, 20)
    return Host(dut), R.Endpoint()


async def check_led(h, m):
    v = int(h.dut.LED.value) & 0xFFFF
    assert v == m.cmds & 0xFFFF, f"LED[15:0] should show commands carried out {m.cmds & 0xFFFF}, shows {v}"


async def exchange(h, m, raw, tag):
    await h.send_packet(raw)
    exp = m.packet(raw)
    n = await h.rd(RLEN)
    if exp is None:
        assert n == 0, f"{tag}: dropped packet should earn no reply (latest reply length 0), length is {n}"
        return None
    assert n >= 9, f"{tag}: reply length {n} shorter than the 9-byte minimum"
    data = await h.words(RIDX, RWORD, n)
    rep, pad = data[:n], data[n:]
    assert pad == bytes(len(pad)), f"{tag}: bytes past the end of the reply must read as zero, got {pad.hex()}"
    assert rep[0] == (exp.typ | 0x80) & 0xFF, f"{tag}: reply type byte expected {(exp.typ | 0x80) & 0xFF:#x}, got {rep[0]:#x}"
    assert rep[1] == exp.status, f"{tag}: status expected {exp.status}, got {rep[1]}"
    assert (rep[2] << 8 | rep[3]) == exp.seq, f"{tag}: reply sequence number expected {exp.seq:#x}, got {rep[2]:#x}{rep[3]:02x}"
    assert rep[4] == n - 9, f"{tag}: payload length byte {rep[4]} does not match reply of {n} bytes"
    assert int.from_bytes(rep[-4:], "little") == R.crc32(rep[:-4]), f"{tag}: reply CRC-32 trailer wrong (low byte first): {rep.hex()}"
    if exp.payload is not None:
        assert rep[5:-4] == exp.payload, f"{tag}: payload expected {exp.payload.hex()}, got {rep[5:-4].hex()}"
    return rep


async def check_frame(h, m, tag):
    n = await h.rd(TLEN)
    exp = m.held
    if exp is None:
        assert n == 0, f"{tag}: no frame held, telemetry frame length should be 0, got {n}"
        return
    assert n == len(exp), f"{tag}: held frame length expected {len(exp)}, got {n}"
    data = await h.words(TIDX, TWORD, n)
    assert data[:n] == exp, f"{tag}: held frame expected {exp.hex()}, got {data[:n].hex()}"
    assert data[n:] == bytes(len(data) - n), f"{tag}: bytes past frame end must read zero"
    st = await h.rd(STAT)
    assert (st & 1) == (1 if m.tel_on else 0), f"{tag}: status bit 0 (telemetry on) expected {int(m.tel_on)}, got {st & 1}"


@cocotb.test()
async def reads_writes_and_read_only_registers(dut):
    h, m = await setup(dut)
    s = 0x1234  # after reset the first packet may carry any number
    pkts = [R.rd_pkt(s + i, i) for i in range(9)]  # register 8 is unknown -> status 3
    pkts += [R.wr_pkt(s + 9, 1, 0xDEADBEEF), R.wr_pkt(s + 10, 2, 0x80000001), R.wr_pkt(s + 11, 3, 0x01020304),
             R.rd_pkt(s + 12, 1), R.rd_pkt(s + 13, 2), R.rd_pkt(s + 14, 3),
             R.wr_pkt(s + 15, 0, 5), R.wr_pkt(s + 16, 4, 5), R.wr_pkt(s + 17, 6, 5),
             R.rd_pkt(s + 18, 4), R.rd_pkt(s + 19, 5)]
    for i, k in enumerate(pkts):
        await exchange(h, m, k, f"packet {i}")
    await check_led(h, m)


@cocotb.test()
async def refusal_order_and_counters_in_status_reply(dut):
    h, m = await setup(dut)
    ex = lambda k, t: exchange(h, m, k, t)
    await ex(R.rd_pkt(10, 0), "first ok")
    good = R.rd_pkt(11, 1)
    await ex(R.mk(1, 11, b"\0\0\0\0\0\0\0\0\0"), "length byte 9: too long, silent")
    await ex(R.mk(1, 11, b"\0\0", ln=9)[:6], "length byte above 8 beats too short")
    await ex(good + b"\x00", "extra byte: too long")
    await ex(good[:-1], "one byte missing: too short")
    await ex(b"\xff\xff\xff", "under four bytes: too short whatever")
    await ex(good[:-1][:-1] , "corrupt+short is too short")
    bad = bytearray(good); bad[-1] ^= 1
    await ex(bytes(bad), "bad check silent")
    await ex(R.mk(9, 11, b""), "unknown type status 1")
    await ex(R.mk(0, 11, b""), "type 0 unknown")
    await ex(R.mk(1, 11, b"\0"), "read with 1-byte payload status 2")
    await ex(R.mk(3, 11, b"\0"), "status with payload status 2")
    await ex(good, "number 11 still new: type/length failures do not use it")
    await ex(good, "repeated number status 4")
    await ex(R.rd_pkt(6, 1), "old number status 4")
    await ex(R.wr_pkt(11, 1, 0x77), "repeated write changes nothing")
    await ex(R.rd_pkt(11 + 32768, 1), "difference 32768 refused")
    await ex(R.rd_pkt(12, 8), "unknown register status 3")
    await ex(R.rd_pkt(12, 1), "number used up by register failure")
    await ex(R.wr_pkt(13, 4, 1), "write to read-only status 5")
    await ex(R.tstart_pkt(13, 9), "repeated start refused, telemetry stays off")
    bad = bytearray(R.tstart_pkt(14, 9)); bad[5] ^= 1
    await ex(bytes(bad), "bad-check start ignored")
    await ex(R.rd_pkt(14, 1), "scratch unchanged by refused writes")
    await ex(R.rd_pkt(15, 4), "commands carried out before this read counted")
    await ex(R.rd_pkt(16, 5), "refused packets before this read counted")
    await ex(R.status_pkt(17), "status reply layout")
    await ex(R.status_pkt(18), "status again")
    await check_led(h, m)


@cocotb.test()
async def sequence_number_window_and_wrap(dut):
    h, m = await setup(dut)
    ex = lambda k, t: exchange(h, m, k, t)
    await ex(R.rd_pkt(0xFFF0, 1), "first any")
    await ex(R.rd_pkt(0x000F, 1), "wrap diff 31 new")
    await ex(R.rd_pkt(0x000F, 1), "repeat")
    await ex(R.rd_pkt(0x800F, 1), "diff 32768 refused")
    await ex(R.rd_pkt(0x800E, 1), "diff 32767 accepted")
    await ex(R.rd_pkt(0x0000, 1), "diff 32754 accepted")
    await ex(R.rd_pkt(0xFFFF, 1), "diff 65535 refused")
    await ex(R.status_pkt(0x0001), "status")
    await check_led(h, m)


@cocotb.test()
async def telemetry_frame_content_hold_drop_take(dut):
    h, m = await setup(dut)
    ex = lambda k, t: exchange(h, m, k, t)
    await ex(R.tstart_pkt(1, 5), "start period 5")
    assert (await h.rd(STAT)) & 1 == 1, "status bit 0 should show telemetry on"
    for n in (4, 0):
        await h.wr(TICK, n); m.tick(n)
    await check_frame(h, m, "no frame after 4 ticks")
    await h.wr(TICK, 1); m.tick(1)
    assert m.held is not None
    await check_frame(h, m, "frame due at tick 5")
    await ex(R.rd_pkt(2, 7), "uptime register")
    await h.wr(TICK, 10); m.tick(10)          # a frame falling due while one is held is dropped
    await check_frame(h, m, "held frame unchanged, second dropped")
    await ex(R.status_pkt(3), "frame count counts held frames only")
    await h.wr(TAKE, 1); m.take()
    await check_frame(h, m, "after take")
    await h.wr(TICK, 5); m.tick(5)
    await check_frame(h, m, "second frame sequence 1")
    await ex(R.status_pkt(4), "status shows 2 frames")
    await check_led(h, m)


@cocotb.test()
async def telemetry_start_period_restart_stop(dut):
    h, m = await setup(dut)
    ex = lambda k, t: exchange(h, m, k, t)
    await ex(R.tstart_pkt(1, 2), "period 2 becomes 4")
    await ex(R.rd_pkt(2, 6), "period register is 4")
    await ex(R.tstart_pkt(3, 0), "zero keeps the period")
    await ex(R.rd_pkt(4, 6), "period still 4")
    await h.wr(TICK, 3); m.tick(3)
    await ex(R.tstart_pkt(5, 0), "start restarts the count")
    await h.wr(TICK, 3); m.tick(3)
    await check_frame(h, m, "no frame 3 ticks after restart")
    await h.wr(TICK, 1); m.tick(1)
    await check_frame(h, m, "frame 4 ticks after restart")
    await ex(R.tstop_pkt(6), "stop forgets held frame")
    await check_frame(h, m, "after stop")
    await h.wr(TICK, 8); m.tick(8)
    await check_frame(h, m, "no frames while off")
    await ex(R.tstart_pkt(7, 7), "start period 7")
    await ex(R.rd_pkt(8, 6), "period 7")
    await h.wr(TICK, 7); m.tick(7)
    await check_frame(h, m, "frame sequence continues after stop/start")
    await ex(R.status_pkt(9), "status")
    await check_led(h, m)
