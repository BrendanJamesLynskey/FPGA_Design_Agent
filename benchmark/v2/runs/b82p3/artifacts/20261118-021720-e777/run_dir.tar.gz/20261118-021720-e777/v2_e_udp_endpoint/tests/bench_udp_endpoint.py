"""cocotb bench for v2_e_udp_endpoint: every register access goes through the test shell UART
(window 0x80 + offset) and every value read is compared with model.py.

The UART divider is overridden to CLKS_PER_BIT = 10 (the model has no timing parameter that matters here).
One shell access costs 15 bytes * 10 bits * 10 clocks = 1500 clocks, so every test is kept near or
below ~130 accesses (200 000 clocks).
"""
import os
import random
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, FallingEdge
from cocotb.utils import get_sim_time

from model import Model

CLKS = 10
PARAMS = {"CLKS_PER_BIT": CLKS}
ID_WORD = 0x55445031
WIN = 0x80


# ------------------------------------------------------------------ packet helpers
def crc4(b):
    return (zlib.crc32(bytes(b)) & 0xFFFFFFFF).to_bytes(4, "little")


def mkpkt(typ, seq, payload=b"", ln=None):
    payload = bytes(payload)
    ln = len(payload) if ln is None else ln
    body = bytes([typ & 0xFF, ln & 0xFF]) + (seq & 0xFFFF).to_bytes(2, "big") + payload
    return body + crc4(body)


def bad_crc(pkt):
    return bytes(pkt[:-1]) + bytes([pkt[-1] ^ 0xFF])


def rdpkt(seq, reg):
    return mkpkt(1, seq, reg.to_bytes(2, "big"))


def wrpkt(seq, reg, val):
    return mkpkt(2, seq, reg.to_bytes(2, "big") + (val & 0xFFFFFFFF).to_bytes(4, "big"))


def stat(seq):
    return mkpkt(3, seq)


def tstart(seq, period):
    return mkpkt(4, seq, period.to_bytes(2, "big"))


def tstop(seq):
    return mkpkt(5, seq)


def mkreply(typ, status, seq, payload=b""):
    body = bytes([(typ | 0x80) & 0xFF, status]) + seq.to_bytes(2, "big") + bytes([len(payload)]) + bytes(payload)
    return body + crc4(body)


def val_of(r):
    return int.from_bytes(r["data"][5:9], "big")


def check_reply(r, typ, status, seq, payload=None, tag=""):
    d = r["data"]
    assert r["len"] >= 9, f"{tag} reply too short: {r['len']}"
    assert d[0] == ((typ | 0x80) & 0xFF), f"{tag} reply type {d[0]:#x} for request type {typ:#x}"
    assert d[1] == status, f"{tag} reply status {d[1]} != {status}"
    assert d[2:4] == seq.to_bytes(2, "big"), f"{tag} reply seq {d[2:4].hex()} != {seq:#x}"
    if payload is not None:
        assert len(d) == r["len"], f"{tag} full reply needed to compare payload"
        assert r["len"] == 9 + len(payload), f"{tag} reply length {r['len']} for payload {len(payload)}"
        assert d[4] == len(payload), f"{tag} payload length byte {d[4]}"
        assert d[5:5 + len(payload)] == bytes(payload), f"{tag} payload {d[5:5 + len(payload)].hex()} != {bytes(payload).hex()}"
        assert d[-4:] == crc4(d[:-4]), f"{tag} reply crc wrong"


def check_tframe(fr, seq, ticks, cmds, refused):
    assert fr is not None and len(fr) == 17, f"frame {fr}"
    assert fr[0] == 0xC0 and fr[1] == 0, f"frame type/status {fr[:2].hex()}"
    assert fr[2:4] == seq.to_bytes(2, "big"), f"frame seq {fr[2:4].hex()} != {seq}"
    assert fr[4] == 8
    assert fr[5:9] == ticks.to_bytes(4, "big"), f"frame ticks {fr[5:9].hex()} != {ticks}"
    assert fr[9:11] == cmds.to_bytes(2, "big"), f"frame cmds {fr[9:11].hex()} != {cmds}"
    assert fr[11:13] == refused.to_bytes(2, "big"), f"frame refused {fr[11:13].hex()} != {refused}"
    assert fr[13:17] == crc4(fr[:13]), "frame crc"


def status_payload(ok, bad, short, long_, rep, ooo, other, fcount, tel):
    out = b""
    for c in (ok, bad, short, long_, rep, ooo, other, fcount):
        out += c.to_bytes(2, "big")
    return out + bytes([tel])


def make_clock(sig):
    try:
        return Clock(sig, 10, unit="ns")
    except TypeError:
        return Clock(sig, 10, units="ns")


# ------------------------------------------------------------------ environment
class Env:
    def __init__(self, dut):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        self.m = Model(**PARAMS)
        self.rxq = []
        self.rxt = []
        self.rxerr = 0
        self.nacc = 0
        self.min_gap = None
        self.max_gap = None

    @staticmethod
    async def create(dut):
        s = Env(dut)
        dut.UART_TXD_IN.value = 1
        dut.CPU_RESETN.value = 0
        cocotb.start_soon(make_clock(dut.CLK100MHZ).start())
        await ClockCycles(dut.CLK100MHZ, 8)
        dut.CPU_RESETN.value = 1
        await ClockCycles(dut.CLK100MHZ, 20)
        s.m.reset()
        cocotb.start_soon(s._rx())
        return s

    async def reset(self, cycles=6):
        self.dut.CPU_RESETN.value = 0
        await ClockCycles(self.clk, cycles)
        self.dut.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 10)
        self.m.reset()
        self.rxq.clear()
        self.rxt.clear()

    async def _rx(self):
        d = self.dut
        while True:
            await FallingEdge(d.UART_RXD_OUT)
            t0 = int(round(float(get_sim_time("ns")) / 10.0))
            await ClockCycles(self.clk, CLKS // 2)
            if int(d.UART_RXD_OUT.value) != 0:
                self.rxerr += 1
                continue
            b = 0
            for k in range(8):
                await ClockCycles(self.clk, CLKS)
                b |= int(d.UART_RXD_OUT.value) << k
            await ClockCycles(self.clk, CLKS)
            if int(d.UART_RXD_OUT.value) != 1:
                self.rxerr += 1
            self.rxq.append(b)
            self.rxt.append(t0)

    async def tx_byte(self, b):
        bits = [0] + [(b >> i) & 1 for i in range(8)] + [1]
        for v in bits:
            self.dut.UART_TXD_IN.value = v
            await ClockCycles(self.clk, CLKS)

    async def txn(self, cmd, addr, data=0):
        body = bytes([cmd, addr]) + (data & 0xFFFFFFFF).to_bytes(4, "little")
        chk = 0
        for b in body:
            chk ^= b
        req = bytes([0xA5]) + body + bytes([chk])
        self.rxq.clear()
        self.rxt.clear()
        for b in req:
            await self.tx_byte(b)
        waited = 0
        while len(self.rxq) < 7:
            await ClockCycles(self.clk, 10)
            waited += 10
            assert waited < 70 * CLKS + 3000, f"no shell response to cmd {cmd} addr {addr:#x}"
        await ClockCycles(self.clk, 2 * CLKS)
        r = self.rxq[:7]
        assert r[0] == 0x5A, f"response sync {r}"
        x = 0
        for b in r[1:6]:
            x ^= b
        assert x == r[6], f"response checksum {r}"
        assert r[1] == 0, f"shell status {r[1]} for cmd {cmd} addr {addr:#x}"
        for i in range(1, 7):
            g = self.rxt[i] - self.rxt[i - 1]
            self.min_gap = g if self.min_gap is None else min(self.min_gap, g)
            self.max_gap = g if self.max_gap is None else max(self.max_gap, g)
            assert 10 * CLKS - 1 <= g <= 11 * CLKS, f"response byte spacing {g} clocks, expected {10 * CLKS}"
        assert self.rxerr == 0, "UART framing error on FPGA output"
        self.nacc += 1
        return int.from_bytes(bytes(r[2:6]), "little")

    # register window access, mirrored on the model
    async def wr(self, off, val):
        await self.txn(2, WIN + off, val)
        self.m.write_reg(off, val)
        if off == 1:
            for _ in range(val & 0xFF):
                self.m.step()

    async def rd(self, off):
        v = await self.txn(1, WIN + off, 0)
        e = self.m.read_reg(off)
        assert v == e, f"register {off}: RTL {v:#x} model {e:#x}"
        return v

    async def led(self):
        out = self.m.step()
        v = int(self.dut.LED.value)
        assert v == out["LED"], f"LED {v:#x} model {out['LED']:#x}"
        return v

    async def ticks(self, n):
        while n > 0:
            k = min(n, 255)
            await self.wr(1, k)
            n -= k

    async def get_reply(self, mode):
        rl = await self.rd(2)
        data = b""
        if rl and mode:
            nw = (rl + 3) // 4 if mode == "full" else min(mode, (rl + 3) // 4)
            for i in range(nw):
                await self.wr(3, i)
                data += (await self.rd(4)).to_bytes(4, "big")
            if mode == "full":
                assert data[rl:] == bytes(len(data) - rl), "bytes past the end of the reply are not zero"
            data = data[:rl]
        return {"len": rl, "data": data}

    async def xfer(self, pkt, mode=1):
        n = len(pkt)
        for i, b in enumerate(pkt):
            await self.wr(0, b | (0x100 if i == n - 1 else 0))
        return await self.get_reply(mode)

    async def read_tframe(self):
        tl = await self.rd(5)
        if tl == 0:
            return None
        d = b""
        for i in range((tl + 3) // 4):
            await self.wr(6, i)
            d += (await self.rd(7)).to_bytes(4, "big")
        assert d[tl:] == bytes(len(d) - tl)
        return d[:tl]


# ------------------------------------------------------------------ directed tests
# req: REQ-19, REQ-20, REQ-22, REQ-23, REQ-45, REQ-48, REQ-49, REQ-51, REQ-52, REQ-55, REQ-56, REQ-12
@cocotb.test()
async def test_smoke_reset_values(dut):
    s = await Env.create(dut)
    for off in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 0x7F):
        assert await s.rd(off) == 0, f"reset/unmapped value at offset {off}"
    # read-only and unmapped registers ignore writes
    for off in (2, 4, 5, 7, 9, 10, 0x20):
        await s.wr(off, 0xFFFF)
    for off in (2, 4, 5, 7, 9, 10, 0x20, 3, 6):
        assert await s.rd(off) == 0
    assert int(dut.LED.value) == 0
    assert int(dut.UART_RXD_OUT.value) == 1
    r = await s.xfer(rdpkt(1, 0), "full")
    check_reply(r, 1, 0, 1, ID_WORD.to_bytes(4, "big"), "id")
    r = await s.xfer(rdpkt(2, 6), "full")
    check_reply(r, 1, 0, 2, (100).to_bytes(4, "big"), "period")
    r = await s.xfer(rdpkt(3, 7), "full")
    check_reply(r, 1, 0, 3, (0).to_bytes(4, "big"), "ticks")
    assert await s.rd(2) == 13
    assert await s.rd(9) == 0
    assert await s.rd(5) == 0
    assert await s.led() == 3
    # UART runs at CLKS_PER_BIT clocks per bit
    assert s.min_gap >= 10 * CLKS - 1 and s.max_gap <= 11 * CLKS


# req: REQ-52, REQ-39, REQ-40, REQ-20, REQ-22, REQ-12, REQ-23
@cocotb.test()
async def test_reset_clears_state(dut):
    s = await Env.create(dut)
    r = await s.xfer(wrpkt(1, 1, 0xCAFEBABE), 0)
    assert r["len"] == 9
    r = await s.xfer(tstart(2, 4), 0)
    assert r["len"] == 9
    await s.ticks(8)
    assert await s.rd(5) == 17
    assert await s.rd(9) == 1
    await s.wr(3, 5)
    await s.wr(6, 3)
    await s.wr(0, 0x01)  # unfinished packet
    await s.wr(0, 0x02)
    assert await s.rd(9) == 3
    assert int(dut.LED.value) == 2
    await s.reset()
    for off in (9, 5, 2, 3, 6, 4, 7):
        assert await s.rd(off) == 0, f"offset {off} after reset"
    assert int(dut.LED.value) == 0
    r = await s.xfer(rdpkt(1, 1), 3)  # the same sequence number is accepted again
    check_reply(r, 1, 0, 1)
    assert val_of(r) == 0
    r = await s.xfer(rdpkt(2, 6), 3)
    check_reply(r, 1, 0, 2)
    assert val_of(r) == 100
    await s.xfer(tstart(3, 4), 0)
    await s.ticks(4)
    check_tframe(await s.read_tframe(), 0, 4, 3, 0)
    r = await s.xfer(stat(4), "full")
    check_reply(r, 3, 0, 4, status_payload(3, 0, 0, 0, 0, 0, 0, 1, 1), "status after reset")


# req: REQ-01, REQ-18, REQ-25, REQ-06, REQ-21
@cocotb.test()
async def test_crc_and_reply_format(dut):
    s = await Env.create(dut)
    r = await s.xfer(stat(0x1234), "full")
    check_reply(r, 3, 0, 0x1234, status_payload(0, 0, 0, 0, 0, 0, 0, 0, 0), "status")
    r = await s.xfer(rdpkt(0x1235, 0), "full")
    check_reply(r, 1, 0, 0x1235, ID_WORD.to_bytes(4, "big"), "read")
    r = await s.xfer(wrpkt(0x1236, 2, 0x01020304), "full")
    check_reply(r, 2, 0, 0x1236, b"", "write")
    r = await s.xfer(mkpkt(0x41, 0x1237), "full")
    check_reply(r, 0x41, 1, 0x1237, b"", "unknown type")
    assert await s.led() == 3


# req: REQ-02, REQ-03, REQ-04, REQ-05, REQ-15, REQ-45, REQ-03
@cocotb.test()
async def test_drop_cases(dut):
    s = await Env.create(dut)
    cases = [
        (bytes([0x01]), "short"),
        (bytes([0x01, 0x02, 0x00]), "short"),
        (bytes([0x01, 0x09, 0x00, 0x01]), "long"),       # long beats short
        (bytes([0x03, 0xFF]), "long"),
        (stat(1) + b"\x55", "long"),
        (rdpkt(1, 0)[:-1], "short"),
        (mkpkt(1, 1, b"\x00\x01", ln=9), "long"),
        (bad_crc(mkpkt(1, 1, b"\x00\x01", ln=9)), "long"),  # long beats bad check
        (bad_crc(rdpkt(1, 0))[:-1], "short"),             # short beats bad check
        (bad_crc(rdpkt(1, 0)), "bad"),
        (bad_crc(mkpkt(9, 1)), "bad"),                    # bad check beats unknown type
        (bad_crc(stat(1)), "bad"),
    ]
    exp = {"short": 0, "long": 0, "bad": 0}
    for pkt, kind in cases:
        r = await s.xfer(pkt, 0)
        assert r["len"] == 0, f"dropped packet {pkt.hex()} earned a reply"
        exp[kind] += 1
    r = await s.xfer(stat(1), "full")
    check_reply(r, 3, 0, 1, status_payload(0, exp["bad"], exp["short"], exp["long"], 0, 0, 0, 0, 0), "counters")


# req: REQ-15, REQ-02, REQ-03, REQ-04, REQ-09, REQ-26, REQ-27, REQ-25, REQ-51, REQ-45
@cocotb.test()
async def test_status_counters(dut):
    s = await Env.create(dut)
    assert (await s.xfer(rdpkt(10, 0), 0))["len"] == 13
    assert (await s.xfer(bad_crc(rdpkt(11, 0)), 0))["len"] == 0
    assert (await s.xfer(bytes([1, 2, 0]), 0))["len"] == 0
    assert (await s.xfer(bytes([1, 9, 0, 12]), 0))["len"] == 0
    assert (await s.xfer(stat(12) + b"\x55", 0))["len"] == 0
    check_reply(await s.xfer(rdpkt(10, 0), 1), 1, 4, 10, tag="repeated")
    check_reply(await s.xfer(rdpkt(5, 0), 1), 1, 4, 5, tag="old")
    check_reply(await s.xfer(mkpkt(9, 11), 1), 9, 1, 11, tag="unknown type")
    check_reply(await s.xfer(mkpkt(1, 11, b"\0\0\0"), 1), 1, 2, 11, tag="wrong length")
    r = await s.xfer(stat(11), "full")
    # counters are the values before this command is counted
    check_reply(r, 3, 0, 11, status_payload(1, 1, 1, 2, 1, 1, 2, 0, 0), "status")
    assert await s.led() == 2


# req: REQ-24, REQ-16, REQ-51
@cocotb.test()
async def test_counter_registers_read(dut):
    s = await Env.create(dut)
    await s.xfer(rdpkt(1, 0), 0)                    # commands 1
    assert (await s.xfer(bad_crc(tstop(2)), 0))["len"] == 0   # refused 1
    check_reply(await s.xfer(mkpkt(9, 2), 1), 9, 1, 2)         # refused 2, seq 2 not consumed
    r = await s.xfer(rdpkt(2, 4), 3)
    check_reply(r, 1, 0, 2)
    assert val_of(r) == 1, "register 4 must show the count before this read"
    r = await s.xfer(rdpkt(3, 4), 3)
    assert val_of(r) == 2
    r = await s.xfer(rdpkt(4, 5), 3)
    check_reply(r, 1, 0, 4)
    assert val_of(r) == 2, "register 5 counts each refused packet once"
    check_reply(await s.xfer(rdpkt(5, 9), 1), 1, 3, 5, tag="unknown register")
    r = await s.xfer(rdpkt(6, 5), 3)
    assert val_of(r) == 3
    assert await s.led() == 5


# req: REQ-09, REQ-11, REQ-12, REQ-10
@cocotb.test()
async def test_sequence_window(dut):
    s = await Env.create(dut)

    async def stop(seq, st):
        r = await s.xfer(tstop(seq), 1)
        check_reply(r, 5, st, seq, tag=f"seq {seq:#x}")

    await stop(0x8000, 0)       # first packet: any number
    await stop(0x8000, 4)       # repeated
    await stop(0x7FFF, 4)       # old
    await stop(0x0000, 4)       # difference 32768 is refused
    await stop(0xFFFF, 0)       # difference 32767 is accepted
    await stop(0x7FFF, 4)       # 32768 from last
    await stop(0x0000, 0)       # wraps, difference 1
    await stop(0x0000, 4)
    await stop(0x8000, 4)       # 32768
    await stop(0x7FFF, 0)       # 32767
    await stop(0x8000, 0)       # 1
    await s.reset()
    await stop(0xFFFF, 0)       # first packet after reset again any number
    await stop(0x0000, 0)


# req: REQ-14, REQ-09, REQ-13, REQ-08, REQ-17
@cocotb.test()
async def test_sequence_consumed(dut):
    s = await Env.create(dut)
    check_reply(await s.xfer(wrpkt(5, 0, 0x12345678), 1), 2, 5, 5, tag="write ro")
    check_reply(await s.xfer(rdpkt(5, 0), 1), 1, 4, 5, tag="number consumed by ro write")
    check_reply(await s.xfer(rdpkt(6, 9), 1), 1, 3, 6, tag="bad register")
    check_reply(await s.xfer(rdpkt(6, 0), 1), 1, 4, 6, tag="number consumed by bad register")
    check_reply(await s.xfer(wrpkt(7, 8, 1), 1), 2, 3, 7, tag="write reg 8")
    check_reply(await s.xfer(wrpkt(7, 1, 0xAAAAAAAA), 1), 2, 4, 7, tag="repeat write")
    r = await s.xfer(rdpkt(8, 1), 3)
    check_reply(r, 1, 0, 8)
    assert val_of(r) == 0, "a refused write must not change the scratch register"


# req: REQ-06, REQ-07, REQ-05, REQ-14
@cocotb.test()
async def test_error_status_type_length(dut):
    s = await Env.create(dut)
    check_reply(await s.xfer(mkpkt(9, 1), 1), 9, 1, 1, tag="unknown 9")
    check_reply(await s.xfer(mkpkt(0x7F, 1), 1), 0x7F, 1, 1, tag="unknown 7f")
    check_reply(await s.xfer(mkpkt(1, 1, bytes(3)), 1), 1, 2, 1, tag="read len 3")
    check_reply(await s.xfer(mkpkt(2, 1, bytes(2)), 1), 2, 2, 1, tag="write len 2")
    check_reply(await s.xfer(mkpkt(3, 1, bytes(1)), 1), 3, 2, 1, tag="status len 1")
    check_reply(await s.xfer(mkpkt(4, 1), 1), 4, 2, 1, tag="start len 0")
    check_reply(await s.xfer(mkpkt(5, 1, bytes(2)), 1), 5, 2, 1, tag="stop len 2")
    # none of these consumed number 1
    check_reply(await s.xfer(tstop(1), 1), 5, 0, 1, tag="stop accepted")
    # type and length errors come before the sequence rule
    check_reply(await s.xfer(mkpkt(9, 1), 1), 9, 1, 1, tag="unknown, repeated number")
    check_reply(await s.xfer(mkpkt(3, 1, bytes(1)), 1), 3, 2, 1, tag="wrong length, repeated number")
    assert await s.led() == 1


# req: REQ-13, REQ-08, REQ-14, REQ-17
@cocotb.test()
async def test_error_status_register(dut):
    s = await Env.create(dut)
    for i, reg in enumerate((0, 4, 5, 6, 7)):
        check_reply(await s.xfer(wrpkt(i + 1, reg, 0x01020304), 1), 2, 5, i + 1, tag=f"write reg {reg}")
    check_reply(await s.xfer(wrpkt(6, 8, 1), 1), 2, 3, 6, tag="write reg 8")
    check_reply(await s.xfer(rdpkt(7, 0xFFFF), 1), 1, 3, 7, tag="read reg 65535")
    assert await s.led() == 0
    assert await s.rd(9) == 0


# req: REQ-20, REQ-19, REQ-24
@cocotb.test()
async def test_scratch_after_reset(dut):
    s = await Env.create(dut)
    for i, reg in enumerate((1, 2, 3)):
        r = await s.xfer(rdpkt(i + 1, reg), 3)
        check_reply(r, 1, 0, i + 1)
        assert val_of(r) == 0, f"scratch {reg} after reset"
    r = await s.xfer(rdpkt(4, 4), 3)
    assert val_of(r) == 3
    r = await s.xfer(rdpkt(5, 5), 3)
    assert val_of(r) == 0


# req: REQ-21, REQ-17
@cocotb.test()
async def test_scratch_write_read(dut):
    s = await Env.create(dut)
    a, b, c = 0xDEADBEEF, 0xFFFFFFFF, 0x00000001
    assert (await s.xfer(wrpkt(1, 1, a), 0))["len"] == 9
    assert (await s.xfer(wrpkt(2, 2, b), 0))["len"] == 9
    for i, (reg, exp) in enumerate(((1, a), (2, b), (3, 0))):
        r = await s.xfer(rdpkt(3 + i, reg), 3)
        check_reply(r, 1, 0, 3 + i)
        assert val_of(r) == exp, f"scratch {reg}"
    assert (await s.xfer(wrpkt(6, 3, c), 0))["len"] == 9
    for i, (reg, exp) in enumerate(((3, c), (1, a))):
        r = await s.xfer(rdpkt(7 + i, reg), 3)
        assert val_of(r) == exp, f"scratch {reg} second"


# req: REQ-23, REQ-44
@cocotb.test()
async def test_tick_register(dut):
    s = await Env.create(dut)
    await s.wr(1, 5)
    r = await s.xfer(rdpkt(1, 7), 3)
    assert val_of(r) == 5
    await s.wr(1, 255)
    r = await s.xfer(rdpkt(2, 7), 3)
    assert val_of(r) == 260
    await s.wr(1, 0)
    await s.wr(1, 0x105)   # only bits 7:0 are the count
    r = await s.xfer(rdpkt(3, 7), 3)
    assert val_of(r) == 265


async def tel_case(s, seq, p, n, tag):
    r = await s.xfer(tstart(seq, p), 1)
    check_reply(r, 4, 0, seq, tag=tag)
    assert (await s.rd(9)) & 1 == 1
    if n > 1:
        await s.ticks(n - 1)
        assert await s.rd(5) == 0, f"{tag}: frame early"
    await s.ticks(1)
    assert await s.rd(5) == 17, f"{tag}: frame not due after {n} ticks"
    await s.wr(8, 0)
    assert await s.rd(5) == 0


# req: REQ-28, REQ-29, REQ-30, REQ-31, REQ-32, REQ-33, REQ-44
@cocotb.test()
async def test_telemetry_period_set(dut):
    s = await Env.create(dut)
    await tel_case(s, 1, 0, 100, "p0 keeps 100")
    await tel_case(s, 2, 4, 4, "p4")
    await tel_case(s, 3, 3, 4, "p3 raised to 4")
    r = await s.xfer(rdpkt(4, 6), 3)
    assert val_of(r) == 4
    await tel_case(s, 5, 5, 5, "p5")
    await tel_case(s, 6, 0, 5, "p0 keeps 5")


# req: REQ-28, REQ-29, REQ-30, REQ-32, REQ-33
@cocotb.test()
async def test_telemetry_period_restart(dut):
    s = await Env.create(dut)
    await s.xfer(tstart(1, 10), 0)
    await s.ticks(6)
    assert await s.rd(5) == 0
    await s.xfer(tstart(2, 0), 0)    # keeps 10 and restarts the count
    await s.ticks(9)
    assert await s.rd(5) == 0, "start must restart the tick-period count"
    await s.ticks(1)
    assert await s.rd(5) == 17
    await s.wr(8, 0)
    await tel_case(s, 3, 300, 300, "p300")
    r = await s.xfer(rdpkt(4, 6), 3)
    assert val_of(r) == 300
    await tel_case(s, 5, 1, 4, "p1 raised to 4")


# req: REQ-36, REQ-37, REQ-38, REQ-39, REQ-40, REQ-34, REQ-35, REQ-47, REQ-33
@cocotb.test()
async def test_telemetry_frame_contents(dut):
    s = await Env.create(dut)
    assert (await s.xfer(bad_crc(tstop(9)), 0))["len"] == 0          # refused 1
    await s.xfer(tstart(1, 4), 0)                                      # commands 1
    await s.ticks(4)
    f1 = await s.read_tframe()
    check_tframe(f1, 0, 4, 1, 1)
    await s.xfer(rdpkt(2, 0), 0)                                       # commands 2, held frame unchanged
    await s.ticks(8)                                                   # two frames fall due and are dropped
    f1b = await s.read_tframe()
    assert f1b == f1, "a frame falling due while one is held must be dropped"
    await s.wr(8, 0)
    assert await s.rd(5) == 0
    await s.ticks(4)
    check_tframe(await s.read_tframe(), 1, 16, 2, 1)
    r = await s.xfer(stat(3), "full")
    check_reply(r, 3, 0, 3, status_payload(2, 1, 0, 0, 0, 0, 0, 2, 1), "status")   # two frames held so far
    await s.xfer(tstop(4), 0)
    assert await s.rd(5) == 0, "stop discards the held frame"
    await s.xfer(tstart(5, 4), 0)
    await s.ticks(4)
    check_tframe(await s.read_tframe(), 2, 20, 5, 1)


# req: REQ-41, REQ-42, REQ-43, REQ-48, REQ-49, REQ-31, REQ-35
@cocotb.test()
async def test_telemetry_take_stop(dut):
    s = await Env.create(dut)
    await s.xfer(tstart(1, 4), 0)
    assert await s.rd(9) == 1
    await s.ticks(4)
    assert await s.rd(5) == 17
    await s.wr(8, 0)
    assert await s.rd(5) == 0
    await s.wr(8, 0)                    # take with nothing held
    assert await s.rd(5) == 0
    await s.ticks(4)
    assert await s.rd(5) == 17
    check_reply(await s.xfer(tstop(2), 1), 5, 0, 2)
    assert await s.rd(5) == 0
    assert await s.rd(9) == 0
    await s.ticks(8)
    assert await s.rd(5) == 0, "no frames while telemetry is off"
    await s.xfer(tstart(3, 4), 0)
    await s.ticks(3)
    assert await s.rd(5) == 0
    await s.ticks(1)
    assert await s.rd(5) == 17


# req: REQ-50, REQ-53, REQ-54, REQ-46, REQ-47, REQ-48, REQ-45, REQ-49
@cocotb.test()
async def test_busy_and_readback(dut):
    s = await Env.create(dut)
    assert await s.rd(9) == 0
    pkt = tstop(1)
    await s.wr(0, pkt[0])
    assert await s.rd(9) == 2, "busy from the first byte"
    for b in pkt[1:-1]:
        await s.wr(0, b)
    assert await s.rd(9) == 2
    await s.wr(0, pkt[-1] | 0x100)
    assert await s.rd(9) == 0, "reply is built and busy is clear at the next access"
    assert await s.rd(2) == 9
    exp = mkreply(5, 0, 1)
    for i in range(4):
        await s.wr(3, i)
        e = (exp[4 * i:4 * i + 4] + bytes(4))[:4]
        assert await s.rd(4) == int.from_bytes(e, "big"), f"reply word {i}"
    await s.wr(3, 127)
    assert await s.rd(4) == 0
    await s.wr(3, 0x83)
    assert await s.rd(3) == 3
    await s.wr(6, 0)
    assert await s.rd(7) == 0 and await s.rd(5) == 0
    r = await s.xfer(tstart(2, 4), 0)     # immediately after the previous packet
    assert r["len"] == 9
    await s.ticks(4)
    fr = await s.read_tframe()
    check_tframe(fr, 0, 4, 2, 0)
    await s.wr(6, 4)
    assert await s.rd(7) == fr[16] << 24
    await s.wr(6, 5)
    assert await s.rd(7) == 0
    await s.wr(6, 127)
    assert await s.rd(7) == 0
    pkt = tstop(3)
    await s.wr(0, pkt[0])
    assert await s.rd(9) == 3, "telemetry on and busy"
    for b in pkt[1:-1]:
        await s.wr(0, b)
    await s.wr(0, pkt[-1] | 0x100)
    assert await s.rd(9) == 0
    assert await s.rd(5) == 0
    await s.wr(6, 0)
    assert await s.rd(7) == 0


# req: REQ-05, REQ-06, REQ-07, REQ-08, REQ-09, REQ-13
@cocotb.test()
async def test_refusal_order(dut):
    s = await Env.create(dut)
    check_reply(await s.xfer(tstop(1), 1), 5, 0, 1)
    check_reply(await s.xfer(mkpkt(9, 2, bytes(3)), 1), 9, 1, 2, tag="unknown beats wrong length")
    check_reply(await s.xfer(mkpkt(3, 1, bytes(1)), 1), 3, 2, 1, tag="wrong length beats sequence")
    check_reply(await s.xfer(rdpkt(1, 9), 1), 1, 4, 1, tag="sequence beats register")
    check_reply(await s.xfer(wrpkt(1, 0, 5), 1), 2, 4, 1, tag="sequence beats access")
    check_reply(await s.xfer(wrpkt(2, 9, 5), 1), 2, 3, 2, tag="register number beats access")


# req: REQ-10, REQ-17, REQ-15, REQ-35, REQ-09
@cocotb.test()
async def test_refused_changes_nothing(dut):
    s = await Env.create(dut)
    await s.xfer(tstart(1, 4), 0)
    await s.xfer(wrpkt(2, 1, 0xAAAA5555), 0)
    check_reply(await s.xfer(tstop(2), 1), 5, 4, 2, tag="repeated stop")
    check_reply(await s.xfer(wrpkt(1, 1, 0xBBBBBBBB), 1), 2, 4, 1, tag="old write")
    assert (await s.xfer(bad_crc(tstop(3)), 0))["len"] == 0
    check_reply(await s.xfer(mkpkt(5, 3, bytes(2)), 1), 5, 2, 3, tag="wrong length stop")
    check_reply(await s.xfer(mkpkt(0x20, 3), 1), 0x20, 1, 3, tag="unknown type")
    assert await s.rd(9) == 1, "telemetry stays on"
    await s.ticks(4)
    check_tframe(await s.read_tframe(), 0, 4, 2, 5)
    check_reply(await s.xfer(tstop(2), 1), 5, 4, 2, tag="repeated stop with frame held")
    assert await s.rd(5) == 17, "held frame survives a refused stop"
    r = await s.xfer(rdpkt(3, 1), 3)
    check_reply(r, 1, 0, 3)
    assert val_of(r) == 0xAAAA5555


# ------------------------------------------------------------------ constrained random
def rand_val(rng):
    return {"zero": 0, "one": 1, "max": 0xFFFFFFFF, "rand": rng.getrandbits(32)}[rng.choice(["zero", "one", "max", "rand"])]


def pick_seq(rng, st):
    r = rng.random()
    last = st["last"]
    if r < 0.5:
        q = (last + 1) & 0xFFFF
    elif r < 0.6:
        q = last
    elif r < 0.7:
        q = (last - 1) & 0xFFFF
    elif r < 0.78:
        q = (last + 32767) & 0xFFFF
    elif r < 0.85:
        q = (last + 32768) & 0xFFFF
    elif r < 0.92:
        q = (last + rng.randint(2, 20)) & 0xFFFF
    else:
        q = rng.getrandbits(16)
    return q


def base_packet(rng, q, periods, regs):
    k = rng.choice(["read", "write", "status", "start", "stop"])
    if k == "read":
        return rdpkt(q, rng.choice(regs))
    if k == "write":
        return wrpkt(q, rng.choice(regs), rand_val(rng))
    if k == "status":
        return stat(q)
    if k == "start":
        return tstart(q, rng.choice(periods))
    return tstop(q)


async def random_step(s, rng, st, weights, periods, ticks, regs, budget):
    kinds = list(weights)
    k = rng.choices(kinds, [weights[x] for x in kinds])[0]
    if k == "tick":
        await s.wr(1, rng.choice(ticks))
        if rng.random() < 0.6:
            if rng.random() < 0.5:
                await s.read_tframe()
            else:
                await s.rd(5)
        return
    if k == "take":
        await s.wr(8, 0)
        return
    if k == "tlen":
        await s.read_tframe()
        return
    if k == "ridx":
        await s.wr(3, rng.choice([0, 1, 2, 3, 6, 7, 100, 127, 0x1FF]))
        await s.rd(4)
        await s.rd(3)
        return
    if k == "busy":
        await s.rd(9)
        return
    q = pick_seq(rng, st)
    if k == "good":
        pkt = base_packet(rng, q, periods, regs)
        st["last"] = q
    elif k == "badcrc":
        pkt = bad_crc(base_packet(rng, q, periods, regs))
    elif k == "trunc":
        p = base_packet(rng, q, periods, regs)
        pkt = p[:rng.randint(1, len(p) - 1)]
    elif k == "extend":
        pkt = base_packet(rng, q, periods, regs) + bytes(rng.getrandbits(8) for _ in range(rng.randint(1, 3)))
    elif k == "longlen":
        pkt = mkpkt(rng.randint(1, 5), q, bytes(rng.randint(0, 3)), ln=rng.randint(9, 255))
    elif k == "unknown":
        pkt = mkpkt(rng.choice([0, 6, 7, 0x20, 0x80, 0xC0, 0xFF]), q, bytes(rng.randint(0, 8)))
    else:  # wronglen
        typ = rng.randint(1, 5)
        need = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}[typ]
        n = rng.choice([x for x in range(0, 9) if x != need])
        pkt = mkpkt(typ, q, bytes(rng.getrandbits(8) for _ in range(n)))
    mode = rng.choice([0, 0, 1, 1, 3, "full"])
    await s.xfer(pkt, mode)


# req: REQ-01, REQ-02, REQ-03, REQ-04, REQ-05, REQ-09, REQ-10, REQ-11, REQ-15, REQ-16, REQ-17, REQ-24, REQ-46, REQ-54
@cocotb.test()
async def test_random_traffic(dut):
    s = await Env.create(dut)
    rng = random.Random(int(getattr(cocotb, "RANDOM_SEED", 1)) * 7919 + 1)
    st = {"last": rng.getrandbits(16)}
    weights = {"good": 40, "badcrc": 6, "trunc": 6, "extend": 5, "longlen": 3, "unknown": 5, "wronglen": 7,
               "tick": 8, "take": 2, "tlen": 3, "ridx": 3, "busy": 2}
    regs = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0xFFFF, 0x100]
    periods = [0, 1, 3, 4, 5, 7, 9]
    ticks = [0, 1, 2, 3, 4, 5, 9, 255, rng.randint(0, 255)]
    while s.nacc < 110:
        await random_step(s, rng, st, weights, periods, ticks, regs, 110)
    assert int(dut.LED.value) == (await s.led())


# req: REQ-33, REQ-34, REQ-35, REQ-36, REQ-37, REQ-38, REQ-41, REQ-42, REQ-43, REQ-44, REQ-47, REQ-48
@cocotb.test()
async def test_random_telemetry(dut):
    s = await Env.create(dut)
    rng = random.Random(int(getattr(cocotb, "RANDOM_SEED", 1)) * 104729 + 3)
    st = {"last": rng.getrandbits(16)}
    weights = {"good": 22, "badcrc": 3, "unknown": 2, "tick": 40, "take": 6, "tlen": 10, "busy": 3, "ridx": 2}
    regs = [4, 5, 6, 7, 0, 1]
    periods = [0, 4, 4, 5, 6, 8]
    ticks = [0, 1, 1, 2, 3, 4, 5, 7, 255, rng.randint(0, 40)]
    while s.nacc < 110:
        await random_step(s, rng, st, weights, periods, ticks, regs, 110)
    assert int(dut.LED.value) == (await s.led())
