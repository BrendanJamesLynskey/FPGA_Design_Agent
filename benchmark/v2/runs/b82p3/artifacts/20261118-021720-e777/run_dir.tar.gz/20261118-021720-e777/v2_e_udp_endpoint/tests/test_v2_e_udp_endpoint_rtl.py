"""pytest entry: runs the cocotb bench (tests/bench_udp_endpoint.py) against rtl/*.sv, one run per seed."""
import sys
from pathlib import Path

DESIGN = Path(__file__).resolve().parents[1]
for _p in DESIGN.parents:
    if (_p / "flow").is_dir():
        sys.path.insert(0, str(_p))
        break
sys.path.insert(0, str(Path(__file__).resolve().parent))

from flow import cocotb_run  # noqa: E402

SEEDS = (1, 2, 3)
PARAMETERS = {"CLKS_PER_BIT": 10}


def test_v2_e_udp_endpoint_rtl():
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN / "rtl").glob("*.sv"))
    for seed in SEEDS:
        cocotb_run.run(
            "v2_e_udp_endpoint",
            "v2_e_udp_endpoint_top",
            sources,
            "bench_udp_endpoint",
            DESIGN / "tests",
            parameters=PARAMETERS,
            seed=seed,
        )
