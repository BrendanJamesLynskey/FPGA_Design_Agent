import zlib


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000000, BUILD_STAMP=0,
                 ID_WORD=1430540337, REG_COUNT=8, MAX_PAYLOAD=8,
                 DEFAULT_PERIOD=100, MIN_PERIOD=4, REPLY_BUILD_CYCLES=100):
        self.ID_WORD = ID_WORD
        self.MAX_PAYLOAD = MAX_PAYLOAD
        self.DEFAULT_PERIOD = DEFAULT_PERIOD
        self.MIN_PERIOD = MIN_PERIOD
        self.reset()

    def reset(self):
        self.buf = []
        self.busy = 0
        self.scratch = [0, 0, 0]
        self.cmds = 0
        self.refused = 0
        self.cnt = [0] * 7  # ok, badcrc, short, long, repeat, ooo, other
        self.cnt[0] = 0
        self.last_seq = None
        self.period = self.DEFAULT_PERIOD
        self.tel_on = 0
        self.tel_cnt = 0
        self.ticks = 0
        self.pending = 0
        self.held = None
        self.fseq = 0
        self.fcount = 0
        self.reply = b""
        self.ridx = 0
        self.tidx = 0

    # ---- helpers
    @staticmethod
    def _crc(b):
        return (zlib.crc32(bytes(b)) & 0xFFFFFFFF).to_bytes(4, "little")

    def _refuse(self, idx):
        self.cnt[idx] = (self.cnt[idx] + 1) & 0xFFFF
        self.refused = (self.refused + 1) & 0xFFFF

    def _ok(self):
        self.cnt[0] = (self.cnt[0] + 1) & 0xFFFF
        self.cmds = self.cnt[0]

    def _mkreply(self, typ, status, seq, payload):
        body = bytes([(typ | 0x80) & 0xFF, status, (seq >> 8) & 0xFF, seq & 0xFF,
                      len(payload)]) + bytes(payload)
        return body + self._crc(body)

    def _process(self, b):
        n = len(b)
        self.reply = b""
        if n >= 2 and (b[1] > 8 or n > 8 + b[1]):
            self._refuse(3)
            return
        if n < 8 or (n < 8 + b[1]):
            self._refuse(2)
            return
        if self._crc(b[:-4]) != bytes(b[-4:]):
            self._refuse(1)
            return
        typ, ln = b[0], b[1]
        seq = (b[2] << 8) | b[3]
        pl = b[4:4 + ln]
        need = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}
        if typ not in need:
            self._refuse(6)
            self.reply = self._mkreply(typ, 1, seq, [])
            return
        if ln != need[typ]:
            self._refuse(6)
            self.reply = self._mkreply(typ, 2, seq, [])
            return
        if self.last_seq is not None:
            d = (seq - self.last_seq) & 0xFFFF
            if not (1 <= d <= 32767):
                self._refuse(4 if d == 0 else 5)
                self.reply = self._mkreply(typ, 4, seq, [])
                return
        self.last_seq = seq
        status = 0
        payload = []
        if typ in (1, 2):
            reg = (pl[0] << 8) | pl[1]
            if typ == 1:
                if reg >= 8:
                    status = 3
                else:
                    v = [self.ID_WORD, *self.scratch, self.cnt[0], self.refused,
                         self.period, self.ticks][reg]
                    payload = list((v & 0xFFFFFFFF).to_bytes(4, "big"))
            else:
                if reg >= 8:
                    status = 3
                elif reg == 0 or reg >= 4:
                    status = 5
                else:
                    self.scratch[reg - 1] = int.from_bytes(bytes(pl[2:6]), "big")
        elif typ == 3:
            for c in self.cnt:
                payload += [(c >> 8) & 0xFF, c & 0xFF]
            payload += [(self.fcount >> 8) & 0xFF, self.fcount & 0xFF, self.tel_on]
        elif typ == 4:
            p = (pl[0] << 8) | pl[1]
            if p != 0:
                self.period = max(p, self.MIN_PERIOD)
            self.tel_on = 1
            self.tel_cnt = 0
        elif typ == 5:
            self.tel_on = 0
            self.held = None
        if status == 0:
            self._ok()
        else:
            self._refuse(6)
        self.reply = self._mkreply(typ, status, seq, payload)

    def _tick(self):
        self.ticks = (self.ticks + 1) & 0xFFFFFFFF
        if self.tel_on:
            self.tel_cnt += 1
            if self.tel_cnt >= self.period:
                self.tel_cnt = 0
                if self.held is None:
                    body = bytes([0xC0, 0, (self.fseq >> 8) & 0xFF, self.fseq & 0xFF, 8]) \
                        + self.ticks.to_bytes(4, "big") \
                        + self.cmds.to_bytes(2, "big") \
                        + self.refused.to_bytes(2, "big")
                    self.held = body + self._crc(body)
                    self.fseq = (self.fseq + 1) & 0xFFFF
                    self.fcount = (self.fcount + 1) & 0xFFFF

    @staticmethod
    def _word(b, i):
        seg = bytes(b[4 * i:4 * i + 4])
        seg = seg + b"\x00" * (4 - len(seg))
        return int.from_bytes(seg, "big")

    # ---- API
    def step(self, inputs=None):
        if self.pending > 0:
            self.pending -= 1
            self._tick()
        return {"UART_RXD_OUT": 1, "LED": self.cnt[0] & 0xFFFF}

    def write_reg(self, offset, value):
        if offset == 0:
            self.busy = 1
            self.buf.append(value & 0xFF)
            if value & 0x100:
                b = self.buf
                self.buf = []
                self._process(b)
                self.busy = 0
        elif offset == 1:
            self.pending = value & 0xFF
        elif offset == 8:
            self.held = None
        elif offset == 3:
            self.ridx = value & 0x7F
        elif offset == 6:
            self.tidx = value & 0x7F

    def read_reg(self, offset):
        if offset == 2:
            return len(self.reply)
        if offset == 3:
            return self.ridx
        if offset == 4:
            return self._word(self.reply, self.ridx)
        if offset == 5:
            return len(self.held) if self.held else 0
        if offset == 6:
            return self.tidx
        if offset == 7:
            return self._word(self.held or b"", self.tidx)
        if offset == 9:
            return self.tel_on | (self.busy << 1)
        return 0
