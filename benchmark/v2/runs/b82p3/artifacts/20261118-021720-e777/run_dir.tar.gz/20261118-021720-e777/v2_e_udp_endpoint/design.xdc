## design.xdc: pins from the board's master XDC (Nexys-A7-100T-Master.xdc), timing lines appended.

set_property -dict { PACKAGE_PIN E3   IOSTANDARD LVCMOS33 } [get_ports { CLK100MHZ }];  # CLK100MHZ
create_clock -add -name sys_clk_pin -period 10.00 -waveform {0 5} [get_ports { CLK100MHZ }];
set_property -dict { PACKAGE_PIN C12  IOSTANDARD LVCMOS33 } [get_ports { CPU_RESETN }];  # CPU_RESETN
set_property -dict { PACKAGE_PIN H17  IOSTANDARD LVCMOS33 } [get_ports { LED[0] }];  # LED[0]
set_property -dict { PACKAGE_PIN K15  IOSTANDARD LVCMOS33 } [get_ports { LED[1] }];  # LED[1]
set_property -dict { PACKAGE_PIN J13  IOSTANDARD LVCMOS33 } [get_ports { LED[2] }];  # LED[2]
set_property -dict { PACKAGE_PIN N14  IOSTANDARD LVCMOS33 } [get_ports { LED[3] }];  # LED[3]
set_property -dict { PACKAGE_PIN R18  IOSTANDARD LVCMOS33 } [get_ports { LED[4] }];  # LED[4]
set_property -dict { PACKAGE_PIN V17  IOSTANDARD LVCMOS33 } [get_ports { LED[5] }];  # LED[5]
set_property -dict { PACKAGE_PIN U17  IOSTANDARD LVCMOS33 } [get_ports { LED[6] }];  # LED[6]
set_property -dict { PACKAGE_PIN U16  IOSTANDARD LVCMOS33 } [get_ports { LED[7] }];  # LED[7]
set_property -dict { PACKAGE_PIN V16  IOSTANDARD LVCMOS33 } [get_ports { LED[8] }];  # LED[8]
set_property -dict { PACKAGE_PIN T15  IOSTANDARD LVCMOS33 } [get_ports { LED[9] }];  # LED[9]
set_property -dict { PACKAGE_PIN U14  IOSTANDARD LVCMOS33 } [get_ports { LED[10] }];  # LED[10]
set_property -dict { PACKAGE_PIN T16  IOSTANDARD LVCMOS33 } [get_ports { LED[11] }];  # LED[11]
set_property -dict { PACKAGE_PIN V15  IOSTANDARD LVCMOS33 } [get_ports { LED[12] }];  # LED[12]
set_property -dict { PACKAGE_PIN V14  IOSTANDARD LVCMOS33 } [get_ports { LED[13] }];  # LED[13]
set_property -dict { PACKAGE_PIN V12  IOSTANDARD LVCMOS33 } [get_ports { LED[14] }];  # LED[14]
set_property -dict { PACKAGE_PIN V11  IOSTANDARD LVCMOS33 } [get_ports { LED[15] }];  # LED[15]
set_property -dict { PACKAGE_PIN D4   IOSTANDARD LVCMOS33 } [get_ports { UART_RXD_OUT }];  # UART_RXD_OUT
set_property -dict { PACKAGE_PIN C4   IOSTANDARD LVCMOS33 } [get_ports { UART_TXD_IN }];  # UART_TXD_IN

# Reset button and UART rx are asynchronous to the clock (synchronised inside the design):
# zero delay plus a false path, so check_timing sees a delay but no timing is invented.
set ASYNC_IN [get_ports { CPU_RESETN UART_TXD_IN }]
set_input_delay -clock sys_clk_pin -max 0.0 $ASYNC_IN
set_input_delay -clock sys_clk_pin -min 0.0 $ASYNC_IN
set_false_path -from $ASYNC_IN

# LEDs and UART tx drive slow human/serial loads with no timing relationship to the clock:
# zero delay plus a false path.
set SLOW_OUT [get_ports { LED[*] UART_RXD_OUT }]
set_output_delay -clock sys_clk_pin -max 0.0 $SLOW_OUT
set_output_delay -clock sys_clk_pin -min 0.0 $SLOW_OUT
set_false_path -to $SLOW_OUT
