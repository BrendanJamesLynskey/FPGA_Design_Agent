// Port-only checker for v2_e_udp_endpoint (covers only: the RTL internals are not visible to the verifier).
`include "v_macros.svh"

module udp_endpoint_checker (
    input logic        clk,
    input logic        rst_n,
    input logic        rxd,
    input logic [15:0] led
);
    wire  rst = ~rst_n;
    logic seen_rst = 1'b0;
    logic past_ok  = 1'b0;

    always @(posedge clk) begin
        if (rst) seen_rst <= 1'b1;
        past_ok <= 1'b1;
    end

    `V_COVER(C_tx_active, !rxd) // req: REQ-43
    `V_COVER(C_led_nonzero, led != 16'd0) // req: REQ-38
endmodule
