"""Independent reference model of the UDP command and telemetry endpoint, written from the request only."""
import zlib

ID_WORD = 0x55445031
NEED_LEN = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}   # payload each type needs


def crc32(b):
    return zlib.crc32(bytes(b)) & 0xFFFFFFFF


def with_crc(b):
    # four-byte CRC-32 trailer, low byte first
    return bytes(b) + crc32(b).to_bytes(4, "little")


def command(typ, seq, payload=b""):
    # type, length, sequence (high byte first), payload, CRC
    return with_crc(bytes([typ, len(payload)]) + seq.to_bytes(2, "big") + bytes(payload))


def read_cmd(seq, reg):
    # register number as 2 bytes, high byte first (same convention as the rest of the request)
    return command(1, seq, reg.to_bytes(2, "big"))


def write_cmd(seq, reg, val):
    return command(2, seq, reg.to_bytes(2, "big") + val.to_bytes(4, "big"))


def start_cmd(seq, period):
    return command(4, seq, period.to_bytes(2, "big"))


def words_of(frame, i):
    """Bytes 4i..4i+3, first byte on top, zero past the end."""
    chunk = bytes(frame[4 * i:4 * i + 4])
    chunk += bytes(4 - len(chunk))
    return int.from_bytes(chunk, "big")


class Reply:
    def __init__(self, typ, status, seq, payload):
        self.typ, self.status, self.seq, self.payload = typ | 0x80, status, seq, payload

    def bytes(self):
        assert self.payload is not None
        return with_crc(bytes([self.typ, self.status]) + self.seq.to_bytes(2, "big")
                        + bytes([len(self.payload)]) + self.payload)


class Endpoint:
    def __init__(self):
        self.scratch = [0, 0, 0]
        self.cmds = 0
        self.refused = 0
        self.period = 100
        self.ticks = 0
        self.last = None
        self.c_crc = self.c_short = self.c_long = self.c_rep = self.c_ooo = self.c_other = 0
        self.frames = 0
        self.frame_seq = 0
        self.on = False
        self.cnt = 0
        self.held = None

    def tick(self, n=1):
        for _ in range(n):
            self.ticks += 1
            if self.on:
                self.cnt += 1
                if self.cnt >= self.period:
                    self.cnt = 0
                    if self.held is None:
                        body = (bytes([0xC0, 0]) + self.frame_seq.to_bytes(2, "big") + bytes([8])
                                + (self.ticks & 0xFFFFFFFF).to_bytes(4, "big")
                                + (self.cmds & 0xFFFF).to_bytes(2, "big")
                                + (self.refused & 0xFFFF).to_bytes(2, "big"))
                        self.held = with_crc(body)
                        self.frame_seq = (self.frame_seq + 1) & 0xFFFF
                        self.frames += 1

    def take(self):
        self.held = None

    def _status_payload(self):
        c = [self.cmds, self.c_crc, self.c_short, self.c_long, self.c_rep, self.c_ooo, self.c_other, self.frames]
        return b"".join((x & 0xFFFF).to_bytes(2, "big") for x in c) + bytes([1 if self.on else 0])

    def _refuse(self, counter, typ=None, seq=0, status=None):
        setattr(self, counter, getattr(self, counter) + 1)
        self.refused += 1
        if status is None:
            return None
        return Reply(typ, status, seq, None)

    def packet(self, d):
        """Returns None (dropped silently) or a Reply (payload None if the request does not fix it)."""
        d = bytes(d)
        n = len(d)
        if n < 4:
            return self._refuse("c_short")
        L = d[1]
        if L > 8 or n > 8 + L:
            return self._refuse("c_long")
        if n < 8 + L:
            return self._refuse("c_short")
        if crc32(d[:-4]) != int.from_bytes(d[-4:], "little"):
            return self._refuse("c_crc")
        typ = d[0]
        seq = int.from_bytes(d[2:4], "big")
        pl = d[4:4 + L]
        if typ not in NEED_LEN:
            return self._refuse("c_other", typ, seq, 1)
        if L != NEED_LEN[typ]:
            return self._refuse("c_other", typ, seq, 2)
        if self.last is not None:
            diff = (seq - self.last) % 65536
            if not 1 <= diff <= 32767:
                return self._refuse("c_rep" if diff == 0 else "c_ooo", typ, seq, 4)
        self.last = seq   # number is used up even if the register check fails
        payload = b""
        if typ in (1, 2):
            reg = int.from_bytes(pl[:2], "big")
            if reg >= 8:
                return self._refuse("c_other", typ, seq, 3)
            if typ == 1:
                vals = [ID_WORD, *self.scratch, self.cmds, self.refused, self.period, self.ticks]
                payload = (vals[reg] & 0xFFFFFFFF).to_bytes(4, "big")
                payload_known = True
            else:
                if reg == 0 or reg >= 4:
                    return self._refuse("c_other", typ, seq, 5)
                self.scratch[reg - 1] = int.from_bytes(pl[2:6], "big")
                payload = None
        elif typ == 3:
            payload = self._status_payload()
        elif typ == 4:
            per = int.from_bytes(pl, "big")
            if per:
                self.period = max(per, 4)
            self.on = True
            self.cnt = 0
            payload = None
        elif typ == 5:
            self.on = False
            self.held = None
            payload = None
        self.cmds += 1
        return Reply(typ, 0, seq, payload)
