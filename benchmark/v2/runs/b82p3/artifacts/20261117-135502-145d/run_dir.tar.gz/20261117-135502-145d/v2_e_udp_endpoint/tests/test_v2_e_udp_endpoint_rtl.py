"""Pytest entry: runs the cocotb bench (bench_udp_endpoint) against the RTL, once per seed."""
from pathlib import Path

import flow.cocotb_run as cocotb_run

DESIGN = Path(__file__).resolve().parents[1]
TESTS = Path(__file__).resolve().parent
PARAMS = {"CLKS_PER_BIT": 8}   # same value as CPB in the bench and the model
SEEDS = (1, 2, 3)


def test_v2_e_udp_endpoint_rtl():
    sources = cocotb_run.SHELL_RTL + sorted((DESIGN / "rtl").glob("*.sv"))
    for seed in SEEDS:
        cocotb_run.run("v2_e_udp_endpoint", "v2_e_udp_endpoint_top", sources,
                       "bench_udp_endpoint", TESTS, parameters=PARAMS, seed=seed)
