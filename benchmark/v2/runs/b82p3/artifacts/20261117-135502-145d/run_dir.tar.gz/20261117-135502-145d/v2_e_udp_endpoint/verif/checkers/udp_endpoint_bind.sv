bind v2_e_udp_endpoint_top udp_endpoint_checker u_udp_endpoint_checker (
    .clk   (CLK100MHZ),
    .rst_n (CPU_RESETN),
    .rxd   (UART_RXD_OUT),
    .led   (LED)
);
