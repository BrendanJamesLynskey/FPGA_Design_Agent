import zlib


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000, BUILD_STAMP=0,
                 ID_WORD=1430540337, TELEMETRY_PERIOD_RESET=100,
                 TELEMETRY_PERIOD_MIN=4, MAX_PAYLOAD=8,
                 REPLY_BUILD_CYCLES_MAX=100):
        self.p_id = ID_WORD
        self.p_per = TELEMETRY_PERIOD_RESET
        self.p_min = TELEMETRY_PERIOD_MIN
        self.p_max = MAX_PAYLOAD
        self.inputs = {"CPU_RESETN": 1, "UART_TXD_IN": 1}
        self.reset()

    def reset(self):
        self.scratch = [0, 0, 0]
        self.cmds = 0
        self.refused = 0
        self.c_crc = 0
        self.c_short = 0
        self.c_long = 0
        self.c_rep = 0
        self.c_ooo = 0
        self.c_err = 0
        self.period = self.p_per
        self.ticks = 0
        self.pending = 0
        self.tel_on = 0
        self.tcnt = 0
        self.held = None
        self.fseq = 0
        self.fcount = 0
        self.have_last = False
        self.last = 0
        self.buf = []
        self.reply = b""
        self.ridx = 0
        self.tidx = 0

    # ---- helpers
    @staticmethod
    def _crc(b):
        return zlib.crc32(bytes(b)) & 0xFFFFFFFF

    def _word(self, data, idx):
        if data is None:
            return 0
        i = idx * 4
        w = 0
        for k in range(4):
            w <<= 8
            if i + k < len(data):
                w |= data[i + k]
        return w

    def _mkreply(self, typ, status, seq, payload):
        b = [typ | 0x80, status, (seq >> 8) & 255, seq & 255, len(payload)] + list(payload)
        c = self._crc(b)
        b += [(c >> (8 * k)) & 255 for k in range(4)]
        return bytes(b)

    def _refuse(self, which):
        self.refused = (self.refused + 1) & 0xFFFFFFFF
        setattr(self, which, getattr(self, which) + 1)

    def _packet(self, d):
        self.reply = b""
        n = len(d)
        if n < 4:
            self._refuse("c_short"); return
        L = d[1]
        if L > self.p_max or n > 8 + L:
            self._refuse("c_long"); return
        if n < 8 + L:
            self._refuse("c_short"); return
        crc = d[-4] | d[-3] << 8 | d[-2] << 16 | d[-1] << 24
        if crc != self._crc(d[:-4]):
            self._refuse("c_crc"); return
        t = d[0]
        seq = d[2] << 8 | d[3]
        pl = d[4:4 + L]
        if t not in (1, 2, 3, 4, 5):
            self._refuse("c_err")
            self.reply = self._mkreply(t, 1, seq, b""); return
        need = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}[t]
        if L != need:
            self._refuse("c_err")
            self.reply = self._mkreply(t, 2, seq, b""); return
        if self.have_last:
            diff = (seq - self.last) & 0xFFFF
            if not (1 <= diff <= 32767):
                self._refuse("c_rep" if diff == 0 else "c_ooo")
                self.reply = self._mkreply(t, 4, seq, b""); return
        self.have_last = True
        self.last = seq
        payload = b""
        status = 0
        if t in (1, 2):
            r = pl[0] << 8 | pl[1] if False else pl[0]
            if r >= 8:
                status = 3
            elif t == 1:
                if r == 0:
                    v = self.p_id
                elif r <= 3:
                    v = self.scratch[r - 1]
                elif r == 4:
                    v = self.cmds
                elif r == 5:
                    v = self.refused
                elif r == 6:
                    v = self.period
                else:
                    v = self.ticks
                payload = bytes((v >> s) & 255 for s in (24, 16, 8, 0))
            else:
                if r in (0, 4, 5, 6, 7):
                    status = 5
                else:
                    self.scratch[r - 1] = int.from_bytes(bytes(pl[1:5]), "big")
        elif t == 3:
            vals = [self.cmds, self.c_crc, self.c_short, self.c_long,
                    self.c_rep, self.c_ooo, self.c_err, self.fcount]
            out = []
            for v in vals:
                v &= 0xFFFF
                out += [v >> 8, v & 255]
            out.append(self.tel_on)
            payload = bytes(out)
        elif t == 4:
            p = pl[0] << 8 | pl[1]
            if p != 0:
                self.period = max(p, self.p_min)
            self.tel_on = 1
            self.tcnt = 0
        elif t == 5:
            self.tel_on = 0
            self.held = None
        if status:
            self._refuse("c_err")
        else:
            self.cmds = (self.cmds + 1) & 0xFFFFFFFF
        self.reply = self._mkreply(t, status, seq, payload)

    def _tick(self):
        self.ticks = (self.ticks + 1) & 0xFFFFFFFF
        if self.tel_on:
            self.tcnt += 1
            if self.tcnt >= self.period:
                self.tcnt = 0
                if self.held is None:
                    b = [0xC0, 0, (self.fseq >> 8) & 255, self.fseq & 255, 8]
                    b += [(self.ticks >> s) & 255 for s in (24, 16, 8, 0)]
                    b += [(self.cmds >> 8) & 255, self.cmds & 255]
                    b += [(self.refused >> 8) & 255, self.refused & 255]
                    c = self._crc(b)
                    b += [(c >> (8 * k)) & 255 for k in range(4)]
                    self.held = bytes(b)
                    self.fseq = (self.fseq + 1) & 0xFFFF
                    self.fcount = (self.fcount + 1) & 0xFFFF

    # ---- API
    def step(self, inputs=None):
        if inputs:
            self.inputs.update(inputs)
        if not self.inputs.get("CPU_RESETN", 1):
            self.reset()
        elif self.pending > 0:
            self.pending -= 1
            self._tick()
        return {"UART_RXD_OUT": 1, "LED": self.cmds & 0xFFFF}

    def read_reg(self, offset):
        if offset == 2:
            return len(self.reply)
        if offset == 3:
            return self.ridx
        if offset == 4:
            return self._word(self.reply, self.ridx)
        if offset == 5:
            return len(self.held) if self.held else 0
        if offset == 6:
            return self.tidx
        if offset == 7:
            return self._word(self.held, self.tidx)
        if offset == 9:
            return self.tel_on & 1
        return 0

    def write_reg(self, offset, value):
        if offset == 0:
            self.buf.append(value & 255)
            if value & 0x100:
                d = self.buf
                self.buf = []
                self._packet(d)
        elif offset == 1:
            self.pending += value & 255
        elif offset == 3:
            self.ridx = value & 127
        elif offset == 6:
            self.tidx = value & 127
        elif offset == 8:
            self.held = None
