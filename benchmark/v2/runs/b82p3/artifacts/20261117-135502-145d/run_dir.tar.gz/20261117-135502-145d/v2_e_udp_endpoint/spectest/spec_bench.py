import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles

from pathlib import Path  # noqa: F401
import spec_ref
from spec_ref import Endpoint, command, read_cmd, write_cmd, start_cmd, with_crc, crc32, words_of
from shell.tests.uart_bfm import UartBfm
from shell.host import protocol as p

CPB = 8
PARAMS = {"CLKS_PER_BIT": CPB, "TIMEOUT_CYCLES": 100000}

# window offsets (request, answer to Q1); shell ADDR = 0x80 + offset
IN, TICK, RLEN, RIDX, RWORD, TLEN, TIDX, TWORD, TAKE, STAT = 0, 1, 2, 3, 4, 5, 6, 7, 8, 9


class Host:
    def __init__(self, dut):
        self.dut = dut
        self.bfm = UartBfm(dut.CLK100MHZ, dut.UART_TXD_IN, dut.UART_RXD_OUT, CPB)
        self.seq = 1000

    def new(self):
        self.seq += 1
        return self.seq

    async def wr(self, off, val):
        r = p.decode_response(await self.bfm.transact(p.encode_request(p.CMD_WRITE, 0x80 + off, val)))
        assert r.ok, f"shell write to window offset {off} gave status {r.status_name}"

    async def rd(self, off):
        r = p.decode_response(await self.bfm.transact(p.encode_request(p.CMD_READ, 0x80 + off, 0)))
        assert r.ok, f"shell read of window offset {off} gave status {r.status_name}"
        return r.data

    async def words(self, lenreg, idxreg, wordreg):
        n = await self.rd(lenreg)
        out = b""
        for i in range((n + 3) // 4):
            await self.wr(idxreg, i)
            out += (await self.rd(wordreg)).to_bytes(4, "big")
        assert out[n:] == bytes(len(out) - n), "bytes past the end must read as zero"
        return out[:n]

    async def exchange(self, m, pkt, what, fetch=True):
        for i, b in enumerate(pkt):
            await self.wr(IN, b | (0x100 if i == len(pkt) - 1 else 0))
        exp = m.packet(pkt)
        if not fetch:
            return exp
        got = await self.words(RLEN, RIDX, RWORD)
        if exp is None:
            assert got == b"", f"{what}: expected no reply (RLEN 0), design replied {got.hex()}"
        elif exp.payload is None:
            assert len(got) >= 9, f"{what}: reply too short: {got.hex()}"
            hdr = bytes([exp.typ, exp.status]) + exp.seq.to_bytes(2, "big")
            assert got[:4] == hdr, f"{what}: expected type/status/seq {hdr.hex()}, got {got[:4].hex()}"
            assert got[4] == len(got) - 9, f"{what}: length byte {got[4]} does not match reply size {len(got)}"
            assert int.from_bytes(got[-4:], "little") == crc32(got[:-4]), f"{what}: bad CRC trailer on reply"
        else:
            assert got == exp.bytes(), f"{what}: expected reply {exp.bytes().hex()}, got {got.hex()}"
        return exp

    async def tick(self, m, n):
        await self.wr(TICK, n)
        m.tick(n)

    async def check_frame(self, m, what):
        got = await self.words(TLEN, TIDX, TWORD)
        if m.held is None:
            assert got == b"", f"{what}: expected no held telemetry frame (length 0), got {got.hex()}"
        else:
            assert got == m.held, f"{what}: expected held frame {m.held.hex()}, got {got.hex()}"


async def setup(dut):
    cocotb.start_soon(Clock(dut.CLK100MHZ, 10, "ns").start())
    dut.UART_TXD_IN.value = 1
    dut.CPU_RESETN.value = 0
    await ClockCycles(dut.CLK100MHZ, 10)
    dut.CPU_RESETN.value = 1
    await ClockCycles(dut.CLK100MHZ, 20)
    return Host(dut), Endpoint()


@cocotb.test()
async def registers_scratch_ticks_and_led(dut):
    h, m = await setup(dut)
    await h.exchange(m, read_cmd(h.new(), 0), "read identification register 0")
    await h.exchange(m, write_cmd(h.new(), 2, 0xDEADBEEF), "write scratch 2")
    await h.exchange(m, read_cmd(h.new(), 2), "read scratch 2 back (high byte first)")
    await h.exchange(m, read_cmd(h.new(), 1), "read scratch 1 (0 after reset)")
    await h.exchange(m, read_cmd(h.new(), 6), "read telemetry period (100 after reset)")
    await h.tick(m, 200)
    await h.exchange(m, read_cmd(h.new(), 7), "read ticks since reset after writing 200 to tick register")
    await h.exchange(m, read_cmd(h.new(), 4), "read commands-carried-out shows count before this read")
    led = int(dut.LED.value) & 0xFFFF
    assert led == m.cmds & 0xFFFF, f"LED[15:0] should show commands carried out {m.cmds}, got {led}"


@cocotb.test()
async def silent_drops_are_counted_and_unanswered(dut):
    h, m = await setup(dut)
    # fewer than four bytes is too short whatever its bytes say (length byte 9 here)
    await h.exchange(m, bytes([1, 9, 0]), "3-byte packet: too short, no reply")
    full = read_cmd(h.new(), 0)
    await h.exchange(m, full[:-1], "packet ending before announced size: too short, no reply")
    await h.exchange(m, full + b"\x00", "more bytes than announced: too long, no reply")
    big = command(1, h.new(), bytes(9))
    await h.exchange(m, big, "length byte above 8: too long, no reply")
    bad = bytearray(read_cmd(h.new(), 0))
    bad[-1] ^= 0x40
    await h.exchange(m, bytes(bad), "bad check: no reply")
    await h.exchange(m, read_cmd(h.new(), 5), "read refused-packets register counts all 5 drops")
    await h.exchange(m, command(3, h.new()), "status command shows each drop in its own counter")


@cocotb.test()
async def refusal_statuses_and_order(dut):
    h, m = await setup(dut)
    s1 = h.new()
    await h.exchange(m, read_cmd(s1, 0), "accepted read establishes last number")
    await h.exchange(m, command(9, h.new()), "unknown type -> status 1")
    await h.exchange(m, command(9, s1), "unknown type judged before sequence -> status 1")
    await h.exchange(m, command(1, s1), "wrong length judged before sequence -> status 2")
    await h.exchange(m, command(3, h.new(), b"\x00"), "status with payload -> status 2")
    await h.exchange(m, read_cmd(h.new(), 8), "read register 8 -> status 3")
    await h.exchange(m, write_cmd(h.new(), 9, 1), "write register 9 -> status 3")
    await h.exchange(m, write_cmd(h.new(), 0, 1), "write read-only register 0 -> status 5")
    s = h.new()
    await h.exchange(m, write_cmd(s, 4, 7), "write read-only register 4 -> status 5")
    await h.exchange(m, read_cmd(s, 0), "number used up by the failed packet -> status 4")
    s = h.new()
    await h.exchange(m, write_cmd(s, 1, 5), "write scratch 1 = 5")
    await h.exchange(m, write_cmd(s, 1, 9), "repeated number -> status 4, changes nothing")
    await h.exchange(m, read_cmd(h.new(), 1), "scratch 1 still 5 after refused write")
    await h.exchange(m, command(3, h.new()), "status counters after refusals")


@cocotb.test()
async def sequence_number_rule_and_wrap(dut):
    h, m = await setup(dut)
    for s, why in [(0xFFFF, "first packet after reset may carry any number"),
                   (0x0000, "0 after 65535 is new (difference 1)"),
                   (0x8000, "difference 32768 is refused"),
                   (0x7FFF, "difference 32767 is new"),
                   (0x7FFF, "repeated number refused"),
                   (0x0000, "old number (difference 32769) refused")]:
        await h.exchange(m, read_cmd(s, 7), why)
    bad = bytearray(read_cmd(0x8000, 7))
    bad[-2] ^= 1
    await h.exchange(m, bytes(bad), "bad-check packet: silent, does not use its number")
    await h.exchange(m, read_cmd(0x8000, 7), "number 0x8000 still new after dropped packet")
    await h.exchange(m, read_cmd(0x8001, 5), "refused-packets register counts every refusal")


@cocotb.test()
async def telemetry_frames_hold_drop_take_stop(dut):
    h, m = await setup(dut)
    await h.exchange(m, start_cmd(h.new(), 5), "telemetry start period 5", fetch=False)
    assert int(await h.rd(STAT)) & 1 == 1, "status word bit 0 should show telemetry on"
    await h.tick(m, 12)   # frame due at tick 5 (held), at tick 10 dropped
    await h.check_frame(m, "held frame after 12 ticks (second one dropped)")
    await h.wr(TAKE, 1)
    m.take()
    await h.check_frame(m, "no frame after take")
    await h.tick(m, 3)    # tick 15 due: frame sequence number 1 (dropped one used none)
    await h.check_frame(m, "frame at tick 15 carries sequence 1")
    await h.exchange(m, command(5, h.new()), "telemetry stop", fetch=False)
    await h.check_frame(m, "stop forgets the held frame")
    assert int(await h.rd(STAT)) & 1 == 0, "status word bit 0 should show telemetry off"
    await h.tick(m, 10)
    await h.check_frame(m, "no frames while off")
    await h.exchange(m, start_cmd(h.new(), 2), "start with period 2 -> 4", fetch=False)
    await h.tick(m, 3)
    await h.check_frame(m, "no frame before 4th tick after start")
    await h.tick(m, 1)
    await h.check_frame(m, "frame on 4th tick after start, sequence continues")
    await h.wr(TAKE, 1)
    m.take()
    await h.exchange(m, start_cmd(h.new(), 0), "start with period 0 keeps period", fetch=False)
    await h.exchange(m, read_cmd(h.new(), 6), "period register is 4")
    await h.tick(m, 4)
    await h.check_frame(m, "frame after restart with kept period")
    await h.exchange(m, command(3, h.new()), "status: frames count and telemetry on")
    assert int(await h.rd(STAT)) & 1 == 1, "status word bit 0 should show telemetry on"
