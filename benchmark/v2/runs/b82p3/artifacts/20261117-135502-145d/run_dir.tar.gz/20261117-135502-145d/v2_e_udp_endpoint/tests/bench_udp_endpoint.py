"""cocotb bench for v2_e_udp_endpoint: everything goes through the test shell over the UART.

Window register N of the design is shell address 0x80+N.  Every register read is compared with the
blind model (model.py); replies and frames are also checked against independent facts (zlib CRC,
fixed field values) so a wrong model cannot hide a wrong RTL.

Register number encoding: spec says read payload = 2 bytes (register number) and write payload = 6 bytes
(register number then 32-bit value), so the register number is taken as 2 bytes, high byte first.
The model reads a one byte register number, so the model sees a translated copy of such packets
(to_model); the DUT sees the raw bytes.
"""
import math
import random
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402
from model import Model  # noqa: E402

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ClockCycles, FallingEdge, First, RisingEdge  # noqa: E402

CPB = 8
PARAMS = {"CLKS_PER_BIT": CPB}
NEED = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}


# ---------------------------------------------------------------- packet builders
def pkt(typ, seq, payload=b"", L=None, crc=None):
    L = len(payload) if L is None else L
    body = bytes([typ, L, (seq >> 8) & 255, seq & 255]) + bytes(payload)
    c = zlib.crc32(body) if crc is None else (crc & 0xFFFFFFFF)
    return body + c.to_bytes(4, "little")


def p_read(seq, reg):
    return pkt(1, seq, reg.to_bytes(2, "big"))


def p_write(seq, reg, val):
    return pkt(2, seq, reg.to_bytes(2, "big") + (val & 0xFFFFFFFF).to_bytes(4, "big"))


def p_status(seq):
    return pkt(3, seq)


def p_tstart(seq, period):
    return pkt(4, seq, period.to_bytes(2, "big"))


def p_tstop(seq):
    return pkt(5, seq)


def badcrc(p, bit=0):
    good = int.from_bytes(p[-4:], "little")
    return p[:-4] + (good ^ (1 << bit)).to_bytes(4, "little")


def to_model(raw):
    """Translate the 2-byte register number into the model's 1-byte form (same length, same CRC validity)."""
    n = len(raw)
    if n >= 8 and raw[0] in (1, 2) and raw[1] == n - 8 and raw[1] == NEED[raw[0]]:
        body = bytearray(raw[:-4])
        ok = bytes(raw[-4:]) == zlib.crc32(bytes(body)).to_bytes(4, "little")
        reg = (body[4] << 8) | body[5]
        r = reg if reg < 256 else 0xFF
        if raw[0] == 1:
            body[4] = r
            body[5] = 0
        else:
            val = bytes(body[6:10])
            body[4:10] = bytes([r]) + val + b"\x00"
        c = zlib.crc32(bytes(body))
        if not ok:
            c ^= 0xA5A5A5A5
        return bytes(body) + c.to_bytes(4, "little")
    return bytes(raw)


def dec_status(b):
    assert len(b) == 26 and b[4] == 17, f"status reply shape {b.hex()}"
    pl = b[5:22]
    v = [int.from_bytes(pl[2 * i:2 * i + 2], "big") for i in range(8)]
    return dict(cmds=v[0], crc=v[1], short=v[2], long=v[3], rep=v[4], ooo=v[5], err=v[6],
                fcount=v[7], tel=pl[16])


def frame_fields(b):
    return dict(seq=int.from_bytes(b[2:4], "big"), ticks=int.from_bytes(b[5:9], "big"),
                cmds=int.from_bytes(b[9:11], "big"), refused=int.from_bytes(b[11:13], "big"))


class Rep:
    def __init__(self, n, words, expect_full):
        self.n = n
        self.words = words
        self.full = expect_full

    @property
    def b(self):
        assert self.full, "bytes only known in full mode"
        out = bytearray()
        for i in range((self.n + 3) // 4):
            out += self.words[i].to_bytes(4, "big")
        return bytes(out[:self.n])

    @property
    def status(self):
        return (self.words[0] >> 16) & 255

    @property
    def typ(self):
        return (self.words[0] >> 24) & 255

    @property
    def seq(self):
        return self.words[0] & 0xFFFF


# ---------------------------------------------------------------- environment
class Env:
    def __init__(self, dut):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        dut.UART_TXD_IN.value = 1
        dut.CPU_RESETN.value = 0
        try:
            clock = Clock(self.clk, 10, units="ns")
        except TypeError:
            clock = Clock(self.clk, 10, unit="ns")
        cocotb.start_soon(clock.start())
        self.m = Model(**PARAMS)
        self.ridx = 0
        self.tidx = 0
        self.seq = 0

    def nseq(self):
        self.seq = (self.seq + 1) & 0xFFFF
        return self.seq

    async def reset(self, cycles=6):
        self.dut.CPU_RESETN.value = 0
        self.dut.UART_TXD_IN.value = 1
        await ClockCycles(self.clk, cycles)
        self.dut.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 8)
        self.m.step({"CPU_RESETN": 0})
        self.m.step({"CPU_RESETN": 1})
        self.ridx = 0
        self.tidx = 0
        self.seq = 0

    # ---- UART
    async def tx_req(self, req):
        for i, b in enumerate(req):
            last = i == len(req) - 1
            for v in [0] + [(b >> k) & 1 for k in range(8)]:
                self.dut.UART_TXD_IN.value = v
                await ClockCycles(self.clk, CPB)
            self.dut.UART_TXD_IN.value = 1
            if not last:
                await ClockCycles(self.clk, CPB)

    async def rx_byte(self):
        rxd = self.dut.UART_RXD_OUT
        await First(FallingEdge(rxd), ClockCycles(self.clk, 20000))
        assert int(rxd.value) == 0, "no response from the shell"
        await ClockCycles(self.clk, CPB // 2)
        assert int(rxd.value) == 0, "start bit not stable"
        v = 0
        for i in range(8):
            await ClockCycles(self.clk, CPB)
            v |= int(rxd.value) << i
        await ClockCycles(self.clk, CPB)
        assert int(rxd.value) == 1, "stop bit low"
        return v

    @staticmethod
    def build_req(cmd, addr, data=0):
        body = bytes([cmd, addr]) + (data & 0xFFFFFFFF).to_bytes(4, "little")
        chk = 0
        for x in body:
            chk ^= x
        return bytes([0xA5]) + body + bytes([chk])

    async def transact(self, cmd, addr, data=0):
        await self.tx_req(self.build_req(cmd, addr, data))
        resp = [await self.rx_byte() for _ in range(7)]
        await ClockCycles(self.clk, 2 * CPB)
        assert resp[0] == 0x5A, f"bad response sync {resp}"
        c = 0
        for x in resp[1:6]:
            c ^= x
        assert c == resp[6], f"bad response checksum {resp}"
        return resp[1], int.from_bytes(bytes(resp[2:6]), "little")

    async def win_write(self, off, val):
        st, _ = await self.transact(2, 0x80 + off, val)
        assert st == 0, f"window write {off} status {st}"

    async def win_read(self, off):
        st, d = await self.transact(1, 0x80 + off)
        assert st == 0, f"window read {off} status {st}"
        return d

    # ---- register level (compared with the model)
    async def reg_write(self, off, val):
        assert off != 0
        await self.win_write(off, val)
        self.m.write_reg(off, val)
        if off == 1:
            for _ in range((val & 255) + 1):
                self.m.step()
        elif off == 3:
            self.ridx = val & 127
        elif off == 6:
            self.tidx = val & 127

    async def reg_read(self, off):
        got = await self.win_read(off)
        exp = self.m.read_reg(off)
        assert got == exp, f"register {off}: RTL 0x{got:08X} model 0x{exp:08X}"
        return got

    async def tick(self, n):
        await self.reg_write(1, n)

    def led_check(self):
        exp = self.m.step()["LED"]
        got = int(self.dut.LED.value)
        assert got == exp, f"LED 0x{got:04X} model 0x{exp:04X}"
        return got

    # ---- packets
    async def send_packet(self, raw):
        assert len(raw) >= 1
        mraw = to_model(raw)
        for i, b in enumerate(raw):
            last = i == len(raw) - 1
            await self.win_write(0, b | (0x100 if last else 0))
            self.m.write_reg(0, mraw[i] | (0x100 if last else 0))
        self.led_check()

    async def _read_words(self, n, mode, lenoff, idxoff, wordoff, kind):
        nw = (n + 3) // 4
        if mode == "full":
            idxs = list(range(nw))
        else:
            idxs = sorted({0, nw - 1})
        cur = self.ridx if kind == "r" else self.tidx
        if cur > nw // 2:
            idxs.reverse()
        words = {}
        for i in idxs:
            cur = self.ridx if kind == "r" else self.tidx
            if cur != i:
                await self.reg_write(idxoff, i)
            words[i] = await self.reg_read(wordoff)
        return words

    async def check_reply(self, mode="full"):
        n = await self.reg_read(2)
        if mode == "len" or n == 0:
            return Rep(n, {}, False)
        words = await self._read_words(n, mode, 2, 3, 4, "r")
        rep = Rep(n, words, mode == "full")
        if mode == "full":
            b = rep.b
            assert n >= 9 and b[0] & 0x80, f"reply header {b.hex()}"
            assert b[4] == n - 9, f"reply length byte {b.hex()}"
            assert int.from_bytes(b[-4:], "little") == zlib.crc32(b[:-4]), f"reply CRC {b.hex()}"
        return rep

    async def check_frame(self, mode="full"):
        n = await self.reg_read(5)
        if n == 0:
            return Rep(0, {}, False)
        assert n == 17, f"frame length {n}"
        words = await self._read_words(n, mode, 5, 6, 7, "t")
        rep = Rep(n, words, mode == "full")
        if mode == "full":
            b = rep.b
            assert b[0] == 0xC0 and b[1] == 0 and b[4] == 8, f"frame header {b.hex()}"
            assert int.from_bytes(b[-4:], "little") == zlib.crc32(b[:-4]), f"frame CRC {b.hex()}"
        return rep

    async def pk(self, raw, mode="full", status=None, silent=False):
        await self.send_packet(raw)
        rep = await self.check_reply(mode)
        if silent:
            assert rep.n == 0, "a reply was built for a packet that must be dropped silently"
        if status is not None:
            assert rep.n > 0 and mode != "len"
            assert rep.status == status, f"status {rep.status} expected {status}"
        return rep


async def new_env(dut):
    env = Env(dut)
    await env.reset()
    return env


# ---------------------------------------------------------------- tests
# req: REQ-39, REQ-44, REQ-37, REQ-16
@cocotb.test()
async def test_smoke_reset_values(dut):
    env = await new_env(dut)
    for off in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 127):
        assert await env.reg_read(off) == 0, f"reset/unmapped value of {off}"
    assert int(dut.LED.value) == 0
    await env.reg_write(3, 0x7F)
    assert await env.reg_read(3) == 0x7F
    await env.reg_write(6, 0x55)
    assert await env.reg_read(6) == 0x55
    await env.reg_write(3, 0)
    await env.reg_write(6, 0)
    # writes to read-only and unmapped window offsets change nothing
    for off in (2, 4, 5, 7, 9, 12):
        await env.reg_write(off, 0x1234)
    for off in (2, 4, 5, 7, 9, 12):
        assert await env.reg_read(off) == 0
    assert (await env.reg_read(9)) & 2 == 0, "busy while idle"


# req: REQ-01, REQ-12, REQ-15, REQ-16, REQ-22
@cocotb.test()
async def test_read_id_scratch(dut):
    env = await new_env(dut)
    first = 0xABCD  # any number is accepted as the first after reset
    rep = await env.pk(p_read(first, 0), status=0)
    b = rep.b
    assert int.from_bytes(b[5:9], "big") == 0x55445031, f"R0 = {b[5:9].hex()}"
    assert b[0] == 0x81 and b[1] == 0 and b[2:4] == first.to_bytes(2, "big") and b[4] == 4
    for r in (1, 2, 3):
        rep = await env.pk(p_read(first + r, r), status=0)
        assert int.from_bytes(rep.b[5:9], "big") == 0, f"R{r} after reset"
        assert rep.b[0] == 0x81 and rep.b[4] == 4


# req: REQ-17, REQ-18, REQ-19, REQ-32
@cocotb.test()
async def test_read_counters_ticks(dut):
    env = await new_env(dut)
    await env.tick(10)
    await env.tick(0)
    await env.tick(255)
    rep = await env.pk(p_read(0, 7), status=0)
    assert int.from_bytes(rep.b[5:9], "big") == 265, "R7 ticks since reset"
    rep = await env.pk(p_read(1, 6), status=0)
    assert int.from_bytes(rep.b[5:9], "big") == 100, "R6 reset value"
    await env.pk(b"\x55", mode="len", silent=True)  # one refused packet
    rep = await env.pk(p_read(2, 4), status=0)
    assert int.from_bytes(rep.b[5:9], "big") == 2, "R4 before this read is counted"
    rep = await env.pk(p_read(3, 5), status=0)
    assert int.from_bytes(rep.b[5:9], "big") == 1, "R5 before this read is counted"


# req: REQ-45
@cocotb.test()
async def test_write_scratch(dut):
    env = await new_env(dut)
    vals = {1: 0x01020304, 2: 0xFFFFFFFF, 3: 0xA5A5A5A5}
    for r, v in vals.items():
        await env.pk(p_write(env.nseq(), r, v), status=0)
    for r, v in vals.items():
        rep = await env.pk(p_read(env.nseq(), r), status=0)
        assert int.from_bytes(rep.b[5:9], "big") == v, f"R{r} readback"


# req: REQ-10, REQ-06, REQ-17, REQ-44
@cocotb.test()
async def test_write_readonly(dut):
    env = await new_env(dut)
    for r, v in ((0, 0xFFFFFFFF), (4, 1), (5, 0x12345678), (6, 7), (7, 0x55)):
        rep = await env.pk(p_write(env.nseq(), r, v), mode="sparse", status=5)
        assert rep.typ == 0x82
    rep = await env.pk(p_read(env.nseq(), 6), status=0)
    assert int.from_bytes(rep.b[5:9], "big") == 100, "R6 unchanged by refused write"
    rep = await env.pk(p_read(env.nseq(), 5), status=0)
    assert int.from_bytes(rep.b[5:9], "big") == 5, "R5 counts the five refused writes"


# req: REQ-09, REQ-06
@cocotb.test()
async def test_unknown_register(dut):
    env = await new_env(dut)
    await env.pk(p_read(env.nseq(), 8), mode="sparse", status=3)
    await env.pk(p_read(env.nseq(), 0x0100), mode="sparse", status=3)
    await env.pk(p_write(env.nseq(), 0xFFFF, 1), mode="sparse", status=3)
    await env.pk(p_write(env.nseq(), 9, 1), mode="sparse", status=3)
    rep = await env.pk(p_status(env.nseq()), status=0)
    s = dec_status(rep.b)
    assert s == dict(cmds=0, crc=0, short=0, long=0, rep=0, ooo=0, err=4, fcount=0, tel=0), s


# req: REQ-11, REQ-12, REQ-13, REQ-14, REQ-40
@cocotb.test()
async def test_sequence_rules(dut):
    env = await new_env(dut)
    await env.pk(p_read(100, 1), mode="len")                       # a: first packet, any number
    await env.pk(p_read(100, 1), mode="sparse", status=4)          # b: repeated
    await env.pk(p_read(98, 1), mode="sparse", status=4)           # c: old
    await env.pk(p_write(32867, 1, 5), mode="sparse", status=0)    # d: 100 + 32767 is new
    await env.pk(p_read(99, 1), mode="sparse", status=4)           # e: diff 32768 is old
    await env.pk(p_write(32866, 1, 0x99), mode="sparse", status=4)  # f: old, must change nothing
    rep = await env.pk(p_read(65535, 1), status=0)                 # g: new, wraps the half range
    assert int.from_bytes(rep.b[5:9], "big") == 5, "refused write changed R1"
    await env.pk(p_write(0, 4, 1), mode="sparse", status=5)        # h: new (wrap), then fails on access
    await env.pk(p_read(0, 1), mode="sparse", status=4)            # i: number 0 was used up by h
    rep = await env.pk(p_status(1), status=0)
    s = dec_status(rep.b)
    assert s == dict(cmds=3, crc=0, short=0, long=0, rep=2, ooo=3, err=1, fcount=0, tel=0), s


# req: REQ-02, REQ-03, REQ-04, REQ-05, REQ-06
@cocotb.test()
async def test_refusal_silent(dut):
    env = await new_env(dut)
    cases = [
        pkt(1, 20, bytes(9), L=9),                  # long: length byte 9
        pkt(3, 21) + b"\xAA\xBB",                   # long: more bytes than announced
        bytes([1, 200, 0, 22, 0, 0]),               # long: length byte 200
        bytes([1, 2, 0]),                           # short: fewer than four bytes
        b"\x55",                                    # short: one byte
        p_write(23, 1, 5)[:10],                     # short: ends before the announced size
        p_status(24)[:7],                           # short: seven bytes for an 8-byte packet
        badcrc(p_read(25, 1)),                      # bad check
        pkt(9, 26, b"", crc=0x12345678),            # bad check wins over unknown type
    ]
    for c in cases:
        await env.pk(c, mode="len", silent=True)
    rep = await env.pk(p_status(30), status=0)
    s = dec_status(rep.b)
    assert s == dict(cmds=0, crc=2, short=4, long=3, rep=0, ooo=0, err=0, fcount=0, tel=0), s
    rep = await env.pk(p_read(31, 5), status=0)
    assert int.from_bytes(rep.b[5:9], "big") == 9, "R5 counts every refused packet"


# req: REQ-07, REQ-08, REQ-22, REQ-06
@cocotb.test()
async def test_unknown_type_wrong_length(dut):
    env = await new_env(dut)
    rep = await env.pk(pkt(7, 40), status=1)
    assert rep.b[0] == 0x87 and rep.b[2:4] == (40).to_bytes(2, "big") and rep.b[4] == 0
    await env.pk(pkt(6, 41, b"\x01\x02\x03"), mode="sparse", status=1)   # type wins over length
    await env.pk(pkt(0, 42), mode="sparse", status=1)
    for typ, seq, pl in ((1, 43, b"\x00"), (2, 44, bytes(5)), (3, 45, b"\x00"),
                         (5, 46, b"\x00\x00"), (1, 48, bytes(6))):
        rep = await env.pk(pkt(typ, seq, pl), mode="sparse", status=2)
        assert rep.typ == (typ | 0x80) and rep.seq == seq
    rep = await env.pk(p_status(49), status=0)
    s = dec_status(rep.b)
    assert s == dict(cmds=0, crc=0, short=0, long=0, rep=0, ooo=0, err=8, fcount=0, tel=0), s


# req: REQ-05, REQ-11, REQ-14
@cocotb.test()
async def test_order_of_refusals(dut):
    env = await new_env(dut)
    await env.pk(p_read(60, 1), mode="sparse", status=0)
    await env.pk(pkt(1, 60, b"\x00"), mode="sparse", status=2)           # length before sequence
    await env.pk(pkt(9, 60), mode="sparse", status=1)                    # type before sequence
    await env.pk(p_read(60, 9), mode="sparse", status=4)                 # sequence before register
    await env.pk(p_write(59, 0, 1), mode="sparse", status=4)             # sequence before access
    await env.pk(p_read(61, 9), mode="sparse", status=3)                 # new number, unknown register
    await env.pk(p_read(61, 1), mode="sparse", status=4)                 # number 61 was used up
    await env.pk(badcrc(pkt(9, 62)), mode="len", silent=True)            # check before type
    rep = await env.pk(p_status(62), status=0)
    s = dec_status(rep.b)
    assert s == dict(cmds=1, crc=1, short=0, long=0, rep=2, ooo=1, err=3, fcount=0, tel=0), s


# req: REQ-20, REQ-21, REQ-46, REQ-22
# (the 16-bit counters cannot be driven to 65536 through the UART in the cycle budget; this checks
# the field layout and counts with distinct values, wrap itself is only modelled)
@cocotb.test()
async def test_status_layout(dut):
    env = await new_env(dut)
    await env.pk(p_tstart(10, 4), mode="sparse", status=0)
    for _ in range(3):
        await env.pk(b"\x55", mode="len", silent=True)                     # short
    for _ in range(2):
        await env.pk(badcrc(p_status(20)), mode="len", silent=True)        # bad check
    await env.pk(p_status(21) + b"\x01\x02", mode="len", silent=True)     # long
    for _ in range(2):
        await env.pk(p_status(10), mode="sparse", status=4)               # repeated
    for sq in (9, 8, 10 + 32768):
        await env.pk(p_status(sq), mode="sparse", status=4)               # out of order
    await env.pk(pkt(9, 11), mode="sparse", status=1)                     # type error
    await env.tick(4)
    rep = await env.pk(p_status(12), status=0)
    s = dec_status(rep.b)
    assert s == dict(cmds=1, crc=2, short=3, long=1, rep=2, ooo=3, err=1, fcount=1, tel=1), s


# req: REQ-23, REQ-24, REQ-25
@cocotb.test()
async def test_telemetry_period(dut):
    env = await new_env(dut)
    for p, expect in ((0, 100), (3, 4), (300, 300), (0, 300)):
        await env.pk(p_tstart(env.nseq(), p), mode="len")
        rep = await env.pk(p_read(env.nseq(), 6), status=0)
        assert int.from_bytes(rep.b[5:9], "big") == expect, f"period after start {p}"


# req: REQ-23, REQ-26, REQ-32
@cocotb.test()
async def test_telemetry_due(dut):
    env = await new_env(dut)
    await env.pk(p_tstart(env.nseq(), 2), mode="sparse", status=0)      # period 2 -> 4
    await env.tick(3)
    assert await env.reg_read(5) == 0
    await env.tick(1)
    assert await env.reg_read(5) == 17
    rep = await env.check_frame("full")
    assert frame_fields(rep.b)["ticks"] == 4
    await env.reg_write(8, 1)
    assert await env.reg_read(5) == 0
    await env.tick(4)
    assert await env.reg_read(5) == 17
    await env.reg_write(8, 1)
    await env.pk(p_tstart(env.nseq(), 0), mode="len")                    # keeps 4, restarts the count
    await env.tick(3)
    assert await env.reg_read(5) == 0
    await env.pk(p_tstart(env.nseq(), 0), mode="len")                    # restart again
    await env.tick(3)
    assert await env.reg_read(5) == 0, "tick count not restarted by start"
    await env.tick(1)
    assert await env.reg_read(5) == 17
    rep = await env.check_frame("full")
    assert frame_fields(rep.b)["ticks"] == 15


# req: REQ-27, REQ-28, REQ-31, REQ-35, REQ-47, REQ-01
@cocotb.test()
async def test_telemetry_frame(dut):
    env = await new_env(dut)
    await env.pk(p_tstart(env.nseq(), 4), mode="len")
    await env.pk(b"\x55", mode="len", silent=True)
    await env.tick(4)
    assert await env.reg_read(5) == 17
    f0 = await env.check_frame("full")
    fl = frame_fields(f0.b)
    assert fl == dict(seq=0, ticks=4, cmds=1, refused=1), fl
    await env.tick(8)                                   # two dues while held: dropped
    assert await env.reg_read(5) == 17
    f0b = await env.check_frame("full")
    assert f0b.b == f0.b, "held frame changed"
    await env.reg_write(8, 1)
    assert await env.reg_read(5) == 0
    await env.tick(4)
    f1 = await env.check_frame("full")
    fl = frame_fields(f1.b)
    assert fl == dict(seq=1, ticks=16, cmds=1, refused=1), fl
    for i in (5, 127):
        await env.reg_write(6, i)
        assert await env.reg_read(7) == 0
    rep = await env.pk(p_status(env.nseq()), status=0)
    s = dec_status(rep.b)
    assert s["fcount"] == 2 and s["tel"] == 1 and s["cmds"] == 1, s


# req: REQ-29, REQ-30, REQ-31, REQ-36, REQ-47
@cocotb.test()
async def test_telemetry_stop_take(dut):
    env = await new_env(dut)
    await env.pk(p_tstart(env.nseq(), 4), mode="len")
    assert (await env.reg_read(9)) & 1 == 1
    await env.tick(4)
    assert await env.reg_read(5) == 17
    await env.pk(p_tstop(env.nseq()), mode="sparse", status=0)
    assert await env.reg_read(5) == 0, "stop forgets a held frame"
    assert (await env.reg_read(9)) & 1 == 0
    await env.tick(8)
    assert await env.reg_read(5) == 0, "frame made while off"
    await env.pk(p_tstart(env.nseq(), 0), mode="len")
    assert (await env.reg_read(9)) & 1 == 1
    await env.tick(4)
    f = await env.check_frame("full")
    fl = frame_fields(f.b)
    assert fl["seq"] == 1 and fl["ticks"] == 16, f"frame sequence not kept across stop: {fl}"
    await env.reg_write(8, 1)
    assert await env.reg_read(5) == 0
    rep = await env.pk(p_status(env.nseq()), status=0)
    s = dec_status(rep.b)
    assert s["fcount"] == 2 and s["tel"] == 1 and s["cmds"] == 3, s


# req: REQ-13, REQ-11
@cocotb.test()
async def test_refused_no_change(dut):
    env = await new_env(dut)
    await env.pk(p_read(5, 1), mode="len")
    await env.pk(p_tstart(6, 5), mode="len")
    await env.tick(5)
    assert await env.reg_read(5) == 17
    await env.pk(p_write(4, 1, 0x1234), mode="sparse", status=4)
    await env.pk(p_tstop(4), mode="sparse", status=4)
    await env.pk(p_tstart(6, 9), mode="sparse", status=4)
    assert (await env.reg_read(9)) & 1 == 1, "refused stop switched telemetry off"
    assert await env.reg_read(5) == 17, "refused stop dropped the held frame"
    rep = await env.pk(p_read(5, 6), mode="sparse", status=4)      # last accepted is still 6
    rep = await env.pk(p_read(7, 6), status=0)
    assert int.from_bytes(rep.b[5:9], "big") == 5, "refused start changed the period"
    rep = await env.pk(p_read(8, 1), status=0)
    assert int.from_bytes(rep.b[5:9], "big") == 0, "refused write changed R1"


# req: REQ-39, REQ-12
@cocotb.test()
async def test_reset_clears(dut):
    env = await new_env(dut)
    await env.reg_write(3, 3)
    await env.reg_write(6, 2)
    await env.pk(p_write(50, 1, 0xCAFEBABE), mode="sparse", status=0)
    await env.tick(3)
    await env.pk(p_tstart(51, 4), mode="len")
    await env.tick(4)
    assert await env.reg_read(5) == 17
    await env.pk(b"\x55", mode="len", silent=True)
    await env.reset()
    assert int(dut.LED.value) == 0
    for off in (2, 3, 4, 5, 6, 7, 9):
        assert await env.reg_read(off) == 0, f"register {off} after reset"
    rep = await env.pk(p_status(1), status=0)     # older than 50/51: accepted because reset forgot them
    s = dec_status(rep.b)
    assert s == dict(cmds=0, crc=0, short=0, long=0, rep=0, ooo=0, err=0, fcount=0, tel=0), s
    rep = await env.pk(p_read(2, 1), status=0)
    assert int.from_bytes(rep.b[5:9], "big") == 0
    rep = await env.pk(p_read(3, 7), status=0)
    assert int.from_bytes(rep.b[5:9], "big") == 0, "ticks not cleared"
    rep = await env.pk(p_read(4, 6), status=0)
    assert int.from_bytes(rep.b[5:9], "big") == 100, "period not reset"


# req: REQ-29, REQ-47, REQ-39
@cocotb.test()
async def test_reset_frame_seq(dut):
    env = await new_env(dut)
    await env.pk(p_tstart(env.nseq(), 4), mode="len")
    await env.tick(4)
    await env.reg_write(8, 1)
    await env.tick(4)
    f = await env.check_frame("full")
    assert frame_fields(f.b)["seq"] == 1
    await env.reset()
    await env.pk(p_tstart(env.nseq(), 4), mode="len")
    await env.tick(4)
    f = await env.check_frame("full")
    assert frame_fields(f.b)["seq"] == 0, "frame sequence not cleared by reset"
    rep = await env.pk(p_status(env.nseq()), status=0)
    s = dec_status(rep.b)
    assert s["fcount"] == 1, s


# req: REQ-38
@cocotb.test()
async def test_led_count(dut):
    env = await new_env(dut)
    for i in range(5):
        await env.pk(p_tstop(env.nseq()), mode="len")
        assert int(dut.LED.value) == i + 1
    await env.pk(b"\x55", mode="len", silent=True)
    assert int(dut.LED.value) == 5
    await env.pk(p_write(env.nseq(), 4, 1), mode="sparse", status=5)
    assert int(dut.LED.value) == 5, "failed command counted"
    await env.pk(p_tstop(env.seq), mode="len")                 # stale
    assert int(dut.LED.value) == 5
    await env.pk(p_tstop(env.nseq()), mode="len")
    assert int(dut.LED.value) == 6


# req: REQ-33, REQ-34, REQ-35, REQ-22
@cocotb.test()
async def test_reply_readback(dut):
    env = await new_env(dut)
    rep = await env.pk(p_read(env.nseq(), 1), status=0)
    assert rep.n == 13
    b = rep.b
    for i, off_val in ((3, b[12] << 24), (4, 0), (127, 0)):
        await env.reg_write(3, i)
        assert await env.reg_read(4) == off_val, f"RWORD index {i}"
    await env.reg_write(3, 0x82)
    assert await env.reg_read(3) == 2
    rep = await env.pk(p_status(env.nseq()), mode="len")
    assert rep.n == 26
    rep = await env.pk(p_write(env.nseq(), 1, 3), mode="len")
    assert rep.n == 9
    await env.pk(b"\x55", mode="len", silent=True)
    assert await env.reg_read(2) == 0
    await env.reg_write(3, 0)
    assert await env.reg_read(4) == 0
    assert await env.reg_read(5) == 0
    assert await env.reg_read(7) == 0


# req: REQ-43
@cocotb.test()
async def test_uart_bit_timing(dut):
    env = await new_env(dut)
    rxd = dut.UART_RXD_OUT
    await env.tx_req(env.build_req(1, 0x82))
    await FallingEdge(rxd)
    count = 0
    while True:
        await RisingEdge(env.clk)
        count += 1
        if int(rxd.value) == 1 or count > 10 * CPB:
            break
    # response sync byte 0x5A: start bit and bit 0 are both low = 2 bit times
    assert 2 * CPB - 1 <= count <= 2 * CPB + 2, f"low time {count} clocks, bit time {CPB}"
    await ClockCycles(env.clk, 7 * 10 * CPB)
    assert await env.reg_read(2) == 0


# req: REQ-01, REQ-05, REQ-06, REQ-11, REQ-13, REQ-26, REQ-40, REQ-41, REQ-42, REQ-37
@cocotb.test()
async def test_random_traffic(dut):
    env = await new_env(dut)
    rnd = random.Random(getattr(cocotb, "RANDOM_SEED", 1))
    kinds = ["read", "read", "write", "status", "tstart", "tstop", "badcrc", "short", "long",
             "badtype", "wronglen", "tick", "tick", "take", "peek"]

    def pick_seq():
        if rnd.random() < 0.85:
            return env.nseq()
        return (env.seq - rnd.randint(0, 3)) & 0xFFFF

    for _ in range(9):
        kind = rnd.choice(kinds)
        mode = rnd.choice(["len", "sparse", "full"])
        if kind == "read":
            raw = p_read(pick_seq(), rnd.choice([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0x100]))
        elif kind == "write":
            val = rnd.choice([0, 1, 0xFFFFFFFF, rnd.getrandbits(32)])
            raw = p_write(pick_seq(), rnd.choice([0, 1, 2, 3, 4, 5, 6, 7, 8]), val)
        elif kind == "status":
            raw = p_status(pick_seq())
        elif kind == "tstart":
            raw = p_tstart(pick_seq(), rnd.choice([0, 1, 3, 4, 5, 50]))
        elif kind == "tstop":
            raw = p_tstop(pick_seq())
        elif kind == "badcrc":
            raw = badcrc(rnd.choice([p_status(pick_seq()), p_read(pick_seq(), 1)]), rnd.randrange(32))
        elif kind == "short":
            full = rnd.choice([p_status(pick_seq()), p_read(pick_seq(), 2), p_write(pick_seq(), 1, 5)])
            raw = full[:rnd.randrange(1, len(full))]
        elif kind == "long":
            raw = pkt(rnd.choice([1, 2, 3]), pick_seq(), bytes(rnd.randrange(256) for _ in range(9)), L=9)
        elif kind == "badtype":
            raw = pkt(rnd.choice([0, 6, 7, 0x80, 0xFF]), pick_seq(), bytes(rnd.randrange(4)))
        elif kind == "wronglen":
            typ = rnd.choice([1, 2, 3, 4, 5])
            n = (NEED[typ] + 1 + rnd.randrange(3)) % 9
            if n == NEED[typ]:
                n = (n + 1) % 9
            raw = pkt(typ, pick_seq(), bytes(n))
        elif kind == "tick":
            await env.tick(rnd.choice([0, 1, 3, 4, 5, 10, 255]))
            if await env.reg_read(5) and rnd.random() < 0.5:
                await env.check_frame("sparse")
            continue
        elif kind == "take":
            await env.reg_write(8, 1)
            await env.reg_read(5)
            continue
        else:
            await env.reg_read(9)
            await env.reg_read(5)
            continue
        await env.pk(raw, mode=mode)
    rep = await env.pk(p_status((env.seq + 1) & 0xFFFF), mode="full")
    env.nseq()
    await env.reg_read(5)
