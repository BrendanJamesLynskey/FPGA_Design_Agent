# v2_e_udp_endpoint architecture

UDP-style command and telemetry endpoint on the Nexys A7-100T. Packet bytes arrive through the test shell IN register; replies and telemetry frames are read back through the shell window. Single 100 MHz clock domain.

## Block diagram

```text
 UART_TXD_IN --> +-----------+ win bus  +----------+   bytes   +-----------+
                 | fpga_shell|<-------->| win_regs |---------->| rx_parser |
 UART_RXD_OUT <--+-----------+          +----------+           | (CRC-32)  |
                                          ^   ^  ^             +-----+-----+
                                   TICK   |   |  | TAKE              |
                                   +------+   |  |             +-----v-----+      LED[15:0]
                                   v          |  |             | seq_regs  |----> (commands
                              +--------+      |  |             | R0..R7,   |       carried out)
                              |tick_gen|--+   |  |             | counters  |
                              +--------+  |   |  |             +-----+-----+
                                          v   |  |                   |
                                     +-----------+--+          +-----v-------+
                                     | telemetry    |          |reply_builder|
                                     | held frame   |          | reply buf   |
                                     +--------------+          +-------------+
 CPU_RESETN --> reset_sync --> active-high rst to all blocks
```

## Clock plan

One clock, CLK100MHZ at 100 MHz, used directly (no MMCM). No clock crossings other than the external CPU_RESETN button, which goes through reset_sync (async assert, sync release), inverted once to an active-high internal reset. All other registers use synchronous reset. UART_TXD_IN is synchronised inside fpga_shell.

## Behaviour summary

- Parser counts bytes, computes CRC-32 (reflected 0xEDB88320), applies refusal order: too long, too short, bad check, unknown type, wrong length, sequence, register/access.
- Reply built in at most 100 clocks into a byte buffer (max 8 + 17 byte payload cases, under 32 bytes); the parser is ready again on the clock after the end-flag byte.
- Telemetry: period counter on ticks (from TICK writes, one per clock), one 16-byte held frame (8-byte payload plus header and CRC), later frames dropped while held.
- Resources estimated at about 2000 LUT and 2000 FF, 0 DSP; buffers small enough for distributed RAM or registers.

## Pin list

| Port | Dir | Width | Board resource |
|---|---|---|---|
| CLK100MHZ | in | 1 | 100 MHz oscillator |
| CPU_RESETN | in | 1 | CPU RESET button, active low |
| UART_TXD_IN | in | 1 | USB-UART host to FPGA |
| UART_RXD_OUT | out | 1 | USB-UART FPGA to host |
| LED | out | 16 | LED[15:0], commands carried out |
