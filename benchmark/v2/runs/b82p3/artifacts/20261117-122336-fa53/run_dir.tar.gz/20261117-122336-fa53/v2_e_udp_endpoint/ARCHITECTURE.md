# v2_e_udp_endpoint architecture

UDP command and telemetry endpoint on the Nexys A7-100T (xc7a100tcsg324-1). A host drives packet bytes through the UART test shell register window. The block checks, executes and answers them, and generates telemetry frames.

## Block diagram

```text
 CPU_RESETN --> reset_sync (xpm_cdc_async_rst) --> rst (active high, sync)
                                                    |
 UART_TXD_IN --> fpga_shell --win_*--> endpoint ----+--> LED[15:0]
 UART_RXD_OUT <--              |
                               +-- packet_rx (len, CRC-32, too long/short/bad check)
                               +-- cmd_exec  (type, length, seq, reg access, regs 0-7, counters, ticks)
                               +-- reply_builder (reply buffer + CRC-32, RLEN/RWORD)
                               +-- telemetry (period, one held frame, TLEN/TWORD, TAKE)
```

## Clock plan

One clock domain: CLK100MHZ, 100 MHz (10 ns), no MMCM. All logic is synchronous to it. CPU_RESETN is an asynchronous button, synchronised once by reset_sync (asynchronous assert, synchronous release) to a single active-high internal reset. All other resets are synchronous. UART_TXD_IN is synchronised inside the shell's receiver. No other crossings.

## Pin list

| Port | Dir | Width | Role |
|---|---|---|---|
| CLK100MHZ | in | 1 | 100 MHz system clock |
| CPU_RESETN | in | 1 | CPU reset button, active low |
| UART_TXD_IN | in | 1 | USB-UART host to FPGA (shell RX) |
| UART_RXD_OUT | out | 1 | USB-UART FPGA to host (shell TX) |
| LED | out | 16 | commands-carried-out count, low 16 bits |

## Resource prediction

LUT 900 to 3500, FF 700 to 3000, BRAM 0, DSP 0. Byte buffers are small, held in distributed RAM or registers; CRC-32 is bytewise logic.
