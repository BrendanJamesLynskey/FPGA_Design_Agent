"""Pytest entry: runs the cocotb bench (bench_udp.py) against the RTL, one run per seed."""
import sys
from pathlib import Path

DESIGN = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(DESIGN))
sys.path.insert(0, str(DESIGN / "tests"))

try:
    from flow import cocotb_run
except ImportError:  # find the repo root that holds flow/
    for _p in Path(__file__).resolve().parents:
        if (_p / "flow").is_dir():
            sys.path.insert(0, str(_p))
            break
    from flow import cocotb_run

# Keep equal to CPB in tests/bench_udp.py
PARAMS = {"CLKS_PER_BIT": 8}


def test_v2_e_udp_endpoint_rtl():
    sources = list(cocotb_run.SHELL_RTL) + sorted((DESIGN / "rtl").glob("*.sv"))
    for seed in (1, 2, 3):
        cocotb_run.run(
            "v2_e_udp_endpoint",
            "v2_e_udp_endpoint_top",
            sources,
            "bench_udp",
            DESIGN / "tests",
            parameters=PARAMS,
            seed=seed,
        )
