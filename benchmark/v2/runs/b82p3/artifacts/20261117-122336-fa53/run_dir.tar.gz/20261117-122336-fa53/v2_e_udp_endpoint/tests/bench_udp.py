"""cocotb bench for v2_e_udp_endpoint: drives the window registers through the UART test shell
(PROTOCOL.md 1.1) and checks the RTL against model.py and against spec-derived expectations."""
import random
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402,F401
from model import Model  # noqa: E402

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ClockCycles, FallingEdge  # noqa: E402

CPB = 8
PARAMS = {"CLKS_PER_BIT": CPB}
ID_WORD = 0x55445031
WIN = 0x80


def mk(typ, seq, payload=(), ln=None, bad_crc=False, extra=()):
    payload = list(payload)
    ln = len(payload) if ln is None else ln
    body = [typ & 255, ln & 255, (seq >> 8) & 255, seq & 255] + payload + list(extra)
    c = zlib.crc32(bytes(body))
    if bad_crc:
        c ^= 0x00000100
    return body + [(c >> (8 * i)) & 255 for i in range(4)]


# Payload sizes follow the spec: read 2 bytes, write 6 bytes (register number in the first byte,
# the value in the next four, one spare byte), telemetry start 2.
def p_read(s, r):
    return mk(1, s, [r, 0])


def p_write(s, r, v):
    return mk(2, s, [r] + list(v.to_bytes(4, "big")) + [0])


def p_tstart(s, per):
    return mk(3, s, list(per.to_bytes(2, "big")))


def p_status(s):
    return mk(4, s, [])


def p_stop(s):
    return mk(5, s, [])


def frame_bytes(seq, t, c, r):
    body = [0xC0, 0, (seq >> 8) & 255, seq & 255, 8]
    body += list((t & 0xFFFFFFFF).to_bytes(4, "big"))
    body += list((c & 0xFFFF).to_bytes(2, "big"))
    body += list((r & 0xFFFF).to_bytes(2, "big"))
    return body + list(zlib.crc32(bytes(body)).to_bytes(4, "little"))


def word_of(data, i):
    v = 0
    for k in range(4):
        j = 4 * i + k
        v = (v << 8) | (data[j] if j < len(data) else 0)
    return v


def parse(r):
    if not r:
        return None
    assert len(r) >= 9, f"reply too short {r}"
    ln = r[4]
    assert len(r) == 9 + ln, f"reply length {len(r)} does not match payload length {ln}"
    assert int.from_bytes(bytes(r[-4:]), "little") == zlib.crc32(bytes(r[:-4])), "reply CRC"
    return dict(typ=r[0], status=r[1], seq=(r[2] << 8) | r[3], payload=list(r[5:5 + ln]))


KINDS = {
    "ok": (0, "cmds"), "long": (None, "long"), "short": (None, "short"), "bad": (None, "bad"),
    "s1": (1, "err"), "s2": (2, "err"), "s3": (3, "err"), "s5": (5, "err"),
    "rep": (4, "rep"), "ooo": (4, "ooo"),
}


class Bench:
    def __init__(self, dut, rng=None):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        self.m = Model(**PARAMS)
        self.rng = rng or random.Random(getattr(cocotb, "RANDOM_SEED", 1))
        self.rxq = []
        self.reset_trackers()

    def reset_trackers(self):
        self.cnt = dict(cmds=0, bad=0, short=0, long=0, rep=0, ooo=0, err=0, ref=0)
        self.scr = {1: 0, 2: 0, 3: 0}
        self.period = 100
        self.ticks_total = 0
        self.tlm_on = 0
        self.fcount = 0
        self.fseq = 0
        self.last = None
        self.seq = self.rng.randrange(65536)

    async def start(self):
        self.dut.UART_TXD_IN.value = 1
        self.dut.CPU_RESETN.value = 0
        cocotb.start_soon(Clock(self.clk, 10, "ns").start())
        cocotb.start_soon(self._rx())
        await self.do_reset()

    async def do_reset(self, cycles=10):
        self.dut.UART_TXD_IN.value = 1
        self.dut.CPU_RESETN.value = 0
        await ClockCycles(self.clk, cycles)
        self.dut.CPU_RESETN.value = 1
        await ClockCycles(self.clk, cycles)
        self.m.reset()
        self.rxq.clear()
        self.reset_trackers()

    def ns(self):
        self.seq = (self.seq + 1) & 0xFFFF
        return self.seq

    # ------------------------------------------------------------------ UART
    async def _rx(self):
        rx = self.dut.UART_RXD_OUT
        while True:
            await FallingEdge(rx)
            await ClockCycles(self.clk, CPB + CPB // 2)
            v = 0
            for i in range(8):
                v |= (int(rx.value) & 1) << i
                await ClockCycles(self.clk, CPB)
            self.rxq.append(v)

    async def _tx_byte(self, b):
        for bit in [0] + [(b >> i) & 1 for i in range(8)] + [1]:
            self.dut.UART_TXD_IN.value = bit
            await ClockCycles(self.clk, CPB)

    async def xfer(self, cmd, addr, data=0):
        body = [cmd, addr] + list(data.to_bytes(4, "little"))
        chk = 0
        for b in body:
            chk ^= b
        self.rxq.clear()
        for b in [0xA5] + body + [chk]:
            await self._tx_byte(b)
        for _ in range(400):
            if len(self.rxq) >= 7:
                break
            await ClockCycles(self.clk, 8)
        assert len(self.rxq) >= 7, f"no shell response ({len(self.rxq)} bytes)"
        r = self.rxq[:7]
        del self.rxq[:7]
        assert r[0] == 0x5A, f"bad response sync {r}"
        c = 0
        for b in r[1:6]:
            c ^= b
        assert c == r[6], f"bad response checksum {r}"
        await ClockCycles(self.clk, 2 * CPB)
        return r[1], int.from_bytes(bytes(r[2:6]), "little")

    async def rd(self, off):
        st, d = await self.xfer(1, WIN + off)
        assert st == 0, f"shell read status {st} at {off}"
        return d

    async def wr(self, off, val):
        st, d = await self.xfer(2, WIN + off, val)
        assert st == 0, f"shell write status {st} at {off}"

    async def wr_m(self, off, val):
        await self.wr(off, val)
        self.m.write_reg(off, val)
        if off == 1:
            for _ in range((val & 255) + 2):
                self.m.step()

    # ------------------------------------------------------------------ packet level
    async def pkt(self, data):
        for i, b in enumerate(data):
            await self.wr_m(0, b | (0x100 if i == len(data) - 1 else 0))

    async def reply(self):
        n = await self.rd(2)
        assert n == self.m.read_reg(2), f"RLEN {n} != model {self.m.read_reg(2)}"
        out = []
        for i in range((n + 3) // 4 + 1):
            await self.wr_m(3, i)
            got = await self.rd(4)
            exp = self.m.read_reg(4)
            assert got == exp, f"RWORD[{i}] {got:#x} != model {exp:#x}"
            out += list(got.to_bytes(4, "big"))
        led = self.m.step()["LED"]
        assert int(self.dut.LED.value) == led, f"LED {int(self.dut.LED.value):#x} != model {led:#x}"
        return out[:n]

    async def tele(self):
        n = await self.rd(5)
        assert n == self.m.read_reg(5), f"TLEN {n} != model {self.m.read_reg(5)}"
        out = []
        for i in range((n + 3) // 4 + 1):
            await self.wr_m(6, i)
            got = await self.rd(7)
            exp = self.m.read_reg(7)
            assert got == exp, f"TWORD[{i}] {got:#x} != model {exp:#x}"
            out += list(got.to_bytes(4, "big"))
        return out[:n]

    async def check_all(self):
        await self.reply()
        await self.tele()
        s = await self.rd(9)
        assert s == self.m.read_reg(9), f"STAT {s} != model {self.m.read_reg(9)}"
        for off in (3, 6):
            v = await self.rd(off)
            assert v == self.m.read_reg(off), f"reg {off} {v} != model"

    async def cmd(self, data):
        await self.pkt(data)
        return parse(await self.reply())

    async def expect(self, data, kind, payload=None):
        rep = await self.cmd(data)
        st, key = KINDS[kind]
        if st is None:
            assert rep is None, f"{kind}: expected silent drop, got {rep}"
        else:
            assert rep is not None, f"{kind}: expected a reply"
            assert rep["status"] == st, f"{kind}: status {rep['status']} != {st}"
            assert rep["typ"] == ((data[0] | 0x80) & 255), f"reply type {rep['typ']:#x}"
            assert rep["seq"] == ((data[2] << 8) | data[3]), "reply seq"
            if payload is not None:
                assert rep["payload"] == list(payload), f"payload {rep['payload']} != {list(payload)}"
            elif st != 0:
                assert rep["payload"] == [], "non-zero status must carry no payload"
            if kind in ("ok", "s3", "s5"):
                self.last = (data[2] << 8) | data[3]
        self.cnt[key] += 1
        if kind != "ok":
            self.cnt["ref"] += 1
        assert int(self.dut.LED.value) == (self.cnt["cmds"] & 0xFFFF), "LED vs commands carried out"
        return rep

    def regval(self, r):
        return {0: ID_WORD, 1: self.scr[1], 2: self.scr[2], 3: self.scr[3], 4: self.cnt["cmds"],
                5: self.cnt["ref"], 6: self.period, 7: self.ticks_total}[r] & 0xFFFFFFFF

    async def read(self, r, seq=None):
        s = self.ns() if seq is None else seq
        exp = self.regval(r)
        await self.expect(p_read(s, r), "ok", list(exp.to_bytes(4, "big")))
        return exp

    async def write(self, r, v, seq=None):
        s = self.ns() if seq is None else seq
        await self.expect(p_write(s, r, v), "ok", [])
        if 1 <= r <= 3:
            self.scr[r] = v

    async def tstart(self, per, seq=None):
        s = self.ns() if seq is None else seq
        await self.expect(p_tstart(s, per), "ok", [])
        self.tlm_on = 1
        if per != 0:
            self.period = max(per, 4)

    async def stop(self, seq=None):
        s = self.ns() if seq is None else seq
        await self.expect(p_stop(s), "ok", [])
        self.tlm_on = 0

    async def status(self, seq=None):
        s = self.ns() if seq is None else seq
        c = self.cnt
        exp = [c["cmds"], c["bad"], c["short"], c["long"], c["rep"], c["ooo"], c["err"], self.fcount]
        pl = []
        for v in exp:
            pl += [(v >> 8) & 255, v & 255]
        pl.append(self.tlm_on)
        assert len(pl) == 17
        await self.expect(p_status(s), "ok", pl)

    async def tick(self, n):
        await self.wr_m(1, n)
        self.ticks_total += n

    async def take(self):
        await self.wr_m(8, 0)

    async def frame_after(self, n):
        """No frame held: n-1 ticks leave none, the n-th makes one due."""
        if n > 1:
            await self.tick(n - 1)
            assert await self.tele() == [], "frame fell due too early"
        c, r = self.cnt["cmds"], self.cnt["ref"]
        await self.tick(1)
        f = await self.tele()
        assert f == frame_bytes(self.fseq, self.ticks_total, c, r), f"frame {f}"
        self.fseq += 1
        self.fcount += 1
        return f


# ============================================================================ tests

# req: REQ-21, REQ-22, REQ-23, REQ-52, REQ-42, REQ-44, REQ-46, REQ-48
@cocotb.test()
async def test_reset_smoke(dut):
    B = Bench(dut)
    await B.start()
    await B.check_all()
    assert int(dut.LED.value) == 0
    assert await B.rd(2) == 0 and await B.rd(5) == 0 and await B.rd(9) == 0
    assert await B.read(0) == ID_WORD
    # spec parameter ID_WORD = 0x55445031 (ASCII "UDP1"); the register must read this value
    assert ID_WORD == 1430540337
    for r in (1, 2, 3):
        assert await B.read(r) == 0
    assert await B.read(6) == 100
    await B.check_all()


# req: REQ-01, REQ-18, REQ-19, REQ-23, REQ-24, REQ-22
@cocotb.test()
async def test_read_registers(dut):
    B = Bench(dut)
    await B.start()
    await B.write(1, 0xDEADBEEF)
    await B.write(2, 0x01020304)
    await B.expect(p_read(B.ns(), 9), "s3")
    await B.tick(10)
    a = await B.read(4)
    b = await B.read(4)
    assert b == a + 1
    r1 = await B.read(5)
    r2 = await B.read(5)
    assert r1 == r2 == 1
    for r in range(8):
        await B.read(r)
    assert await B.read(7) == 10
    rep = await B.expect(p_read(B.ns(), 1), "ok", [0xDE, 0xAD, 0xBE, 0xEF])
    assert len(rep["payload"]) == 4
    await B.check_all()


# req: REQ-09, REQ-11, REQ-15, REQ-20, REQ-21
@cocotb.test()
async def test_write_registers(dut):
    B = Bench(dut)
    await B.start()
    vals = [0, 1, 0xFFFFFFFF, 0x80000001, 0x12345678, 0xA5A5A5A5, 0x00FF00FF]
    for i, v in enumerate(vals):
        await B.write(1 + i % 3, v)
        for r in (1, 2, 3):
            await B.read(r)
    for r in (0, 4, 5, 6, 7):
        s = B.ns()
        await B.expect(p_write(s, r, 0xDEADBEEF), "s5")
        await B.expect(p_read(s, 0), "rep")
        exp = B.regval(r)  # value before this read is counted
        assert await B.read(r) == exp
    assert await B.read(0) == ID_WORD
    assert await B.read(6) == 100
    for r in (8, 9, 15, 255):
        s = B.ns()
        await B.expect(p_write(s, r, 5), "s3")
        await B.expect(p_read(s, r), "rep")
        await B.expect(p_read(B.ns(), r), "s3")
    await B.status()
    await B.check_all()


# req: REQ-01, REQ-02, REQ-03, REQ-04, REQ-05, REQ-06, REQ-07, REQ-08, REQ-16, REQ-17, REQ-25, REQ-26, REQ-27
@cocotb.test()
async def test_framing_errors(dut):
    B = Bench(dut)
    await B.start()
    s = B.ns
    await B.read(0)
    # too long
    await B.expect(mk(1, s(), [0] * 9), "long")
    await B.expect(mk(1, s(), [0, 0], ln=200), "long")
    await B.expect(mk(1, s(), [0, 0], ln=9), "long")
    await B.expect(mk(1, s(), [0, 0], extra=[0x55]), "long")
    await B.expect(mk(4, s(), [], extra=[1, 2, 3]), "long")
    await B.expect(mk(1, s(), [0] * 9, bad_crc=True), "long")
    await B.expect([1, 0xFF, 0, 0], "long")
    await B.expect(mk(1, B.last, [0, 0], extra=[1, 2]), "long")
    # too short
    for d in ([0x01], [1, 0], [1, 0, 0], [1, 0xFF, 0], [0x42]):
        await B.expect(d, "short")
    await B.expect([4, 0, 0, 5], "short")
    await B.expect([4, 0, 0, 5, 0, 0, 0], "short")
    await B.expect(mk(1, s(), [], ln=2), "short")
    await B.expect(mk(1, s(), [0], ln=2), "short")
    await B.expect(mk(1, s(), [0, 0], bad_crc=True)[:-1], "short")
    await B.expect(mk(4, s(), [])[:-1], "short")
    # bad check, valid size
    await B.expect(mk(1, s(), [0, 0], bad_crc=True), "bad")
    d = mk(1, s(), [0, 0])
    d[4] ^= 1
    await B.expect(d, "bad")
    d = mk(4, s(), [])
    d[0] ^= 0x40
    await B.expect(d, "bad")
    d = mk(4, s(), [])
    d[-1] ^= 0x80
    await B.expect(d, "bad")
    d = mk(4, s(), [])
    d[3] ^= 1
    await B.expect(d, "bad")
    await B.expect(mk(9, s(), [], bad_crc=True), "bad")
    await B.expect(mk(1, B.last, [9, 0], bad_crc=True), "bad")
    # unknown type before length and sequence
    for t in (0, 6, 7, 0x7F, 0x80, 0xC0, 0xFF):
        await B.expect(mk(t, s(), []), "s1")
    await B.expect(mk(9, s(), [1, 2, 3]), "s1")
    await B.expect(mk(9, B.last, []), "s1")
    await B.expect(mk(0xFF, B.last, [1]), "s1")
    # wrong length before sequence
    for typ, plens in ((1, (0, 1, 3, 4, 8)), (2, (0, 1, 2, 5, 7, 8)), (3, (0, 1, 3)), (4, (1, 2, 8)), (5, (1, 8))):
        for pl in plens:
            await B.expect(mk(typ, s(), [0] * pl), "s2")
    await B.expect(mk(1, B.last, [0]), "s2")
    await B.expect(mk(4, B.last, [0]), "s2")
    # sequence before register
    await B.expect(mk(1, B.last, [9, 0]), "rep")
    await B.expect(p_write(B.last, 0, 1), "rep")
    await B.expect(p_write((B.last - 5) & 0xFFFF, 0, 1), "ooo")
    await B.expect(mk(1, (B.last - 1) & 0xFFFF, [200, 0]), "ooo")
    await B.status()
    await B.status()
    await B.check_all()


# req: REQ-10, REQ-12, REQ-13, REQ-14, REQ-15, REQ-16, REQ-17, REQ-29
@cocotb.test()
async def test_sequence(dut):
    B = Bench(dut)
    await B.start()
    for first in (0xABCD, 0, 0xFFFF, 0x8000, 0x7FFF, 0x0001):
        await B.do_reset()
        B.seq = first
        await B.read(0, seq=first)
        await B.expect(p_read(first, 0), "rep")
        await B.check_all()
    await B.do_reset()
    await B.read(0, seq=100)
    await B.expect(p_read(100, 0), "rep")
    await B.expect(p_read(99, 0), "ooo")
    await B.read(0, seq=101)
    await B.read(0, seq=101 + 32767)
    last = (101 + 32767) & 0xFFFF
    await B.expect(p_read((last + 32768) & 0xFFFF, 0), "ooo")
    await B.expect(p_read((last + 32769) & 0xFFFF, 0), "ooo")
    await B.expect(p_read((last - 1) & 0xFFFF, 0), "ooo")
    await B.expect(p_read(last, 0), "rep")
    await B.read(0, seq=last + 1)
    await B.read(0, seq=0xFFFF)
    await B.read(0, seq=0)
    await B.read(0, seq=1)
    await B.expect(p_read(0, 0), "ooo")
    await B.expect(p_read(1, 0), "rep")
    await B.expect(p_read(0xFFFF, 0), "ooo")
    # a refused packet changes nothing
    B.seq = B.last
    await B.write(1, 0x11111111)
    await B.expect(p_write(B.last, 1, 0x22222222), "rep")
    await B.expect(p_write((B.last - 3) & 0xFFFF, 2, 0x33333333), "ooo")
    assert await B.read(1) == 0x11111111
    assert await B.read(2) == 0
    B.seq = B.last
    await B.expect(p_tstart(B.last, 50), "rep")
    assert await B.rd(9) == 0
    assert await B.read(6) == 100
    B.seq = B.last
    await B.tstart(8)
    assert await B.rd(9) == 1
    await B.expect(p_stop(B.last), "rep")
    await B.expect(p_stop((B.last - 9) & 0xFFFF), "ooo")
    assert await B.rd(9) == 1
    await B.expect(p_tstart(B.last, 50), "rep")
    assert await B.read(6) == 8
    B.seq = B.last
    f = await B.frame_after(8)
    await B.expect(p_stop(B.last), "rep")
    assert await B.tele() == f
    assert await B.rd(9) == 1
    await B.check_all()
    B.seq = B.last
    await B.read(3)
    # the number is consumed even if the register check fails
    s = B.ns()
    await B.expect(p_write(s, 0, 1), "s5")
    await B.expect(p_read(s, 0), "rep")
    s = B.ns()
    await B.expect(mk(1, s, [12, 0]), "s3")
    await B.expect(mk(1, s, [0, 0]), "rep")
    await B.read(0)
    await B.status()
    await B.check_all()


# req: REQ-25, REQ-26, REQ-28, REQ-29, REQ-30, REQ-31, REQ-32, REQ-33, REQ-34, REQ-35, REQ-36, REQ-37, REQ-38, REQ-39, REQ-40, REQ-44, REQ-46
@cocotb.test()
async def test_telemetry(dut):
    B = Bench(dut)
    await B.start()
    await B.tstart(0)                       # zero keeps the default period 100
    assert await B.read(6) == 100
    assert await B.rd(9) & 1 == 1
    f0 = await B.frame_after(100)
    # a frame falling due while one is held is dropped: no sequence number, no count
    await B.tick(100)
    assert await B.tele() == f0
    await B.status()
    await B.read(4)
    assert await B.tele() == f0
    await B.take()
    assert await B.tele() == []
    assert await B.rd(5) == 0
    await B.frame_after(100)                # sequence 1, not 2
    assert B.fseq == 2
    await B.status()
    await B.take()
    # period below 4 becomes 4; start restarts the count
    await B.tick(2)
    await B.tstart(3)
    assert await B.read(6) == 4
    await B.frame_after(4)
    await B.take()
    # period 0 keeps the previous period
    await B.tick(3)
    await B.tstart(0)
    assert await B.read(6) == 4
    await B.frame_after(4)
    await B.take()
    for per, shown in ((1, 4), (2, 4), (5, 5)):
        await B.tstart(per)
        assert await B.read(6) == shown
    await B.frame_after(5)
    await B.take()
    # period above 255
    await B.tstart(0x100)
    assert B.period == 256
    await B.frame_after(256)
    await B.take()
    # stop discards a held frame and switches off
    await B.tstart(4)
    await B.frame_after(4)
    assert await B.rd(5) == 17
    await B.stop()
    assert await B.tele() == []
    assert await B.rd(9) == 0
    await B.tick(255)
    assert await B.tele() == []
    await B.status()
    await B.stop()
    await B.tstart(0)                       # keeps period 4; frame sequence continues
    await B.frame_after(4)
    await B.status()
    await B.check_all()
    # reset clears frame sequence and frame count
    await B.do_reset()
    await B.status()
    await B.tstart(4)
    await B.frame_after(4)
    assert (await B.tele())[:5] == [0xC0, 0, 0, 0, 8]
    await B.status()
    await B.check_all()


# req: REQ-41, REQ-30
@cocotb.test()
async def test_tick(dut):
    B = Bench(dut)
    await B.start()
    assert await B.read(7) == 0
    for n in (0, 1, 2, 255, 17, 0, 128):
        await B.tick(n)
        assert await B.read(7) == B.ticks_total
    await B.tstart(4)
    await B.tick(3)
    assert await B.tele() == []
    await B.tick(0)
    assert await B.tele() == []
    await B.tick(1)
    f = await B.tele()
    assert len(f) == 17
    await B.take()
    await B.tick(255)
    await B.check_all()
    assert await B.read(7) == B.ticks_total


# req: REQ-42, REQ-43, REQ-44, REQ-45, REQ-18, REQ-40
@cocotb.test()
async def test_readback_window(dut):
    B = Bench(dut)
    await B.start()
    s = B.ns()
    await B.expect(p_read(s, 0), "ok")
    exp = [0x81, 0, s >> 8, s & 255, 4, 0x55, 0x44, 0x50, 0x31]
    exp += list(zlib.crc32(bytes(exp)).to_bytes(4, "little"))
    assert await B.rd(2) == 13 == len(exp)
    for i in (0, 1, 2, 3, 4, 5, 100, 127):
        await B.wr_m(3, i)
        assert await B.rd(3) == i
        assert await B.rd(4) == word_of(exp, i), f"reply word {i}"
    await B.wr_m(3, 0x85)
    assert await B.rd(3) == 5
    await B.status()
    assert await B.rd(2) == 26
    await B.expect([1, 2], "short")
    assert await B.rd(2) == 0
    await B.wr_m(3, 0)
    assert await B.rd(4) == 0
    await B.tstart(4)
    assert await B.rd(2) == 9               # telemetry start reply: header + CRC, no payload
    f = await B.frame_after(4)
    assert await B.rd(5) == 17 == len(f)
    await B.wr_m(3, 1)
    for i in (0, 1, 2, 3, 4, 5, 127):
        await B.wr_m(6, i)
        assert await B.rd(6) == i
        assert await B.rd(7) == word_of(f, i), f"telemetry word {i}"
    assert await B.rd(3) == 1
    await B.take()
    assert await B.rd(5) == 0
    await B.wr_m(6, 2)
    assert await B.rd(7) == 0
    for off in (0, 1, 8, 10, 11, 64, 127):
        assert await B.rd(off) == 0
    for off in (2, 4, 5, 7, 9, 10, 100):
        await B.wr_m(off, 0xFFFFFFFF)
    await B.check_all()
    assert await B.rd(2) == 9


# req: REQ-46, REQ-47, REQ-48
@cocotb.test()
async def test_led_status(dut):
    B = Bench(dut)
    await B.start()
    assert int(dut.LED.value) == 0
    for i in range(6):
        await B.read(0)
        assert int(dut.LED.value) == (i + 1)
    await B.expect([1], "short")
    assert int(dut.LED.value) == 6
    await B.expect(mk(1, B.ns(), [9, 0]), "s3")
    assert int(dut.LED.value) == 6
    st = await B.rd(9)
    assert st & 1 == 0 and st & 2 == 0
    await B.tstart(4)
    st = await B.rd(9)
    assert st & 1 == 1 and st & 2 == 0
    assert int(dut.LED.value) == 7
    await B.stop()
    st = await B.rd(9)
    assert st & 1 == 0 and st & 2 == 0
    assert int(dut.LED.value) == 8
    await B.check_all()


# req: REQ-49, REQ-21, REQ-22, REQ-36, REQ-37, REQ-13, REQ-48
@cocotb.test()
async def test_reset_midrun(dut):
    B = Bench(dut)
    await B.start()
    await B.write(1, 0x1234)
    await B.write(2, 0x5678)
    await B.write(3, 0x9ABC)
    await B.tstart(5)
    await B.frame_after(5)
    await B.tick(3)
    await B.read(4)
    await B.expect([1], "short")
    await B.wr_m(3, 2)
    await B.wr_m(6, 3)
    for b in (1, 0, 0):                     # partial packet, no end flag
        await B.wr_m(0, b)
    old = B.last
    await B.do_reset()
    await B.check_all()
    assert int(dut.LED.value) == 0
    assert await B.rd(3) == 0 and await B.rd(6) == 0
    assert await B.rd(2) == 0 and await B.rd(5) == 0 and await B.rd(9) == 0
    B.seq = (old - 1) & 0xFFFF
    for r in (1, 2, 3):
        assert await B.read(r) == 0         # the pre-reset number is accepted again
    assert await B.read(6) == 100
    assert await B.read(4) == 4
    assert await B.read(5) == 0
    assert await B.read(7) == 0
    await B.status()
    await B.tstart(4)
    await B.frame_after(4)
    await B.check_all()


# req: REQ-50, REQ-51, REQ-53
# REQ-53 (timing closure) is discharged by analysis post_route:setup; this test only runs the
# design on a 10 ns (100 MHz) clock as functional context.
@cocotb.test()
async def test_back_to_back(dut):
    B = Bench(dut)
    await B.start()
    s = B.ns
    seq = [p_write(s(), 1, 0x01020304), p_read(s(), 1), mk(1, s(), [0, 0], bad_crc=True),
           p_status(s()), p_tstart(s(), 4), p_read(s(), 4), [3], p_read(s(), 0), p_stop(s()),
           p_read(s(), 1)]
    for d in seq:
        await B.pkt(d)                      # next packet right after the last-flag byte
    await B.check_all()
    rep = parse(await B.reply())
    assert rep is not None and rep["status"] == 0 and rep["payload"] == [1, 2, 3, 4]
    await B.pkt([1])
    await B.pkt(p_read(s(), 0))
    rep = parse(await B.reply())
    assert rep["status"] == 0 and rep["payload"] == list(ID_WORD.to_bytes(4, "big"))
    await B.check_all()


def rand_data(rng, s):
    t = rng.choice([1, 1, 2, 2, 3, 4, 5])
    if t == 1:
        pl = [rng.randrange(10), 0]
    elif t == 2:
        v = rng.choice([0, 1, 0xFFFFFFFF, rng.randrange(1 << 32)])
        pl = [rng.randrange(10)] + list(v.to_bytes(4, "big")) + [0]
    elif t == 3:
        per = rng.choice([0, 1, 2, 3, 4, 4, 5, 6, 9, 300, rng.randrange(65536)])
        pl = list(per.to_bytes(2, "big"))
    else:
        pl = []
    m = rng.random()
    if m < 0.55:
        return mk(t, s, pl)
    if m < 0.62:
        return mk(t, s, pl, bad_crc=True)
    if m < 0.70:
        d = mk(t, s, pl)
        return d[:rng.randint(1, len(d) - 1)]
    if m < 0.78:
        return mk(t, s, pl, extra=[rng.randrange(256) for _ in range(rng.randint(1, 3))])
    if m < 0.86:
        return mk(t, s, [rng.randrange(256) for _ in range(rng.randint(0, 8))])
    if m < 0.92:
        return mk(rng.choice([0, 6, 7, 0x80, 0xC0, 0xFF]), s, pl)
    if m < 0.96:
        return mk(t, s, pl, ln=rng.randint(9, 255))
    return mk(t, s, pl, ln=rng.randint(0, 8))


# req: REQ-02, REQ-03, REQ-04, REQ-05, REQ-06, REQ-12, REQ-14, REQ-16, REQ-17, REQ-18, REQ-30, REQ-31, REQ-32, REQ-35, REQ-42, REQ-43
@cocotb.test()
async def test_random_traffic(dut):
    rng = random.Random(getattr(cocotb, "RANDOM_SEED", 1))
    B = Bench(dut, rng)
    await B.start()
    for it in range(60):
        a = rng.random()
        if a < 0.10:
            await B.tick(rng.choice([0, 1, 2, 3, 4, 5, 8, 20, 100, 255]))
            await B.tele()
        elif a < 0.14:
            await B.take()
            await B.tele()
        elif a < 0.16:
            await B.do_reset()
            await B.check_all()
        else:
            r = rng.random()
            if r < 0.78:
                s = B.ns()
            elif r < 0.88:
                s = B.seq
            elif r < 0.95:
                s = (B.seq - rng.randint(1, 40000)) & 0xFFFF
            else:
                s = rng.randrange(65536)
            if rng.random() < 0.15:
                data = mk(3, s, list(rng.choice([0, 1, 3, 4, 5, 6]).to_bytes(2, "big")))
            else:
                data = rand_data(rng, s)
            await B.cmd(data)
        if it % 6 == 5:
            await B.check_all()
    await B.check_all()
    await B.cmd(p_status(B.ns()))
