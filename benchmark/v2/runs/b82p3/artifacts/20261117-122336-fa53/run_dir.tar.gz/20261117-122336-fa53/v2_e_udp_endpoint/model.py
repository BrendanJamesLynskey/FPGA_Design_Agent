class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000, BUILD_STAMP=0,
                 ID_WORD=1430540337, NUM_REGS=8, MAX_PAYLOAD=8,
                 DEFAULT_PERIOD=100, MIN_PERIOD=4, REPLY_BUILD_CYCLES=100,
                 SEQ_WINDOW=32767, CRC_POLY=3988292384):
        self.p = dict(ID_WORD=ID_WORD, NUM_REGS=NUM_REGS, MAX_PAYLOAD=MAX_PAYLOAD,
                      DEFAULT_PERIOD=DEFAULT_PERIOD, MIN_PERIOD=MIN_PERIOD,
                      SEQ_WINDOW=SEQ_WINDOW, CRC_POLY=CRC_POLY)
        self.inputs = {}
        self.reset()

    def _crc(self, data):
        poly = self.p['CRC_POLY']
        c = 0xFFFFFFFF
        for b in data:
            c ^= b
            for _ in range(8):
                c = (c >> 1) ^ poly if c & 1 else c >> 1
        return c ^ 0xFFFFFFFF

    def reset(self):
        self.buf = []
        self.scratch = [0, 0, 0, 0]
        self.cmds = 0
        self.refused = 0
        self.c_bad = self.c_short = self.c_long = 0
        self.c_rep = self.c_ooo = self.c_err = 0
        self.last = None
        self.period = self.p['DEFAULT_PERIOD']
        self.ticks = 0
        self.pending = 0
        self.tlm_on = 0
        self.tcount = 0
        self.held = None
        self.fseq = 0
        self.fcount = 0
        self.reply = []
        self.ridx = 0
        self.tidx = 0

    def _outputs(self):
        return {'UART_RXD_OUT': 1, 'LED': self.cmds & 0xFFFF}

    def _tick(self):
        self.ticks = (self.ticks + 1) & 0xFFFFFFFF
        if self.tlm_on:
            self.tcount += 1
            if self.tcount >= self.period:
                self.tcount = 0
                if self.held is None:
                    body = [0xC0, 0, (self.fseq >> 8) & 255, self.fseq & 255, 8]
                    for v, n in ((self.ticks, 4), (self.cmds, 2), (self.refused, 2)):
                        body += [(v >> (8 * (n - 1 - i))) & 255 for i in range(n)]
                    c = self._crc(body)
                    body += [(c >> (8 * i)) & 255 for i in range(4)]
                    self.held = body
                    self.fseq = (self.fseq + 1) & 0xFFFF
                    self.fcount = (self.fcount + 1) & 0xFFFF

    def step(self, inputs=None):
        if inputs:
            self.inputs.update(inputs)
        if self.inputs.get('CPU_RESETN', 1) == 0:
            self.reset()
            return self._outputs()
        if self.pending > 0:
            self.pending -= 1
            self._tick()
        return self._outputs()

    def _word(self, data, i):
        v = 0
        for k in range(4):
            j = 4 * i + k
            v = (v << 8) | (data[j] if j < len(data) else 0)
        return v

    def read_reg(self, offset):
        if offset == 2:
            return len(self.reply)
        if offset == 3:
            return self.ridx
        if offset == 4:
            return self._word(self.reply, self.ridx)
        if offset == 5:
            return len(self.held) if self.held else 0
        if offset == 6:
            return self.tidx
        if offset == 7:
            return self._word(self.held or [], self.tidx)
        if offset == 9:
            return self.tlm_on & 1
        return 0

    def write_reg(self, offset, value):
        if offset == 0:
            self.buf.append(value & 255)
            if value & 0x100:
                b = self.buf
                self.buf = []
                self._process(b)
        elif offset == 1:
            self.pending = value & 255
        elif offset == 3:
            self.ridx = value & 127
        elif offset == 6:
            self.tidx = value & 127
        elif offset == 8:
            self.held = None

    def _refuse(self, which):
        setattr(self, which, (getattr(self, which) + 1) & 0xFFFF)
        self.refused = (self.refused + 1) & 0xFFFFFFFF
        self.reply = []

    def _reg_val(self, r):
        if r == 0:
            return self.p['ID_WORD']
        if 1 <= r <= 3:
            return self.scratch[r]
        if r == 4:
            return self.cmds
        if r == 5:
            return self.refused
        if r == 6:
            return self.period
        return self.ticks

    def _process(self, b):
        n = len(b)
        if n < 4:
            return self._refuse('c_short')
        ln = b[1]
        if ln > self.p['MAX_PAYLOAD'] or n > 8 + ln:
            return self._refuse('c_long')
        if n < 8 + ln:
            return self._refuse('c_short')
        trailer = b[-4] | (b[-3] << 8) | (b[-2] << 16) | (b[-1] << 24)
        if self._crc(b[:-4]) != trailer:
            return self._refuse('c_bad')
        typ = b[0]
        seq = (b[2] << 8) | b[3]
        pl = b[4:4 + ln]
        status = 0
        payload = []
        need = {1: 2, 2: 6, 3: 2, 4: 0, 5: 0}
        if typ not in need:
            status = 1
        elif ln != need[typ]:
            status = 2
        if status == 0 and self.last is not None:
            d = (seq - self.last) & 0xFFFF
            if not (1 <= d <= self.p['SEQ_WINDOW']):
                status = 4
        if status in (1, 2):
            self._refuse('c_err')
            return self._finish(typ, status, seq, [])
        if status == 4:
            self._refuse('c_rep' if seq == self.last else 'c_ooo')
            return self._finish(typ, status, seq, [])
        self.last = seq
        if typ in (1, 2):
            r = (pl[0] << 8) | pl[1]
            if r >= self.p['NUM_REGS']:
                status = 3
            elif typ == 2 and not (1 <= r <= 3):
                status = 5
            elif typ == 1:
                v = self._reg_val(r)
                payload = [(v >> s) & 255 for s in (24, 16, 8, 0)]
            else:
                self.scratch[r] = (pl[2] << 24) | (pl[3] << 16) | (pl[4] << 8) | pl[5]
        elif typ == 3:
            per = (pl[0] << 8) | pl[1]
            if per != 0:
                self.period = max(per, self.p['MIN_PERIOD'])
            self.tlm_on = 1
            self.tcount = 0
        elif typ == 4:
            for v in (self.cmds, self.c_bad, self.c_short, self.c_long,
                      self.c_rep, self.c_ooo, self.c_err, self.fcount):
                payload += [(v >> 8) & 255, v & 255]
            payload.append(self.tlm_on)
        elif typ == 5:
            self.tlm_on = 0
            self.held = None
        if status != 0:
            self._refuse('c_err')
            return self._finish(typ, status, seq, [])
        self.cmds = (self.cmds + 1) & 0xFFFFFFFF
        self._finish(typ, 0, seq, payload)

    def _finish(self, typ, status, seq, payload):
        body = [typ | 0x80, status, (seq >> 8) & 255, seq & 255, len(payload)] + payload
        c = self._crc(body)
        self.reply = body + [(c >> (8 * i)) & 255 for i in range(4)]
