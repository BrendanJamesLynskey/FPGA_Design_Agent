# v2_e_udp_endpoint architecture

UDP command and telemetry endpoint on the Nexys A7-100T (xc7a100tcsg324-1). Packet bytes enter through the test shell register window (IN register), are judged and answered; replies and telemetry frames are read back through the window.

## Block diagram

```text
 UART_TXD_IN --> [fpga_shell] <-- UART_RXD_OUT
                    | win_* (addr, wr, rd, wdata, rdata)
                    v
 CPU_RESETN --> [rst_sync] --> rst (active high)
                    |
   +----------------+-----------------------------+
   | uep_rx: CRC-32, judging, sequence, counters, |
   |         regs 0..7                            |
   +--> uep_reply (reply buffer, CRC trailer)     |
   +--> uep_telemetry (ticks, period, held frame) |
   +----------------------------------------------+
                    |
                    +--> LED[15:0] = commands carried out
```

## Clock plan

One clock domain: CLK100MHZ, 100 MHz (10 ns), used directly with no MMCM. Reset CPU_RESETN (active low, asynchronous button) goes through rst_sync (asynchronous assert, synchronous release) and is active high inside; all other logic uses synchronous reset. The only crossing is CPU_RESETN to sys (reset_sync).

## Resources (prediction)

About 1500 LUT, 1500 FF, 0 to 1 BRAM, 0 DSP. Reply and frame buffers are distributed RAM or registers.

## Pin list

| Port | Dir | Width | Role |
|---|---|---|---|
| CLK100MHZ | in | 1 | 100 MHz system clock |
| CPU_RESETN | in | 1 | CPU reset button, active low |
| UART_TXD_IN | in | 1 | USB-UART host to FPGA |
| UART_RXD_OUT | out | 1 | USB-UART FPGA to host |
| LED | out | 16 | commands-carried-out count |
