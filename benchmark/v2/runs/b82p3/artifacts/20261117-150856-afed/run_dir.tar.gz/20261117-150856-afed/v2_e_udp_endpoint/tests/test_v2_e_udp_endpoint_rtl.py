"""Pytest entry: runs the cocotb bench (udp_bench) against the RTL, one run per seed."""
from pathlib import Path

import pytest

import flow.cocotb_run

DESIGN = Path(__file__).resolve().parents[1]
PARAMS = {"CLKS_PER_BIT": 6, "TIMEOUT_CYCLES": 3000}


@pytest.mark.parametrize("seed", [1, 2, 3])
def test_v2_e_udp_endpoint_rtl(seed):
    sources = flow.cocotb_run.SHELL_RTL + sorted((DESIGN / "rtl").glob("*.sv"))
    res = flow.cocotb_run.run(
        "v2_e_udp_endpoint",
        "v2_e_udp_endpoint_top",
        sources,
        "udp_bench",
        Path(__file__).resolve().parent,
        parameters=PARAMS,
        seed=seed,
    )
    if isinstance(res, bool):
        assert res
