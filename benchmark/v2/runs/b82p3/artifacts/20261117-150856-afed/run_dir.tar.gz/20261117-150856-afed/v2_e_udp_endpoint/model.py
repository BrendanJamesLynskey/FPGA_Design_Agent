import zlib


def _crc(b):
    return zlib.crc32(bytes(b)) & 0xFFFFFFFF


def _trail(b):
    c = _crc(b)
    return list(b) + [(c >> (8 * i)) & 0xFF for i in range(4)]


class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000, BUILD_STAMP=0,
                 NUM_REGS=8, MAX_PAYLOAD=8, DEFAULT_PERIOD=100, MIN_PERIOD=4,
                 REPLY_BUILD_CYCLES=100, ID_WORD=1430540337):
        self.CLKS_PER_BIT = CLKS_PER_BIT
        self.TIMEOUT_CYCLES = TIMEOUT_CYCLES
        self.BUILD_STAMP = BUILD_STAMP
        self.NUM_REGS = NUM_REGS
        self.MAX_PAYLOAD = MAX_PAYLOAD
        self.DEFAULT_PERIOD = DEFAULT_PERIOD
        self.MIN_PERIOD = MIN_PERIOD
        self.REPLY_BUILD_CYCLES = REPLY_BUILD_CYCLES
        self.ID_WORD = ID_WORD
        self.reset()

    def reset(self):
        self.scratch = [0, 0, 0]
        self.cnt = [0] * 7  # cmds, bad crc, short, long, repeat, ooo, err
        self.refused = 0
        self.period = self.DEFAULT_PERIOD
        self.ticks = 0
        self.pending = 0
        self.tel_on = 0
        self.due = 0
        self.held = None
        self.fseq = 0
        self.fcount = 0
        self.last_seq = None
        self.buf = []
        self.n = 0
        self.idle = 0
        self.reply = []
        self.ridx = 0
        self.tidx = 0
        self.busy = 0

    # ---- packet handling
    def _refuse(self, k):
        self.cnt[k] = (self.cnt[k] + 1) & 0xFFFF
        self.refused = (self.refused + 1) & 0xFFFF

    def _byte(self, v):
        v &= 0x1FF
        self.n += 1
        if len(self.buf) < 64:
            self.buf.append(v & 0xFF)
        self.idle = 0
        if v & 0x100:
            self._judge()
            self.buf = []
            self.n = 0

    def _judge(self):
        b, n = self.buf, self.n
        self.reply = []
        if n < 4:
            return self._refuse(2)
        ln = b[1]
        if ln > 8 or n > 8 + ln:
            return self._refuse(3)
        if n < 8 + ln:
            return self._refuse(2)
        body = b[:4 + ln]
        got = sum(b[4 + ln + i] << (8 * i) for i in range(4))
        if got != _crc(body):
            return self._refuse(1)
        t = b[0]
        seq = (b[2] << 8) | b[3]
        pl = b[4:4 + ln]

        def rep(status, payload=()):
            self.reply = _trail([t | 0x80, status, b[2], b[3], len(payload)] + list(payload))

        if t not in (1, 2, 3, 4, 5):
            self._refuse(6)
            return rep(1)
        need = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}[t]
        if ln != need:
            self._refuse(6)
            return rep(2)
        if self.last_seq is not None:
            d = (seq - self.last_seq) & 0xFFFF
            if not (1 <= d <= 32767):
                self._refuse(4 if d == 0 else 5)
                return rep(4)
        self.last_seq = seq
        if t in (1, 2):
            reg = (pl[0] << 8) | pl[1]
            if reg >= 8:
                self._refuse(6)
                return rep(3)
            if t == 1:
                val = self._reg(reg)
                rep(0, [(val >> s) & 0xFF for s in (24, 16, 8, 0)])
            else:
                if reg == 0 or reg >= 4:
                    self._refuse(6)
                    return rep(5)
                self.scratch[reg - 1] = (pl[2] << 24) | (pl[3] << 16) | (pl[4] << 8) | pl[5]
                rep(0)
        elif t == 3:
            p = []
            for c in self.cnt:
                p += [c >> 8, c & 0xFF]
            p += [self.fcount >> 8, self.fcount & 0xFF, self.tel_on]
            rep(0, p)
        elif t == 4:
            p = (pl[0] << 8) | pl[1]
            if p:
                self.period = max(p, self.MIN_PERIOD)
            self.tel_on = 1
            self.due = 0
            rep(0)
        else:
            self.tel_on = 0
            self.held = None
            rep(0)
        self.cnt[0] = (self.cnt[0] + 1) & 0xFFFF

    def _reg(self, r):
        if r == 0:
            return self.ID_WORD
        if r in (1, 2, 3):
            return self.scratch[r - 1]
        if r == 4:
            return self.cnt[0]
        if r == 5:
            return self.refused
        if r == 6:
            return self.period
        if r == 7:
            return self.ticks & 0xFFFFFFFF
        return 0

    # ---- API
    def step(self, inputs=None):
        if self.n:
            self.idle += 1
            if self.idle >= self.TIMEOUT_CYCLES:
                self._refuse(2)
                self.reply = []
                self.buf = []
                self.n = 0
                self.idle = 0
        if self.pending > 0:
            self.pending -= 1
            self.ticks = (self.ticks + 1) & 0xFFFFFFFF
            if self.tel_on:
                self.due += 1
                if self.due >= self.period:
                    self.due = 0
                    if self.held is None:
                        t = self.ticks
                        body = [0xC0, 0, (self.fseq >> 8) & 0xFF, self.fseq & 0xFF, 8,
                                (t >> 24) & 0xFF, (t >> 16) & 0xFF, (t >> 8) & 0xFF, t & 0xFF,
                                (self.cnt[0] >> 8) & 0xFF, self.cnt[0] & 0xFF,
                                (self.refused >> 8) & 0xFF, self.refused & 0xFF]
                        self.held = _trail(body)
                        self.fseq = (self.fseq + 1) & 0xFFFF
                        self.fcount = (self.fcount + 1) & 0xFFFF
        return {"UART_RXD_OUT": 1, "LED": self.cnt[0] & 0xFFFF}

    @staticmethod
    def _word(buf, i):
        bs = (buf or [])[4 * i:4 * i + 4]
        bs = list(bs) + [0] * (4 - len(bs))
        return (bs[0] << 24) | (bs[1] << 16) | (bs[2] << 8) | bs[3]

    def read_reg(self, offset):
        if offset == 4:
            return self._word(self.reply, self.ridx)
        if offset == 9:
            return self.tel_on | (self.busy << 1)
        if offset == 3:
            return self.ridx
        if offset == 2:
            return len(self.reply)
        if offset == 6:
            return self.tidx
        if offset == 7:
            return self._word(self.held, self.tidx)
        if offset == 5:
            return len(self.held) if self.held else 0
        return 0

    def write_reg(self, offset, value):
        if offset == 0:
            self._byte(value)
        elif offset == 1:
            self.pending = min(65535, self.pending + (value & 0xFF))
        elif offset == 8:
            self.held = None
        elif offset == 3:
            self.ridx = value & 0x7F
        elif offset == 6:
            self.tidx = value & 0x7F
