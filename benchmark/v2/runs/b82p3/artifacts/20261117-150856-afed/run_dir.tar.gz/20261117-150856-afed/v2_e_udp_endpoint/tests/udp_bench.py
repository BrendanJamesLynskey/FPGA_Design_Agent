"""cocotb bench for v2_e_udp_endpoint: a UART host drives the test shell, every window value is compared with model.py."""
import random
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ClockCycles, RisingEdge  # noqa: E402

CPB = 6
TIMEOUT = 3000
PARAMS = dict(CLKS_PER_BIT=CPB, TIMEOUT_CYCLES=TIMEOUT)
ID_WORD = 0x55445031

# window offsets
IN, TICK, RLEN, RIDX, RWORD, TLEN, TIDX, TWORD, TAKE, STAT = 0, 1, 2, 3, 4, 5, 6, 7, 8, 9


def build(t, payload, seq, ln=None, badcrc=False):
    body = [t, len(payload) if ln is None else ln, (seq >> 8) & 255, seq & 255] + list(payload)
    c = zlib.crc32(bytes(body)) & 0xFFFFFFFF
    if badcrc:
        c ^= 0x00008001
    return body + [(c >> (8 * i)) & 255 for i in range(4)]


def rdp(reg, seq):
    return build(1, [reg >> 8, reg & 255], seq)


def wrp(reg, val, seq):
    return build(2, [reg >> 8, reg & 255] + list(val.to_bytes(4, "big")), seq)


def stp(seq):
    return build(3, [], seq)


def tsp(period, seq):
    return build(4, [period >> 8, period & 255], seq)


def tkp(seq):
    return build(5, [], seq)


class Env:
    def __init__(self, dut):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        self.m = model.Model(**PARAMS)
        self.clear()

    def clear(self):
        self.exp = [0] * 7      # independent tally: commands, bad check, short, long, repeated, out of order, errors
        self.ticks = 0
        self.fs = 0
        self.seq = 0x1233

    def ns(self):
        self.seq = (self.seq + 1) & 0xFFFF
        return self.seq

    async def start(self):
        try:
            c = Clock(self.clk, 10, unit="ns")
        except TypeError:
            c = Clock(self.clk, 10, units="ns")
        cocotb.start_soon(c.start())
        self.dut.UART_TXD_IN.value = 1
        self.dut.CPU_RESETN.value = 0
        await ClockCycles(self.clk, 5)
        await self.reset()

    async def reset(self, hold=6):
        self.dut.UART_TXD_IN.value = 1
        self.dut.CPU_RESETN.value = 0
        await ClockCycles(self.clk, hold)
        self.dut.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 10)
        self.m.reset()
        self.clear()

    # ---- UART host
    async def tx_byte(self, b):
        for bit in [0] + [(b >> i) & 1 for i in range(8)] + [1]:
            self.dut.UART_TXD_IN.value = bit
            await ClockCycles(self.clk, CPB)

    async def rx_byte(self):
        n = 0
        while int(self.dut.UART_RXD_OUT.value) == 1:
            await RisingEdge(self.clk)
            n += 1
            assert n < 20000, "no UART response from the shell"
        await ClockCycles(self.clk, CPB + CPB // 2)
        v = 0
        for i in range(8):
            v |= int(self.dut.UART_RXD_OUT.value) << i
            await ClockCycles(self.clk, CPB)
        assert int(self.dut.UART_RXD_OUT.value) == 1, "stop bit low"
        return v

    async def sh(self, cmd, addr, data=0):
        body = [cmd, addr] + list(data.to_bytes(4, "little"))
        chk = 0
        for b in body:
            chk ^= b
        await ClockCycles(self.clk, 2 * CPB)
        for b in [0xA5] + body + [chk]:
            await self.tx_byte(b)
        resp = [await self.rx_byte() for _ in range(7)]
        assert resp[0] == 0x5A, resp
        x = 0
        for b in resp[1:6]:
            x ^= b
        assert x == resp[6], resp
        assert resp[1] == 0, "shell status %d" % resp[1]
        return int.from_bytes(bytes(resp[2:6]), "little")

    # ---- window access, mirrored on the model
    async def rd(self, off):
        return await self.sh(1, 0x80 + off)

    async def wr(self, off, val):
        await self.sh(2, 0x80 + off, val)
        self.m.write_reg(off, val)
        if off == TICK:
            for _ in range((val & 0xFF) + 3):
                self.m.step()

    async def chk(self, off):
        got = await self.rd(off)
        exp = self.m.read_reg(off)
        assert got == exp, "window offset %d: rtl 0x%X model 0x%X" % (off, got, exp)
        return got

    async def idle(self, n):
        await ClockCycles(self.clk, n)
        for _ in range(n):
            self.m.step()

    # ---- packets
    async def send_raw(self, raw, end=True):
        for i, b in enumerate(raw):
            v = b | (0x100 if (end and i == len(raw) - 1) else 0)
            await self.wr(IN, v)

    async def check_reply(self, full=False):
        rl = await self.chk(RLEN)
        out = []
        for i in range((rl + 3) // 4 + (1 if full else 0)):
            await self.wr(RIDX, i)
            w = await self.chk(RWORD)
            out += list(w.to_bytes(4, "big"))
        assert all(b == 0 for b in out[rl:]), "bytes past the end not zero"
        r = out[:rl]
        if rl:
            assert rl == 9 + r[4], "length field %d vs reply %d" % (r[4], rl)
            assert int.from_bytes(bytes(r[-4:]), "little") == zlib.crc32(bytes(r[:-4])) & 0xFFFFFFFF, "reply CRC"
        o = self.m.step()
        assert int(self.dut.LED.value) == o["LED"] == self.m.cnt[0], "LED"
        return r

    async def packet(self, raw, full=False):
        await self.send_raw(raw)
        return await self.check_reply(full)

    async def sendx(self, raw, status=None, kind=None, full=False):
        r = await self.packet(raw, full)
        if status is None:
            assert r == [], "expected no reply, got %r" % r
        else:
            assert r, "no reply"
            assert r[0] == (raw[0] | 0x80) & 0xFF and r[1] == status, "reply %r wanted status %d" % (r, status)
            assert r[2:4] == raw[2:4]
            if kind is None:
                kind = "ok" if status == 0 else 6
        if kind == "ok":
            self.exp[0] += 1
        elif kind is not None:
            self.exp[kind] += 1
        return r

    def refused(self):
        return sum(self.exp[1:]) & 0xFFFF

    async def reg_read(self, reg, seq=None, status=0, kind=None):
        if seq is not None:
            self.seq = seq
        r = await self.sendx(rdp(reg, self.ns() if seq is None else seq), status, kind)
        if status == 0:
            assert r[4] == 4 and len(r) == 13
            return int.from_bytes(bytes(r[5:9]), "big")
        return None

    async def reg_write(self, reg, val, seq=None, status=0, kind=None):
        if seq is not None:
            self.seq = seq
        r = await self.sendx(wrp(reg, val, self.ns() if seq is None else seq), status, kind)
        if status == 0:
            assert r[4] == 0 and len(r) == 9

    async def status_cmd(self):
        snap = list(self.exp)
        r = await self.sendx(stp(self.ns()), 0, "ok")
        assert len(r) == 26 and r[4] == 17
        p = r[5:22]
        cn = [(p[2 * i] << 8) | p[2 * i + 1] for i in range(7)]
        fc = (p[14] << 8) | p[15]
        assert cn == [x & 0xFFFF for x in snap], "counters %r expected %r" % (cn, snap)
        return cn, fc, p[16]

    async def tick(self, n):
        await self.wr(TICK, n)
        self.ticks += n

    async def read_frame(self):
        tl = await self.chk(TLEN)
        out = []
        for i in range((tl + 3) // 4):
            await self.wr(TIDX, i)
            w = await self.chk(TWORD)
            out += list(w.to_bytes(4, "big"))
        fr = out[:tl]
        if tl:
            assert int.from_bytes(bytes(fr[-4:]), "little") == zlib.crc32(bytes(fr[:-4])) & 0xFFFFFFFF, "frame CRC"
        return fr

    async def expect_frame(self):
        fr = await self.read_frame()
        assert len(fr) == 17, "frame length %d" % len(fr)
        assert fr[0] == 0xC0 and fr[1] == 0 and fr[4] == 8
        assert ((fr[2] << 8) | fr[3]) == self.fs, "frame seq %d want %d" % ((fr[2] << 8) | fr[3], self.fs)
        assert int.from_bytes(bytes(fr[5:9]), "big") == self.ticks, "frame ticks"
        assert int.from_bytes(bytes(fr[9:11]), "big") == self.exp[0], "frame commands"
        assert int.from_bytes(bytes(fr[11:13]), "big") == self.refused(), "frame refused"
        self.fs += 1
        return fr

    async def expect_no_frame(self):
        assert await self.chk(TLEN) == 0


async def setup(dut):
    env = Env(dut)
    await env.start()
    return env


# req: REQ-02, REQ-03, REQ-04, REQ-21, REQ-39, REQ-34, REQ-35, REQ-36, REQ-37
@cocotb.test()
async def test_identity_and_reset_values(dut):
    env = await setup(dut)
    for off in (RLEN, RIDX, RWORD, TLEN, TIDX, TWORD, STAT, TAKE, TICK, IN, 0x0A, 0x7F):
        assert await env.rd(off) == 0, "reset value of offset %d" % off
    assert int(dut.LED.value) == 0
    # unmapped writes and writes to read-only offsets are ignored
    for off in (0x0A, RWORD, RLEN, TLEN, TWORD, STAT):
        await env.wr(off, 0x55)
    for off in (0x0A, RWORD, RLEN, TLEN, TWORD, STAT):
        await env.chk(off)
    assert await env.reg_read(0, seq=0x4321) == ID_WORD  # first packet, any sequence number
    assert await env.chk(RLEN) == 13
    for r in (1, 2, 3):
        assert await env.reg_read(r) == 0
    assert await env.reg_read(6) == 100
    assert await env.reg_read(7) == 0
    assert await env.reg_read(4) == 6   # six commands carried out before this read
    assert await env.reg_read(5) == 0
    assert await env.chk(STAT) == 0


# req: REQ-41, REQ-03, REQ-21
@cocotb.test()
async def test_scratch_registers(dut):
    env = await setup(dut)
    for v in (0xFFFFFFFF, 0xA5A5A5A5, 0x12345678, 0):
        held = {}
        for r in (1, 2, 3):
            held[r] = v ^ (0x01010101 * r) if v not in (0, 0xFFFFFFFF) else (v if r != 2 else 0x80000001)
            await env.reg_write(r, held[r])
        for r in (1, 2, 3):
            assert await env.reg_read(r) == held[r], "reg %d" % r


# req: REQ-05, REQ-17, REQ-38
@cocotb.test()
async def test_count_before_read(dut):
    env = await setup(dut)
    assert await env.reg_read(4) == 0
    assert await env.reg_read(4) == 1
    assert int(dut.LED.value) == 2
    assert await env.reg_read(5) == 0
    await env.reg_read(9, status=3)    # a refused packet
    assert await env.reg_read(5) == 1  # before this read is counted
    assert await env.reg_read(5) == 1  # reads are not refusals
    await env.reg_write(8, 1, status=3)
    assert await env.reg_read(4) == 5  # reads 4, 4, 5, 5, 5 carried out
    assert await env.reg_read(5) == 2


# req: REQ-06, REQ-07, REQ-08, REQ-34, REQ-17, REQ-19
@cocotb.test()
async def test_drop_silently(dut):
    env = await setup(dut)
    await env.reg_read(0)  # a reply exists
    assert await env.chk(RLEN) == 13
    await env.sendx([0x01], None, 2)                          # one byte: short
    await env.sendx([0x01, 0, 0], None, 2)                    # three bytes: short
    await env.sendx(stp(env.ns())[:-1], None, 2)              # CRC cut
    await env.sendx(rdp(0, env.ns())[:-3], None, 2)           # cut in the payload
    await env.sendx([0x03, 0, 0, 1], None, 2)                 # 4 bytes, no CRC
    await env.sendx(build(3, list(range(9)), env.ns()), None, 3)    # length byte 9
    await env.sendx([3, 255, 0, 1], None, 3)                  # length byte 255, short packet: still too long
    await env.sendx(stp(env.ns()) + [0xAA], None, 3)          # one byte more than announced
    await env.sendx(rdp(0, env.ns()) + [1, 2, 3], None, 3)
    await env.sendx(stp(env.ns()), 0, "ok")
    await env.sendx(build(3, [], env.ns(), badcrc=True), None, 1)
    await env.sendx(build(0x77, [], env.ns(), badcrc=True), None, 1)
    # a state-changing command with a bad CRC changes nothing
    await env.sendx(build(2, [0, 1, 0, 0, 0, 9], env.ns(), badcrc=True), None, 1)
    await env.sendx(build(4, [0, 9], env.ns(), badcrc=True), None, 1)
    assert await env.chk(STAT) == 0
    assert await env.reg_read(1) == 0
    assert await env.reg_read(6) == 100
    # timeout: bytes without the end flag are dropped as too short
    await env.send_raw([0x01, 0x02, 0x00], end=False)
    await env.idle(TIMEOUT + 1500)
    assert await env.chk(RLEN) == 0
    env.exp[2] += 1
    await env.status_cmd()
    r5 = await env.reg_read(5)
    assert r5 == env.refused()
    await env.send_raw([0x03, 0x00], end=False)
    await env.idle(TIMEOUT + 1500)
    env.exp[2] += 1
    await env.status_cmd()


# req: REQ-09, REQ-10, REQ-11, REQ-12, REQ-42, REQ-20, REQ-21, REQ-17, REQ-19
@cocotb.test()
async def test_status_codes(dut):
    env = await setup(dut)
    for t, pl in ((0, []), (6, [1, 2, 3]), (0x81, [9]), (255, []), (0x40, [1, 2, 3, 4, 5, 6, 7, 8])):
        r = await env.sendx(build(t, pl, env.ns()), 1)
        assert r[4] == 0 and len(r) == 9
    for t, ln in ((1, 0), (1, 1), (1, 3), (2, 0), (2, 2), (2, 5), (2, 7), (2, 8), (3, 1), (3, 8),
                  (4, 0), (4, 1), (4, 3), (5, 1), (5, 2)):
        await env.sendx(build(t, [0x11] * ln, env.ns()), 2)
    for reg in (8, 9, 0x100, 0x7FFF, 0xFFFF):
        await env.reg_read(reg, status=3)
        await env.reg_write(reg, 0x1234, status=3)
    await env.reg_write(1, 0x600D)
    for reg in (0, 4, 5, 6, 7):
        await env.reg_write(reg, 0xDEADBEEF, status=5)
    assert await env.reg_read(0) == ID_WORD
    assert await env.reg_read(6) == 100
    assert await env.reg_read(7) == 0
    assert await env.reg_read(1) == 0x600D
    assert await env.reg_read(5) == env.refused()
    for reg in range(8):
        await env.reg_read(reg)
    await env.status_cmd()


# req: REQ-13, REQ-14, REQ-15, REQ-16, REQ-43, REQ-17, REQ-19
@cocotb.test()
async def test_sequence_rules(dut):
    env = await setup(dut)
    await env.sendx(stp(0x8000), 0, "ok")        # first packet: any number
    await env.sendx(stp(0x8000), 4, 4)           # repeated
    await env.sendx(stp(0x7FFF), 4, 5)           # old
    await env.sendx(stp(0xFFFF), 0, "ok")        # difference 32767
    await env.sendx(stp(0x0000), 0, "ok")        # wraps, difference 1
    await env.sendx(stp(0x8000), 4, 5)           # difference 32768
    await env.sendx(stp(0x7FFF), 0, "ok")        # difference 32767
    await env.sendx(stp(0xFFFF), 4, 5)           # difference 32768
    await env.reg_write(1, 0x11, seq=0x8000)     # difference 1
    # refused packets change nothing
    await env.reg_write(1, 0xAAAAAAAA, seq=0x8000, status=4, kind=4)
    await env.reg_write(2, 0xAAAAAAAA, seq=0x7000, status=4, kind=5)
    assert await env.reg_read(1, seq=0x8001) == 0x11
    assert await env.reg_read(2, seq=0x8002) == 0
    await env.sendx(tsp(50, 0x8002), 4, 4)
    assert await env.chk(STAT) == 0
    assert await env.reg_read(6, seq=0x8003) == 100
    await env.sendx(tsp(50, 0x8004), 0, "ok")
    assert await env.chk(STAT) == 1
    await env.sendx(tkp(0x8004), 4, 4)           # stop refused: telemetry stays on
    await env.sendx(tsp(9, 0x8004), 4, 4)        # start refused: period unchanged
    await env.sendx(tkp(0x8003), 4, 5)
    assert await env.chk(STAT) == 1
    assert await env.reg_read(6, seq=0x8005) == 50
    await env.sendx(stp(0x8005), 4, 4)
    # a number passing the sequence rule is used up even if the register check fails
    await env.reg_write(9, 1, seq=0x9000, status=3)
    await env.reg_read(0, seq=0x9000, status=4, kind=4)
    await env.reg_write(4, 1, seq=0x9001, status=5)
    await env.reg_read(0, seq=0x9001, status=4, kind=4)
    await env.reg_read(12, seq=0x9002, status=3)
    await env.reg_write(5, 1, seq=0x9002, status=4, kind=4)
    # wrong length and unknown type do not use up the number
    await env.sendx(build(1, [0], 0x9003), 2)
    assert await env.reg_read(0, seq=0x9003) == ID_WORD
    await env.sendx(build(0x20, [], 0x9004), 1)
    assert await env.reg_read(0, seq=0x9004) == ID_WORD
    # far ahead is accepted, exactly half the circle ahead is refused
    await env.sendx(stp((0x9004 + 32767) & 0xFFFF), 0, "ok")
    await env.sendx(stp((0x9004 + 32767 + 32768) & 0xFFFF), 4, 5)
    env.seq = (0x9004 + 32767) & 0xFFFF
    await env.status_cmd()


# req: REQ-18, REQ-06, REQ-07, REQ-08, REQ-09, REQ-10, REQ-11, REQ-12, REQ-13, REQ-16
@cocotb.test()
async def test_judging_order(dut):
    env = await setup(dut)
    await env.sendx(build(3, [], 10), 0, "ok")
    await env.sendx(build(3, list(range(9)), 11, badcrc=True), None, 3)       # long beats bad CRC
    await env.sendx(build(3, list(range(9)), 11)[:6], None, 3)                # long beats short
    await env.sendx(rdp(0, 11)[:-1], None, 2)                                 # short beats bad CRC
    await env.sendx(build(0x77, [1], 11, badcrc=True), None, 1)               # bad CRC beats unknown type
    await env.sendx(build(2, [0, 4], 10, badcrc=True), None, 1)
    await env.sendx(build(9, [1, 2, 3], 10), 1)                               # type beats length and sequence
    await env.sendx(build(1, [0], 10), 2)                                     # length beats sequence
    await env.sendx(build(2, [0, 1], 10), 2)
    await env.sendx(rdp(9, 10), 4, 4)                                         # sequence beats register
    await env.sendx(wrp(4, 1, 10), 4, 4)                                      # sequence beats access
    await env.sendx(wrp(9, 1, 11), 3)                                         # register beats access
    await env.sendx(wrp(0, 1, 12), 5)
    await env.sendx(rdp(0, 12), 4, 4)                                         # number 12 used up
    await env.sendx(wrp(7, 1, 9), 4, 5)
    await env.sendx(tsp(5, 9), 4, 5)
    await env.sendx(tkp(8), 4, 5)
    await env.sendx(tkp(13), 0, "ok")
    env.seq = 13
    await env.status_cmd()


# req: REQ-22, REQ-17, REQ-23, REQ-01, REQ-20
@cocotb.test()
async def test_status_reply(dut):
    env = await setup(dut)
    cn, fc, fl = await env.status_cmd()
    assert cn == [0] * 7 and fc == 0 and fl == 0
    cn, fc, fl = await env.status_cmd()
    assert cn[0] == 1
    for _ in range(3):
        await env.reg_read(0)
    for _ in range(2):
        await env.sendx(build(3, [], env.ns(), badcrc=True), None, 1)
    await env.sendx([3, 0], None, 2)
    await env.sendx(stp(env.ns()) + [1], None, 3)
    last = env.m.last_seq
    await env.sendx(stp(last), 4, 4)
    await env.sendx(stp((last - 5) & 0xFFFF), 4, 5)
    await env.sendx(build(8, [], env.ns()), 1)
    await env.sendx(build(1, [], env.ns()), 2)
    await env.reg_read(8, status=3)
    await env.reg_write(0, 0, status=5)
    cn, fc, fl = await env.status_cmd()
    assert cn[1:] == [2, 1, 1, 1, 1, 4], cn
    cn2, _, _ = await env.status_cmd()
    assert cn2[0] == cn[0] + 1   # the first status reply showed the count before itself
    await env.sendx(tsp(4, env.ns()), 0, "ok")
    await env.tick(4)
    await env.expect_frame()
    cn3, fc, fl = await env.status_cmd()
    assert fc == 1 and fl == 1


# req: REQ-25, REQ-26, REQ-27, REQ-28, REQ-29, REQ-30, REQ-44, REQ-31, REQ-32, REQ-36, REQ-37, REQ-22, REQ-01
@cocotb.test()
async def test_telemetry(dut):
    env = await setup(dut)
    # default period 100 kept by a start with period 0
    await env.sendx(tsp(0, env.ns()), 0, "ok")
    assert await env.chk(STAT) == 1
    assert await env.reg_read(6) == 100
    await env.tick(99)
    await env.expect_no_frame()
    await env.tick(1)
    await env.expect_frame()            # the first frame has sequence number 0
    await env.wr(TAKE, 1)
    await env.expect_no_frame()
    # period 2 becomes 4
    await env.sendx(tsp(2, env.ns()), 0, "ok")
    assert await env.reg_read(6) == 4
    await env.tick(3)
    await env.expect_no_frame()
    await env.tick(1)
    fr = await env.expect_frame()
    # a frame falling due while one is held is dropped
    await env.tick(4)
    assert await env.read_frame() == fr
    cn, fc, fl = await env.status_cmd()
    assert fc == env.fs and fl == 1
    await env.wr(TAKE, 0)
    await env.expect_no_frame()
    await env.tick(4)
    await env.expect_frame()        # the dropped one did not advance the sequence number
    cn, fc, fl = await env.status_cmd()
    assert fc == env.fs
    # start with 0 keeps the period and restarts the count
    await env.wr(TAKE, 1)
    await env.sendx(tsp(0, env.ns()), 0, "ok")
    assert await env.reg_read(6) == 4
    await env.tick(3)
    await env.sendx(tsp(0, env.ns()), 0, "ok")
    await env.tick(3)
    await env.expect_no_frame()
    await env.tick(1)
    await env.expect_frame()
    # period 7: one frame every 7 ticks
    await env.wr(TAKE, 1)
    await env.sendx(tsp(7, env.ns()), 0, "ok")
    assert await env.reg_read(6) == 7
    for _ in range(3):
        await env.tick(6)
        await env.expect_no_frame()
        await env.tick(1)
        await env.expect_frame()
        await env.wr(TAKE, 1)
    await env.tick(7)
    await env.expect_frame()
    # stop discards the held frame and switches off
    await env.sendx(tkp(env.ns()), 0, "ok")
    await env.expect_no_frame()
    assert await env.chk(STAT) == 0
    await env.tick(14)
    await env.expect_no_frame()
    cn, fc, fl = await env.status_cmd()
    assert fl == 0 and fc == env.fs
    # the frame sequence number is not cleared by stop and start
    await env.sendx(tsp(5, env.ns()), 0, "ok")
    assert await env.reg_read(6) == 5
    await env.tick(5)
    await env.expect_frame()
    await env.wr(TAKE, 1)
    for p, want in ((1, 4), (3, 4), (4, 4), (5, 5), (0, 5), (0xFFFF, 0xFFFF), (0, 0xFFFF), (6, 6)):
        await env.sendx(tsp(p, env.ns()), 0, "ok")
        assert await env.reg_read(6) == want, "period %d" % p
    await env.status_cmd()


# req: REQ-33
@cocotb.test()
async def test_tick_register(dut):
    env = await setup(dut)
    total = 0
    for n in (0, 1, 2, 7, 255, 0, 33, 255):
        await env.tick(n)
        total += n
        assert await env.reg_read(7) == total
    await env.wr(TICK, 0x1FF)     # only [7:0] is used
    total += 255
    assert await env.reg_read(7) == total
    await env.wr(TICK, 0x100)
    assert await env.reg_read(7) == total


# req: REQ-35, REQ-36, REQ-34
@cocotb.test()
async def test_readback_words(dut):
    env = await setup(dut)
    r = await env.sendx(stp(env.ns()), 0, "ok", full=True)
    assert await env.chk(RLEN) == 26
    for i in range(8):
        await env.wr(RIDX, i)
        assert await env.rd(RIDX) == i
        bs = (r[4 * i:4 * i + 4] + [0] * 4)[:4]
        assert await env.rd(RWORD) == int.from_bytes(bytes(bs), "big"), "word %d" % i
    # word numbers beyond the buffer: only the index register itself is checked
    await env.wr(RIDX, 0xFF)
    assert await env.rd(RIDX) == 0x7F
    await env.wr(RIDX, 0)
    # a read reply
    await env.reg_read(0)
    await env.wr(RIDX, 1)
    assert await env.rd(RWORD) == 0x04000000 | (ID_WORD >> 8)
    await env.wr(RIDX, 2)
    assert (await env.rd(RWORD)) >> 24 == ID_WORD & 255
    await env.wr(RIDX, 4)
    assert await env.rd(RWORD) == 0
    # telemetry frame words
    assert await env.rd(TLEN) == 0
    await env.wr(TIDX, 0)
    assert await env.rd(TWORD) == 0
    await env.sendx(tsp(4, env.ns()), 0, "ok")
    await env.tick(4)
    fr = await env.expect_frame()
    assert await env.rd(TLEN) == 17
    for i in range(6):
        await env.wr(TIDX, i)
        assert await env.rd(TIDX) == i
        bs = (fr[4 * i:4 * i + 4] + [0] * 4)[:4]
        assert await env.rd(TWORD) == int.from_bytes(bytes(bs), "big"), "frame word %d" % i
    await env.wr(TIDX, 0xFF)
    assert await env.rd(TIDX) == 0x7F
    await env.wr(TIDX, 0)
    await env.wr(TAKE, 0)
    assert await env.rd(TLEN) == 0


# req: REQ-38, REQ-05
@cocotb.test()
async def test_led_follows_count(dut):
    env = await setup(dut)
    n = 0
    for i in range(8):
        await env.reg_read(i)
        n += 1
        assert int(dut.LED.value) == n
    await env.reg_read(20, status=3)
    await env.sendx(build(3, [], env.ns(), badcrc=True), None, 1)
    assert int(dut.LED.value) == n
    await env.reg_write(1, 5)
    n += 1
    await env.reg_write(0, 5, status=5)
    assert int(dut.LED.value) == n


# req: REQ-24, REQ-45, REQ-37, REQ-20
@cocotb.test()
async def test_reply_ready(dut):
    env = await setup(dut)
    for raw, ln in ((rdp(1, 1), 13), (stp(2), 26), (wrp(1, 5, 3), 9), (tsp(4, 4), 9), (tkp(5), 9)):
        await env.send_raw(raw)
        # the first window read after the end flag already sees the finished reply and an idle block
        assert await env.chk(RLEN) == ln
        assert (await env.chk(STAT)) >> 1 == 0
    # ready for the next packet as soon as the end flag is handled: back-to-back packets all work
    for i in range(6):
        r = await env.sendx(rdp(0, 6 + i), 0, "ok")
        assert len(r) == 13


# req: REQ-39, REQ-15, REQ-03, REQ-04, REQ-44, REQ-38, REQ-34, REQ-36, REQ-37
@cocotb.test()
async def test_reset_clears_state(dut):
    env = await setup(dut)
    await env.reg_write(1, 0xCAFE)
    await env.reg_write(3, 0xBEEF)
    await env.reg_read(9, status=3)
    await env.sendx(tsp(5, env.ns()), 0, "ok")
    await env.tick(5)
    await env.expect_frame()
    await env.wr(RIDX, 3)
    await env.wr(TIDX, 2)
    await env.send_raw([1, 2, 0], end=False)   # partial packet
    await env.reset()
    for off in (RLEN, RIDX, RWORD, TLEN, TIDX, TWORD, STAT):
        assert await env.chk(off) == 0
    assert int(dut.LED.value) == 0
    # the partial packet and the sequence memory are gone: the first packet takes any number
    assert await env.reg_read(1, seq=0x1234) == 0
    assert await env.reg_read(3) == 0
    assert await env.reg_read(2) == 0
    assert await env.reg_read(4) == 3
    assert await env.reg_read(5) == 0
    assert await env.reg_read(6) == 100
    assert await env.reg_read(7) == 0
    await env.sendx(tsp(4, env.ns()), 0, "ok")
    await env.tick(4)
    await env.expect_frame()           # the frame sequence restarts at 0
    cn, fc, fl = await env.status_cmd()
    assert fc == 1
    # reset again with a held frame and telemetry on
    await env.reset()
    assert await env.chk(TLEN) == 0
    assert await env.chk(STAT) == 0
    await env.sendx(stp(0x1234), 0, "ok")
    env.seq = 0x1234
    await env.status_cmd()


# req: REQ-01, REQ-06, REQ-07, REQ-08, REQ-09, REQ-10, REQ-11, REQ-12, REQ-13, REQ-14, REQ-17, REQ-18, REQ-23, REQ-25, REQ-26, REQ-27, REQ-28, REQ-31, REQ-32, REQ-33
@cocotb.test()
async def test_random_traffic(dut):
    env = await setup(dut)
    rng = random.Random(int(cocotb.RANDOM_SEED))
    last = None

    def seq_pick():
        if last is None:
            return rng.randrange(65536)
        c = rng.random()
        if c < 0.55:
            return (last + rng.randrange(1, 4)) & 0xFFFF
        if c < 0.7:
            return last
        if c < 0.85:
            return (last - rng.randrange(1, 100)) & 0xFFFF
        return (last + 32768 + rng.randrange(-3, 4)) & 0xFFFF

    for it in range(30):
        s = seq_pick()
        k = rng.randrange(20)
        reg = rng.choice([0, 1, 2, 3, 4, 5, 6, 7, 7, 8, 9, 300, 0xFFFF])
        val = rng.choice([0, 1, 0xFFFFFFFF, rng.getrandbits(32)])
        if k < 4:
            raw = rdp(reg, s)
        elif k < 8:
            raw = wrp(reg, val, s)
        elif k < 10:
            raw = stp(s)
        elif k < 12:
            raw = tsp(rng.choice([0, 0, 1, 2, 3, 4, 5, 9]), s)
        elif k < 13:
            raw = tkp(s)
        elif k == 13:
            raw = build(rng.choice([0, 6, 7, 0x84, 255]), [rng.getrandbits(8) for _ in range(rng.randrange(9))], s)
        elif k == 14:
            raw = build(rng.randrange(1, 6), [rng.getrandbits(8) for _ in range(rng.randrange(9))], s)
        elif k == 15:
            raw = build(rng.randrange(1, 6), [0] * rng.randrange(9), s, badcrc=True)
        elif k == 16:
            raw = build(rng.randrange(1, 6), [0] * rng.randrange(9), s)
            raw = raw[:rng.randrange(1, len(raw))]
        elif k == 17:
            raw = rdp(reg, s) + [rng.getrandbits(8) for _ in range(rng.randrange(1, 4))]
        elif k == 18:
            raw = build(rng.randrange(1, 6), [rng.getrandbits(8) for _ in range(rng.randrange(9))],
                        s, ln=rng.randrange(9, 256))
        else:
            raw = [rng.getrandbits(8) for _ in range(rng.randrange(1, 4))]
        await env.packet(raw, full=(it % 7 == 0))
        if env.m.last_seq is not None:
            last = env.m.last_seq
        await env.chk(STAT)
        if rng.random() < 0.4:
            await env.tick(rng.choice([1, 3, 4, 5, 9, 20]))
            fr = await env.read_frame()
            if fr and rng.random() < 0.5:
                await env.wr(TAKE, 1)
    nxt = ((last + 1) & 0xFFFF) if last is not None else 1
    r = await env.packet(stp(nxt))
    assert r and r[1] == 0 and len(r) == 26
