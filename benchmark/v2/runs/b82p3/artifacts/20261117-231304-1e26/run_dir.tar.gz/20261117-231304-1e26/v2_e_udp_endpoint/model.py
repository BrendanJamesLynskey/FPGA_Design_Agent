class Model:
    def __init__(self, CLKS_PER_BIT=868, TIMEOUT_CYCLES=100000000, BUILD_STAMP=0,
                 ID_WORD=1430540337, NUM_REGS=8, MAX_PAYLOAD=8,
                 TELEMETRY_PERIOD_RESET=100, TELEMETRY_PERIOD_MIN=4,
                 REPLY_BUDGET_CYCLES=100, CRC_POLY=3988292384,
                 CRC_INIT=4294967295):
        self.p = dict(ID_WORD=ID_WORD, NUM_REGS=NUM_REGS, MAX_PAYLOAD=MAX_PAYLOAD,
                      PRST=TELEMETRY_PERIOD_RESET, PMIN=TELEMETRY_PERIOD_MIN,
                      POLY=CRC_POLY, INIT=CRC_INIT)
        self._in = {}
        self.reset()

    def _crc(self, data):
        c = self.p['INIT'] & 0xFFFFFFFF
        for b in data:
            c ^= b
            for _ in range(8):
                c = (c >> 1) ^ self.p['POLY'] if c & 1 else c >> 1
            c &= 0xFFFFFFFF
        return c ^ 0xFFFFFFFF

    def _seal(self, data):
        c = self._crc(data)
        return list(data) + [(c >> (8 * i)) & 0xFF for i in range(4)]

    def reset(self):
        self.buf = []
        self.regs = [0] * 4
        self.cmds = 0
        self.refused = 0
        self.cnt = [0] * 6  # badcheck, short, long, repeat, ooo, err
        self.last = None
        self.period = self.p['PRST']
        self.uptime = 0
        self.tel_on = 0
        self.tickc = 0
        self.fseq = 0
        self.fcount = 0
        self.held = None
        self.reply = []
        self.pending = 0
        self.ridx = 0
        self.tidx = 0

    def _refuse(self, i):
        self.cnt[i] = (self.cnt[i] + 1) & 0xFFFF
        self.refused = (self.refused + 1) & 0xFFFFFFFF

    def _process(self):
        b = self.buf
        self.buf = []
        self.reply = []
        n = len(b)
        if n < 4:
            self._refuse(1)
            return
        ln = b[1]
        if ln > self.p['MAX_PAYLOAD'] or n > 8 + ln:
            self._refuse(2)
            return
        if n < 8 + ln:
            self._refuse(1)
            return
        body = b[:-4]
        if self._crc(body) != sum(b[-4 + i] << (8 * i) for i in range(4)):
            self._refuse(0)
            return
        typ = b[0]
        seq = (b[2] << 8) | b[3]
        pl = b[4:4 + ln]

        def rep(status, payload=()):
            self.reply = self._seal([typ | 0x80, status, b[2], b[3], len(payload)] + list(payload))

        need = {1: 2, 2: 6, 3: 0, 4: 2, 5: 0}
        if typ not in need:
            self._refuse(5)
            rep(1)
            return
        if ln != need[typ]:
            self._refuse(5)
            rep(2)
            return
        if self.last is not None:
            d = (seq - self.last) & 0xFFFF
            if not (1 <= d <= 32767):
                self._refuse(3 if d == 0 else 4)
                rep(4)
                return
        self.last = seq
        payload = []
        if typ in (1, 2):
            r = (pl[0] << 8) | pl[1]
            if r >= self.p['NUM_REGS']:
                self._refuse(5)
                rep(3)
                return
            if typ == 2:
                if not (1 <= r <= 3):
                    self._refuse(5)
                    rep(5)
                    return
                self.regs[r] = (pl[2] << 24) | (pl[3] << 16) | (pl[4] << 8) | pl[5]
            else:
                v = self._rd(r)
                payload = [(v >> s) & 0xFF for s in (24, 16, 8, 0)]
        elif typ == 3:
            vals = [self.cmds & 0xFFFF] + self.cnt + [self.fcount & 0xFFFF]
            for v in vals:
                payload += [v >> 8, v & 0xFF]
            payload.append(self.tel_on)
        elif typ == 4:
            per = (pl[0] << 8) | pl[1]
            if per:
                self.period = max(per, self.p['PMIN'])
            self.tel_on = 1
            self.tickc = 0
        elif typ == 5:
            self.tel_on = 0
            self.held = None
        self.cmds = (self.cmds + 1) & 0xFFFFFFFF
        rep(0, payload)

    def _rd(self, r):
        if r == 0:
            return self.p['ID_WORD'] & 0xFFFFFFFF
        if 1 <= r <= 3:
            return self.regs[r]
        if r == 4:
            return self.cmds
        if r == 5:
            return self.refused
        if r == 6:
            return self.period
        if r == 7:
            return self.uptime & 0xFFFFFFFF
        return 0

    @staticmethod
    def _word(data, i):
        v = 0
        for k in range(4):
            j = 4 * i + k
            v = (v << 8) | (data[j] if j < len(data) else 0)
        return v

    def _tick(self):
        self.uptime = (self.uptime + 1) & 0xFFFFFFFF
        if self.tel_on:
            self.tickc += 1
            if self.tickc >= self.period:
                self.tickc = 0
                if self.held is None:
                    u = self.uptime
                    c = self.cmds & 0xFFFF
                    r = self.refused & 0xFFFF
                    d = [0xC0, 0, self.fseq >> 8, self.fseq & 0xFF, 8,
                         (u >> 24) & 255, (u >> 16) & 255, (u >> 8) & 255, u & 255,
                         c >> 8, c & 255, r >> 8, r & 255]
                    self.held = self._seal(d)
                    self.fseq = (self.fseq + 1) & 0xFFFF
                    self.fcount = (self.fcount + 1) & 0xFFFF

    def step(self, inputs=None):
        if inputs:
            self._in.update(inputs)
        if self._in.get('CPU_RESETN', 1) == 0:
            self.reset()
        elif self.pending > 0:
            self.pending -= 1
            self._tick()
        return {'UART_RXD_OUT': 1, 'LED': self.cmds & 0xFFFF}

    def read_reg(self, offset):
        if offset == 4:
            return self._word(self.reply, self.ridx)
        if offset == 2:
            return len(self.reply)
        if offset == 3:
            return self.ridx
        if offset == 5:
            return len(self.held) if self.held else 0
        if offset == 6:
            return self.tidx
        if offset == 7:
            return self._word(self.held, self.tidx) if self.held else 0
        if offset == 9:
            return self.tel_on
        return 0

    def write_reg(self, offset, value):
        if offset == 0:
            self.buf.append(value & 0xFF)
            if value & 0x100:
                self._process()
        elif offset == 1:
            self.pending = value & 0xFF
        elif offset == 3:
            self.ridx = value & 0x7F
        elif offset == 6:
            self.tidx = value & 0x7F
        elif offset == 8:
            self.held = None
