// Port-only checker for v2_e_udp_endpoint_top, bound to the top.
`include "v_macros.svh"

module v2_e_udp_endpoint_checker (
    input logic        clk,
    input logic        rst,
    input logic        txd,
    input logic [15:0] led
);
  logic seen_rst;
  logic past_ok;
  initial begin
    seen_rst = 1'b0;
    past_ok  = 1'b0;
  end
  always @(posedge clk) begin
    past_ok <= 1'b1;
    if (rst) seen_rst <= 1'b1;
  end

  // LED (commands carried out) moves by at most +1 per clock
  `V_SAME(A_led_step, 1'b1, (led == $past(led)) || (led == ($past(led) + 16'd1))) // req: REQ-52

  `V_COVER(C_led_nonzero, led != 16'd0) // req: REQ-52
  `V_COVER(C_led_step, led == ($past(led) + 16'd1)) // req: REQ-52
  `V_COVER(C_tx_active, !txd) // req: REQ-56
endmodule

bind v2_e_udp_endpoint_top v2_e_udp_endpoint_checker u_v2_e_udp_endpoint_checker (
    .clk(CLK100MHZ),
    .rst(~CPU_RESETN),
    .txd(UART_RXD_OUT),
    .led(LED)
);
