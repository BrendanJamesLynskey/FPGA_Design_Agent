"""Pytest entry: runs the cocotb bench on the RTL for several seeds."""
from pathlib import Path

import pytest

DESIGN_DIR = Path(__file__).resolve().parents[1]
SEEDS = (1, 2, 3)


@pytest.mark.parametrize("seed", SEEDS)
def test_v2_e_udp_endpoint_rtl(seed):
    import flow.cocotb_run as cocotb_run

    sources = cocotb_run.SHELL_RTL + sorted((DESIGN_DIR / "rtl").glob("*.sv"))
    cocotb_run.run(
        "v2_e_udp_endpoint",
        "v2_e_udp_endpoint_top",
        sources,
        "v2_e_udp_endpoint_bench",
        DESIGN_DIR / "tests",
        parameters={"CLKS_PER_BIT": 6},
        seed=seed,
    )
