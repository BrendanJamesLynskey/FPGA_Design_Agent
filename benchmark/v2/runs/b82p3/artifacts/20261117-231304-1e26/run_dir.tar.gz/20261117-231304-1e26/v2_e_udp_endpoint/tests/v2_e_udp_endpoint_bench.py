"""cocotb bench for v2_e_udp_endpoint: drives the design through its UART test shell
(PROTOCOL.md 1.1) and compares every register / reply word with model.py (and with
independent hand-written expectations from spec.yaml)."""
import os
import random
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import model  # noqa: E402
from model import Model  # noqa: E402

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ClockCycles, FallingEdge, First  # noqa: E402

CPB = 6                      # clocks per UART bit in simulation (spec: 868)
PARAMS = {"CLKS_PER_BIT": CPB}
ID_WORD = 0x55445031


def seed_of():
    try:
        return int(getattr(cocotb, "RANDOM_SEED", 1) or 1)
    except Exception:
        return 1


# ---------------------------------------------------------------- packet helpers
def crc_le(body):
    return list(zlib.crc32(bytes(body)).to_bytes(4, "little"))


def mkpkt(typ, seq, payload=(), ln=None, bad_crc=False):
    payload = list(payload)
    ln = len(payload) if ln is None else ln
    body = [typ & 0xFF, ln & 0xFF, (seq >> 8) & 0xFF, seq & 0xFF] + payload
    crc = crc_le(body)
    if bad_crc:
        crc[0] ^= 0x5A
    return body + crc


def rd_pl(r):
    return [(r >> 8) & 0xFF, r & 0xFF]


def wr_pl(r, v):
    return [(r >> 8) & 0xFF, r & 0xFF] + list(v.to_bytes(4, "big"))


def parse_reply(r):
    assert len(r) >= 9, r
    assert r[4] == len(r) - 9, ("length byte", r)
    assert r[-4:] == crc_le(r[:-4]), ("reply crc", r)
    return dict(type=r[0], status=r[1], seq=(r[2] << 8) | r[3], payload=list(r[5:-4]), raw=list(r))


def status_fields(p):
    assert len(p) == 17, p
    v = [(p[2 * i] << 8) | p[2 * i + 1] for i in range(8)]
    return v[:7], v[7], p[16]


def check_frame(fr, seq, uptime, cmds, refused):
    assert len(fr) == 17, fr
    assert fr[0] == 0xC0 and fr[1] == 0, fr
    assert ((fr[2] << 8) | fr[3]) == seq, ("frame seq", fr, seq)
    assert fr[4] == 8
    assert int.from_bytes(bytes(fr[5:9]), "big") == uptime, ("uptime", fr, uptime)
    assert int.from_bytes(bytes(fr[9:11]), "big") == cmds & 0xFFFF, ("cmds", fr)
    assert int.from_bytes(bytes(fr[11:13]), "big") == refused & 0xFFFF, ("refused", fr)
    assert fr[13:17] == crc_le(fr[:13]), ("frame crc", fr)


def xor8(data):
    x = 0
    for d in data:
        x ^= d
    return x


def shell_req(cmd, addr, data=0):
    body = [cmd, addr] + list(data.to_bytes(4, "little"))
    return [0xA5] + body + [xor8(body)]


def shell_resp(status, data=0):
    body = [status] + list(data.to_bytes(4, "little"))
    return [0x5A] + body + [xor8(body)]


# ---------------------------------------------------------------- bench
class Bench:
    def __init__(self, dut):
        self.dut = dut
        self.clk = dut.CLK100MHZ
        self.m = Model(**PARAMS)
        self.reset_tally()

    def reset_tally(self):
        self.last = None
        self.ticks = 0
        self.e = dict(cmds=0, bad=0, short=0, long=0, rep=0, ooo=0, err=0)
        self.ref = 0

    async def reset(self, cycles=12):
        d = self.dut
        d.UART_TXD_IN.value = 1
        d.CPU_RESETN.value = 0
        await ClockCycles(self.clk, cycles)
        d.CPU_RESETN.value = 1
        await ClockCycles(self.clk, 30)
        self.m.reset()
        self.reset_tally()

    # ---- UART
    async def _tx(self, byte):
        bits = [0] + [(byte >> i) & 1 for i in range(8)] + [1]
        for bit in bits:
            self.dut.UART_TXD_IN.value = bit
            await ClockCycles(self.clk, CPB)

    async def _rx(self, n):
        rxd = self.dut.UART_RXD_OUT
        out = []
        for _ in range(n):
            await First(FallingEdge(rxd), ClockCycles(self.clk, 60000))
            assert int(rxd.value) == 0, "timeout waiting for shell response"
            await ClockCycles(self.clk, CPB + CPB // 2)
            v = 0
            for i in range(8):
                v |= int(rxd.value) << i
                await ClockCycles(self.clk, CPB)
            assert int(rxd.value) == 1, "stop bit"
            out.append(v)
        await ClockCycles(self.clk, CPB + 8)
        return out

    async def xfer_raw(self, frame):
        rx = cocotb.start_soon(self._rx(7))
        for byte in frame:
            await self._tx(byte)
        return await rx

    async def xfer(self, cmd, addr, data=0):
        r = await self.xfer_raw(shell_req(cmd, addr, data))
        assert r[0] == 0x5A and xor8(r[1:6]) == r[6], r
        return r[1], int.from_bytes(bytes(r[2:6]), "little")

    # ---- window registers
    async def wr(self, off, val):
        st, _ = await self.xfer(2, 0x80 + off, val & 0xFFFFFFFF)
        assert st == 0, ("window write status", off, st)

    async def rd(self, off):
        st, d = await self.xfer(1, 0x80 + off)
        assert st == 0, ("window read status", off, st)
        return d

    async def wrm(self, off, val):
        await self.wr(off, val)
        self.m.write_reg(off, val)

    async def rdm(self, off):
        got = await self.rd(off)
        exp = self.m.read_reg(off)
        assert got == exp, f"reg {off}: rtl {got:#x} model {exp:#x}"
        return got

    async def tick(self, n):
        await self.wr(1, n)
        self.m.write_reg(1, n)
        for _ in range(n):
            self.m.step()
        self.ticks += n

    # ---- packets
    async def feed(self, raw):
        for i, bv in enumerate(raw):
            v = bv | (0x100 if i == len(raw) - 1 else 0)
            await self.wr(0, v)
            self.m.write_reg(0, v)

    async def get_reply(self, extra=True):
        n = await self.rdm(2)
        out = []
        nw = (n + 3) // 4
        for i in range(nw + (1 if extra else 0)):
            await self.wrm(3, i)
            w = await self.rdm(4)
            if i < nw:
                out += list(w.to_bytes(4, "big"))
            else:
                assert w == 0
        return out[:n]

    async def read_frame(self):
        tl = await self.rdm(5)
        out = []
        for i in range((tl + 3) // 4):
            await self.wrm(6, i)
            w = await self.rdm(7)
            out += list(w.to_bytes(4, "big"))
        return out[:tl]

    async def check_state(self, tel_words=False):
        st = await self.rdm(9)
        tl = await self.rdm(5)
        if tel_words and tl:
            for i in range((tl + 3) // 4 + 1):
                await self.wrm(6, i)
                await self.rdm(7)
        led = int(self.dut.LED.value)
        exp = self.m.step()["LED"]
        assert led == exp, f"LED rtl {led:#x} model {exp:#x}"
        return st, tl

    async def send(self, raw, tel_words=False):
        await self.feed(raw)
        rep = await self.get_reply()
        await self.check_state(tel_words)
        return parse_reply(rep) if rep else None

    def fresh(self):
        return 0x0100 if self.last is None else (self.last + 1) & 0xFFFF

    async def cmd(self, typ, payload=(), seq=None, ln=None, bad_crc=False, tel_words=False):
        if seq is None:
            seq = self.fresh()
        rep = await self.send(mkpkt(typ, seq, payload, ln, bad_crc), tel_words)
        if rep is not None:
            assert rep["seq"] == seq, "sequence number echoed"
            assert rep["type"] == (typ | 0x80) & 0xFF
            if rep["status"] in (0, 3, 5):
                self.last = seq
        return rep

    def tally(self, status, kind=None):
        if status == 0:
            self.e["cmds"] += 1
        else:
            if kind is None:
                assert status in (1, 2, 3, 5)
                kind = "err"
            self.e[kind] += 1
            self.ref += 1

    async def do(self, typ, payload=(), status=0, kind=None, seq=None, ln=None, tel_words=False):
        rep = await self.cmd(typ, payload, seq=seq, ln=ln, tel_words=tel_words)
        assert rep is not None, "no reply"
        assert rep["status"] == status, f"status {rep['status']} expected {status}"
        if status != 0:
            assert rep["payload"] == []
        self.tally(status, kind)
        return rep

    async def drop(self, raw, kind):
        rep = await self.send(raw)
        assert rep is None, "refused packet must get no reply"
        self.tally(1, kind)

    async def regval(self, r, seq=None):
        rep = await self.do(1, rd_pl(r), seq=seq)
        assert len(rep["payload"]) == 4
        return int.from_bytes(bytes(rep["payload"]), "big")

    async def status_check(self):
        rep = await self.cmd(3, [])
        assert rep["status"] == 0
        c, fc, tel = status_fields(rep["payload"])
        e = self.e
        want = [e["cmds"], e["bad"], e["short"], e["long"], e["rep"], e["ooo"], e["err"]]
        assert c == [v & 0xFFFF for v in want], f"status counters {c} expected {want}"
        self.e["cmds"] += 1
        return fc, tel


async def setup(dut):
    cocotb.start_soon(Clock(dut.CLK100MHZ, 10, "ns").start())
    dut.UART_TXD_IN.value = 1
    dut.CPU_RESETN.value = 0
    b = Bench(dut)
    await b.reset()
    return b


# ---------------------------------------------------------------- tests
# req: REQ-01, REQ-02, REQ-04, REQ-06, REQ-08, REQ-09, REQ-10, REQ-11, REQ-22, REQ-52, REQ-53, REQ-55, REQ-56
@cocotb.test()
async def test_reset_values_and_reads(dut):
    b = await setup(dut)
    assert int(dut.LED.value) == 0
    for off in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0x7F):
        assert await b.rdm(off) == 0, off
    exp = [ID_WORD, 0, 0, 0, 4, 0, 100, 0]
    for r in range(8):
        rep = await b.cmd(1, rd_pl(r), seq=0xABCD if r == 0 else None)
        assert rep["status"] == 0 and rep["type"] == 0x81 and len(rep["payload"]) == 4
        assert rep["seq"] == 0xABCD + r
        val = int.from_bytes(bytes(rep["payload"]), "big")
        assert val == exp[r], (r, hex(val))
        b.tally(0)
    assert int(dut.LED.value) == 8
    await b.status_check()


# req: REQ-03, REQ-04, REQ-05, REQ-07, REQ-25, REQ-26, REQ-10
@cocotb.test()
async def test_scratch_and_access_errors(dut):
    b = await setup(dut)
    vals = {1: 0xDEADBEEF, 2: 0x01020304, 3: 0xFFFFFFFF}
    for r in (1, 2, 3):
        assert await b.regval(r) == 0
    for r, v in vals.items():
        rep = await b.do(2, wr_pl(r, v))
        assert rep["payload"] == [] and rep["type"] == 0x82
    for r, v in vals.items():
        assert await b.regval(r) == v
    await b.do(2, wr_pl(1, 0))
    assert await b.regval(1) == 0
    assert await b.regval(2) == vals[2]
    for r in (0, 4, 5, 6, 7):
        await b.do(2, wr_pl(r, 0x1234), status=5)
    for r in (8, 9, 0x100, 0xFFFF):
        await b.do(2, wr_pl(r, 0x77), status=3)
        await b.do(1, rd_pl(r), status=3)
    assert await b.regval(0) == ID_WORD
    assert await b.regval(6) == 100
    assert await b.regval(1) == 0 and await b.regval(3) == vals[3]
    before = b.e["cmds"]
    assert await b.regval(4) == before
    rb = b.ref
    assert await b.regval(5) == rb
    assert await b.regval(5) == rb
    s = b.fresh()
    await b.do(2, wr_pl(0, 1), status=5, seq=s)
    await b.do(1, rd_pl(1), status=4, kind="rep", seq=s)
    s = b.fresh()
    await b.do(1, rd_pl(9), status=3, seq=s)
    await b.do(1, rd_pl(1), status=4, kind="rep", seq=s)
    assert await b.regval(5) == b.ref
    await b.status_check()


# req: REQ-12, REQ-13, REQ-15, REQ-16, REQ-17, REQ-18, REQ-19, REQ-20, REQ-23, REQ-26, REQ-27, REQ-52
@cocotb.test()
async def test_refusal_rules_and_counters(dut):
    b = await setup(dut)
    await b.do(1, rd_pl(1))
    # too long
    await b.drop(mkpkt(1, b.fresh(), [0] * 9), "long")
    await b.drop(mkpkt(1, b.fresh(), rd_pl(1)) + [0, 0], "long")
    await b.drop([1, 200, 0, 1, 0x11, 0x22, 0x33, 0x44], "long")
    # too short
    await b.drop([1, 2, 0], "short")
    await b.drop([0x01], "short")
    await b.drop(mkpkt(1, b.fresh(), [0], ln=2), "short")
    await b.drop(mkpkt(1, b.fresh(), rd_pl(1), bad_crc=True)[:-1], "short")
    # bad check, before unknown type and wrong length
    await b.drop(mkpkt(1, b.fresh(), rd_pl(1), bad_crc=True), "bad")
    await b.drop(mkpkt(9, b.fresh(), [], bad_crc=True), "bad")
    await b.drop(mkpkt(1, b.fresh(), [], bad_crc=True), "bad")
    # unknown type, wrong length: refused before the sequence rule (number not consumed)
    await b.do(9, [], status=1)
    await b.do(0, [], status=1)
    await b.do(1, [], status=2)
    await b.do(2, [0, 1], status=2)
    await b.do(3, [0], status=2)
    await b.do(4, [], status=2)
    await b.do(5, [0, 0], status=2)
    await b.do(1, [0, 1, 2], status=2)
    # sequence refusals
    ok = await b.do(1, rd_pl(2))
    s = b.last
    await b.do(1, rd_pl(1), status=4, kind="rep", seq=s)
    await b.do(1, rd_pl(1), status=4, kind="ooo", seq=(s + 0x8000) & 0xFFFF)
    await b.do(1, rd_pl(1), status=4, kind="ooo", seq=(s - 5) & 0xFFFF)
    await b.do(1, rd_pl(1), seq=(s + 0x7FFF) & 0xFFFF)
    await b.do(9, [], status=1, seq=b.last)
    await b.do(1, [], status=2, seq=b.last)
    await b.do(1, rd_pl(9), status=4, kind="rep", seq=b.last)
    # register / access errors consume the number
    await b.do(1, rd_pl(8), status=3)
    await b.do(1, rd_pl(1), status=4, kind="rep", seq=b.last)
    await b.do(2, wr_pl(0, 5), status=5)
    await b.do(2, wr_pl(4, 5), status=5)
    await b.do(2, wr_pl(0x100, 1), status=3)
    # final counters
    fc, tel = await b.status_check()
    assert fc == 0 and tel == 0
    e = b.e
    assert e["long"] == 3 and e["short"] == 4 and e["bad"] == 3
    assert e["rep"] == 3 and e["ooo"] == 2 and e["err"] == 14
    before = b.ref
    assert await b.regval(5) == before
    c = b.e["cmds"]
    assert await b.regval(4) == c
    assert int(dut.LED.value) == b.e["cmds"] & 0xFFFF
    assert ok["status"] == 0


# req: REQ-21, REQ-22, REQ-23, REQ-24, REQ-25, REQ-27, REQ-32, REQ-42
@cocotb.test()
async def test_sequence_rules(dut):
    b = await setup(dut)
    await b.do(1, rd_pl(1), seq=0x8000)             # first packet: any number
    await b.do(1, rd_pl(1), seq=0x8001)             # +1
    await b.do(1, rd_pl(1), status=4, kind="rep", seq=0x8001)
    await b.do(1, rd_pl(1), status=4, kind="ooo", seq=0x8000)
    await b.do(1, rd_pl(1), seq=0x0000)             # +32767, wraps
    await b.do(1, rd_pl(1), status=4, kind="ooo", seq=0x8000)   # +32768
    await b.do(1, rd_pl(1), status=4, kind="ooo", seq=0xFFFF)
    await b.do(1, rd_pl(1), seq=0x0001)
    await b.do(1, rd_pl(1), status=4, kind="ooo", seq=0x8001)
    await b.do(1, rd_pl(1), seq=0x8000)
    # refused write changes nothing
    await b.do(2, wr_pl(1, 0x11111111), status=4, kind="rep", seq=0x8000)
    assert await b.regval(1) == 0
    await b.do(2, wr_pl(1, 0x22222222))
    await b.do(2, wr_pl(1, 0x33333333), status=4, kind="ooo", seq=(b.last - 1) & 0xFFFF)
    assert await b.regval(1) == 0x22222222
    # refused packets leave the last accepted number: the next fresh number still works
    await b.do(1, rd_pl(1))
    # telemetry state untouched by refused start / stop
    await b.do(4, [0, 5])
    await b.do(5, [], status=4, kind="rep", seq=b.last)
    assert (await b.rd(9)) & 1 == 1
    await b.do(4, [0, 9], status=4, kind="rep", seq=b.last)
    assert await b.regval(6) == 5
    await b.tick(5)
    assert await b.rd(5) == 17
    await b.do(5, [], status=4, kind="rep", seq=b.last)
    assert await b.rd(5) == 17
    assert (await b.rd(9)) & 1 == 1
    # number consumed although the access check fails
    s = b.fresh()
    await b.do(2, wr_pl(0, 1), status=5, seq=s)
    await b.do(2, wr_pl(1, 1), status=4, kind="rep", seq=s)
    await b.do(5)                                   # fresh stop still accepted
    assert (await b.rd(9)) & 1 == 0
    await b.status_check()


# req: REQ-12, REQ-32, REQ-34, REQ-35, REQ-36, REQ-37, REQ-38, REQ-39, REQ-41, REQ-42, REQ-43, REQ-44, REQ-50
@cocotb.test()
async def test_telemetry_frames(dut):
    b = await setup(dut)
    assert await b.rd(5) == 0
    rep = await b.do(4, [0, 6])
    assert rep["payload"] == []
    assert (await b.rd(9)) & 1 == 1
    await b.tick(5)
    assert await b.rd(5) == 0
    await b.tick(1)
    assert await b.rd(5) == 17
    fr = await b.read_frame()
    check_frame(fr, 0, 6, b.m.cmds, b.m.refused)
    fc, tel = await b.status_check()
    assert fc == 1 and tel == 1
    await b.tick(12)                                # two frames fall due: dropped
    assert await b.read_frame() == fr
    fc, tel = await b.status_check()
    assert fc == 1
    await b.wrm(8, 0)                               # take
    assert await b.rd(5) == 0
    await b.drop(mkpkt(1, b.fresh(), rd_pl(1), bad_crc=True), "bad")
    await b.tick(6)
    fr2 = await b.read_frame()
    check_frame(fr2, 1, b.ticks, b.m.cmds, b.m.refused)
    assert b.ticks == 24
    await b.do(5)                                   # stop discards
    assert await b.rd(5) == 0
    assert (await b.rd(9)) & 1 == 0
    await b.tick(20)
    assert await b.rd(5) == 0
    fc, tel = await b.status_check()
    assert fc == 2 and tel == 0
    await b.do(4, [0, 0])
    assert await b.regval(6) == 6
    await b.tick(6)
    fr3 = await b.read_frame()
    check_frame(fr3, 2, b.ticks, b.m.cmds, b.m.refused)
    await b.wrm(8, 0)
    await b.wrm(8, 0)
    assert await b.rd(5) == 0
    fc, tel = await b.status_check()
    assert fc == 3 and tel == 1


# req: REQ-30, REQ-31, REQ-32, REQ-33, REQ-34, REQ-50
@cocotb.test()
async def test_telemetry_period_rules(dut):
    b = await setup(dut)
    await b.do(4, [0, 0])
    assert await b.regval(6) == 100
    await b.tick(99)
    assert await b.rd(5) == 0
    await b.tick(1)
    assert await b.rd(5) == 17
    check_frame(await b.read_frame(), 0, 100, b.m.cmds, b.m.refused)
    await b.do(5)
    for per, eff in ((1, 4), (2, 4), (3, 4), (4, 4), (5, 5)):
        await b.do(4, [0, per])
        assert await b.regval(6) == eff
        await b.tick(eff - 1)
        assert await b.rd(5) == 0, (per,)
        await b.tick(1)
        assert await b.rd(5) == 17, (per,)
        await b.wrm(8, 0)
    await b.do(4, [0x01, 0x02])
    assert await b.regval(6) == 258
    # restart of the period count, zero keeps the period
    await b.do(4, [0, 6])
    await b.tick(4)
    await b.do(4, [0, 0])
    assert await b.regval(6) == 6
    await b.tick(4)
    assert await b.rd(5) == 0
    await b.tick(2)
    assert await b.rd(5) == 17
    await b.status_check()


# req: REQ-08, REQ-45
@cocotb.test()
async def test_tick_register(dut):
    b = await setup(dut)
    assert await b.regval(7) == 0
    for n in (0, 1, 2, 255, 17, 0, 100):
        await b.tick(n)
        assert await b.regval(7) == b.ticks, n
    await b.do(4, [0, 4])
    await b.tick(255)
    assert await b.regval(7) == b.ticks
    await b.read_frame()
    await b.status_check()


# req: REQ-22, REQ-40, REQ-41, REQ-52, REQ-53
@cocotb.test()
async def test_reset_clears_state(dut):
    b = await setup(dut)
    await b.do(2, wr_pl(1, 0x1234))
    await b.do(2, wr_pl(2, 0x5678))
    await b.do(1, rd_pl(0))
    await b.drop(mkpkt(1, b.fresh(), rd_pl(1), bad_crc=True), "bad")
    await b.do(4, [0, 9])
    await b.tick(9)
    assert await b.rd(5) == 17
    await b.wrm(3, 2)
    await b.wrm(6, 3)
    await b.tick(3)
    assert int(dut.LED.value) != 0
    old = b.last
    await b.reset()
    assert int(dut.LED.value) == 0
    for off in (2, 3, 4, 5, 6, 7, 9):
        assert await b.rdm(off) == 0, off
    assert await b.regval(4, seq=old) == 0          # first packet accepts any number
    assert await b.regval(1) == 0 and await b.regval(2) == 0
    assert await b.regval(5) == 0
    assert await b.regval(6) == 100
    assert await b.regval(7) == 0
    await b.do(4, [0, 0])
    await b.tick(100)
    check_frame(await b.read_frame(), 0, 100, b.m.cmds, b.m.refused)
    fc, tel = await b.status_check()
    assert fc == 1 and tel == 1
    assert old is not None
    # reset in the middle of a packet
    await b.wr(0, 1)
    await b.wr(0, 2)
    await b.reset()
    rep = await b.do(1, rd_pl(0))
    assert int.from_bytes(bytes(rep["payload"]), "big") == ID_WORD
    await b.status_check()


# req: REQ-46, REQ-47, REQ-48, REQ-49, REQ-50, REQ-51, REQ-10, REQ-11
@cocotb.test()
async def test_register_window(dut):
    b = await setup(dut)
    # unmapped: reads 0, writes ignored
    for off in (10, 11, 12, 0x20, 0x7F, 0, 1, 8):
        assert await b.rdm(off) == 0, off
    for off in (2, 4, 5, 7, 9, 10, 0x7F):
        await b.wrm(off, 0xFFFFFFFF)
    for off in (2, 4, 5, 7, 9, 10, 0x7F):
        assert await b.rdm(off) == 0, off
    # index registers
    for v, exp in ((0x7F, 0x7F), (0xFF, 0x7F), (0x85, 5), (0, 0)):
        await b.wrm(3, v)
        assert await b.rdm(3) == exp
        await b.wrm(6, v)
        assert await b.rdm(6) == exp
    # reply words (independent expectation)
    seq = 0x1357
    rep = await b.cmd(1, rd_pl(0), seq=seq)
    b.tally(0)
    body = [0x81, 0, 0x13, 0x57, 4, 0x55, 0x44, 0x50, 0x31]
    exp = body + crc_le(body)
    assert rep["raw"] == exp
    assert await b.rd(2) == 13
    for i in range(6):
        await b.wrm(3, i)
        w = 0
        for k in range(4):
            j = 4 * i + k
            w = (w << 8) | (exp[j] if j < 13 else 0)
        assert await b.rdm(4) == w, i
    await b.wrm(3, 0x7F)
    assert await b.rdm(4) == 0
    assert await b.rd(3) == 0x7F
    assert (await b.rd(9)) & 2 == 0
    # no reply -> length 0, words 0
    await b.drop(mkpkt(1, b.fresh(), rd_pl(1), bad_crc=True), "bad")
    assert await b.rdm(2) == 0
    await b.wrm(3, 0)
    assert await b.rdm(4) == 0
    assert await b.rdm(5) == 0
    await b.wrm(6, 0)
    assert await b.rdm(7) == 0
    # telemetry frame words
    await b.do(4, [0, 4])
    assert (await b.rd(9)) & 3 == 1
    await b.tick(4)
    assert await b.rd(5) == 17
    exp = [0xC0, 0, 0, 0, 8, 0, 0, 0, 4, 0, 2, 0, 1]
    exp = exp + crc_le(exp)
    for i in range(6):
        await b.wrm(6, i)
        w = 0
        for k in range(4):
            j = 4 * i + k
            w = (w << 8) | (exp[j] if j < 17 else 0)
        assert await b.rdm(7) == w, i
    await b.wrm(8, 0)
    assert await b.rd(5) == 0
    await b.wrm(6, 0)
    assert await b.rdm(7) == 0
    await b.status_check()
    await b.check_state(tel_words=True)


# req: REQ-28, REQ-29, REQ-09
@cocotb.test()
async def test_back_to_back_packets(dut):
    b = await setup(dut)
    seq = 0x0200
    plan = [(1, rd_pl(0)), (2, wr_pl(2, 0xA5A5A5A5)), (1, rd_pl(2)), (3, []), (4, [0, 7]), (5, [])]
    for typ, pl in plan:
        await b.feed(mkpkt(typ, seq, pl))
        b.last = seq
        b.tally(0)
        seq += 1
        await b.feed(mkpkt(1, seq, rd_pl(1), bad_crc=True))
        b.tally(1, "bad")
        # the next packet is accepted immediately after the dropped one
    rep = await b.do(1, rd_pl(2))
    assert int.from_bytes(bytes(rep["payload"]), "big") == 0xA5A5A5A5
    await b.status_check()


# req: REQ-54, REQ-55, REQ-56
@cocotb.test()
async def test_shell_roundtrip(dut):
    b = await setup(dut)
    await b._tx(0x00)                               # junk before sync is discarded
    await b._tx(0x37)
    r = await b.xfer_raw([0xA5, 0x02, 0x03, 0x78, 0x56, 0x34, 0x12, 0x09])
    assert r == [0x5A, 0x00, 0x78, 0x56, 0x34, 0x12, 0x08], r
    r = await b.xfer_raw(shell_req(1, 3))
    assert r == shell_resp(0, 0x12345678), r
    r = await b.xfer_raw(shell_req(1, 1))
    assert r == shell_resp(0, 0x00010001), r
    r = await b.xfer_raw([0xA5, 0x01, 0x00, 0, 0, 0, 0, 0xFF])
    assert r == [0x5A, 0x01, 0, 0, 0, 0, 0x01], r
    r = await b.xfer_raw(shell_req(2, 0, 0))
    assert r == shell_resp(4, 0), r
    r = await b.xfer_raw(shell_req(1, 6))
    assert r == shell_resp(3, 0), r
    r = await b.xfer_raw(shell_req(3, 3))
    assert r == shell_resp(2, 0), r
    r = await b.xfer_raw(shell_req(1, 4))
    assert r == shell_resp(0, 0x00000301), r
    # a whole packet carried in through the window, reply read back
    rep = await b.do(1, rd_pl(0))
    assert int.from_bytes(bytes(rep["payload"]), "big") == ID_WORD
    await b.status_check()


# req: REQ-14, REQ-19
@cocotb.test()
async def test_counter_wrap(dut):
    # The full 65536+ refusals need ~40M clocks; run it with FDA_FULL_WRAP=1.
    b = await setup(dut)
    full = os.environ.get("FDA_FULL_WRAP") == "1"
    n = 65536 + 3 if full else 20
    for _ in range(n):
        await b.wr(0, 0x1FF)                        # one-byte packet: too short
        b.m.write_reg(0, 0x1FF)
    b.e["short"] += n
    b.ref += n
    await b.status_check()
    assert b.e["short"] & 0xFFFF == (3 if full else 20)
    assert await b.regval(5) == b.ref
    await b.get_reply()


# req: REQ-01, REQ-09, REQ-15, REQ-16, REQ-17, REQ-18, REQ-19, REQ-20, REQ-21, REQ-23, REQ-24, REQ-27, REQ-28, REQ-34, REQ-35, REQ-36, REQ-44, REQ-45
@cocotb.test()
async def test_random_traffic(dut):
    b = await setup(dut)
    rng = random.Random(seed_of() * 7919 + 1)
    kinds = [("read", 6), ("write", 6), ("status", 2), ("tstart", 3), ("tstop", 2), ("badcrc", 2),
             ("trunc", 2), ("extra", 1), ("longlen", 1), ("badtype", 1), ("badlen", 1),
             ("tick", 5), ("take", 1), ("badseq", 3)]
    names = [k for k, _ in kinds]
    weights = [w for _, w in kinds]

    def reg():
        return rng.choice([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0xFFFF])

    def val():
        return rng.choice([0, 1, 0xFFFFFFFF, rng.getrandbits(32)])

    def seq():
        return None if rng.random() < 0.8 else (b.fresh() + rng.randint(0, 3000)) & 0xFFFF

    for it in range(40):
        kind = rng.choices(names, weights)[0]
        if kind == "read":
            await b.cmd(1, rd_pl(reg()), seq=seq())
        elif kind == "write":
            await b.cmd(2, wr_pl(reg(), val()), seq=seq())
        elif kind == "status":
            await b.cmd(3, [], seq=seq())
        elif kind == "tstart":
            per = rng.choice([0, 1, 3, 4, 5, 6, 9])
            await b.cmd(4, [per >> 8, per & 255], seq=seq())
        elif kind == "tstop":
            await b.cmd(5, [], seq=seq())
        elif kind == "badcrc":
            pl = [rng.getrandbits(8) for _ in range(rng.randint(0, 8))]
            await b.send(mkpkt(rng.randint(0, 6), b.fresh(), pl, bad_crc=True))
        elif kind == "trunc":
            raw = mkpkt(1, b.fresh(), rd_pl(1))
            await b.send(raw[:rng.randint(1, len(raw) - 1)])
        elif kind == "extra":
            raw = mkpkt(1, b.fresh(), rd_pl(1)) + [rng.getrandbits(8) for _ in range(rng.randint(1, 3))]
            await b.send(raw)
        elif kind == "longlen":
            await b.send(mkpkt(1, b.fresh(), [0] * rng.randint(9, 12)))
        elif kind == "badtype":
            await b.cmd(rng.choice([0, 6, 7, 0x80, 0xC0, 0xFF]), [], seq=seq())
        elif kind == "badlen":
            pl = [rng.getrandbits(8) for _ in range(rng.choice([0, 1, 3, 5, 7, 8]))]
            await b.cmd(rng.choice([1, 2, 3, 4, 5]), pl, seq=seq())
        elif kind == "badseq":
            if b.last is None:
                await b.cmd(1, rd_pl(1))
            else:
                s = rng.choice([b.last, (b.last - rng.randint(1, 100)) & 0xFFFF,
                                (b.last + rng.randint(0x8000, 0xFFFF)) & 0xFFFF])
                await b.cmd(rng.choice([1, 3]), rd_pl(rng.randint(0, 9)) if rng.random() < 0.5 else [], seq=s)
        elif kind == "tick":
            await b.tick(rng.choice([0, 1, 2, 3, 5, 8, 13, 30]))
            await b.check_state(tel_words=True)
        elif kind == "take":
            await b.wrm(8, 0)
            await b.check_state(tel_words=True)
        if it % 10 == 9:
            await b.check_state(tel_words=True)
    await b.check_state(tel_words=True)
