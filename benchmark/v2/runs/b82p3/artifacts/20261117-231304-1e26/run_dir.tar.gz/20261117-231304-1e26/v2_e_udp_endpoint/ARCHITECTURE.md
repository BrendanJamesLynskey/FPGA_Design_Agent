# Architecture: v2_e_udp_endpoint

UDP-style command and telemetry endpoint on the Nexys A7-100T. The host talks over the USB-UART through the test shell; packet bytes go in through the IN register, replies and telemetry frames are read back as words.

## Block diagram

```text
 UART_TXD_IN --> [fpga_shell] --win bus--> [regwin] --byte--> [pkt_rx + CRC32]
 UART_RXD_OUT <-- [fpga_shell] <-rdata---- [regwin]               |
                                              ^                    v
                     [reply buffer] <-- [reply_builder] <-- [regfile R0..R7, counters]
                     [telemetry frame] <-- [telemetry: ticks, period, 1 held frame]
 CPU_RESETN --> [reset_sync] --> rst (active high) to all blocks
 regfile commands-carried-out count --> LED[15:0]
```

## Clock plan

One clock domain: CLK100MHZ, 100 MHz (10 ns), no MMCM. CPU_RESETN is asynchronous and enters through a reset synchroniser (async assert, sync release), inverted once to an active-high reset. All other resets are synchronous and applied only to control registers. No clock-domain crossings other than that reset.

## Resource prediction

LUT 800 to 3500, FF 800 to 3500, BRAM 0 to 1, DSP 0. Reply and frame buffers are small (at most 27 bytes), held in registers or distributed RAM.

## Pin list

| Port | Dir | Pin | Note |
|---|---|---|---|
| CLK100MHZ | in | E3 | 100 MHz clock |
| CPU_RESETN | in | C12 | active-low reset |
| UART_TXD_IN | in | C4 | host to FPGA serial |
| UART_RXD_OUT | out | D4 | FPGA to host serial |
| LED[15:0] | out | board LEDs | low 16 bits of commands carried out |
